const fs = require("fs");
const path = require("path");
const { chromium } = require("playwright");
const TARGET_RULE_IDS = ["custom-wcag22-sc-1410-reflow"];

const ROOT_DIR = path.resolve(__dirname, "..");
const TEST_PAGE_PATH = path.join(
  ROOT_DIR,
  "tests",
  "sc-1410",
  "test-cases-sc-1410.html"
);
const AXE_PATH = path.join(ROOT_DIR, "lib", "axe-core", "axe.min.js");
const REGISTRY_PATH = path.join(ROOT_DIR, "custom_rules", "registry.js");

function toFileUrl(filePath) {
  const resolved = path.resolve(filePath);
  return "file:///" + resolved.replace(/\\/g, "/");
}

function readFile(filePath) {
  return fs.readFileSync(filePath, "utf8");
}

function nodeMatchesElement(node, elementId) {
  const selectorTarget = `#${elementId}`;
  const hasTargetMatch = (target) => {
    if (typeof target === "string") {
      return target === selectorTarget || target.endsWith(selectorTarget);
    }
    if (Array.isArray(target)) {
      return target.some(hasTargetMatch);
    }
    return false;
  };

  if (Array.isArray(node.target) && node.target.some(hasTargetMatch)) {
    return true;
  }

  if (node.html && node.html.includes(`id="${elementId}"`)) {
    return true;
  }

  return false;
}

async function main() {
  if (!fs.existsSync(TEST_PAGE_PATH)) {
    throw new Error(`Test page not found: ${TEST_PAGE_PATH}`);
  }

  const headed = process.argv.includes("--headed");
  const browser = await chromium.launch({ headless: !headed });
  const page = await browser.newPage();

  try {
    await page.goto(toFileUrl(TEST_PAGE_PATH), { waitUntil: "load" });

    await page.addScriptTag({ path: AXE_PATH });
    await page.evaluate((ruleIds) => {
      window.__AXE_TARGET_RULE_IDS__ = ruleIds;
    }, TARGET_RULE_IDS);

    await page.evaluate(() => {
      window.__AXE_CUSTOM_RULES_REGISTRY_PROMISE__ = new Promise((resolve) => {
        window.addEventListener(
          "AXE_CUSTOM_RULES_REGISTRY_READY",
          (e) => resolve(e.detail || []),
          { once: true }
        );
      });
    });

    await page.addScriptTag({ path: REGISTRY_PATH });
    const ruleFiles = await page.evaluate(() => window.__AXE_CUSTOM_RULES_REGISTRY_PROMISE__);

    for (const ruleFile of ruleFiles) {
      await page.addScriptTag({ path: path.join(ROOT_DIR, ruleFile) });
    }

    const results = await page.evaluate(async () => {
      if (!window.axe) {
        return { error: "axe-core not found on page" };
      }
      try {
        return await window.axe.run(document, {
          runOnly: { type: "rule", values: window.__AXE_TARGET_RULE_IDS__ || [] }
        });
      } catch (err) {
        return { error: String(err) };
      }
    });

    if (results && results.error) {
      throw new Error(results.error);
    }

    const testCases = await page.evaluate(function () {
      const re = /^TC-\d{3}-(PASS|FAIL)$/;
      const candidates = Array.from(document.querySelectorAll("[id]")).filter(
        (el) => re.test(el.id)
      );

      return {
        testCases: candidates.map((el) => {
          const parts = el.id.split("-");
          return {
            testCaseId: `${parts[0]}-${parts[1]}`,
            elementId: el.id,
            expected: el.getAttribute("data-expected")
          };
        }),
        counts: {
          withId: document.querySelectorAll("[id]").length,
          withDataExpected: document.querySelectorAll("[data-expected]").length,
          tcIdMatches: candidates.length
        },
        sampleIds: candidates.slice(0, 5).map((el) => el.id),
        sampleExpected: candidates
          .slice(0, 5)
          .map((el) => el.getAttribute("data-expected"))
      };
    });

    if (!testCases.testCases.length) {
      const pageInfo = await page.evaluate(function () {
        return {
          title: document.title,
          url: window.location.href,
          bodyTextPreview: (document.body && document.body.innerText || "")
            .slice(0, 200)
        };
      });
      console.error("No test cases found on page.");
      console.error("counts:", testCases.counts);
      console.error("sample ids:", testCases.sampleIds);
      console.error("sample data-expected:", testCases.sampleExpected);
      console.error("page title:", pageInfo.title);
      console.error("page url:", pageInfo.url);
      console.error("page body preview:", pageInfo.bodyTextPreview);
      process.exit(1);
    }

    const testCasesList = testCases.testCases;

    console.log("TARGET_RULE_IDS:", TARGET_RULE_IDS.join(", "));

    const discrepancies = [];
    const rows = [];

    for (const ruleId of TARGET_RULE_IDS) {
      const filteredViolations = results.violations.filter(
        (r) => r.id === ruleId
      );

      for (const testCase of testCasesList) {
        const elementId = testCase.elementId;

        const hasViolation = filteredViolations.some((result) =>
          result.nodes.some((node) => nodeMatchesElement(node, elementId))
        );

        let observed = "none";
        if (hasViolation) observed = "violation";

        let status = "OK";
        if (testCase.expected === "fail" && !hasViolation) {
          status = "DISCREPANCY";
          discrepancies.push(
            `${testCase.testCaseId} expected fail for ${ruleId} but observed ${observed}`
          );
        }
        if (testCase.expected === "pass" && hasViolation) {
          status = "DISCREPANCY";
          discrepancies.push(
            `${testCase.testCaseId} expected pass for ${ruleId} but observed ${observed}`
          );
        }

        rows.push({
          testCaseId: testCase.testCaseId,
          elementId: testCase.elementId,
          expected: testCase.expected,
          ruleId,
          observed,
          status
        });
      }
    }

    console.log(
      "Test Case ID | elementId | data-expected | Rule ID | observed (violation/none) | status (OK/DISCREPANCY)"
    );
    for (const row of rows) {
      console.log(
        `${row.testCaseId} | ${row.elementId} | ${row.expected} | ${row.ruleId} | ${row.observed} | ${row.status}`
      );
    }

    console.log("total test cases checked:", rows.length);
    console.log("total discrepancies:", discrepancies.length);
    if (discrepancies.length) {
      console.log("failing Test Case IDs with reason:");
      for (const message of discrepancies) {
        console.log(`- ${message}`);
      }
      process.exit(1);
    }

    process.exit(0);
  } finally {
    await browser.close();
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
