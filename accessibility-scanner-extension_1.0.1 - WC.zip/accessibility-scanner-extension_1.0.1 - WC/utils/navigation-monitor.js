export class NavigationMonitor {
  start() {}
  stop() {}
}
