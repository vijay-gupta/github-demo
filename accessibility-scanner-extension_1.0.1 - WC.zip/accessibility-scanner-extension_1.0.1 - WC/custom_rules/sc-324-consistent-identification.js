/**
 * SC 3.2.4 Consistent Identification
 * Automatable subset: Elements that point to the same destination (same href)
 * or share an explicit data-consistent-id must use the same accessible name.
 * Limitations:
 * - Does not evaluate consistency across multiple pages.
 * - Cannot infer identical functionality without shared href or data-consistent-id.
 * Version: 1.0
 * Author: Vijay Gupta  
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-324-consistent-identification";
  const CHECK_ID = "sc-324-consistent-identification";
  const SELECTOR = 'a[href], [data-consistent-id]';

  function normalizeText(text) {
    if (!text) return "";
    return text.replace(/\s+/g, " ").trim().toLowerCase();
  }

  function getLabelledbyText(node) {
    const raw = (node.getAttribute("aria-labelledby") || "").trim();
    if (!raw) return "";
    const ids = raw.split(/\s+/).filter(Boolean);
    const parts = [];
    for (const id of ids) {
      const el = document.getElementById(id);
      if (!el) continue;
      const text = (el.textContent || "").trim();
      if (text) parts.push(text);
    }
    return parts.join(" ").trim();
  }

  function getAltText(node) {
    const imgs = Array.from(node.querySelectorAll("img[alt]"));
    const parts = imgs
      .map((img) => (img.getAttribute("alt") || "").trim())
      .filter(Boolean);
    return parts.join(" ").trim();
  }

  function getAccessibleName(node) {
    const ariaLabel = (node.getAttribute("aria-label") || "").trim();
    if (ariaLabel) return normalizeText(ariaLabel);

    const labelledby = getLabelledbyText(node);
    if (labelledby) return normalizeText(labelledby);

    if (node.tagName && node.tagName.toLowerCase() === "input") {
      const type = (node.getAttribute("type") || "").toLowerCase();
      if (type === "submit" || type === "button" || type === "reset") {
        const value = (node.getAttribute("value") || "").trim();
        if (value) return normalizeText(value);
      }
    }

    const textContent = (node.textContent || "").trim();
    if (textContent) return normalizeText(textContent);

    const altText = getAltText(node);
    if (altText) return normalizeText(altText);

    return "";
  }

  function getConsistencyKey(node) {
    const dataId = (node.getAttribute("data-consistent-id") || "").trim();
    if (dataId) return `data:${dataId}`;

    if (node.tagName && node.tagName.toLowerCase() === "a") {
      const href = (node.getAttribute("href") || "").trim();
      if (!href) return null;
      if (/^\s*javascript:/i.test(href)) return null;
      return `href:${href}`;
    }

    return null;
  }

  function buildGroups() {
    const groups = new Map();
    const nodes = Array.from(document.querySelectorAll(SELECTOR));
    for (const node of nodes) {
      const key = getConsistencyKey(node);
      if (!key) continue;
      const name = getAccessibleName(node);
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push({ node, name });
    }
    return groups;
  }

  function getConsistencyInfo(node) {
    const key = getConsistencyKey(node);
    if (!key) return { pass: true };
    const groups = buildGroups();
    const group = groups.get(key) || [];
    if (group.length < 2) return { pass: true };

    const names = group.map((item) => item.name).filter(Boolean);
    if (names.length < 2) return { pass: true };

    const first = names[0];
    const distinct = Array.from(new Set(names));
    if (distinct.length <= 1) return { pass: true };

    return {
      pass: false,
      data: {
        reason: "Elements sharing the same destination/id have inconsistent names.",
        key,
        currentName: getAccessibleName(node),
        groupSize: group.length,
        distinctNames: distinct
      }
    };
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector: SELECTOR,
        impact: "moderate",
        tags: ["wcag2aa", "wcag22aa", "wcag324", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Components that point to the same destination must be identified consistently",
          help:
            "Ensure repeated links or explicitly grouped controls use the same accessible name",
          helpUrl:
            "https://www.w3.org/TR/WCAG22/#consistent-identification",
          messages: {
            pass: "3.2.4 - Consistent Identification - Pass",
            fail: "3.2.4 - Consistent Identification - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          const info = getConsistencyInfo(node);
          if (info.pass) return true;
          this.data = info.data;
          return false;
        },
        metadata: {
          impact: "moderate",
          messages: {
            pass:
              "3.2.4 - Consistent Identification - shared targets have consistent names - Pass",
            fail:
              "3.2.4 - Consistent Identification - shared targets have inconsistent names - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-324-consistent-identification loaded");
})();
