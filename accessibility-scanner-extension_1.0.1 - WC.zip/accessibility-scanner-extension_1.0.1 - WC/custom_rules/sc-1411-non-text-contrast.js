/**
 * SC 1.4.11 Non-text Contrast
 * Automatable subset: Visible UI components (native form controls + common ARIA roles)
 * with a discernible solid border or solid background must have >= 3:1 contrast
 * against the computed parent background.
 * Limitations:
 * - Does not evaluate complex graphics, icons, or background images.
 * - Does not detect contrast between component states (hover/active/focus).
 * - Uses computed styles only and cannot infer adjacent colors in complex layouts.
 * Version: 1.0
 * Author: Vijay Gupta  
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-1411-non-text-contrast";
  const CHECK_ID = "sc-1411-non-text-contrast-min-3";
  const MIN_CONTRAST = 3;

  const CONTROL_SELECTOR = [
    "button",
    "input",
    "select",
    "textarea",
    "[role=\"button\"]",
    "[role=\"checkbox\"]",
    "[role=\"radio\"]",
    "[role=\"switch\"]",
    "[role=\"combobox\"]",
    "[role=\"listbox\"]",
    "[role=\"slider\"]",
    "[role=\"spinbutton\"]",
    "[role=\"textbox\"]"
  ].join(", ");

  function parseColor(value) {
    if (!value) return null;
    if (value === "transparent") {
      return { r: 0, g: 0, b: 0, a: 0 };
    }

    const match = value.match(/rgba?\(([^)]+)\)/);
    if (!match) return null;

    const parts = match[1].split(",").map((part) => part.trim());
    if (parts.length < 3) return null;

    const r = parseFloat(parts[0]);
    const g = parseFloat(parts[1]);
    const b = parseFloat(parts[2]);
    const a = parts.length >= 4 ? parseFloat(parts[3]) : 1;

    if (![r, g, b, a].every((n) => Number.isFinite(n))) return null;

    return { r, g, b, a };
  }

  function blendColors(foreground, background) {
    const alpha = foreground.a;
    return {
      r: foreground.r * alpha + background.r * (1 - alpha),
      g: foreground.g * alpha + background.g * (1 - alpha),
      b: foreground.b * alpha + background.b * (1 - alpha),
      a: 1
    };
  }

  function srgbToLinear(channel) {
    const value = channel / 255;
    return value <= 0.03928
      ? value / 12.92
      : Math.pow((value + 0.055) / 1.055, 2.4);
  }

  function relativeLuminance(color) {
    return (
      0.2126 * srgbToLinear(color.r) +
      0.7152 * srgbToLinear(color.g) +
      0.0722 * srgbToLinear(color.b)
    );
  }

  function contrastRatio(colorA, colorB) {
    if (!colorA || !colorB) return null;
    const lumA = relativeLuminance(colorA);
    const lumB = relativeLuminance(colorB);
    const light = Math.max(lumA, lumB);
    const dark = Math.min(lumA, lumB);
    return (light + 0.05) / (dark + 0.05);
  }

  function toRgbaString(color) {
    if (!color) return "";
    const r = Math.round(color.r);
    const g = Math.round(color.g);
    const b = Math.round(color.b);
    const a = Number.isFinite(color.a) ? color.a : 1;
    return `rgba(${r}, ${g}, ${b}, ${a})`;
  }

  function isVisible(style) {
    if (!style) return false;
    if (style.display === "none") return false;
    if (style.visibility === "hidden") return false;
    if (parseFloat(style.opacity) === 0) return false;
    return true;
  }

  function getEffectiveBackground(element) {
    const layers = [];
    let current = element;

    while (current && current.nodeType === 1) {
      const style = window.getComputedStyle(current);
      const color = parseColor(style.backgroundColor);
      if (color && color.a > 0) {
        layers.push(color);
      }
      current = current.parentElement;
    }

    layers.reverse();

    let result = { r: 255, g: 255, b: 255, a: 1 };
    for (const layer of layers) {
      result = blendColors(layer, result);
    }

    return result;
  }

  function hasBorder(style) {
    const widths = [
      style.borderTopWidth,
      style.borderRightWidth,
      style.borderBottomWidth,
      style.borderLeftWidth
    ];

    return widths.some((value) => parseFloat(value) > 0);
  }

  function getBorderColor(style) {
    if (!hasBorder(style)) return null;
    const color = parseColor(style.borderTopColor);
    if (!color || color.a === 0) return null;
    return color;
  }

  function getBackgroundColor(style) {
    const color = parseColor(style.backgroundColor);
    if (!color || color.a === 0) return null;
    return color;
  }

  function getAbsoluteXPath(el) {
    if (!el || el.nodeType !== 1) return "";
    const segments = [];
    let current = el;
    while (current && current.nodeType === 1) {
      const tag = current.nodeName.toLowerCase();
      let index = 1;
      let sibling = current.previousElementSibling;
      while (sibling) {
        if (sibling.nodeName.toLowerCase() === tag) index += 1;
        sibling = sibling.previousElementSibling;
      }
      segments.unshift(`${tag}[${index}]`);
      current = current.parentElement;
    }
    return "/" + segments.join("/");
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector: CONTROL_SELECTOR,
        impact: "serious",
        tags: ["wcag2aa", "wcag22aa", "wcag1411", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "UI components must have at least 3:1 contrast against adjacent colors",
          help:
            "Ensure form controls and common ARIA widgets have 3:1 contrast for their boundary or fill",
          helpUrl: "https://www.w3.org/TR/WCAG22/#non-text-contrast",
          messages: {
            pass: "1.4.11 - Non-text Contrast - Pass",
            fail: "1.4.11 - Non-text Contrast - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          try {
            console.log("[SC-1411] evaluate start", node);
          } catch (_) {}
          try {
            console.log("[SC-1411] element xpath", getAbsoluteXPath(node));
            console.log("[SC-1411] parent xpath", getAbsoluteXPath(node?.parentElement));
          } catch (_) {}
          const style = window.getComputedStyle(node);

          if (!isVisible(style)) {
            try {
              console.log("[SC-1411] skip: not visible");
            } catch (_) {}
            return true;
          }
          if (node.tagName === "INPUT" && node.type === "hidden") {
            try {
              console.log("[SC-1411] skip: input type=hidden");
            } catch (_) {}
            return true;
          }

          const parentBackground = getEffectiveBackground(node.parentElement);
          try {
            console.log("[SC-1411] parent background", toRgbaString(parentBackground));
          } catch (_) {}

          const borderColor = getBorderColor(style);
          let componentColor = null;
          let source = "";

          if (borderColor) {
            componentColor = blendColors(borderColor, parentBackground);
            source = "border";
            try {
              console.log("[SC-1411] using border", {
                borderColor: toRgbaString(borderColor),
                blended: toRgbaString(componentColor)
              });
            } catch (_) {}
          } else {
            if (style.backgroundImage && style.backgroundImage !== "none") {
              try {
                console.log("[SC-1411] skip: background image present");
              } catch (_) {}
              return true;
            }

            const backgroundColor = getBackgroundColor(style);
            if (!backgroundColor) {
              try {
                console.log("[SC-1411] skip: no background color");
              } catch (_) {}
              return true;
            }

            componentColor = blendColors(backgroundColor, parentBackground);
            source = "background";
            try {
              console.log("[SC-1411] using background", {
                backgroundColor: toRgbaString(backgroundColor),
                blended: toRgbaString(componentColor)
              });
            } catch (_) {}
          }

          const ratio = contrastRatio(componentColor, parentBackground);
          if (ratio === null) {
            try {
              console.log("[SC-1411] skip: ratio null");
            } catch (_) {}
            return true;
          }

          if (ratio >= MIN_CONTRAST) {
            try {
              console.log("[SC-1411] pass", { ratio, min: MIN_CONTRAST });
            } catch (_) {}
            return true;
          }

          this.data = {
            reason: `Contrast ratio ${ratio.toFixed(2)} is below ${MIN_CONTRAST}:1 using ${source} color.`,
            ratio,
            minContrast: MIN_CONTRAST,
            source,
            componentColor: toRgbaString(componentColor),
            parentBackground: toRgbaString(parentBackground),
            style: {
              borderTopWidth: style.borderTopWidth,
              borderTopColor: style.borderTopColor,
              backgroundColor: style.backgroundColor
            }
          };
          try {
            console.log("[SC-1411] fail", this.data);
          } catch (_) {}
          return false;
        },
        metadata: {
          impact: "serious",
          messages: {
            pass:
              "1.4.11 - Non-text Contrast - component boundary contrast >= 3:1 - Pass",
            fail:
              "1.4.11 - Non-text Contrast - component boundary contrast < 3:1 - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-1411-non-text-contrast loaded");
})();
