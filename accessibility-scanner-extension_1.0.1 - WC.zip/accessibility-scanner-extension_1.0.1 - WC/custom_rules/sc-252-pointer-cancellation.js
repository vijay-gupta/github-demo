/**
 * SC 2.5.2 Pointer Cancellation
 * Automatable subset: Inline pointer-down handlers that appear to trigger
 * activation (submit/click/navigation/window.open) are flagged. If activation
 * intent appears on down (including matching activation on up/cancel), fail.
 * Limitations:
 * - Does not detect handlers added via addEventListener or external scripts.
 * - Cannot determine whether an action is essential.
 * - Cannot verify undo/abort mechanisms provided elsewhere.
 * - Activation intent detection is limited to simple inline patterns.
 * Version: 1.0
 * Author: Vijay Gupta  
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-252-pointer-cancellation";
  const CHECK_ID = "sc-252-pointerdown-has-cancel-up";

  const DOWN_ATTRS = ["onpointerdown", "onmousedown", "ontouchstart"];
  const UP_CANCEL_ATTRS = [
    "onpointerup",
    "onpointercancel",
    "onmouseup",
    "ontouchend",
    "ontouchcancel"
  ];

  const DOWN_SELECTOR = DOWN_ATTRS.map((attr) => `[${attr}]`).join(", ");

  const ACTIVATION_PATTERNS = [
    /\bsubmit\s*\(/i,
    /\bclick\s*\(/i,
    /\blocation\s*=\s*/i,
    /\blocation\.href\s*=\s*/i,
    /\bwindow\.location\b/i,
    /\bdocument\.location\b/i,
    /\bwindow\.open\s*\(/i
  ];

  function isVisible(node) {
    const style = window.getComputedStyle(node);
    if (!style) return false;
    if (style.display === "none") return false;
    if (style.visibility === "hidden") return false;
    if (parseFloat(style.opacity) === 0) return false;
    return true;
  }

  function getInlineHandler(node, attr) {
    const value = node.getAttribute(attr);
    return value ? value.trim() : "";
  }

  function getInlineHandlers(node, attrs) {
    return attrs.map((attr) => getInlineHandler(node, attr)).join(" ");
  }

  function hasActivationIntent(handler) {
    if (!handler || !handler.trim()) return false;
    return ACTIVATION_PATTERNS.some((regex) => regex.test(handler));
  }

  function normalizeHandler(handler) {
    if (!handler) return "";
    return handler.trim().replace(/;+\s*$/, "").toLowerCase();
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector: DOWN_SELECTOR,
        impact: "serious",
        tags: ["wcag2aa", "wcag22aa", "wcag252", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Pointer down activation should not occur; up/cancel handlers should handle activation",
          help:
            "Ensure activation occurs on up/cancel handlers, not on pointer-down",
          helpUrl: "https://www.w3.org/TR/WCAG22/#pointer-cancellation",
          messages: {
            pass: "2.5.2 - Pointer Cancellation - Pass",
            fail: "2.5.2 - Pointer Cancellation - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          if (!node || typeof node.matches !== "function") return true;
          if (!node.matches(DOWN_SELECTOR)) return true;
          if (!isVisible(node)) return true;

          const downHandlers = getInlineHandlers(node, DOWN_ATTRS);
          const upHandlers = getInlineHandlers(node, UP_CANCEL_ATTRS);
          const downHasActivation = hasActivationIntent(downHandlers);
          const upHasActivation = hasActivationIntent(upHandlers);

          if (!downHasActivation) return true;

          if (upHasActivation) {
            const downNormalized = normalizeHandler(downHandlers);
            const upNormalized = normalizeHandler(upHandlers);
            if (downNormalized && downNormalized === upNormalized) {
              this.data = {
                reason: "Same activation intent on both down and up"
              };
            }
          }

          return false;
        },
        metadata: {
          impact: "serious",
          messages: {
            pass:
              "2.5.2 - Pointer Cancellation - no down activation or up-only activation - Pass",
            fail:
              "2.5.2 - Pointer Cancellation - Fail (same activation intent on both down and up OR activation on down)"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-252-pointer-cancellation loaded");
})();
