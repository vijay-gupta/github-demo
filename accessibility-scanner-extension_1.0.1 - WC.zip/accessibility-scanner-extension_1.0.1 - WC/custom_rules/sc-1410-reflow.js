/**
 * SC 1.4.10 Reflow
 * Automatable subset: Flag visible non-inline elements (excluding known
 * two-dimensional content) that set min-width greater than 320px or an
 * explicit inline width greater than 320px.
 * Limitations:
 * - Does not measure actual horizontal scrolling or layout at 320px.
 * - Does not evaluate reflow failures caused by fixed widths, positioning,
 *   or long unbreakable strings.
 * - Only checks inline width styles, not class-based CSS widths.
 * Version: 1.0
 * Author: Vijay Gupta  
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-1410-reflow";
  const CHECK_ID = "sc-1410-reflow-min-width-over-320";
  const MAX_REFLOW_WIDTH = 320;

  const EXCEPTION_TAGS = new Set([
    "IMG",
    "SVG",
    "CANVAS",
    "VIDEO",
    "IFRAME",
    "OBJECT",
    "EMBED",
    "TABLE"
  ]);

  function isVisible(style) {
    if (!style) return false;
    if (style.display === "none") return false;
    if (style.visibility === "hidden") return false;
    return true;
  }

  function isInline(style) {
    return style && style.display === "inline";
  }

  function parsePx(value) {
    if (!value) return null;
    if (value === "auto") return null;
    const num = parseFloat(value);
    return Number.isFinite(num) ? num : null;
  }

  function getInlineWidthPx(node) {
    if (!node || !node.style) return null;
    const raw = node.style.width;
    if (!raw || !raw.endsWith("px")) return null;
    return parsePx(raw);
  }

  function isExceptionTag(node) {
    return EXCEPTION_TAGS.has(node.tagName);
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        //selector: "*",
        selector: "div, section, article, aside, main, header, footer, p, h1, h2, h3, h4, h5, h6, li, blockquote, span, a, strong, em, b, i, img, svg, video, canvas, table, th, td, caption, form, label, input, textarea, select, option, button, nav, ul, ol",
        impact: "serious",
        tags: ["wcag2aa", "wcag22aa", "wcag1410", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Content should reflow at 320 CSS pixels without horizontal scrolling",
          help:
            "Ensure containers do not enforce min-width or inline width greater than 320px (except for two-dimensional content)",
          helpUrl: "https://www.w3.org/TR/WCAG22/#reflow",
          messages: {
            pass: "1.4.10 - Reflow - Pass",
            fail: "1.4.10 - Reflow - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          const style = window.getComputedStyle(node);

          if (!isVisible(style)) return true;
          if (isInline(style)) return true;
          if (isExceptionTag(node)) return true;

          const minWidth = parsePx(style.minWidth);
          const inlineWidth = getInlineWidthPx(node);
          const hasInlineWidthViolation =
            inlineWidth !== null && inlineWidth > MAX_REFLOW_WIDTH;
          const hasMinWidthViolation =
            minWidth !== null && minWidth > MAX_REFLOW_WIDTH;

          if (!hasInlineWidthViolation && !hasMinWidthViolation) return true;

          const reasons = [];
          if (hasInlineWidthViolation) {
            reasons.push(`inline width ${inlineWidth}px > ${MAX_REFLOW_WIDTH}px`);
          }
          if (hasMinWidthViolation) {
            reasons.push(`min-width ${minWidth}px > ${MAX_REFLOW_WIDTH}px`);
          }

          this.data = {
            reason: `Element exceeds reflow width: ${reasons.join(" and ")}.`,
            minWidth,
            inlineWidth,
            limit: MAX_REFLOW_WIDTH,
            style: {
              display: style.display,
              minWidth: style.minWidth,
              width: style.width
            }
          };

          return false;
        },
        metadata: {
          impact: "serious",
          messages: {
            pass:
              "1.4.10 - Reflow - min-width or inline width at or below 320px - Pass",
            fail:
              "1.4.10 - Reflow - min-width or inline width greater than 320px - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-1410-reflow loaded");
})();
