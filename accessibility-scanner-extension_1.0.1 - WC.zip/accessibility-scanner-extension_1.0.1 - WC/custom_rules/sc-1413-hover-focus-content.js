/**
 * SC 1.4.13 Content on Hover or Focus
 * Automatable subset: Elements with inline hover/focus handlers that show or
 * hide content, or interactive elements with non-empty title tooltips, must
 * provide a dismiss mechanism on the same element or a parent element.
 * Limitations:
 * - Does not detect handlers added via addEventListener or external scripts.
 * - Show/hide intent detection is limited to inline string patterns.
 * - Does not determine whether tooltip content is essential.
 * Version: 1.0
 * Author: Vijay Gupta  
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-1413-hover-focus-content";
  const CHECK_ID = "sc-1413-title-tooltip-disallowed";

  const INTERACTIVE_SELECTOR = [
    "a[href]",
    "button",
    "input:not([type=\"hidden\"])",
    "select",
    "textarea",
    "summary",
    "[role=\"button\"]",
    "[role=\"link\"]",
    "[role=\"menuitem\"]",
    "[role=\"tab\"]",
    "[role=\"switch\"]",
    "[role=\"checkbox\"]",
    "[role=\"radio\"]",
    "[role=\"option\"]",
    "[role=\"textbox\"]",
    "[tabindex]:not([tabindex=\"-1\"])"
  ].join(", ");

  const HOVER_FOCUS_ATTRS = [
    "onmouseover",
    "onmouseenter",
    "onmouseout",
    "onmouseleave",
    "onfocus",
    "onblur"
  ];

  const CONTENT_TOGGLE_PATTERNS = [
    "style.display",
    "display:",
    "style.visibility",
    "visibility:",
    "classList.add",
    "classList.remove",
    "toggle",
    "show",
    "hide",
    "open",
    "close",
    "tooltip",
    "popover",
    "aria-hidden",
    "aria-expanded"
  ];

  const ESCAPE_PATTERNS = [
    "escape",
    "esc",
    "key === 'escape'",
    "keycode === 27"
  ];

  function isVisible(style) {
    if (!style) return false;
    if (style.display === "none") return false;
    if (style.visibility === "hidden") return false;
    if (parseFloat(style.opacity) === 0) return false;
    return true;
  }

  function hasNonEmptyTitle(node) {
    const title = node.getAttribute("title");
    return typeof title === "string" && title.trim().length > 0;
  }

  function isInteractive(node) {
    if (!node || typeof node.matches !== "function") return false;
    return node.matches(INTERACTIVE_SELECTOR);
  }

  function getInlineHandler(node, attr) {
    const value = node.getAttribute(attr);
    return value ? value.trim() : "";
  }

  function getInlineHandlers(node, attrs) {
    return attrs.map((attr) => getInlineHandler(node, attr)).join(" ");
  }

  function hasContentToggleIntent(handler) {
    if (!handler || !handler.trim()) return false;
    const lower = handler.toLowerCase();
    return CONTENT_TOGGLE_PATTERNS.some((pattern) =>
      lower.includes(pattern.toLowerCase())
    );
  }

  function hasEscapeHandler(handler) {
    if (!handler || !handler.trim()) return false;
    const lower = handler.toLowerCase();
    return ESCAPE_PATTERNS.some((pattern) => lower.includes(pattern));
  }

  function findContentPatternMatches(handlersByAttr) {
    const matchedPatterns = new Set();
    const matchedHandlers = new Set();

    for (const [attr, handler] of Object.entries(handlersByAttr)) {
      if (!handler) continue;
      const lower = handler.toLowerCase();
      let matched = false;
      for (const pattern of CONTENT_TOGGLE_PATTERNS) {
        if (lower.includes(pattern.toLowerCase())) {
          matchedPatterns.add(pattern);
          matched = true;
        }
      }
      if (matched) matchedHandlers.add(attr);
    }

    return {
      matchedPatterns: Array.from(matchedPatterns),
      matchedHandlers: Array.from(matchedHandlers)
    };
  }

  function findDismissMechanism(node, handlersByAttr) {
    let current = node;
    let foundScope = "";
    const signals = new Set();

    while (current && current.nodeType === 1) {
      const scope = current === node ? "self" : "parent";
      if (getInlineHandler(current, "onkeydown").length > 0) {
        signals.add("onkeydown");
        if (!foundScope) foundScope = scope;
      }
      if (current.getAttribute("tabindex") === "0") {
        signals.add("tabindex=0");
        if (!foundScope) foundScope = scope;
      }
      if (current.hasAttribute("aria-expanded")) {
        signals.add("aria-expanded");
        if (!foundScope) foundScope = scope;
      }
      if (current.hasAttribute("aria-controls")) {
        signals.add("aria-controls");
        if (!foundScope) foundScope = scope;
      }

      const handlers = [
        getInlineHandlers(current, HOVER_FOCUS_ATTRS),
        getInlineHandler(current, "onkeydown")
      ].join(" ");
      if (hasEscapeHandler(handlers)) {
        signals.add("Escape");
        if (!foundScope) foundScope = scope;
      }

      current = current.parentElement;
    }
    return {
      found: signals.size > 0,
      signals: Array.from(signals),
      scope: foundScope
    };
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector:
          "[onmouseover], [onmouseenter], [onmouseout], [onmouseleave], [onfocus], [onblur], [title]",
        impact: "moderate",
        tags: ["wcag2aa", "wcag22aa", "wcag1413", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Hover/focus content must be dismissible and not rely on native title tooltips",
          help:
            "Ensure hover/focus content has a dismiss mechanism; title tooltips are not allowed",
          helpUrl: "https://www.w3.org/TR/WCAG22/#content-on-hover-or-focus",
          messages: {
            pass: "1.4.13 - Content on Hover or Focus - Pass",
            fail: "1.4.13 - Content on Hover or Focus - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          const style = window.getComputedStyle(node);

          const visible = isVisible(style);
          if (!visible) return true;

          const interactive = isInteractive(node);
          const title = hasNonEmptyTitle(node) ? node.getAttribute("title") : "";
          if (title && interactive) {
            this.data = {
              reason: "TITLE_TOOLTIP",
              triggerType: "title",
              matchedPatterns: [],
              matchedHandlers: [],
              dismissSignalsFound: [],
              dismissScope: "",
              isInteractive: true,
              isHidden: false
            };
            return false;
          }

          if (!node.matches(
            "[onmouseover], [onmouseenter], [onmouseout], [onmouseleave], [onfocus], [onblur]"
          )) {
            return true;
          }

          const handlersByAttr = {};
          HOVER_FOCUS_ATTRS.forEach((attr) => {
            handlersByAttr[attr] = getInlineHandler(node, attr);
          });
          const handlerText = getInlineHandlers(node, HOVER_FOCUS_ATTRS);
          if (!hasContentToggleIntent(handlerText)) return true;

          const patternMatches = findContentPatternMatches(handlersByAttr);
          const dismiss = findDismissMechanism(node, handlersByAttr);
          if (dismiss.found) return true;

          this.data = {
            reason: "NO_DISMISS",
            triggerType: "hover/focus",
            matchedPatterns: patternMatches.matchedPatterns,
            matchedHandlers: patternMatches.matchedHandlers,
            dismissSignalsFound: dismiss.signals,
            dismissScope: dismiss.scope || "",
            isInteractive: interactive,
            isHidden: false
          };
          return false;
        },
        metadata: {
          impact: "moderate",
          messages: {
            pass:
              "1.4.13 - Content on Hover or Focus - dismiss mechanism present - Pass",
            fail:
              "1.4.13 - Content on Hover or Focus - missing dismiss mechanism or title tooltip - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-1413-hover-focus-content loaded");
})();
