/**
 * SC 2.5.4 Motion Actuation
 * Automatable subset: Elements with inline device motion handlers that include
 * action intent must also provide a non-motion alternative on the same element
 * or a parent element.
 * Limitations:
 * - Does not detect handlers added via addEventListener or external scripts.
 * - Cannot verify motion alternatives provided on different elements.
 * - Cannot determine if motion actuation is essential.
 * - Does not verify the ability to disable motion-based activation.
 * Version: 1.0
 * Author: Vijay Gupta  
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-254-motion-actuation";
  const CHECK_ID = "sc-254-motion-has-ui-alternative";

  const MOTION_ATTRS = [
    "ondevicemotion",
    "ondeviceorientation",
    "ondeviceorientationabsolute"
  ];
  const MOTION_SELECTOR = MOTION_ATTRS.map((attr) => `[${attr}]`).join(", ");

  const NON_MOTION_TAGS = new Set(["A", "BUTTON", "INPUT"]);
  const NON_MOTION_ATTRS = ["onclick", "onkeydown", "tabindex", "role"];

  const ACTION_INTENT_PATTERNS = [
    "submit(",
    "click(",
    "location.",
    "window.open",
    "history.push",
    "fetch(",
    "xhr.send",
    "classList.add",
    "classList.remove",
    "style.",
    "setAttribute(",
    "removeAttribute("
  ];

  function isVisible(node) {
    const style = window.getComputedStyle(node);
    if (!style) return false;
    if (style.display === "none") return false;
    if (style.visibility === "hidden") return false;
    if (parseFloat(style.opacity || "1") === 0) return false;
    return true;
  }

  function getInlineHandler(node, attr) {
    const value = node.getAttribute(attr);
    return value ? value.trim() : "";
  }

  function getInlineHandlers(node, attrs) {
    return attrs.map((attr) => getInlineHandler(node, attr)).join(" ");
  }

  function hasActionIntent(handler) {
    if (!handler || !handler.trim()) return false;
    const lower = handler.toLowerCase();
    return ACTION_INTENT_PATTERNS.some((pattern) =>
      lower.includes(pattern.toLowerCase())
    );
  }

  function isNonMotionTag(node) {
    if (!NON_MOTION_TAGS.has(node.tagName)) return false;
    if (node.tagName !== "INPUT") return true;
    const type = (node.getAttribute("type") || "").toLowerCase();
    return type === "button" || type === "submit";
  }

  function hasNonMotionAttr(node) {
    if (node.hasAttribute("onclick")) return true;
    if (node.hasAttribute("onkeydown")) return true;
    if (node.getAttribute("tabindex") === "0") return true;
    if ((node.getAttribute("role") || "").toLowerCase() === "button") {
      return true;
    }
    return false;
  }

  function hasNonMotionAlternative(node) {
    let current = node;
    while (current && current.nodeType === 1) {
      if (isNonMotionTag(current)) return true;
      if (hasNonMotionAttr(current)) return true;
      current = current.parentElement;
    }
    return false;
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector: MOTION_SELECTOR,
        impact: "serious",
        tags: ["wcag2aa", "wcag22aa", "wcag254", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Motion-actuated functionality with action intent should have a non-motion alternative",
          help:
            "Ensure motion-triggered actions have a non-motion alternative on the element or its parent",
          helpUrl: "https://www.w3.org/TR/WCAG22/#motion-actuation",
          messages: {
            pass: "2.5.4 - Motion Actuation - Pass",
            fail: "2.5.4 - Motion Actuation - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          if (!node || typeof node.matches !== "function") return true;
          if (!node.matches(MOTION_SELECTOR)) return true;
          if (!isVisible(node)) return true;

          const motionHandlers = getInlineHandlers(node, MOTION_ATTRS);
          if (!hasActionIntent(motionHandlers)) return true;

          return hasNonMotionAlternative(node);
        },
        metadata: {
          impact: "serious",
          messages: {
            pass:
              "2.5.4 - Motion Actuation - motion handler has UI alternative - Pass",
            fail:
              "2.5.4 - Motion Actuation - motion handler lacks UI alternative - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-254-motion-actuation loaded");
})();
