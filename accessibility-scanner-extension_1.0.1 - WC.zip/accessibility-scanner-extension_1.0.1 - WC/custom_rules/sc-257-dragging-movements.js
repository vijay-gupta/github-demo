/**
 * SC 2.5.7 Dragging Movements
 * Automatable subset: Elements with inline drag event handlers that include
 * drag-logic patterns must provide a non-drag alternative on the same element
 * or a parent element.
 * Limitations:
 * - Does not detect handlers added via addEventListener or external scripts.
 * - Cannot verify alternatives provided on different elements.
 * - Cannot determine whether dragging is essential.
 * - Only inspects explicit drag event handler attributes.
 * Version: 1.0
 * Author: Vijay Gupta  
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-257-dragging-movements";
  const CHECK_ID = "sc-257-dragging-has-single-pointer-alt";

  const DRAG_HANDLER_ATTRS = [
    "ondragstart",
    "ondrag",
    "ondragend",
    "ondragover",
    "ondragenter",
    "ondragleave",
    "ondrop"
  ];

  const DRAG_SELECTOR = DRAG_HANDLER_ATTRS.map((attr) => `[${attr}]`).join(", ");

  const DRAG_LOGIC_STRINGS = [
    "drag",
    "move",
    "deltaX",
    "deltaY",
    "clientX -",
    "clientY -",
    "startX",
    "startY",
    "pageX -",
    "pageY -",
    "setPosition",
    "setTransform",
    "style.left",
    "style.top",
    "translate",
    "translateX",
    "translateY"
  ];

  const NON_DRAG_TAGS = new Set(["BUTTON", "A", "INPUT"]);

  function isVisible(node) {
    const style = window.getComputedStyle(node);
    if (!style) return false;
    if (style.display === "none") return false;
    if (style.visibility === "hidden") return false;
    if (parseFloat(style.opacity) === 0) return false;
    return true;
  }

  function getInlineHandler(node, attr) {
    const value = node.getAttribute(attr);
    return value ? value.trim() : "";
  }

  function getInlineHandlers(node, attrs) {
    return attrs.map((attr) => getInlineHandler(node, attr)).join(" ");
  }

  function hasDragLogic(handler) {
    if (!handler || !handler.trim()) return false;
    const lower = handler.toLowerCase();
    return DRAG_LOGIC_STRINGS.some((pattern) =>
      lower.includes(pattern.toLowerCase())
    );
  }

  function isNonDragTag(node) {
    if (!NON_DRAG_TAGS.has(node.tagName)) return false;
    if (node.tagName !== "INPUT") return true;
    const type = (node.getAttribute("type") || "").toLowerCase();
    return type === "button" || type === "submit";
  }

  function hasNonDragAttr(node) {
    if (getInlineHandler(node, "onclick")) return true;
    if (getInlineHandler(node, "onkeydown")) return true;
    if (node.getAttribute("tabindex") === "0") return true;
    if ((node.getAttribute("role") || "").toLowerCase() === "button") {
      return true;
    }
    if (node.hasAttribute("aria-controls")) return true;
    return false;
  }

  function hasNonDragAlternative(node) {
    let current = node;
    while (current && current.nodeType === 1) {
      if (isNonDragTag(current)) return true;
      if (hasNonDragAttr(current)) return true;
      current = current.parentElement;
    }
    return false;
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector: DRAG_SELECTOR,
        impact: "serious",
        tags: ["wcag2aa", "wcag22aa", "wcag257", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Dragging movements with drag logic must have a non-drag alternative",
          help:
            "Ensure drag logic has a non-drag alternative on the element or its parent",
          helpUrl: "https://www.w3.org/TR/WCAG22/#dragging-movements",
          messages: {
            pass: "2.5.7 - Dragging Movements - Pass",
            fail: "2.5.7 - Dragging Movements - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          if (!node || typeof node.matches !== "function") return true;
          if (!node.matches(DRAG_SELECTOR)) return true;
          if (!isVisible(node)) return true;

          const dragHandlers = getInlineHandlers(node, DRAG_HANDLER_ATTRS);
          if (!hasDragLogic(dragHandlers)) return true;

          return hasNonDragAlternative(node);
        },
        metadata: {
          impact: "serious",
          messages: {
            pass:
              "2.5.7 - Dragging Movements - drag handler has single-pointer alternative - Pass",
            fail:
              "2.5.7 - Dragging Movements - drag handler lacks single-pointer alternative - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-257-dragging-movements loaded");
})();
