# Changelog

All notable changes to this project will be documented in this file.  
This format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)  
and adheres to [Semantic Versioning](https://semver.org/).

---

## [1.0.1] - 20-01-2026
### Added
- Summary Report generation after Stop Scan button is clicked
---

## [1.0.0] - 19-01-2026
### Added
- Automatic accessibility scan on every navigation
- Manual scan option
- Page Level Reports