const status = document.getElementById('status');

document.getElementById('startBtn').onclick = () => {
  chrome.runtime.sendMessage({ action: 'START' });
  updateUI(true);
  //status.innerText = 'Running';
};

document.getElementById('stopBtn').onclick = () => {
  chrome.runtime.sendMessage({ action: 'STOP' });
  //status.innerText = 'Stopped';
  updateUI(false);
};


document.getElementById("scanBtn").addEventListener("click", () => {
  chrome.runtime.sendMessage({ action: "SCAN_CURRENT_PAGE" });
});

function loadReportSettings() {
  chrome.storage.local.get("reportSettings", (data) => {
    const settings = Object.assign(
      { showDebugDetails: true, showNormalizedOutput: false },
      data.reportSettings || {}
    );
    document.getElementById("showDebugDetails").checked =
      settings.showDebugDetails !== false;
    document.getElementById("showNormalizedOutput").checked =
      settings.showNormalizedOutput === true;
  });
}

function saveReportSettings() {
  const settings = {
    showDebugDetails: document.getElementById("showDebugDetails").checked,
    showNormalizedOutput: document.getElementById("showNormalizedOutput").checked
  };
  chrome.storage.local.set({ reportSettings: settings });
}

document
  .getElementById("showDebugDetails")
  .addEventListener("change", saveReportSettings);
document
  .getElementById("showNormalizedOutput")
  .addEventListener("change", saveReportSettings);

/*document.getElementById('scanBtn').onclick = () => {
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    chrome.tabs.sendMessage(tabs[0].id, { action: 'SCAN_CURRENT_PAGE' }, result => {
      console.log('Scan result:', result);
    });
  });
};*/

document.addEventListener("DOMContentLoaded", () => {
  const version = chrome.runtime.getManifest().version;
  document.getElementById("extVersion").textContent = version;
  chrome.storage.local.get("scanState", (data) => {
    const isActive = data.scanState?.active === true;
    updateUI(isActive);
  });
  loadReportSettings();
});

function updateUI(isActive) {
  const statusText = document.getElementById("statusText");
  const startBtn = document.getElementById("startBtn");
  const stopBtn = document.getElementById("stopBtn");

  if (isActive) {
    statusText.textContent = "Scanning started";
    startBtn.textContent = "Scanning Started";
    startBtn.disabled = true;
    startBtn.style.opacity = "0.6";
    stopBtn.disabled = false;
  } else {
    statusText.textContent = "Ready";
    startBtn.textContent = "Start Scanning";
    startBtn.disabled = false;
    startBtn.style.opacity = "1";
    stopBtn.disabled = true;
  }
}

