// Normalization layer for axe results (Phase 2: structural dedup only)
// Pure functions, no DOM access, no rule or axe-core changes.

function toArray(value) {
  return Array.isArray(value) ? value : [];
}

function cloneRule(rule, nodes) {
  return {
    ...rule,
    nodes: nodes
  };
}

function isCustomRule(rule) {
  const id = (rule?.id || "").toLowerCase();
  if (id.startsWith("custom-")) return true;
  const tags = Array.isArray(rule?.tags) ? rule.tags : [];
  return tags.some((tag) => String(tag).toLowerCase() === "custom");
}

function nodeTargetValue(node) {
  const target = toArray(node && node.target);
  if (target.length) return target;
  const xpath = typeof node?.xpath === "string" ? node.xpath : "";
  return xpath ? [xpath] : [];
}

function nodeXPathValue(node) {
  const xpath = typeof node?.xpath === "string" ? node.xpath : "";
  return xpath || "";
}

function targetKey(target) {
  if (Array.isArray(target)) return JSON.stringify(target);
  if (target === null || target === undefined) return "";
  return String(target);
}

function xpathDepth(xpath) {
  if (!xpath || typeof xpath !== "string") return 0;
  const cleaned = xpath.replace(/^\/+/, "");
  if (!cleaned) return 0;
  return cleaned.split("/").filter(Boolean).length;
}

function ancestryDepth(ancestry) {
  if (!Array.isArray(ancestry)) return 0;
  return ancestry.length;
}

function getNodeDepth(node) {
  const ancestry = node?.ancestry;
  if (Array.isArray(ancestry) && ancestry.length) return ancestryDepth(ancestry);
  return xpathDepth(node?.xpath || "");
}

function isXPathAncestor(ancestorXpath, descendantXpath) {
  if (!ancestorXpath || !descendantXpath) return false;
  if (ancestorXpath === descendantXpath) return false;
  if (!descendantXpath.startsWith(ancestorXpath)) return false;
  return descendantXpath.charAt(ancestorXpath.length) === "/";
}

function isAncestryAncestor(ancestorAncestry, descendantAncestry) {
  if (!Array.isArray(ancestorAncestry) || !Array.isArray(descendantAncestry)) return false;
  if (ancestorAncestry.length >= descendantAncestry.length) return false;
  for (let i = 0; i < ancestorAncestry.length; i += 1) {
    if (String(ancestorAncestry[i]).toLowerCase() !== String(descendantAncestry[i]).toLowerCase()) {
      return false;
    }
  }
  return true;
}

function isAncestorNode(ancestorNode, descendantNode) {
  if (!ancestorNode || !descendantNode) return false;
  const aXpath = ancestorNode.xpath || "";
  const dXpath = descendantNode.xpath || "";
  if (aXpath && dXpath) {
    return isXPathAncestor(aXpath, dXpath);
  }
  const aAncestry = ancestorNode.ancestry;
  const dAncestry = descendantNode.ancestry;
  if (Array.isArray(aAncestry) && Array.isArray(dAncestry)) {
    return isAncestryAncestor(aAncestry, dAncestry);
  }
  return false;
}

function pickPreferredDescendant(currentIndex, candidateIndex, nodes) {
  if (currentIndex === null || currentIndex === undefined) return candidateIndex;
  const currentDepth = getNodeDepth(nodes[currentIndex]);
  const candidateDepth = getNodeDepth(nodes[candidateIndex]);
  if (candidateDepth > currentDepth) return candidateIndex;
  if (candidateDepth < currentDepth) return currentIndex;
  return candidateIndex < currentIndex ? candidateIndex : currentIndex;
}

function dedupeRuleNodes(ruleId, nodes) {
  const suppressedByIndex = new Map();
  const nodeCount = nodes.length;

  for (let i = 0; i < nodeCount; i += 1) {
    const maybeAncestor = nodes[i];
    for (let j = 0; j < nodeCount; j += 1) {
      if (i === j) continue;
      const maybeDescendant = nodes[j];
      if (!isAncestorNode(maybeAncestor, maybeDescendant)) continue;
      const currentKept = suppressedByIndex.get(i);
      const nextKept = pickPreferredDescendant(currentKept, j, nodes);
      suppressedByIndex.set(i, nextKept);
    }
  }

  const keptNodes = [];
  const suppressionMetadata = [];

  for (let i = 0; i < nodeCount; i += 1) {
    const suppressedBy = suppressedByIndex.get(i);
    if (suppressedBy === undefined) {
      keptNodes.push(nodes[i]);
      continue;
    }

    const suppressedNode = nodes[i];
    const keptNode = nodes[suppressedBy];

    suppressionMetadata.push({
      ruleId,
      suppressedNodeTarget: nodeTargetValue(suppressedNode),
      suppressedNodeXPath: nodeXPathValue(suppressedNode),
      keptNodeTarget: nodeTargetValue(keptNode),
      keptNodeXPath: nodeXPathValue(keptNode),
      reason: "ANCESTOR_SUPPRESSED"
    });
  }

  return { keptNodes, suppressionMetadata };
}

export function normalizeAxeResults(rawResults) {
  const raw = rawResults || {};
  const normalizedResults = {
    violations: [],
    passes: [],
    incomplete: [],
    inapplicable: []
  };
  const suppressionMetadata = [];

  const violationRules = toArray(raw.violations);
  violationRules.forEach((rule) => {
    const nodes = toArray(rule.nodes);
    if (isCustomRule(rule)) {
      const { keptNodes, suppressionMetadata: ruleSuppression } = dedupeRuleNodes(rule.id, nodes);
      normalizedResults.violations.push(cloneRule(rule, keptNodes));
      suppressionMetadata.push(...ruleSuppression);
    } else {
      normalizedResults.violations.push(cloneRule(rule, nodes));
    }
  });

  const passRules = toArray(raw.passes).map((rule) => cloneRule(rule, toArray(rule.nodes)));
  const incompleteRules = toArray(raw.incomplete).map((rule) => cloneRule(rule, toArray(rule.nodes)));
  const inapplicableRules = toArray(raw.inapplicable).map((rule) => cloneRule(rule, toArray(rule.nodes)));

  normalizedResults.passes = passRules;
  normalizedResults.incomplete = incompleteRules;
  normalizedResults.inapplicable = inapplicableRules;

  return {
    rawResults: rawResults,
    normalizedResults,
    suppressionMetadata
  };
}

// Utility: explain why a node was suppressed and which node replaced it.
// Usage: explainSuppression(ruleId, nodeTarget, suppressionMetadata)
export function explainSuppression(ruleId, nodeTarget, suppressionMetadata) {
  const list = Array.isArray(suppressionMetadata) ? suppressionMetadata : [];
  const target = targetKey(nodeTarget);
  const match = list.find((entry) => {
    if (entry.ruleId !== ruleId) return false;
    return targetKey(entry.suppressedNodeTarget) === target;
  });

  if (!match) {
    return {
      suppressed: false,
      ruleId,
    suppressedNodeTarget: nodeTarget,
    reason: "NOT_SUPPRESSED"
  };
}

  return {
    suppressed: true,
    ruleId: match.ruleId,
    suppressedNodeTarget: match.suppressedNodeTarget,
    keptNodeTarget: match.keptNodeTarget,
    reason: match.reason
  };
}

// Optional helper for the requested signature: explainSuppression(ruleId, nodeTarget)
export function createSuppressionExplainer(suppressionMetadata) {
  return function explainSuppressionForResult(ruleId, nodeTarget) {
    return explainSuppression(ruleId, nodeTarget, suppressionMetadata);
  };
}
