// Utilities for Phase 1 filtering metadata (no DOM access).

function targetKey(target) {
  if (Array.isArray(target)) return JSON.stringify(target);
  if (target === null || target === undefined) return "";
  return String(target);
}

function nodeTargetValue(node) {
  const target = Array.isArray(node?.target) ? node.target : [];
  if (target.length) return target;
  const xpath = typeof node?.xpath === "string" ? node.xpath : "";
  return xpath ? [xpath] : [];
}

export function explainFiltering(ruleId, nodeTarget, phase2Filtered) {
  const list = Array.isArray(phase2Filtered) ? phase2Filtered : [];
  const target = targetKey(nodeTarget);
  const match = list.find((entry) => {
    if (entry.ruleId !== ruleId) return false;
    return targetKey(nodeTargetValue(entry.node || {})) === target;
  });

  if (!match) {
    return {
      filtered: false,
      ruleId,
      nodeTarget,
      reason: "NOT_FILTERED"
    };
  }

  return {
    filtered: true,
    ruleId: match.ruleId,
    reason: match.reason,
    coveredBy: match.debug?.coveringElement || "",
    boundingBox: match.debug?.boundingBox || null
  };
}
