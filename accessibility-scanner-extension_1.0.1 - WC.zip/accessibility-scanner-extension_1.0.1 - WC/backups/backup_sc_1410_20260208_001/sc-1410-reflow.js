/**
 * SC 1.4.10 Reflow
 * Automatable subset: Flag visible non-inline elements (excluding known
 * two-dimensional content) that set min-width greater than 320px or an
 * explicit inline width greater than 320px.
 * Limitations:
 * - Does not measure actual horizontal scrolling or layout at 320px.
 * - Does not evaluate reflow failures caused by fixed widths, positioning,
 *   or long unbreakable strings.
 * - Only checks inline width styles, not class-based CSS widths.
 * - Div/span elements are only included when they match role/class/id hints
 *   or have inline width/min-width in px.
 * Version: 1.0
 * Author: Vijay Gupta  
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-1410-reflow";
  const CHECK_ID = "sc-1410-reflow-min-width-over-320";
  const MAX_REFLOW_WIDTH = 320;
  const CLASS_KEYWORDS = [
    "container",
    "wrapper",
    "layout",
    "grid",
    "col",
    "row",
    "panel",
    "card",
    "sidebar",
    "content",
    "main",
    "section",
    "modal",
    "dialog",
    "drawer",
    "dropdown",
    "menu",
    "nav",
    "carousel",
    "slider",
    "tabs",
    "tabpanel",
    "table"
  ];
  const ID_KEYWORDS = [
    "container",
    "wrapper",
    "layout",
    "grid",
    "col",
    "row",
    "panel",
    "card",
    "sidebar",
    "content",
    "main",
    "section"
  ];
  const ROLE_KEYWORDS = [
    "button",
    "dialog",
    "menu",
    "navigation",
    "tabpanel",
    "region"
  ];

  const EXCEPTION_TAGS = new Set([
    "IMG",
    "SVG",
    "CANVAS",
    "VIDEO",
    "IFRAME",
    "OBJECT",
    "EMBED",
    "TABLE"
  ]);

  function isVisible(style) {
    if (!style) return false;
    if (style.display === "none") return false;
    if (style.visibility === "hidden") return false;
    return true;
  }

  function isInline(style) {
    return style && style.display === "inline";
  }

  function parsePx(value) {
    if (!value) return null;
    if (value === "auto") return null;
    const num = parseFloat(value);
    return Number.isFinite(num) ? num : null;
  }

  function getInlineWidthPx(node) {
    if (!node || !node.style) return null;
    const raw = node.style.width;
    if (!raw || !raw.endsWith("px")) return null;
    return parsePx(raw);
  }

  function isExceptionTag(node) {
    return EXCEPTION_TAGS.has(node.tagName);
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        //selector: "*",
        selector: "div, section, article, aside, main, header, footer, p, h1, h2, h3, h4, h5, h6, li, blockquote, span, a, strong, em, b, i, img, svg, video, canvas, table, th, td, caption, form, label, input, textarea, select, option, button, nav, ul, ol",
        matches: function (node, options) {
          const tag = node.tagName.toUpperCase();

          // Always include non-div/span tags in the selector list
          if (tag !== "DIV" && tag !== "SPAN") return true;

          const role = node.getAttribute("role") || "";
          const cls = String(node.className || "").toLowerCase();
          const id = String(node.id || "").toLowerCase();

          // Keep div/span if they are semantic by role
          if (options && options.roles && options.roles.includes(role)) return true;

          // Keep div/span if class or id hints at layout or UI container
          if (options && options.classKeywords) {
            if (options.classKeywords.some((keyword) => cls.includes(keyword))) {
              return true;
            }
          }
          if (options && options.idKeywords) {
            if (options.idKeywords.some((keyword) => id.includes(keyword))) {
              return true;
            }
          }

          // Keep div/span if they are explicitly sized inline (high risk for reflow)
          if (
            node.style &&
            typeof node.style.minWidth === "string" &&
            node.style.minWidth.endsWith("px")
          ) {
            return true;
          }
          if (
            node.style &&
            typeof node.style.width === "string" &&
            node.style.width.endsWith("px")
          ) {
            return true;
          }

          return false;
        },

        options: {
          classKeywords: CLASS_KEYWORDS,
          idKeywords: ID_KEYWORDS,
          roles: ROLE_KEYWORDS
        },
        
        impact: "serious",
        tags: ["wcag2aa", "wcag22aa", "wcag1410", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Content should reflow at 320 CSS pixels without horizontal scrolling",
          help:
            "Ensure containers do not enforce min-width or inline width greater than 320px (except for two-dimensional content). Note: div/span are only checked when role/class/id hints or inline widths are present.",
          helpUrl: "https://www.w3.org/TR/WCAG22/#reflow",
          messages: {
            pass: "1.4.10 - Reflow - Pass",
            fail: "1.4.10 - Reflow - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          const style = window.getComputedStyle(node);
          const tag = node.tagName ? node.tagName.toUpperCase() : "";

          if (!isVisible(style)) return true;
          if (isInline(style)) return true;
          if (isExceptionTag(node)) return true;

          const minWidth = parsePx(style.minWidth);
          const inlineWidth = getInlineWidthPx(node);
          const hasInlineWidthViolation =
            inlineWidth !== null && inlineWidth > MAX_REFLOW_WIDTH;
          const hasMinWidthViolation =
            minWidth !== null && minWidth > MAX_REFLOW_WIDTH;

          if (!hasInlineWidthViolation && !hasMinWidthViolation) return true;

          const reasons = [];
          if (hasInlineWidthViolation) {
            reasons.push(`inline width ${inlineWidth}px > ${MAX_REFLOW_WIDTH}px`);
          }
          if (hasMinWidthViolation) {
            reasons.push(`min-width ${minWidth}px > ${MAX_REFLOW_WIDTH}px`);
          }

          const filterMatch = [];
          if (tag !== "DIV" && tag !== "SPAN") {
            filterMatch.push("non-div/span");
          } else {
            const role = node.getAttribute("role") || "";
            const cls = String(node.className || "").toLowerCase();
            const id = String(node.id || "").toLowerCase();
            if (ROLE_KEYWORDS.includes(role)) filterMatch.push("role");
            if (CLASS_KEYWORDS.some((keyword) => cls.includes(keyword))) {
              filterMatch.push("class");
            }
            if (ID_KEYWORDS.some((keyword) => id.includes(keyword))) {
              filterMatch.push("id");
            }
            if (
              node.style &&
              typeof node.style.minWidth === "string" &&
              node.style.minWidth.endsWith("px")
            ) {
              filterMatch.push("inline-min-width-px");
            }
            if (
              node.style &&
              typeof node.style.width === "string" &&
              node.style.width.endsWith("px")
            ) {
              filterMatch.push("inline-width-px");
            }
            if (!filterMatch.length) filterMatch.push("div/span-unknown");
          }

          this.data = {
            reason: `Element exceeds reflow width: ${reasons.join(" and ")}.`,
            minWidth,
            inlineWidth,
            limit: MAX_REFLOW_WIDTH,
            filterMatch,
            style: {
              display: style.display,
              minWidth: style.minWidth,
              width: style.width
            }
          };

          return false;
        },
        metadata: {
          impact: "serious",
          messages: {
            pass:
              "1.4.10 - Reflow - min-width or inline width at or below 320px - Pass",
            fail:
              "1.4.10 - Reflow - min-width or inline width greater than 320px - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-1410-reflow loaded");
})();
