/**
 * =========================================================
 * ACCESSIBILITY SCANNER – INJECTOR
 * ---------------------------------------------------------
 * ROLE:
 *  - Runs as CONTENT SCRIPT
 *  - Uses chrome.runtime APIs
 *  - Injects PAGE-CONTEXT scripts
 * =========================================================
 */

(function () {

  console.log("[INJECTOR] Running on:", window.location.href);
  let currentScanContext = null;
  let registryTimeoutId = null;

  /**
   * ---------------------------------------------------------
   * 1. Notify background that page is ready
   * ---------------------------------------------------------
   */
  try {
    chrome.runtime.sendMessage({
      type: "PAGE_READY",
      url: window.location.href
    });
    console.log("[INJECTOR] PAGE_READY sent");
  } catch (e) {
    console.error("[INJECTOR] Failed to send PAGE_READY", e);
  }

  /**
   * ---------------------------------------------------------
   * 2. Listen for START_SCAN from background / popup
   * ---------------------------------------------------------
   */
  chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {

    if (message.type === "START_SCAN") {
      console.log("[INJECTOR] START_SCAN received");

      currentScanContext = message.scanContext || {
        scanId: message.scanId || null,
        debug: message.debug || { enabled: false }
      };

      chrome.storage.local.get("reportSettings", (data) => {
        const settings = Object.assign(
          { showDebugDetails: true },
          data.reportSettings || {}
        );
        currentScanContext.reportSettings = settings;
        injectAxePipeline(currentScanContext);
        sendResponse({ status: "SCAN_TRIGGERED" });
      });
      return true;
    }
  });


function injectRunConfig(reportSettings) {
  const settings = Object.assign(
    { showDebugDetails: true },
    reportSettings || {}
  );
  const inline = document.createElement("script");
  inline.textContent = `window.__AXE_RUN_CONFIG__ = Object.assign({}, window.__AXE_RUN_CONFIG__ || {}, ${JSON.stringify(settings)});`;
  document.documentElement.appendChild(inline);
  inline.remove();

  const script = document.createElement("script");
  script.src = chrome.runtime.getURL("content-scripts/axe-run-config.js");
  script.onload = () => {
    console.log("[INJECTOR] AXE run config injected");
    script.remove();
  };
  document.documentElement.appendChild(script);
}

  /**
   * =========================================================
   * AXE PIPELINE ORCHESTRATION
   * =========================================================
   */

  function injectAxePipeline(scanContext) {

    // -------------------------------------------------------
    // [MODIFIED] Separate flags for core and custom rules
    // -------------------------------------------------------
    if (window.__AXE_PIPELINE_READY__) {
      console.log("[INJECTOR] Axe pipeline already ready, re-running scan");
      injectRunConfig(scanContext?.reportSettings);
      window.dispatchEvent(new Event("AXE_RUN_SCAN"));
      return;
    }

    window.__AXE_PIPELINE_READY__ = true;
    // -------------------------------------------------------
    // STEP 1: Inject axe-core
    // -------------------------------------------------------
    const axeScript = document.createElement("script");
    axeScript.src = chrome.runtime.getURL("lib/axe-core/axe.min.js");

    axeScript.onload = function () {
      console.log("[INJECTOR] axe-core injected");
 
      injectCustomRulesRegistry();
    };

    axeScript.onerror = function (e) {
      console.error("[INJECTOR] Failed to inject axe-core", e);
    };

    document.documentElement.appendChild(axeScript);
  }

  /**
   * ---------------------------------------------------------
   * STEP 2: Inject custom rules registry
   * ---------------------------------------------------------
   */
  function injectCustomRulesRegistry() {

    const registryScript = document.createElement("script");
    registryScript.src = chrome.runtime.getURL("custom_rules/registry.js");

    registryScript.onload = function () {
      console.log("[INJECTOR] custom rules registry injected");
    };

    registryScript.onerror = function (e) {
    };

    document.documentElement.appendChild(registryScript);

    // -------------------------------------------------------
    // [ADDED] Wait for registry readiness signal
    // -------------------------------------------------------
    window.addEventListener(
      "AXE_CUSTOM_RULES_REGISTRY_READY",
        function (e) {
          if (registryTimeoutId) {
            clearTimeout(registryTimeoutId);
            registryTimeoutId = null;
          }
          injectCustomRules(e.detail || []);
        },
        { once: true }
    );

    registryTimeoutId = window.setTimeout(() => {
    }, 5000);
  }

  /**
   * ---------------------------------------------------------
   * STEP 3: Inject each custom rule file sequentially
   * ---------------------------------------------------------
   */
  function injectCustomRules(rules) {
  let index = 0;

    function loadNextRule() {
      if (index >= rules.length) {
        injectAxeRunner();
        return;
      }

      const script = document.createElement("script");
      script.src = chrome.runtime.getURL(rules[index]);

      script.onload = function () {
        console.log("[INJECTOR] custom rule loaded:", rules[index]);
        index++;
        loadNextRule();
      };

      script.onerror = function (e) {
        index++;
        loadNextRule();
      };

      document.documentElement.appendChild(script);
    }

    loadNextRule();
  }


  /**
   * ---------------------------------------------------------
   * STEP 4: Inject axe-runner and trigger scan
   * ---------------------------------------------------------
   */
  function injectAxeRunner() {

    injectRunConfig(currentScanContext?.reportSettings);
    const runnerScript = document.createElement("script");
    runnerScript.src = chrome.runtime.getURL("content-scripts/axe-runner.js");

    runnerScript.onload = function () {
      console.log("[INJECTOR] axe-runner injected successfully");
      window.dispatchEvent(new Event("AXE_RUN_SCAN"));
      console.log("[INJECTOR] AXE_RUN_SCAN dispatched");
    };

    runnerScript.onerror = function (e) {
      console.error("[INJECTOR] Failed to inject axe-runner", e);
    };

    document.documentElement.appendChild(runnerScript);
  }

  /**
   * ---------------------------------------------------------
   * 5. Bridge AXE results from PAGE → EXTENSION
   * ---------------------------------------------------------
   */
  window.addEventListener("AXE_RESULTS", function (event) {

    console.log("[INJECTOR] AXE_RESULTS received");

    const scanId =
      event?.detail?.__debug?.scanId || currentScanContext?.scanId || null;

    chrome.runtime.sendMessage({
      type: "AXE_RESULTS",
      payload: event.detail,
      scanId,
      url: window.location.href
    });
  });

})();
