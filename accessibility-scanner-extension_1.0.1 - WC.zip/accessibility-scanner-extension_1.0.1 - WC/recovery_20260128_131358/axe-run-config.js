// PAGE CONTEXT (CSP-safe)
window.__AXE_RUN_CONFIG__ = Object.assign(
  {
    customOnly: false, // 🔁 toggle this
    showDebugDetails: true
  },
  window.__AXE_RUN_CONFIG__ || {}
);

console.log(
  "[AXE_RUN_CONFIG] customOnly =",
  window.__AXE_RUN_CONFIG__.customOnly
);
