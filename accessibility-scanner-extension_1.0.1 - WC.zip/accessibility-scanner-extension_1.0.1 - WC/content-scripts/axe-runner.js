// ---------------------------------------------------------
// Page-level scan lock (prevents re-entrant scans)
// ---------------------------------------------------------
let axeScanInProgress = false;

(function () {
  if (window.__AXE_RUNNER_LOADED__) return;
  window.__AXE_RUNNER_LOADED__ = true;

  if (!window.axe) {
    console.error("[AXE_RUNNER] axe-core not found on page");
    return;
  }

  console.log("[AXE_RUNNER] axe-core detected");

  window.addEventListener("AXE_RUN_SCAN", function () {

    if (axeScanInProgress) {
      console.log("[AXE_RUNNER] Scan already in progress, skipping");
      return;
    }

    axeScanInProgress = true;
    console.log("[AXE_RUNNER] Scan lock acquired");

    const config = window.__AXE_RUN_CONFIG__ || {};
    const customOnly = config.customOnly === true;

    let options = {};
    const scanStartedAt = Date.now();

    if (customOnly) {
      // dY"' Run ONLY custom rules
      const customRuleIds = axe.getRules()
        .map(r => r.ruleId)
        .filter(id => id.startsWith("custom"));

      console.log("[AXE_RUNNER] Running custom rules only:", customRuleIds);

      options.runOnly = {
        type: "rule",
        values: customRuleIds
      };
    }
    else {
      console.log(
      "[AXE_RUNNER] Running built-in + custom rules"
      );
    }

    console.log("[AXE_SCAN_STARTED]", window.location.href, "ts=", Date.now());

    function buildXPath(el) {
      if (!el || el.nodeType !== 1) return "";

      function escapeForXpath(value) {
        if (value.indexOf("'") === -1) return `'${value}'`;
        if (value.indexOf("\"") === -1) return `"${value}"`;
        return "";
      }

      function segmentWithIndex(node) {
        const tag = node.nodeName.toLowerCase();
        let index = 1;
        let sibling = node.previousElementSibling;
        while (sibling) {
          if (sibling.nodeName.toLowerCase() === tag) index += 1;
          sibling = sibling.previousElementSibling;
        }
        return `${tag}[${index}]`;
      }

      function predicateFromAttributes(node) {
        const attrs = Array.from(node.attributes || []);
        const clauses = [];
        const attrMap = new Map(attrs.map(a => [a.name, a.value]));

        const ordered = [
          "id",
          "name",
          "aria-label",
          "aria-labelledby",
          "aria-describedby",
          "role",
          "type",
          "alt",
          "title",
          "placeholder",
          "value"
        ];

        if (attrMap.has("id")) {
          const literal = escapeForXpath(attrMap.get("id"));
          if (literal) return `[@id=${literal}]`;
        }

        attrs.forEach((attr) => {
          if (!attr.name.startsWith("data-")) return;
          const literal = escapeForXpath(attr.value || "");
          if (literal) clauses.push(`@${attr.name}=${literal}`);
        });

        ordered.forEach((name) => {
          const val = attrMap.get(name);
          if (!val) return;
          const literal = escapeForXpath(val);
          if (literal) clauses.push(`@${name}=${literal}`);
        });

        const classValue = attrMap.get("class");
        if (classValue) {
          const tokens = classValue.split(/\s+/).filter(Boolean);
          tokens.forEach((token) => {
            clauses.push(
              `contains(concat(' ', normalize-space(@class), ' '), ' ${token} ')`
            );
          });
        }

        if (!clauses.length) return "";
        return `[${clauses.join(" and ")}]`;
      }

      function segmentWithPredicate(node) {
        const tag = node.nodeName.toLowerCase();
        const predicate = predicateFromAttributes(node);
        return `${tag}${predicate}`;
      }

      function buildRelativePath(from, to, useIndexMap) {
        const segments = [];
        let node = to;
        while (node && node !== from) {
          segments.unshift(
            useIndexMap.has(node) ? segmentWithIndex(node) : segmentWithPredicate(node)
          );
          node = node.parentElement;
        }
        return segments.join("/");
      }

      const candidates = [];

      function addCandidate(xpath) {
        if (!xpath) return;
        candidates.push(xpath);
      }

      function addAttributeCandidates(node) {
        const attrs = Array.from(node.attributes || []);
        const attrMap = new Map(attrs.map(a => [a.name, a.value]));

        if (attrMap.has("id")) {
          const literal = escapeForXpath(attrMap.get("id"));
          if (literal) addCandidate(`//*[@id=${literal}]`);
        }

        attrs.forEach((attr) => {
          if (!attr.name.startsWith("data-")) return;
          const literal = escapeForXpath(attr.value || "");
          if (literal) addCandidate(`//*[@${attr.name}=${literal}]`);
        });

        const ordered = [
          "name",
          "aria-label",
          "aria-labelledby",
          "aria-describedby",
          "role",
          "type",
          "alt",
          "title",
          "placeholder",
          "value"
        ];

        ordered.forEach((name) => {
          const val = attrMap.get(name);
          if (!val) return;
          const literal = escapeForXpath(val);
          if (literal) addCandidate(`//*[@${name}=${literal}]`);
        });

        const tag = node.nodeName.toLowerCase();
        const classValue = attrMap.get("class");
        if (classValue) {
          const tokens = classValue.split(/\s+/).filter(Boolean);
          tokens.forEach((token) => {
            addCandidate(
              `//${tag}[contains(concat(' ', normalize-space(@class), ' '), ' ${token} ')]`
            );
          });
          if (tokens.length > 1) {
            const combined = tokens.map(t =>
              `contains(concat(' ', normalize-space(@class), ' '), ' ${t} ')`
            ).join(" and ");
            addCandidate(`//${tag}[${combined}]`);
          }
        }
      }

      function resolvesToTarget(xpath) {
        if (!xpath) return false;
        try {
          const result = document.evaluate(
            xpath,
            document,
            null,
            XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,
            null
          );
          if (result.snapshotLength !== 1) return false;
          return result.snapshotItem(0) === el;
        } catch (_) {
          return false;
        }
      }

      function pickBestUnique() {
        if (!candidates.length) return "";
        const unique = candidates.filter(resolvesToTarget);
        if (!unique.length) return "";
        unique.sort((a, b) => a.length - b.length);
        return unique[0];
      }

      function buildIndexedPath(target) {
        const segments = [];
        let node = target;
        while (node && node.nodeType === 1) {
          segments.unshift(segmentWithIndex(node));
          node = node.parentElement;
        }
        return `/${segments.join("/")}`;
      }

      addAttributeCandidates(el);
      let best = pickBestUnique();
      if (best) return best;

      let anchor = el.parentElement;
      while (anchor) {
        addAttributeCandidates(anchor);
        const anchorBest = pickBestUnique();
        if (anchorBest) {
          const useIndexMap = new Set();
          let relativePath = buildRelativePath(anchor, el, useIndexMap);
          const anchorCandidates = [];
          function addAnchorCandidate(xpath) {
            if (!xpath) return;
            anchorCandidates.push(xpath);
          }
          addAnchorCandidate(`${anchorBest}/${relativePath}`);
          addAnchorCandidate(`${anchorBest}//${segmentWithPredicate(el)}`);
          anchorCandidates.forEach(addCandidate);
          best = pickBestUnique();
          if (best) return best;

          let node = el;
          while (node && node !== anchor) {
            useIndexMap.add(node);
            relativePath = buildRelativePath(anchor, el, useIndexMap);
            anchorCandidates.length = 0;
            addAnchorCandidate(`${anchorBest}/${relativePath}`);
            anchorCandidates.forEach(addCandidate);
            best = pickBestUnique();
            if (best) return best;
            node = node.parentElement;
          }
        }
        anchor = anchor.parentElement;
      }

      const useIndexMap = new Set();
      let node = el;
      while (node && node.nodeType === 1) {
        useIndexMap.add(node);
        const absolutePath = buildRelativePath(document.documentElement, el, useIndexMap);
        addCandidate(`/${absolutePath}`);
        best = pickBestUnique();
        if (best) return best;
        node = node.parentElement;
      }

      return buildIndexedPath(el);
    }

    let hasShadowRootsCached = null;

    function hasShadowRoots() {
      if (hasShadowRootsCached !== null) return hasShadowRootsCached;
      let found = false;
      const rootEl = document.documentElement || document;
      if (!rootEl) {
        hasShadowRootsCached = false;
        return hasShadowRootsCached;
      }
      const walker = document.createTreeWalker(
        rootEl,
        NodeFilter.SHOW_ELEMENT
      );
      let node = walker.currentNode;
      while (node) {
        if (node.shadowRoot) {
          found = true;
          break;
        }
        node = walker.nextNode();
      }
      hasShadowRootsCached = found;
      return hasShadowRootsCached;
    }

    function findElementDeep(selector) {
      if (!selector) return null;
      const roots = [document];
      for (let i = 0; i < roots.length; i++) {
        const root = roots[i];
        try {
          const hit = root.querySelector(selector);
          if (hit) return hit;
        } catch (_) {
          // ignore invalid selectors at this root
        }
        const rootEl = root.documentElement || root;
        if (!rootEl) continue;
        const walker = document.createTreeWalker(
          rootEl,
          NodeFilter.SHOW_ELEMENT
        );
        let node = walker.currentNode;
        while (node) {
          if (node.shadowRoot) {
            roots.push(node.shadowRoot);
          }
          node = walker.nextNode();
        }
      }
      return null;
    }

    function findElementInFrames(selector) {
      if (!selector) return null;
      const frames = Array.from(document.querySelectorAll("iframe, frame"));
      for (const frame of frames) {
        try {
          const doc = frame.contentDocument;
          if (!doc) continue;
          const hit = doc.querySelector(selector);
          if (hit) return hit;
        } catch (_) {
          // ignore cross-origin frames
        }
      }
      return null;
    }

    function findElementByXPathInFrames(xpath) {
      if (!xpath) return null;
      const frames = Array.from(document.querySelectorAll("iframe, frame"));
      for (const frame of frames) {
        try {
          const doc = frame.contentDocument;
          if (!doc) continue;
          const result = doc.evaluate(
            xpath,
            doc,
            null,
            XPathResult.FIRST_ORDERED_NODE_TYPE,
            null
          );
          if (result.singleNodeValue) return result.singleNodeValue;
        } catch (_) {
          // ignore cross-origin frames
        }
      }
      return null;
    }

    function findElement(targets) {
      if (!Array.isArray(targets)) return null;
      for (let i = 0; i < targets.length; i++) {
        try {
          const el = document.querySelector(targets[i]);
          if (el) return el;
        } catch (_) {
          // ignore invalid selectors and try the next target
        }
        if (hasShadowRoots()) {
          const deepEl = findElementDeep(targets[i]);
          if (deepEl) return deepEl;
        }
        const frameEl = findElementInFrames(targets[i]);
        if (frameEl) return frameEl;
      }
      return null;
    }

    function findElementByXPath(xpath) {
      if (!xpath) return null;
      try {
        const result = document.evaluate(
          xpath,
          document,
          null,
          XPathResult.FIRST_ORDERED_NODE_TYPE,
          null
        );
        return result.singleNodeValue || null;
      } catch (_) {
        // ignore and try frames
      }
      return findElementByXPathInFrames(xpath);
    }

    function getNodeElement(node) {
      const byTarget = findElement(node?.target || []);
      if (byTarget) return byTarget;
      return findElementByXPath(node?.xpath || "");
    }

    function isStyleVisible(style) {
      if (!style) return false;
      if (style.display === "none") return false;
      if (style.visibility === "hidden") return false;
      if (parseFloat(style.opacity || "1") === 0) return false;
      return true;
    }

      function attachNodeXpaths(results) {
        const violations = results?.violations || [];
        const elementCache = new Map();
        const selectorCache = new Map();
        const xpathCache = new WeakMap();

      function cacheKey(node) {
        const target = Array.isArray(node?.target) ? node.target : [];
        const targetKey = target.length ? JSON.stringify(target) : "";
        const xpathKey = typeof node?.xpath === "string" ? node.xpath : "";
        return `${targetKey}|${xpathKey}`;
      }

      function getSelectorMatch(selector) {
        if (selectorCache.has(selector)) return selectorCache.get(selector);
        let entry = { count: 0, element: null };
        try {
          const matches = document.querySelectorAll(selector);
          entry = {
            count: matches.length,
            element: matches.length === 1 ? matches[0] : null
          };
        } catch (_) {
          entry = { count: 0, element: null };
        }
        selectorCache.set(selector, entry);
        return entry;
      }

        function resolveUniqueTarget(node) {
          const targets = Array.isArray(node?.target) ? node.target : [];
          for (let i = 0; i < targets.length; i += 1) {
            const selector = targets[i];
            if (!selector) continue;
            const match = getSelectorMatch(selector);
            if (match.count === 1 && match.element) {
              return { element: match.element, unique: true, selector };
            }
          }
          return { element: null, unique: false, selector: "" };
        }

        function resolveFirstTarget(node) {
          const targets = Array.isArray(node?.target) ? node.target : [];
          for (let i = 0; i < targets.length; i += 1) {
            const selector = targets[i];
            if (!selector) continue;
            try {
              const el = document.querySelector(selector);
              if (el) return el;
            } catch (_) {
              // ignore invalid selectors and try the next target
            }
          }
          return null;
        }

        function resolveElementFromHtml(html) {
          if (!html || typeof html !== "string") return null;
          const idMatch = html.match(/\sid=["']([^"']+)["']/i);
          if (idMatch && idMatch[1]) {
            return document.getElementById(idMatch[1]);
          }
          return null;
        }

        function getCachedElement(node) {
          const key = cacheKey(node);
          if (elementCache.has(key)) return elementCache.get(key);
          let el = null;
          let uniqueTarget = false;
          let uniqueSelector = "";
          const uniqueHit = resolveUniqueTarget(node);
          if (uniqueHit.element) {
            el = uniqueHit.element;
            uniqueTarget = true;
            uniqueSelector = uniqueHit.selector || "";
          }
          if (node?.xpath) {
            el = findElementByXPath(node.xpath);
          }
          if (!el) {
            el = getNodeElement(node);
          }
          elementCache.set(key, { element: el, uniqueTarget, uniqueSelector });
          return { element: el, uniqueTarget, uniqueSelector };
        }

        function getCachedXPath(el) {
          if (!el) return "";
          if (xpathCache.has(el)) return xpathCache.get(el) || "";
          const xpath = buildXPath(el);
          xpathCache.set(el, xpath || "");
          return xpath || "";
        }

        function isRootTarget(node) {
          const targets = Array.isArray(node?.target) ? node.target : [];
          if (targets.length !== 1) return false;
          return String(targets[0] || "").trim() === ":root";
        }

        violations.forEach((rule) => {
          if (!String(rule?.id || "").startsWith("custom")) return;
          (rule.nodes || []).forEach((node) => {
            if (node.xpath && node.parentXPath) return;
            const cached = getCachedElement(node);
            const uniqueTarget = cached.uniqueTarget;
            const uniqueSelector = cached.uniqueSelector;

            if (uniqueTarget && uniqueSelector && !node.__uniqueTarget) {
              node.__uniqueTarget = uniqueSelector;
            }

            if (node.xpath) return;
            if (uniqueTarget) return;

            let el = resolveFirstTarget(node);
            if (el) {
              node.xpath = getCachedXPath(el);
              return;
            }

            el = resolveElementFromHtml(node?.html || "");
            if (el) {
              node.xpath = getCachedXPath(el);
              return;
            }

            const fallback = cached.element;
            if (fallback) {
              node.xpath = getCachedXPath(fallback);
            }
          });
        });
      }

    function enrichTextSpacingDebug(results) {
      const RULE_ID = "custom-wcag22-sc-1412-text-spacing";
      const CHECK_ID = "sc-1412-text-spacing-no-clipping";

      function isFixedSize(value) {
        if (!value || value === "auto" || value === "none") return false;
        return Number.isFinite(parseFloat(value));
      }

      function clipsOverflow(value) {
        return value === "hidden" || value === "clip";
      }

      function computeDebug(node) {
        const el = getNodeElement(node);
        if (!el) return null;

        const style = window.getComputedStyle(el);
        const overflowX = style.overflowX || style.overflow;
        const overflowY = style.overflowY || style.overflow;
        const fixedHeight =
          isFixedSize(style.height) || isFixedSize(style.maxHeight);
        const fixedWidth =
          isFixedSize(style.width) || isFixedSize(style.maxWidth);
        const clipX = clipsOverflow(overflowX) && fixedWidth;
        const clipY = clipsOverflow(overflowY) && fixedHeight;

        const original = {
          lineHeight: el.style.lineHeight,
          letterSpacing: el.style.letterSpacing,
          wordSpacing: el.style.wordSpacing
        };

        el.style.lineHeight = "1.5";
        el.style.letterSpacing = "0.12em";
        el.style.wordSpacing = "0.16em";

        const metrics = {
          scrollHeight: el.scrollHeight,
          clientHeight: el.clientHeight,
          scrollWidth: el.scrollWidth,
          clientWidth: el.clientWidth
        };

        const clippedX = clipX && (metrics.scrollWidth - metrics.clientWidth > 1);
        const clippedY = clipY && (metrics.scrollHeight - metrics.clientHeight > 1);

        el.style.lineHeight = original.lineHeight;
        el.style.letterSpacing = original.letterSpacing;
        el.style.wordSpacing = original.wordSpacing;

        const axis =
          clippedX && clippedY
            ? "horizontally and vertically"
            : clippedX
            ? "horizontally"
            : "vertically";
        const size =
          fixedWidth && fixedHeight
            ? "fixed width/height"
            : fixedWidth
            ? "fixed width"
            : "fixed height";

        return {
          reason: `Text becomes larger than the visible area after spacing is increased, so it gets cut off ${axis} (${size} with overflow hidden/clip).`,
          clipX,
          clipY,
          fixedWidth,
          fixedHeight,
          style: {
            display: style.display,
            overflowX: overflowX || "",
            overflowY: overflowY || "",
            width: style.width,
            maxWidth: style.maxWidth,
            height: style.height,
            maxHeight: style.maxHeight
          },
          metrics,
          clipping: {
            clippedX,
            clippedY
          },
          spacingApplied: {
            lineHeight: "1.5",
            letterSpacing: "0.12em",
            wordSpacing: "0.16em"
          },
        };
      }

      const violations = results?.violations || [];
      const rule = violations.find((r) => r.id === RULE_ID);
      if (!rule) return;

      (rule.nodes || []).forEach((node) => {
        const checks = []
          .concat(node.any || [], node.all || [], node.none || []);
        const check = checks.find((c) => c.id === CHECK_ID);
        if (!check || check.data) return;
        const data = computeDebug(node);
        if (data) check.data = data;
      });
    }

    function enrichHeadingsLabelsDebug(results) {
      const RULE_ID = "custom-wcag22-sc-246-headings-labels";
      const CHECK_ID = "sc-246-heading-label-has-text";

      function isHidden(node) {
        if (!node) return true;
        if (node.matches && node.matches("[hidden]")) return true;
        if (node.closest && node.closest('[aria-hidden="true"]')) return true;
        const style = window.getComputedStyle(node);
        if (!style) return false;
        if (style.display === "none") return true;
        if (style.visibility === "hidden") return true;
        if (parseFloat(style.opacity) === 0) return true;
        return false;
      }

      function getReferencedText(node, attr) {
        const raw = node.getAttribute(attr) || "";
        const ids = raw.trim().split(/\s+/).filter(Boolean);
        const texts = [];
        for (const id of ids) {
          const el = document.getElementById(id);
          if (!el) continue;
          const text = (el.textContent || "").trim();
          if (text.length) texts.push(text);
        }
        return { ids, texts, hasText: texts.length > 0 };
      }

      function getAccessibleText(node) {
        const textContent = (node.textContent || "").trim();
        if (textContent.length) return { hasText: true, source: "text", value: textContent };

        const ariaLabel = (node.getAttribute("aria-label") || "").trim();
        if (ariaLabel.length) return { hasText: true, source: "aria-label", value: ariaLabel };

        const labelledBy = getReferencedText(node, "aria-labelledby");
        if (labelledBy.hasText) {
          return {
            hasText: true,
            source: "aria-labelledby",
            value: labelledBy.texts.join(" "),
            ids: labelledBy.ids,
            texts: labelledBy.texts
          };
        }

        return { hasText: false, source: "none", value: "" };
      }

      const violations = results?.violations || [];
      const rule = violations.find((r) => r.id === RULE_ID);
      if (!rule) return;

      (rule.nodes || []).forEach((node) => {
        const checks = []
          .concat(node.any || [], node.all || [], node.none || []);
        const check = checks.find((c) => c.id === CHECK_ID);
        if (!check || check.data) return;
        const el = getNodeElement(node);
        if (!el) return;
        const style = window.getComputedStyle(el);
        const visible = isStyleVisible(style);
        const interactive = el.matches(INTERACTIVE_SELECTOR);
        const title = (el.getAttribute("title") || "").trim();

        check.data = {
          reason: title && interactive ? "TITLE_TOOLTIP" : "UNKNOWN",
          triggerType: title ? "title" : "hover/focus",
          matchedPatterns: [],
          matchedHandlers: [],
          dismissSignalsFound: [],
          dismissScope: "",
          isInteractive: interactive,
          isHidden: !visible
        };
      });
    }

    function enrichHoverFocusContentDebug(results) {
      const RULE_ID = "custom-wcag22-sc-1413-hover-focus-content";
      const CHECK_ID = "sc-1413-title-tooltip-disallowed";
      const INTERACTIVE_SELECTOR = [
        "a[href]",
        "button",
        "input:not([type=\"hidden\"])",
        "select",
        "textarea",
        "summary",
        "[role=\"button\"]",
        "[role=\"link\"]",
        "[role=\"menuitem\"]",
        "[role=\"tab\"]",
        "[role=\"switch\"]",
        "[role=\"checkbox\"]",
        "[role=\"radio\"]",
        "[role=\"option\"]",
        "[role=\"textbox\"]",
        "[tabindex]:not([tabindex=\"-1\"])"
      ].join(", ");
      const HOVER_FOCUS_ATTRS = [
        "onmouseover",
        "onmouseenter",
        "onmouseout",
        "onmouseleave",
        "onfocus",
        "onblur"
      ];
      const CONTENT_TOGGLE_PATTERNS = [
        "style.display",
        "display:",
        "style.visibility",
        "visibility:",
        "classList.add",
        "classList.remove",
        "toggle",
        "show",
        "hide",
        "open",
        "close",
        "tooltip",
        "popover",
        "aria-hidden",
        "aria-expanded"
      ];
      const ESCAPE_PATTERNS = [
        "escape",
        "esc",
        "key === 'escape'",
        "keycode === 27"
      ];

      function isVisible(style) {
        if (!style) return false;
        if (style.display === "none") return false;
        if (style.visibility === "hidden") return false;
        if (parseFloat(style.opacity) === 0) return false;
        return true;
      }

      function getInlineHandler(node, attr) {
        const value = node.getAttribute(attr);
        return value ? value.trim() : "";
      }

      function getInlineHandlers(node, attrs) {
        return attrs.map((attr) => getInlineHandler(node, attr)).join(" ");
      }

      function findContentPatternMatches(handlersByAttr) {
        const matchedPatterns = new Set();
        const matchedHandlers = new Set();
        for (const [attr, handler] of Object.entries(handlersByAttr)) {
          if (!handler) continue;
          const lower = handler.toLowerCase();
          let matched = false;
          for (const pattern of CONTENT_TOGGLE_PATTERNS) {
            if (lower.includes(pattern.toLowerCase())) {
              matchedPatterns.add(pattern);
              matched = true;
            }
          }
          if (matched) matchedHandlers.add(attr);
        }
        return {
          matchedPatterns: Array.from(matchedPatterns),
          matchedHandlers: Array.from(matchedHandlers)
        };
      }

      function hasEscapeHandler(handler) {
        if (!handler || !handler.trim()) return false;
        const lower = handler.toLowerCase();
        return ESCAPE_PATTERNS.some((pattern) => lower.includes(pattern));
      }

      function findDismissMechanism(node) {
        let current = node;
        let foundScope = "";
        const signals = new Set();
        while (current && current.nodeType === 1) {
          const scope = current === node ? "self" : "parent";
          if (getInlineHandler(current, "onkeydown").length > 0) {
            signals.add("onkeydown");
            if (!foundScope) foundScope = scope;
          }
          if (current.getAttribute("tabindex") === "0") {
            signals.add("tabindex=0");
            if (!foundScope) foundScope = scope;
          }
          if (current.hasAttribute("aria-expanded")) {
            signals.add("aria-expanded");
            if (!foundScope) foundScope = scope;
          }
          if (current.hasAttribute("aria-controls")) {
            signals.add("aria-controls");
            if (!foundScope) foundScope = scope;
          }

          const handlers = [
            getInlineHandlers(current, HOVER_FOCUS_ATTRS),
            getInlineHandler(current, "onkeydown")
          ].join(" ");
          if (hasEscapeHandler(handlers)) {
            signals.add("Escape");
            if (!foundScope) foundScope = scope;
          }

          current = current.parentElement;
        }
        return {
          found: signals.size > 0,
          signals: Array.from(signals),
          scope: foundScope
        };
      }

      const violations = results?.violations || [];
      const rule = violations.find((r) => r.id === RULE_ID);
      if (!rule) return;

      (rule.nodes || []).forEach((node) => {
        const checks = []
          .concat(node.any || [], node.all || [], node.none || []);
        const check = checks.find((c) => c.id === CHECK_ID);
        if (!check || check.data) return;
        const el = getNodeElement(node);
        if (!el) return;
        const style = window.getComputedStyle(el);
        const visible = isVisible(style);
        const title = (el.getAttribute("title") || "").trim();
        const interactive = !!(el.matches && el.matches(INTERACTIVE_SELECTOR));

        if (title && interactive) {
          check.data = {
            reason: "TITLE_TOOLTIP",
            triggerType: "title",
            matchedPatterns: [],
            matchedHandlers: [],
            dismissSignalsFound: [],
            dismissScope: "",
            isInteractive: true,
            isHidden: !visible
          };
          return;
        }

        const handlersByAttr = {};
        HOVER_FOCUS_ATTRS.forEach((attr) => {
          handlersByAttr[attr] = getInlineHandler(el, attr);
        });
        const handlerText = getInlineHandlers(el, HOVER_FOCUS_ATTRS);
        const patternMatches = findContentPatternMatches(handlersByAttr);
        const dismiss = findDismissMechanism(el);

        check.data = {
          reason: "NO_DISMISS",
          triggerType: "hover/focus",
          matchedPatterns: patternMatches.matchedPatterns,
          matchedHandlers: patternMatches.matchedHandlers,
          dismissSignalsFound: dismiss.signals,
          dismissScope: dismiss.scope || "",
          isInteractive: interactive,
          isHidden: !visible
        };
      });
    }

    function enrichReflowDebug(results) {
      const RULE_ID = "custom-wcag22-sc-1410-reflow";
      const CHECK_ID = "sc-1410-reflow-min-width-over-320";
      const MAX_REFLOW_WIDTH = 320;

      function parsePx(value) {
        if (!value) return null;
        if (value === "auto") return null;
        const num = parseFloat(value);
        return Number.isFinite(num) ? num : null;
      }

      function getInlineWidthPx(el) {
        if (!el || !el.style) return null;
        const raw = el.style.width;
        if (!raw || !raw.endsWith("px")) return null;
        return parsePx(raw);
      }

      const violations = results?.violations || [];
      const rule = violations.find((r) => r.id === RULE_ID);
      if (!rule) return;

      (rule.nodes || []).forEach((node) => {
        const checks = []
          .concat(node.any || [], node.all || [], node.none || []);
        const check = checks.find((c) => c.id === CHECK_ID);
        if (!check || check.data) return;
        const el = getNodeElement(node);
        if (!el) return;
        const style = window.getComputedStyle(el);
        const minWidth = parsePx(style.minWidth);
        const inlineWidth = getInlineWidthPx(el);
        const hasInlineWidthViolation =
          inlineWidth !== null && inlineWidth > MAX_REFLOW_WIDTH;
        const hasMinWidthViolation =
          minWidth !== null && minWidth > MAX_REFLOW_WIDTH;
        if (!hasInlineWidthViolation && !hasMinWidthViolation) return;
        const reasons = [];
        if (hasInlineWidthViolation) {
          reasons.push(`inline width ${inlineWidth}px > ${MAX_REFLOW_WIDTH}px`);
        }
        if (hasMinWidthViolation) {
          reasons.push(`min-width ${minWidth}px > ${MAX_REFLOW_WIDTH}px`);
        }
        check.data = {
          reason: `Element exceeds reflow width: ${reasons.join(" and ")}.`,
          minWidth,
          inlineWidth,
          limit: MAX_REFLOW_WIDTH,
          style: {
            display: style.display,
            minWidth: style.minWidth,
            width: style.width
          }
        };
      });
    }

    function enrichOnFocusDebug(results) {
      const RULE_ID = "custom-wcag22-sc-321-on-focus";
      const CHECK_ID = "sc-321-inline-onfocus-context-change";
      const CONTEXT_CHANGE_PATTERNS = [
        { id: "location-assign", regex: /\blocation\.assign\s*\(/i },
        { id: "location-replace", regex: /\blocation\.replace\s*\(/i },
        { id: "location-href", regex: /\blocation\.href\s*=/i },
        { id: "window-location", regex: /\bwindow\.location\s*=/i },
        { id: "document-location", regex: /\bdocument\.location\s*=/i },
        { id: "location-equals", regex: /\blocation\s*=\s*/i },
        { id: "window-open", regex: /\bwindow\.open\s*\(/i },
        { id: "document-open", regex: /\bdocument\.open\s*\(/i },
        { id: "form-submit", regex: /\bsubmit\s*\(/i }
      ];

      const violations = results?.violations || [];
      const rule = violations.find((r) => r.id === RULE_ID);
      if (!rule) return;

      (rule.nodes || []).forEach((node) => {
        const checks = []
          .concat(node.any || [], node.all || [], node.none || []);
        const check = checks.find((c) => c.id === CHECK_ID);
        if (!check || check.data) return;
        const el = getNodeElement(node);
        if (!el) return;
        const handler = (el.getAttribute("onfocus") || "").trim();
        if (!handler) return;
        const matches = CONTEXT_CHANGE_PATTERNS.filter((pattern) =>
          pattern.regex.test(handler)
        ).map((pattern) => pattern.id);
        if (!matches.length) return;
        check.data = {
          reason: "Inline onfocus triggers a context change pattern.",
          handler,
          patterns: matches
        };
      });
    }

    function enrichOnInputDebug(results) {
      const RULE_ID = "custom-wcag22-sc-322-on-input";
      const CHECK_ID = "sc-322-inline-oninput-context-change";
      const CONTEXT_CHANGE_PATTERNS = [
        { id: "location-assign", regex: /\blocation\.assign\s*\(/i },
        { id: "location-replace", regex: /\blocation\.replace\s*\(/i },
        { id: "location-href", regex: /\blocation\.href\s*=/i },
        { id: "window-location", regex: /\bwindow\.location\s*=/i },
        { id: "document-location", regex: /\bdocument\.location\s*=/i },
        { id: "location-equals", regex: /\blocation\s*=\s*/i },
        { id: "window-open", regex: /\bwindow\.open\s*\(/i },
        { id: "document-open", regex: /\bdocument\.open\s*\(/i },
        { id: "form-submit", regex: /\bsubmit\s*\(/i }
      ];

      function getInlineHandlers(el) {
        const handlers = [];
        const onInput = (el.getAttribute("oninput") || "").trim();
        const onChange = (el.getAttribute("onchange") || "").trim();
        if (onInput) handlers.push(onInput);
        if (onChange) handlers.push(onChange);
        return handlers;
      }

      const violations = results?.violations || [];
      const rule = violations.find((r) => r.id === RULE_ID);
      if (!rule) return;

      (rule.nodes || []).forEach((node) => {
        const checks = []
          .concat(node.any || [], node.all || [], node.none || []);
        const check = checks.find((c) => c.id === CHECK_ID);
        if (!check || check.data) return;
        const el = getNodeElement(node);
        if (!el) return;
        const handlers = getInlineHandlers(el);
        if (!handlers.length) return;
        const matches = CONTEXT_CHANGE_PATTERNS.filter((pattern) =>
          handlers.some((handler) => pattern.regex.test(handler))
        ).map((pattern) => pattern.id);
        if (!matches.length) return;
        check.data = {
          reason: "Inline oninput/onchange triggers a context change pattern.",
          handlers,
          patterns: matches
        };
      });
    }

    function enrichFocusNotObscuredDebug(results) {
      const RULE_ID = "custom-wcag22-sc-2411-focus-not-obscured-minimum";
      const CHECK_ID = "sc-2411-focus-not-obscured-minimum-visible";
      const FOCUSABLE_TAGS = new Set(["A", "BUTTON", "INPUT", "SELECT", "TEXTAREA"]);

      function isVisible(el) {
        const style = window.getComputedStyle(el);
        if (!style) return false;
        if (style.display === "none") return false;
        if (style.visibility === "hidden") return false;
        if (parseFloat(style.opacity || "1") === 0) return false;
        return true;
      }

      function isHiddenInput(el) {
        return el.tagName === "INPUT" && el.type === "hidden";
      }

      function isDisabled(el) {
        return "disabled" in el && el.disabled === true;
      }

      function isFocusable(el) {
        if (isHiddenInput(el)) return false;
        if (isDisabled(el)) return false;
        if (el.isContentEditable) return true;
        if (el.tabIndex >= 0) return true;
        if (FOCUSABLE_TAGS.has(el.tagName)) {
          if (el.tagName === "A") return el.hasAttribute("href");
          return true;
        }
        return false;
      }

      function pointInViewport(point, vw, vh) {
        return (
          point.x >= 0 &&
          point.y >= 0 &&
          point.x <= vw - 1 &&
          point.y <= vh - 1
        );
      }

      function getSamplePoints(rect) {
        const inset = 1;
        const points = [
          { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 },
          { x: rect.left + inset, y: rect.top + inset },
          { x: rect.right - inset, y: rect.top + inset },
          { x: rect.left + inset, y: rect.bottom - inset },
          { x: rect.right - inset, y: rect.bottom - inset }
        ];
        return points.filter(
          (p) =>
            p.x >= rect.left &&
            p.x <= rect.right &&
            p.y >= rect.top &&
            p.y <= rect.bottom
        );
      }

      function nthOfType(el) {
        if (!el || !el.parentElement) return 1;
        const tag = el.tagName;
        let index = 0;
        const siblings = el.parentElement.children;
        for (let i = 0; i < siblings.length; i += 1) {
          if (siblings[i].tagName === tag) {
            index += 1;
            if (siblings[i] === el) return index;
          }
        }
        return 1;
      }

      function buildCssSegment(el) {
        if (!el || !el.tagName) return "";
        const tag = el.tagName.toLowerCase();
        if (el.id) return `#${el.id}`;
        const classes = el.classList && el.classList.length
          ? "." + Array.from(el.classList).slice(0, 2).join(".")
          : "";
        const index = nthOfType(el);
        return `${tag}${classes}${index > 1 ? `:nth-of-type(${index})` : ""}`;
      }

      function describeElement(el) {
        if (!el || !el.tagName) return "";
        if (el.id) return `#${el.id}`;
        const parts = [];
        let current = el;
        for (let i = 0; i < 3 && current; i += 1) {
          const segment = buildCssSegment(current);
          if (!segment) break;
          parts.unshift(segment);
          current = current.parentElement;
        }
        return parts.join(" > ");
      }

      const violations = results?.violations || [];
      const rule = violations.find((r) => r.id === RULE_ID);
      if (!rule) return;

      (rule.nodes || []).forEach((node) => {
        const checks = []
          .concat(node.any || [], node.all || [], node.none || []);
        let check = checks.find((c) => c.id === CHECK_ID);
        if (check && check.data) return;

        const el = getNodeElement(node);
        if (!check) {
          if (!Array.isArray(node.any)) node.any = [];
          check = { id: CHECK_ID };
          node.any.push(check);
        }

        if (!el) {
          check.data = {
            reason: "Unable to resolve element for focus visibility analysis.",
            viewport: null,
            boundingBox: null,
            samplePoints: []
          };
          return;
        }

        if (!isFocusable(el) || !isVisible(el)) {
          check.data = {
            reason: "Element is not focusable or not visible at analysis time.",
            viewport: null,
            boundingBox: null,
            samplePoints: []
          };
          return;
        }

        const rect = el.getBoundingClientRect();
        if (!rect || rect.width <= 0 || rect.height <= 0) {
          check.data = {
            reason: "Element has zero size at analysis time.",
            viewport: null,
            boundingBox: null,
            samplePoints: []
          };
          return;
        }

        const vw = window.innerWidth || document.documentElement.clientWidth;
        const vh = window.innerHeight || document.documentElement.clientHeight;
        const points = getSamplePoints(rect).filter((point) =>
          pointInViewport(point, vw, vh)
        );

        check.data = {
          reason: "Focusable element is fully covered at sampled points.",
          viewport: { width: vw, height: vh },
          boundingBox: {
            left: rect.left,
            top: rect.top,
            right: rect.right,
            bottom: rect.bottom,
            width: rect.width,
            height: rect.height
          },
          samplePoints: points.map((point) => {
            const topElement = document.elementFromPoint(point.x, point.y);
            return {
              x: Math.round(point.x),
              y: Math.round(point.y),
              topElement: describeElement(topElement),
              visible: topElement === el || el.contains(topElement)
            };
          })
        };
      });
    }

    function enrichConsistentIdentificationDebug(results) {
      const RULE_ID = "custom-wcag22-sc-324-consistent-identification";
      const CHECK_ID = "sc-324-consistent-identification";
      const SELECTOR = "a[href], [data-consistent-id]";

      function normalizeText(text) {
        if (!text) return "";
        return text.replace(/\\s+/g, " ").trim().toLowerCase();
      }

      function getLabelledbyText(node) {
        const raw = (node.getAttribute("aria-labelledby") || "").trim();
        if (!raw) return "";
        const ids = raw.split(/\\s+/).filter(Boolean);
        const parts = [];
        for (const id of ids) {
          const el = document.getElementById(id);
          if (!el) continue;
          const text = (el.textContent || "").trim();
          if (text) parts.push(text);
        }
        return parts.join(" ").trim();
      }

      function getAltText(node) {
        const imgs = Array.from(node.querySelectorAll("img[alt]"));
        const parts = imgs
          .map((img) => (img.getAttribute("alt") || "").trim())
          .filter(Boolean);
        return parts.join(" ").trim();
      }

      function getAccessibleName(node) {
        const ariaLabel = (node.getAttribute("aria-label") || "").trim();
        if (ariaLabel) return normalizeText(ariaLabel);

        const labelledby = getLabelledbyText(node);
        if (labelledby) return normalizeText(labelledby);

        if (node.tagName && node.tagName.toLowerCase() === "input") {
          const type = (node.getAttribute("type") || "").toLowerCase();
          if (type === "submit" || type === "button" || type === "reset") {
            const value = (node.getAttribute("value") || "").trim();
            if (value) return normalizeText(value);
          }
        }

        const textContent = (node.textContent || "").trim();
        if (textContent) return normalizeText(textContent);

        const altText = getAltText(node);
        if (altText) return normalizeText(altText);

        return "";
      }

      function getConsistencyKey(node) {
        const dataId = (node.getAttribute("data-consistent-id") || "").trim();
        if (dataId) return `data:${dataId}`;

        if (node.tagName && node.tagName.toLowerCase() === "a") {
          const href = (node.getAttribute("href") || "").trim();
          if (!href) return null;
          if (/^\\s*javascript:/i.test(href)) return null;
          return `href:${href}`;
        }

        return null;
      }

      function buildGroups() {
        const groups = new Map();
        const nodes = Array.from(document.querySelectorAll(SELECTOR));
        for (const node of nodes) {
          const key = getConsistencyKey(node);
          if (!key) continue;
          const name = getAccessibleName(node);
          if (!groups.has(key)) groups.set(key, []);
          groups.get(key).push({ node, name });
        }
        return groups;
      }

      function getConsistencyData(node, groups) {
        const key = getConsistencyKey(node);
        if (!key) return null;
        const group = groups.get(key) || [];
        if (group.length < 2) return null;

        const names = group.map((item) => item.name).filter(Boolean);
        if (names.length < 2) return null;

        const distinct = Array.from(new Set(names));
        if (distinct.length <= 1) return null;

        return {
          reason: "Elements sharing the same destination/id have inconsistent names.",
          key,
          currentName: getAccessibleName(node),
          groupSize: group.length,
          distinctNames: distinct
        };
      }

      const violations = results?.violations || [];
      const rule = violations.find((r) => r.id === RULE_ID);
      if (!rule) return;

      const groups = buildGroups();

      (rule.nodes || []).forEach((node) => {
        const checks = []
          .concat(node.any || [], node.all || [], node.none || []);
        const check = checks.find((c) => c.id === CHECK_ID);
        if (!check || check.data) return;
        const el = getNodeElement(node);
        if (!el) return;
        const data = getConsistencyData(el, groups);
        if (data) check.data = data;
      });
    }

    function enrichNonTextContrastDebug(results) {
      const RULE_ID = "custom-wcag22-sc-1411-non-text-contrast";
      const CHECK_ID = "sc-1411-non-text-contrast-min-3";
      const MIN_CONTRAST = 3;

      function parseColor(value) {
        if (!value) return null;
        if (value === "transparent") {
          return { r: 0, g: 0, b: 0, a: 0 };
        }

        const match = value.match(/rgba?\\(([^)]+)\\)/);
        if (!match) return null;

        const parts = match[1].split(",").map((part) => part.trim());
        if (parts.length < 3) return null;

        const r = parseFloat(parts[0]);
        const g = parseFloat(parts[1]);
        const b = parseFloat(parts[2]);
        const a = parts.length >= 4 ? parseFloat(parts[3]) : 1;

        if (![r, g, b, a].every((n) => Number.isFinite(n))) return null;

        return { r, g, b, a };
      }

      function blendColors(foreground, background) {
        const alpha = foreground.a;
        return {
          r: foreground.r * alpha + background.r * (1 - alpha),
          g: foreground.g * alpha + background.g * (1 - alpha),
          b: foreground.b * alpha + background.b * (1 - alpha),
          a: 1
        };
      }

      function srgbToLinear(channel) {
        const value = channel / 255;
        return value <= 0.03928
          ? value / 12.92
          : Math.pow((value + 0.055) / 1.055, 2.4);
      }

      function relativeLuminance(color) {
        return (
          0.2126 * srgbToLinear(color.r) +
          0.7152 * srgbToLinear(color.g) +
          0.0722 * srgbToLinear(color.b)
        );
      }

      function contrastRatio(colorA, colorB) {
        if (!colorA || !colorB) return null;
        const lumA = relativeLuminance(colorA);
        const lumB = relativeLuminance(colorB);
        const light = Math.max(lumA, lumB);
        const dark = Math.min(lumA, lumB);
        return (light + 0.05) / (dark + 0.05);
      }

      function toRgbaString(color) {
        if (!color) return "";
        const r = Math.round(color.r);
        const g = Math.round(color.g);
        const b = Math.round(color.b);
        const a = Number.isFinite(color.a) ? color.a : 1;
        return `rgba(${r}, ${g}, ${b}, ${a})`;
      }

      function isVisible(style) {
        if (!style) return false;
        if (style.display === "none") return false;
        if (style.visibility === "hidden") return false;
        if (parseFloat(style.opacity) === 0) return false;
        return true;
      }

      function getEffectiveBackground(element) {
        const layers = [];
        let current = element;

        while (current && current.nodeType === 1) {
          const style = window.getComputedStyle(current);
          const color = parseColor(style.backgroundColor);
          if (color && color.a > 0) {
            layers.push(color);
          }
          current = current.parentElement;
        }

        layers.reverse();

        let result = { r: 255, g: 255, b: 255, a: 1 };
        for (const layer of layers) {
          result = blendColors(layer, result);
        }

        return result;
      }

      function hasBorder(style) {
        const widths = [
          style.borderTopWidth,
          style.borderRightWidth,
          style.borderBottomWidth,
          style.borderLeftWidth
        ];

        return widths.some((value) => parseFloat(value) > 0);
      }

      function getBorderColor(style) {
        if (!hasBorder(style)) return null;
        const color = parseColor(style.borderTopColor);
        if (!color || color.a === 0) return null;
        return color;
      }

      function getBackgroundColor(style) {
        const color = parseColor(style.backgroundColor);
        if (!color || color.a === 0) return null;
        return color;
      }

      const violations = results?.violations || [];
      const rule = violations.find((r) => r.id === RULE_ID);
      if (!rule) return;

      (rule.nodes || []).forEach((node) => {
        const checks = []
          .concat(node.any || [], node.all || [], node.none || []);
        let check = checks.find((c) => c.id === CHECK_ID);
        const el = getNodeElement(node);
        if (!el) {
          if (!check) {
            if (!Array.isArray(node.any)) node.any = [];
            check = { id: CHECK_ID };
            node.any.push(check);
          }
          if (!check.data) {
            check.data = {
              reason:
                "Unable to resolve element for color calculation (possible cross-origin iframe or closed shadow root).",
              elementXPath: node.xpath || "",
              parentXPath: node.parentXPath || ""
            };
          }
          return;
        }
        const style = window.getComputedStyle(el);

        if (check && check.data) {
          if (!check.data.elementXPath) {
            check.data.elementXPath = node.xpath || buildXPath(el);
          }
          if (!check.data.parentXPath) {
            check.data.parentXPath =
              node.parentXPath || (el.parentElement ? buildXPath(el.parentElement) : "");
          }
          return;
        }

        if (!isVisible(style)) return;
        if (el.tagName === "INPUT" && el.type === "hidden") return;

        const parentBackground = getEffectiveBackground(el.parentElement);
        const borderColor = getBorderColor(style);
        let componentColor = null;
        let source = "";

        if (borderColor) {
          componentColor = blendColors(borderColor, parentBackground);
          source = "border";
        } else {
          if (style.backgroundImage && style.backgroundImage !== "none") {
            return;
          }

          const backgroundColor = getBackgroundColor(style);
          if (!backgroundColor) return;

          componentColor = blendColors(backgroundColor, parentBackground);
          source = "background";
        }

        const ratio = contrastRatio(componentColor, parentBackground);
        if (ratio === null || ratio >= MIN_CONTRAST) return;

        if (!check) {
          if (!Array.isArray(node.any)) node.any = [];
          check = { id: CHECK_ID };
          node.any.push(check);
        }
        const elementXPath = node.xpath || buildXPath(el);
        const parentXPath =
          node.parentXPath || (el.parentElement ? buildXPath(el.parentElement) : "");

        const debugData = {
          reason: `Contrast ratio ${ratio.toFixed(2)} is below ${MIN_CONTRAST}:1 using ${source} color.`,
          ratio,
          minContrast: MIN_CONTRAST,
          source,
          componentColor: toRgbaString(componentColor),
          parentBackground: toRgbaString(parentBackground),
          elementXPath,
          parentXPath,
          style: {
            borderTopWidth: style.borderTopWidth,
            borderTopColor: style.borderTopColor,
            backgroundColor: style.backgroundColor
          }
        };
        check.data = debugData;
        node.__nonTextContrastDebug = debugData;
      });
    }

    function logNonTextContrastDebug(results) {
      const config = window.__AXE_RUN_CONFIG__ || {};
      if (config.showDebugDetails !== true) return;
      const RULE_ID = "custom-wcag22-sc-1411-non-text-contrast";
      const CHECK_ID = "sc-1411-non-text-contrast-min-3";
      const violations = results?.violations || [];
      const rule = violations.find((r) => r.id === RULE_ID);
      if (!rule) return;

      (rule.nodes || []).forEach((node) => {
        const checks = []
          .concat(node.any || [], node.all || [], node.none || []);
        const check = checks.find((c) => c.id === CHECK_ID);
        const data = check?.data;
        if (data) {
          console.log("[AXE_DEBUG][SC-1411][data]", data);
        } else {
          console.log("[AXE_DEBUG][SC-1411][no-data]", {
            target: node.target || [],
            xpath: node.xpath || "",
            html: node.html || "",
            failureSummary: node.failureSummary || ""
          });
        }
      });
    }

    axe.run(document, options).then(results => {
      const scanCompletedAt = Date.now();
      console.log(
        "[AXE_SCAN_COMPLETED_AT]",
        window.location.href,
        "ts=",
        scanCompletedAt,
        "durationMs=",
        scanCompletedAt - scanStartedAt
      );
      const ruleExecution = [];

      const allRuleBuckets = [
        { key: "violations", items: results.violations || [] },
        { key: "passes", items: results.passes || [] },
        { key: "incomplete", items: results.incomplete || [] },
        { key: "inapplicable", items: results.inapplicable || [] }
      ];

      allRuleBuckets.forEach((bucket) => {
        bucket.items.forEach((rule) => {
          (rule.nodes || []).forEach((node) => {
            const checks = []
              .concat(node.any || [], node.all || [], node.none || []);

            checks.forEach((check) => {
              ruleExecution.push({
                ruleId: rule.id,
                checkId: check.id,
                outcome: check.result,
                bucket: bucket.key,
                impact: rule.impact || "",
                source: (rule.tags || []).includes("custom") || (rule.id || "").startsWith("custom-")
                  ? "custom"
                  : "builtin"
              });
            });
          });
        });
      });

      function logStep(label, startTs) {
        const now = Date.now();
        console.log(`[AXE_ENRICH] ${label} durationMs=`, now - startTs);
      }

      function safeEnrich(label, fn) {
        const stepStart = Date.now();
        try {
          fn(results);
        } catch (error) {
          console.error(`[AXE_ENRICH_ERROR] ${label}`, error);
        }
        logStep(label, stepStart);
      }

      safeEnrich("attachNodeXpaths", attachNodeXpaths);
      safeEnrich("enrichTextSpacingDebug", enrichTextSpacingDebug);
      safeEnrich("enrichHeadingsLabelsDebug", enrichHeadingsLabelsDebug);
      safeEnrich("enrichHoverFocusContentDebug", enrichHoverFocusContentDebug);
      safeEnrich("enrichReflowDebug", enrichReflowDebug);
      safeEnrich("enrichOnFocusDebug", enrichOnFocusDebug);
      safeEnrich("enrichOnInputDebug", enrichOnInputDebug);
      safeEnrich("enrichFocusNotObscuredDebug", enrichFocusNotObscuredDebug);
      safeEnrich("enrichConsistentIdentificationDebug", enrichConsistentIdentificationDebug);
      safeEnrich("enrichNonTextContrastDebug", enrichNonTextContrastDebug);
      safeEnrich("logNonTextContrastDebug", logNonTextContrastDebug);

      results.__debug = {
        url: window.location.href,
        startedAt: scanStartedAt,
        completedAt: scanCompletedAt,
        durationMs: scanCompletedAt - scanStartedAt,
        options,
        ruleExecutionCount: ruleExecution.length
      };

      try {
        console.log("[AXE_RESULTS_DISPATCH_START]");
        window.dispatchEvent(
          new CustomEvent("AXE_RESULTS", { detail: results })
        );
        console.log("[AXE_RESULTS_DISPATCH_DONE]");
      } catch (dispatchError) {
        console.error("[AXE_RESULTS_DISPATCH_ERROR]", dispatchError);
      }
      console.log("[AXE_SCAN_COMPLETED]", results);

    }).catch((error) => {
      console.error("[AXE_SCAN_ERROR]", error);
    }).finally(() => {
    axeScanInProgress = false;
    console.log("[AXE_RUNNER] Scan lock released");
  });

  });

  /*async function runScan() {
    console.log("[AXE_SCAN_STARTED]", window.location.href);

    const results = await window.axe.run(document);

    console.log("[AXE_SCAN_COMPLETED]", {
      violations: results.violations.length
    });

    // Send results back to injector
    window.dispatchEvent(
      new CustomEvent("AXE_RESULTS", { detail: results })
    );
  }*/

  // dY"' THIS LISTENER IS REQUIRED
  //window.addEventListener("AXE_RUN_SCAN", runScan);
})();
