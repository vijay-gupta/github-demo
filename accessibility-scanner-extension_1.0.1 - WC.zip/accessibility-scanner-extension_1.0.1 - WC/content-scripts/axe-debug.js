(function () {
  if (window.__AXE_DEBUG__) return;

  const initialConfig = window.__AXE_DEBUG_CONFIG__ || {};
  const state = {
    enabled: initialConfig.enabled === true,
    overlay: initialConfig.overlay === true,
    scanId: initialConfig.scanId || null,
    url: initialConfig.url || window.location.href,
    events: [],
    registeredRules: new Map(),
    registeredChecks: new Map()
  };

  let overlayEl = null;

  function now() {
    return Date.now();
  }

  function ensureOverlay() {
    if (!state.overlay) return;
    if (overlayEl) return;
    overlayEl = document.createElement("div");
    overlayEl.style.position = "fixed";
    overlayEl.style.bottom = "12px";
    overlayEl.style.right = "12px";
    overlayEl.style.zIndex = "2147483647";
    overlayEl.style.background = "rgba(0,0,0,0.8)";
    overlayEl.style.color = "#fff";
    overlayEl.style.font = "12px/1.4 monospace";
    overlayEl.style.padding = "8px 10px";
    overlayEl.style.borderRadius = "6px";
    overlayEl.style.maxWidth = "320px";
    overlayEl.style.pointerEvents = "none";
    overlayEl.textContent = "AXE DEBUG READY";
    document.documentElement.appendChild(overlayEl);
  }

  function updateOverlay(event) {
    if (!state.overlay || !overlayEl) return;
    const phase = event.phase || "UNKNOWN";
    const label = event.event || "EVENT";
    overlayEl.textContent = `AXE DEBUG ${phase} ${label} (${state.scanId || "no-scan"})`;
  }

  function emit(event) {
    if (!state.enabled) return;
    const payload = Object.assign(
      {
        eventId: `${now()}-${Math.random().toString(16).slice(2)}`,
        scanId: state.scanId,
        url: state.url,
        ts: now(),
        origin: "page"
      },
      event
    );

    state.events.push(payload);
    console.log("[AXE_DEBUG]", payload);
    window.dispatchEvent(new CustomEvent("AXE_DEBUG_EVENT", { detail: payload }));
    ensureOverlay();
    updateOverlay(payload);
  }

  function setContext(next) {
    if (!next) return;
    if (typeof next.enabled === "boolean") state.enabled = next.enabled;
    if (typeof next.overlay === "boolean") state.overlay = next.overlay;
    if (typeof next.scanId === "string") state.scanId = next.scanId;
    if (typeof next.url === "string") state.url = next.url;
  }

  function classifyRuleSource(rule) {
    if (!rule) return "unknown";
    if (rule.tags && rule.tags.includes("custom")) return "custom";
    if (typeof rule.id === "string" && rule.id.startsWith("custom-")) return "custom";
    return "builtin";
  }

  function onAxeReady(axe) {
    if (!axe || axe.__axeDebugWrapped__) return;
    const originalConfigure = axe.configure;

    axe.configure = function (config) {
      const rules = Array.isArray(config?.rules) ? config.rules : [];
      const checks = Array.isArray(config?.checks) ? config.checks : [];

      rules.forEach((rule) => {
        state.registeredRules.set(rule.id, rule);
        emit({
          phase: "RULE_REGISTRY",
          event: "RULE_REGISTER",
          ruleId: rule.id,
          source: classifyRuleSource(rule),
          data: { tags: rule.tags || [], selector: rule.selector || "" }
        });
      });

      checks.forEach((check) => {
        state.registeredChecks.set(check.id, check);
        emit({
          phase: "RULE_REGISTRY",
          event: "CHECK_REGISTER",
          checkId: check.id,
          data: { impact: check.metadata?.impact || "" }
        });
      });

      return originalConfigure.call(this, config);
    };

    axe.__axeDebugWrapped__ = true;
    emit({
      phase: "CORE_INJECT",
      event: "AXE_CONFIGURE_WRAPPED"
    });
  }

  window.addEventListener("securitypolicyviolation", (e) => {
    emit({
      phase: "CORE_INJECT",
      event: "CSP_VIOLATION",
      data: {
        blockedURI: e.blockedURI,
        violatedDirective: e.violatedDirective,
        effectiveDirective: e.effectiveDirective,
        originalPolicy: e.originalPolicy,
        sourceFile: e.sourceFile,
        lineNumber: e.lineNumber,
        columnNumber: e.columnNumber
      }
    });
  });

  window.__AXE_DEBUG__ = {
    emit,
    setContext,
    onAxeReady,
    state
  };

  window.addEventListener("AXE_DEBUG_CONFIG", (event) => {
    setContext(event?.detail || {});
    if (state.enabled) {
      emit({
        phase: "INIT",
        event: "DEBUG_CONFIG_UPDATED",
        data: { overlay: state.overlay }
      });
    }
  });

  if (state.enabled) {
    emit({
      phase: "INIT",
      event: "DEBUG_READY",
      data: { overlay: state.overlay }
    });
  }
})();
