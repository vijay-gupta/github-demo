/**
 * =========================================================
 * ACCESSIBILITY SCANNER – INJECTOR
 * ---------------------------------------------------------
 * ROLE:
 *  - Runs as CONTENT SCRIPT
 *  - Uses chrome.runtime APIs
 *  - Injects PAGE-CONTEXT scripts
 * =========================================================
 */

(function () {

  console.log("[INJECTOR] Running on:", window.location.href);
  let currentScanContext = null;
  let registryTimeoutId = null;

  /**
   * ---------------------------------------------------------
   * 1. Notify background that page is ready
   * ---------------------------------------------------------
   */
  try {
    chrome.runtime.sendMessage({
      type: "PAGE_READY",
      url: window.location.href
    });
    console.log("[INJECTOR] PAGE_READY sent");
  } catch (e) {
    console.error("[INJECTOR] Failed to send PAGE_READY", e);
  }

  /**
   * ---------------------------------------------------------
   * 2. Listen for START_SCAN from background / popup
   * ---------------------------------------------------------
   */
  chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {

    if (message.type === "START_SCAN") {
      console.log("[INJECTOR] START_SCAN received");

      currentScanContext = message.scanContext || {
        scanId: message.scanId || null,
        debug: message.debug || { enabled: false }
      };

      chrome.storage.local.get("reportSettings", (data) => {
        const settings = Object.assign(
          { showDebugDetails: true },
          data.reportSettings || {}
        );
        currentScanContext.reportSettings = settings;
        injectAxePipeline(currentScanContext);
        sendResponse({ status: "SCAN_TRIGGERED" });
      });
      return true;
    }
  });


function injectRunConfig(reportSettings) {
  const settings = Object.assign(
    { showDebugDetails: true },
    reportSettings || {}
  );
  const script = document.createElement("script");
  script.src = chrome.runtime.getURL("content-scripts/axe-run-config.js");
  script.dataset.runConfig = JSON.stringify(settings);
  script.onload = () => {
    console.log("[INJECTOR] AXE run config injected");
    script.remove();
  };
  document.documentElement.appendChild(script);
}

  /**
   * =========================================================
   * AXE PIPELINE ORCHESTRATION
   * =========================================================
   */

  function injectAxePipeline(scanContext) {

    // -------------------------------------------------------
    // [MODIFIED] Separate flags for core and custom rules
    // -------------------------------------------------------
    if (window.__AXE_PIPELINE_READY__) {
      console.log("[INJECTOR] Axe pipeline already ready, re-running scan");
      injectRunConfig(scanContext?.reportSettings);
      window.dispatchEvent(new Event("AXE_RUN_SCAN"));
      return;
    }

    window.__AXE_PIPELINE_READY__ = true;
    // -------------------------------------------------------
    // STEP 1: Inject axe-core
    // -------------------------------------------------------
    const axeScript = document.createElement("script");
    axeScript.src = chrome.runtime.getURL("lib/axe-core/axe.min.js");

    axeScript.onload = function () {
      console.log("[INJECTOR] axe-core injected");
 
      injectCustomRulesRegistry();
    };

    axeScript.onerror = function (e) {
      console.error("[INJECTOR] Failed to inject axe-core", e);
    };

    document.documentElement.appendChild(axeScript);
  }

  /**
   * ---------------------------------------------------------
   * STEP 2: Inject custom rules registry
   * ---------------------------------------------------------
   */
  function injectCustomRulesRegistry() {

    const registryScript = document.createElement("script");
    registryScript.src = chrome.runtime.getURL("custom_rules/registry.js");

    registryScript.onload = function () {
      console.log("[INJECTOR] custom rules registry injected");
    };

    registryScript.onerror = function (e) {
    };

    document.documentElement.appendChild(registryScript);

    // -------------------------------------------------------
    // [ADDED] Wait for registry readiness signal
    // -------------------------------------------------------
    window.addEventListener(
      "AXE_CUSTOM_RULES_REGISTRY_READY",
        function (e) {
          if (registryTimeoutId) {
            clearTimeout(registryTimeoutId);
            registryTimeoutId = null;
          }
          injectCustomRules(e.detail || []);
        },
        { once: true }
    );

    registryTimeoutId = window.setTimeout(() => {
    }, 5000);
  }

  /**
   * ---------------------------------------------------------
   * STEP 3: Inject each custom rule file sequentially
   * ---------------------------------------------------------
   */
  function injectCustomRules(rules) {
  let index = 0;

    function loadNextRule() {
      if (index >= rules.length) {
        injectAxeRunner();
        return;
      }

      const script = document.createElement("script");
      script.src = chrome.runtime.getURL(rules[index]);

      script.onload = function () {
        console.log("[INJECTOR] custom rule loaded:", rules[index]);
        index++;
        loadNextRule();
      };

      script.onerror = function (e) {
        index++;
        loadNextRule();
      };

      document.documentElement.appendChild(script);
    }

    loadNextRule();
  }


  /**
   * ---------------------------------------------------------
   * STEP 4: Inject axe-runner and trigger scan
   * ---------------------------------------------------------
   */
  function injectAxeRunner() {

    injectRunConfig(currentScanContext?.reportSettings);
    const runnerScript = document.createElement("script");
    runnerScript.src = chrome.runtime.getURL("content-scripts/axe-runner.js");

    runnerScript.onload = function () {
      console.log("[INJECTOR] axe-runner injected successfully");
      window.dispatchEvent(new Event("AXE_RUN_SCAN"));
      console.log("[INJECTOR] AXE_RUN_SCAN dispatched");
    };

    runnerScript.onerror = function (e) {
      console.error("[INJECTOR] Failed to inject axe-runner", e);
    };

    document.documentElement.appendChild(runnerScript);
  }

  /**
   * ---------------------------------------------------------
   * 5. Bridge AXE results from PAGE → EXTENSION
   * ---------------------------------------------------------
   */
  const SCROLL_STEP_RATIO = 0.8;
  const SCROLL_WAIT_MS = 200;
  const SCROLL_MAX_STEPS = 60;
  const SCROLL_MAX_MS = 20000;

  function resolveElementByTargets(targets) {
    if (!Array.isArray(targets)) return null;
    for (let i = 0; i < targets.length; i += 1) {
      const selector = targets[i];
      if (!selector) continue;
      try {
        const hit = document.querySelector(selector);
        if (hit) return hit;
      } catch (_) {
        // ignore invalid selector
      }
    }
    return null;
  }

  function resolveElementByXPath(xpath) {
    if (!xpath) return null;
    try {
      const result = document.evaluate(
        xpath,
        document,
        null,
        XPathResult.FIRST_ORDERED_NODE_TYPE,
        null
      );
      return result.singleNodeValue || null;
    } catch (_) {
      return null;
    }
  }

  function resolveNodeElement(node) {
    const byTarget = resolveElementByTargets(node?.target || []);
    if (byTarget) return byTarget;
    return resolveElementByXPath(node?.xpath || "");
  }

  function describeElement(el) {
    if (!el || !el.tagName) return "";
    const tag = el.tagName.toLowerCase();
    const id = el.id ? `#${el.id}` : "";
    const className = (el.className || "").toString().trim();
    const cls = className ? `.${className.split(/\\s+/).join(".")}` : "";
    return `${tag}${id}${cls}`;
  }

  function buildBoundingBox(rect) {
    if (!rect) return null;
    return {
      top: rect.top,
      left: rect.left,
      right: rect.right,
      bottom: rect.bottom,
      width: rect.width,
      height: rect.height
    };
  }

  function isInViewport(rect, viewportWidth, viewportHeight) {
    return (
      rect.bottom > 0 &&
      rect.right > 0 &&
      rect.top < viewportHeight &&
      rect.left < viewportWidth
    );
  }

  function computeVisibilityStatus(node, el, seenInViewport) {
    const debug = {
      boundingBox: null,
      coveringElement: "",
      computedStyle: {}
    };

    if (!el || !document.documentElement.contains(el)) {
      return {
        status: "FILTERED:NON_INTERACTIVE",
        debug: {
          ...debug,
          reason: "detached"
        }
      };
    }

    const style = window.getComputedStyle(el);
    debug.computedStyle = {
      display: style.display,
      visibility: style.visibility,
      opacity: style.opacity,
      pointerEvents: style.pointerEvents
    };

    if (el.closest('[aria-hidden=\"true\"]')) {
      return { status: "FILTERED:ARIA_HIDDEN", debug };
    }

    const opacity = parseFloat(style.opacity || "1");
    if (style.display === "none" || style.visibility === "hidden" || opacity === 0) {
      return { status: "FILTERED:CSS_HIDDEN", debug };
    }

    const rect = el.getBoundingClientRect();
    debug.boundingBox = buildBoundingBox(rect);

    if (rect.width <= 0 || rect.height <= 0) {
      return { status: "FILTERED:ZERO_SIZE", debug };
    }

    const viewportWidth = window.innerWidth || document.documentElement.clientWidth || 0;
    const viewportHeight = window.innerHeight || document.documentElement.clientHeight || 0;
    if (!seenInViewport && !isInViewport(rect, viewportWidth, viewportHeight)) {
      return { status: "FILTERED:OFFSCREEN", debug };
    }

    if (style.pointerEvents === "none") {
      return { status: "FILTERED:NON_INTERACTIVE", debug };
    }

    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    if (
      centerX >= 0 &&
      centerY >= 0 &&
      centerX <= viewportWidth &&
      centerY <= viewportHeight
    ) {
      const topEl = document.elementFromPoint(centerX, centerY);
      if (topEl && topEl !== el && !el.contains(topEl)) {
        debug.coveringElement = describeElement(topEl);
        return { status: "FILTERED:COVERED", debug };
      }
    }

    return { status: "VISIBLE", debug };
  }

  function isCustomRule(rule) {
    const id = (rule?.id || "").toLowerCase();
    if (id.startsWith("custom-")) return true;
    const tags = Array.isArray(rule?.tags) ? rule.tags : [];
    return tags.some((tag) => String(tag).toLowerCase() === "custom");
  }

  function buildDedupeTargets(node) {
    const target = Array.isArray(node?.target) ? node.target : [];
    if (target.length) return target;
    if (typeof node?.xpath === "string" && node.xpath) return [node.xpath];
    return [];
  }

  function getNodeDepthFromElement(el) {
    let depth = 0;
    let current = el;
    while (current && current.nodeType === 1) {
      depth += 1;
      current = current.parentElement;
    }
    return depth;
  }

  function dedupeCustomViolationsByDom(results) {
    const violations = Array.isArray(results?.violations) ? results.violations : [];
    const suppressionMetadata = [];
    const dedupedViolations = violations.map((rule) => {
      if (!isCustomRule(rule)) return rule;
      const nodes = Array.isArray(rule.nodes) ? rule.nodes : [];
      const entries = [];
      const elementToEntry = new Map();

      nodes.forEach((node) => {
        const el = resolveNodeElement(node);
        if (!el) return;
        const entry = {
          node,
          element: el,
          depth: getNodeDepthFromElement(el)
        };
        entries.push(entry);
        elementToEntry.set(el, entry);
      });

      entries.sort((a, b) => b.depth - a.depth);

      const suppressed = new Map();

      entries.forEach((entry) => {
        let parent = entry.element.parentElement;
        while (parent) {
          const ancestorEntry = elementToEntry.get(parent);
          if (ancestorEntry && ancestorEntry.node !== entry.node) {
            if (!suppressed.has(ancestorEntry.node)) {
              suppressed.set(ancestorEntry.node, entry.node);
              suppressionMetadata.push({
                ruleId: rule.id,
                suppressedNodeTarget: buildDedupeTargets(ancestorEntry.node),
                keptNodeTarget: buildDedupeTargets(entry.node),
                suppressedNodeXPath: ancestorEntry.node?.xpath || "",
                keptNodeXPath: entry.node?.xpath || "",
                reason: "ANCESTOR_SUPPRESSED"
              });
            }
            break;
          }
          if (parent.tagName && parent.tagName.toLowerCase() === "body") break;
          parent = parent.parentElement;
        }
      });

      if (!suppressed.size) return rule;

      const keptNodes = nodes.filter((node) => !suppressed.has(node));
      return {
        ...rule,
        nodes: keptNodes
      };
    });

    return {
      dedupedResults: {
        ...results,
        violations: dedupedViolations
      },
      suppressionMetadata
    };
  }

  function nodeTargetValue(node) {
    if (Array.isArray(node?.target) && node.target.length) return node.target;
    if (typeof node?.xpath === "string" && node.xpath) return [node.xpath];
    return [];
  }

  function targetKey(target) {
    if (Array.isArray(target)) return JSON.stringify(target);
    if (target === null || target === undefined) return "";
    return String(target);
  }

  function getDocumentScrollHeight() {
    const doc = document.documentElement;
    const body = document.body;
    return Math.max(
      doc?.scrollHeight || 0,
      body?.scrollHeight || 0,
      doc?.offsetHeight || 0,
      body?.offsetHeight || 0
    );
  }

  function buildNodeEntries(violations) {
    const entries = [];
    const entryByNode = new Map();
    violations.forEach((rule) => {
      if (!isCustomRule(rule)) return;
      const nodes = Array.isArray(rule.nodes) ? rule.nodes : [];
      nodes.forEach((node) => {
        const key = targetKey(nodeTargetValue(node));
        const entry = {
          ruleId: rule.id,
          node,
          key,
          element: null
        };
        entries.push(entry);
        entryByNode.set(node, entry);
      });
    });
    return { entries, entryByNode };
  }

  function collectVisibleKeys(entries) {
    const seen = new Set();
    if (!entries.length) return Promise.resolve(seen);

    const startTime = Date.now();
    const viewportHeight = window.innerHeight || document.documentElement.clientHeight || 0;
    const viewportWidth = window.innerWidth || document.documentElement.clientWidth || 0;
    const maxScroll = Math.max(0, getDocumentScrollHeight() - viewportHeight);
    const step = Math.max(1, Math.floor(viewportHeight * SCROLL_STEP_RATIO));
    const originalScroll = window.scrollY || window.pageYOffset || 0;

    function wait(ms) {
      return new Promise((resolve) => setTimeout(resolve, ms));
    }

    async function scanAtPosition(pos) {
      window.scrollTo(0, pos);
      await wait(SCROLL_WAIT_MS);

      for (let i = 0; i < entries.length; i += 1) {
        const entry = entries[i];
        if (!entry.key || seen.has(entry.key)) continue;
        if (!entry.element) {
          entry.element = resolveNodeElement(entry.node);
        }
        const el = entry.element;
        if (!el) continue;
        if (!document.documentElement.contains(el)) continue;
        const rect = el.getBoundingClientRect();
        if (isInViewport(rect, viewportWidth, viewportHeight)) {
          seen.add(entry.key);
        }
      }
    }

    async function runScroll() {
      let pos = 0;
      let steps = 0;
      while (pos <= maxScroll) {
        await scanAtPosition(pos);
        steps += 1;
        if (steps >= SCROLL_MAX_STEPS) break;
        if (Date.now() - startTime >= SCROLL_MAX_MS) break;
        if (pos === maxScroll) break;
        pos = Math.min(maxScroll, pos + step);
      }
      window.scrollTo(0, originalScroll);
      await wait(SCROLL_WAIT_MS);
      return seen;
    }

    return runScroll();
  }

  async function runVisibilityFilter(rawResults) {
    const results = rawResults || {};
    const phase2 = {
      visible: [],
      filtered: []
    };

    const violations = Array.isArray(results.violations) ? results.violations : [];
    const { entries: nodeEntries, entryByNode } = buildNodeEntries(violations);
    const seenKeys = await collectVisibleKeys(nodeEntries);

    const phase1Violations = violations.map((rule) => {
      const nodes = Array.isArray(rule.nodes) ? rule.nodes : [];
      if (!isCustomRule(rule)) {
        return {
          ...rule,
          nodes: nodes
        };
      }
      const visibleNodes = [];
      nodes.forEach((node) => {
        const key = targetKey(nodeTargetValue(node));
        const entry = entryByNode.get(node);
        const el = entry?.element || resolveNodeElement(node);
        const outcome = computeVisibilityStatus(node, el, seenKeys.has(key));
        if (outcome.status === "VISIBLE") {
          visibleNodes.push(node);
          phase2.visible.push(node);
        } else {
          phase2.filtered.push({
            ruleId: rule.id,
            node,
            reason: outcome.status,
            debug: outcome.debug
          });
        }
      });
      return {
        ...rule,
        nodes: visibleNodes
      };
    });

    const phase2InputResults = {
      ...results,
      violations: phase1Violations
    };

    const phase2Dedup = dedupeCustomViolationsByDom(phase2InputResults);

    return {
      rawResults: rawResults,
      phase1: phase2,
      phase1Filtered: phase2.filtered,
      phase2InputResults: phase2Dedup.dedupedResults,
      phase2SuppressionMetadata: phase2Dedup.suppressionMetadata
    };
  }

  window.addEventListener("AXE_RESULTS", function (event) {

    console.log("[INJECTOR] AXE_RESULTS received");

    const scanId =
      event?.detail?.__debug?.scanId || currentScanContext?.scanId || null;

    (async () => {
      const phase1Start = Date.now();
      console.log("[PHASE1_VISIBILITY_START]", window.location.href, "ts=", phase1Start);
      const phase1Payload = await runVisibilityFilter(event.detail);
      const phase1End = Date.now();
      console.log(
        "[PHASE1_VISIBILITY_DONE]",
        window.location.href,
        "ts=",
        phase1End,
        "durationMs=",
        phase1End - phase1Start
      );

      chrome.runtime.sendMessage({
        type: "AXE_RESULTS",
        payload: phase1Payload,
        scanId,
        url: window.location.href
      });
    })();
  });

})();
