// PAGE CONTEXT (CSP-safe)
const rawConfig = document.currentScript?.dataset?.runConfig || "{}";
let injectedConfig = {};
try {
  injectedConfig = JSON.parse(rawConfig);
} catch (e) {
  injectedConfig = {};
}

window.__AXE_RUN_CONFIG__ = Object.assign(
  {
    customOnly: false, // toggle this
    showDebugDetails: true
  },
  window.__AXE_RUN_CONFIG__ || {},
  injectedConfig
);

console.log(
  "[AXE_RUN_CONFIG] customOnly =",
  window.__AXE_RUN_CONFIG__.customOnly
);
