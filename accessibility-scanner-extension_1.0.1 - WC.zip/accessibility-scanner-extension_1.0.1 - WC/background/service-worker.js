/**
 * Accessibility Scanner Background Service Worker (MV3)
 */

import { normalizeAxeResults } from "../normalization/axe-normalizer.js";

// ---------------------------------------------------------
// In-memory aggregation for current scan session
// ---------------------------------------------------------
let manualScanInProgress = false;
let manualScanId = null;
const extVersion = chrome.runtime.getManifest().version;
let aggregatedResults = [];

const reportDefaults = {
  showDebugDetails: true,
  showNormalizedOutput: false
};

function createScanId() {
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function getReportSettings(callback) {
  chrome.storage.local.get("reportSettings", (data) => {
    const settings = Object.assign(
      {},
      reportDefaults,
      data.reportSettings || {}
    );
    callback(settings);
  });
}


function buildHtmlReport(payload, options = {}) {
  const { url, results, suppressionMetadata, phase1Filtered } = payload;
  const showDebugDetails = options.showDebugDetails !== false;
  const isNormalized = options.showNormalizedOutput === true;
  const suppressionIndex = buildSuppressionIndex(suppressionMetadata);
  const filterIndex = buildFilterIndex(phase1Filtered);

  function escapeHtml(str) {
    if (!str) return "";
    return str.replace(/[&<>"']/g, m => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      "\"": "&quot;",
      "'": "&#039;"
    }[m]));
  }

  function targetKey(target) {
    if (Array.isArray(target)) return JSON.stringify(target);
    if (target === null || target === undefined) return "";
    return String(target);
  }

  function nodeTargetValue(node) {
    if (Array.isArray(node?.target) && node.target.length) return node.target;
    if (typeof node?.xpath === "string" && node.xpath) return [node.xpath];
    return [];
  }

  function buildFilterIndex(items) {
    const index = new Map();
    if (!Array.isArray(items)) return index;
    items.forEach((entry) => {
      if (!entry || !entry.ruleId) return;
      const key = targetKey(nodeTargetValue(entry.node || {}));
      if (!key) return;
      if (!index.has(entry.ruleId)) index.set(entry.ruleId, new Map());
      index.get(entry.ruleId).set(key, entry.reason || "FILTERED:CSS_HIDDEN");
    });
    return index;
  }

  function formatFilterReason(reason) {
    if (!reason) return "UNKNOWN";
    return String(reason).replace(/^FILTERED:/, "");
  }

  function buildSuppressionIndex(metadata) {
    const index = new Map();
    if (!Array.isArray(metadata)) return index;
    metadata.forEach((entry) => {
      if (!entry || !entry.ruleId) return;
      if (!index.has(entry.ruleId)) index.set(entry.ruleId, new Map());
      const ruleMap = index.get(entry.ruleId);
      const key = targetKey(entry.suppressedNodeTarget);
      if (!key) return;
      ruleMap.set(key, {
        reason: entry.reason || "ANCESTOR_SUPPRESSED",
        keptNodeXPath: entry.keptNodeXPath || "",
        keptNodeTarget: entry.keptNodeTarget || []
      });
    });
    return index;
  }

  function getNodeStatus(ruleId, node) {
    if (!isNormalized) return null;
    const filterMap = filterIndex.get(ruleId);
    const filterKey = targetKey(nodeTargetValue(node));
    if (filterMap && filterMap.has(filterKey)) {
      return {
        status: "filtered",
        reason: filterMap.get(filterKey)
      };
    }
    const ruleMap = suppressionIndex.get(ruleId);
    const key = targetKey(nodeTargetValue(node));
    if (ruleMap && ruleMap.has(key)) {
      const detail = ruleMap.get(key);
      return {
        status: "removed",
        reason: detail.reason,
        keptNodeXPath: detail.keptNodeXPath,
        keptNodeTarget: detail.keptNodeTarget
      };
    }
    return { status: "normalized" };
  }

  function formatTarget(target) {
    if (Array.isArray(target)) return target.join(", ");
    if (target === null || target === undefined) return "";
    return String(target);
  }

  function renderStatusBadge(ruleId, node) {
    const status = getNodeStatus(ruleId, node);
    if (!status) return "";
    if (status.status === "filtered") {
      return `<span class="badge filtered">filtering: ${escapeHtml(formatFilterReason(status.reason))}</span>`;
    }
    if (status.status === "removed") {
      const kept = status.keptNodeXPath || "";
      const keptTarget = formatTarget(status.keptNodeTarget);
      const keptLabel = kept
        ? escapeHtml(kept)
        : keptTarget
        ? escapeHtml(keptTarget)
        : "xpath unavailable";
      return `
        <span class="badge removed">removed: ${escapeHtml(status.reason)}</span>
        <div class="badge-sub">kept: ${keptLabel}</div>
      `;
    }
    return `<span class="badge normalized">normalized</span>`;
  }

  function renderNodes(nodes, ruleId) {
    if (!nodes || !nodes.length) return "";
    const hideFailureSummary =
      ruleId === "custom-wcag22-sc-1412-text-spacing" ||
      ruleId === "custom-wcag22-sc-1410-reflow" ||
      ruleId === "custom-wcag22-sc-246-headings-labels" ||
      ruleId === "custom-wcag22-sc-1413-hover-focus-content" ||
      ruleId === "custom-wcag22-sc-321-on-focus" ||
      ruleId === "custom-wcag22-sc-322-on-input" ||
      ruleId === "custom-wcag22-sc-2411-focus-not-obscured-minimum" ||
      ruleId === "custom-wcag22-sc-324-consistent-identification" ||
      ruleId === "custom-wcag22-sc-1411-non-text-contrast";

    function findTextSpacingData(node) {
      const checks = []
        .concat(node.any || [], node.all || [], node.none || []);
      return checks.find((check) =>
        check.id === "sc-1412-text-spacing-no-clipping" && check.data
      )?.data;
    }

    function renderTextSpacingDebug(data) {
      if (!data) return "";
      const style = data.style || {};
      const metrics = data.metrics || {};
      const clipping = data.clipping || {};
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "Clipped after spacing")}</dd></div>
            <div><dt>ClipX</dt><dd>${clipping.clippedX}</dd></div>
            <div><dt>ClipY</dt><dd>${clipping.clippedY}</dd></div>
            <div><dt>OverflowX</dt><dd>${escapeHtml(style.overflowX || "")}</dd></div>
            <div><dt>OverflowY</dt><dd>${escapeHtml(style.overflowY || "")}</dd></div>
            <div><dt>Width</dt><dd>${escapeHtml(style.width || "")}</dd></div>
            <div><dt>MaxWidth</dt><dd>${escapeHtml(style.maxWidth || "")}</dd></div>
            <div><dt>Height</dt><dd>${escapeHtml(style.height || "")}</dd></div>
            <div><dt>MaxHeight</dt><dd>${escapeHtml(style.maxHeight || "")}</dd></div>
            <div><dt>ScrollH</dt><dd>${metrics.scrollHeight}</dd></div>
            <div><dt>ClientH</dt><dd>${metrics.clientHeight}</dd></div>
            <div><dt>ScrollW</dt><dd>${metrics.scrollWidth}</dd></div>
            <div><dt>ClientW</dt><dd>${metrics.clientWidth}</dd></div>
          </dl>
        </div>
      `;
    }

    function renderOnFocusDebug(node) {
      const checks = []
        .concat(node.any || [], node.all || [], node.none || []);
      const data = checks.find((check) =>
        check.id === "sc-321-inline-onfocus-context-change" && check.data
      )?.data;
      if (!data) return "";
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "")}</dd></div>
            <div><dt>Matched Patterns</dt><dd>${escapeHtml((data.patterns || []).join(", "))}</dd></div>
          </dl>
          ${data.handler ? `<div><strong>Handler</strong></div><pre class="debug-code">${escapeHtml(data.handler)}</pre>` : ""}
        </div>
      `;
    }

    function renderOnInputDebug(node) {
      const checks = []
        .concat(node.any || [], node.all || [], node.none || []);
      const data = checks.find((check) =>
        check.id === "sc-322-inline-oninput-context-change" && check.data
      )?.data;
      if (!data) return "";
      const handlers = Array.isArray(data.handlers) ? data.handlers : [];
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "")}</dd></div>
            <div><dt>Matched Patterns</dt><dd>${escapeHtml((data.patterns || []).join(", "))}</dd></div>
          </dl>
          ${handlers.length ? `<div><strong>Handlers</strong></div><pre class="debug-code">${escapeHtml(handlers.join("\n"))}</pre>` : ""}
        </div>
      `;
    }

    function renderFocusNotObscuredDebug(node) {
      const checks = []
        .concat(node.any || [], node.all || [], node.none || []);
      const check = checks.find((item) =>
        item.id === "sc-2411-focus-not-obscured-minimum-visible"
      );
      const data = check?.data || null;
      const reason = data?.reason || check?.message || node?.failureSummary || "";
      if (!reason && !data) return "";
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(reason)}</dd></div>
            ${data?.boundingBox ? `
              <div><dt>Bounding Box</dt><dd>${escapeHtml(JSON.stringify(data.boundingBox))}</dd></div>
            ` : ""}
            ${data?.viewport ? `
              <div><dt>Viewport</dt><dd>${escapeHtml(JSON.stringify(data.viewport))}</dd></div>
            ` : ""}
            ${Array.isArray(data?.samplePoints) ? `
              <div><dt>Sample Points</dt><dd>
                <ul class="debug-list">
                  ${data.samplePoints.map((p) =>
                    `<li>${escapeHtml(`${p.x},${p.y} -> ${p.visible ? "visible" : "covered"} (${p.topElement || "unknown"})`)}</li>`
                  ).join("")}
                </ul>
              </dd></div>
            ` : ""}
          </dl>
        </div>
      `;
    }

    function getConsistentIdentificationData(node) {
      const checks = []
        .concat(node.any || [], node.all || [], node.none || []);
      return checks.find((check) =>
        check.id === "sc-324-consistent-identification" && check.data
      )?.data;
    }

    function renderConsistentIdentificationDebug(node) {
      const data = getConsistentIdentificationData(node);
      if (!data) return "";
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "")}</dd></div>
            <div><dt>Key</dt><dd>${escapeHtml(data.key || "")}</dd></div>
            <div><dt>Current Name</dt><dd>${escapeHtml(data.currentName || "")}</dd></div>
            <div><dt>Group Size</dt><dd>${escapeHtml(String(data.groupSize ?? ""))}</dd></div>
            <div><dt>Distinct Names</dt><dd>${escapeHtml((data.distinctNames || []).join(", "))}</dd></div>
          </dl>
        </div>
      `;
    }

    function renderConsistentIdentificationGroupDebug(data, groupSize) {
      if (!data) return "";
      const size = data.groupSize ?? groupSize ?? "";
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "")}</dd></div>
            <div><dt>Key</dt><dd>${escapeHtml(data.key || "")}</dd></div>
            <div><dt>Group Size</dt><dd>${escapeHtml(String(size))}</dd></div>
            <div><dt>Distinct Names</dt><dd>${escapeHtml((data.distinctNames || []).join(", "))}</dd></div>
          </dl>
        </div>
      `;
    }

    function renderHoverFocusContentDebug(node) {
      const checks = []
        .concat(node.any || [], node.all || [], node.none || []);
      const data = checks.find((check) =>
        check.id === "sc-1413-title-tooltip-disallowed" && check.data
      )?.data;
      if (!data) return "";
      const matchedPatterns = Array.isArray(data.matchedPatterns)
        ? data.matchedPatterns
        : [];
      const matchedHandlers = Array.isArray(data.matchedHandlers)
        ? data.matchedHandlers
        : [];
      const dismissSignals = Array.isArray(data.dismissSignalsFound)
        ? data.dismissSignalsFound
        : [];
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "")}</dd></div>
            <div><dt>Trigger Type</dt><dd>${escapeHtml(data.triggerType || "")}</dd></div>
            <div><dt>Matched Patterns</dt><dd>${escapeHtml(matchedPatterns.join(", "))}</dd></div>
            <div><dt>Matched Handlers</dt><dd>${escapeHtml(matchedHandlers.join(", "))}</dd></div>
            <div><dt>Dismiss Signals</dt><dd>${escapeHtml(dismissSignals.join(", "))}</dd></div>
            <div><dt>Dismiss Scope</dt><dd>${escapeHtml(data.dismissScope || "")}</dd></div>
            <div><dt>Interactive</dt><dd>${escapeHtml(String(data.isInteractive ?? ""))}</dd></div>
            <div><dt>Hidden</dt><dd>${escapeHtml(String(data.isHidden ?? ""))}</dd></div>
          </dl>
        </div>
      `;
    }

    function renderHeadingsLabelsDebug(node) {
      const checks = []
        .concat(node.any || [], node.all || [], node.none || []);
      const data = checks.find((check) =>
        check.id === "sc-246-heading-label-has-text" && check.data
      )?.data;
      if (!data) return "";
      const labelled = data.ariaLabelledby || {};
      const labelledIds = Array.isArray(labelled.ids) ? labelled.ids.join(", ") : "";
      const labelledTexts = Array.isArray(labelled.texts) ? labelled.texts.join(", ") : "";
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "")}</dd></div>
            <div><dt>Hidden</dt><dd>${escapeHtml(String(data.hidden ?? ""))}</dd></div>
            <div><dt>Source</dt><dd>${escapeHtml(data.source || "")}</dd></div>
            <div><dt>Text</dt><dd>${escapeHtml(data.textContent || "")}</dd></div>
            <div><dt>Aria Label</dt><dd>${escapeHtml(data.ariaLabel || "")}</dd></div>
            <div><dt>Aria Labelledby Ids</dt><dd>${escapeHtml(labelledIds)}</dd></div>
            <div><dt>Aria Labelledby Text</dt><dd>${escapeHtml(labelledTexts)}</dd></div>
          </dl>
        </div>
      `;
    }

    function renderNonTextContrastDebug(node) {
      const checks = []
        .concat(node.any || [], node.all || [], node.none || []);
      const check = checks.find((item) =>
        item.id === "sc-1411-non-text-contrast-min-3"
      );
      const data = check?.data || node?.__nonTextContrastDebug;
      const fallbackReason = check?.message || node?.failureSummary || "";
      const elementXPath = data?.elementXPath || node?.xpath || "";
      const parentXPath = data?.parentXPath || node?.parentXPath || "";

      if (!data && !fallbackReason) return "";

      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data?.reason || fallbackReason || "")}</dd></div>
            ${data ? `
              <div><dt>Ratio</dt><dd>${escapeHtml(String(data.ratio ?? ""))}</dd></div>
              <div><dt>Min Contrast</dt><dd>${escapeHtml(String(data.minContrast ?? ""))}</dd></div>
              <div><dt>Source</dt><dd>${escapeHtml(data.source || "")}</dd></div>
              <div><dt>Component Color</dt><dd>${escapeHtml(data.componentColor || "")}</dd></div>
              <div><dt>Parent Background</dt><dd>${escapeHtml(data.parentBackground || "")}</dd></div>
              <div><dt>Border Top Width</dt><dd>${escapeHtml(data.style?.borderTopWidth || "")}</dd></div>
              <div><dt>Border Top Color</dt><dd>${escapeHtml(data.style?.borderTopColor || "")}</dd></div>
              <div><dt>Background Color</dt><dd>${escapeHtml(data.style?.backgroundColor || "")}</dd></div>
            ` : ""}
            ${elementXPath ? `<div><dt>Element XPath</dt><dd>${escapeHtml(elementXPath)}</dd></div>` : ""}
            ${parentXPath ? `<div><dt>Parent XPath</dt><dd>${escapeHtml(parentXPath)}</dd></div>` : ""}
          </dl>
        </div>
      `;
    }

    function hasNonTextContrastData(node) {
      const checks = []
        .concat(node.any || [], node.all || [], node.none || []);
      return Boolean(
        checks.find((check) =>
          check.id === "sc-1411-non-text-contrast-min-3" && check.data
        )
      );
    }

    function renderRuleDebug(node, ruleId) {
      if (ruleId === "custom-wcag22-sc-1412-text-spacing") {
        return renderTextSpacingDebug(findTextSpacingData(node));
      }
      if (ruleId === "custom-wcag22-sc-1410-reflow") {
        const checks = []
          .concat(node.any || [], node.all || [], node.none || []);
        const data = checks.find((check) =>
          check.id === "sc-1410-reflow-min-width-over-320" && check.data
        )?.data;
        if (!data) return "";
        return `
          <div class="debug-block">
            <div class="debug-title">Debug Details</div>
            <dl class="debug-grid">
              <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "")}</dd></div>
              <div><dt>MinWidth</dt><dd>${escapeHtml(String(data.minWidth ?? ""))}</dd></div>
              <div><dt>InlineWidth</dt><dd>${escapeHtml(String(data.inlineWidth ?? ""))}</dd></div>
              <div><dt>Limit</dt><dd>${escapeHtml(String(data.limit ?? ""))}</dd></div>
              <div><dt>Display</dt><dd>${escapeHtml(data.style?.display || "")}</dd></div>
              <div><dt>Style MinWidth</dt><dd>${escapeHtml(data.style?.minWidth || "")}</dd></div>
              <div><dt>Style Width</dt><dd>${escapeHtml(data.style?.width || "")}</dd></div>
            </dl>
          </div>
        `;
      }
      if (ruleId === "custom-wcag22-sc-1413-hover-focus-content") {
        return renderHoverFocusContentDebug(node);
      }
      if (ruleId === "custom-wcag22-sc-246-headings-labels") {
        return renderHeadingsLabelsDebug(node);
      }
      if (ruleId === "custom-wcag22-sc-321-on-focus") {
        return renderOnFocusDebug(node);
      }
      if (ruleId === "custom-wcag22-sc-322-on-input") {
        return renderOnInputDebug(node);
      }
      if (ruleId === "custom-wcag22-sc-2411-focus-not-obscured-minimum") {
        return renderFocusNotObscuredDebug(node);
      }
      if (ruleId === "custom-wcag22-sc-324-consistent-identification") {
        return renderConsistentIdentificationDebug(node);
      }
      if (ruleId === "custom-wcag22-sc-1411-non-text-contrast") {
        return renderNonTextContrastDebug(node);
      }
      return "";
    }

    function renderNodeDetails(node) {
      const targetLabel = node?.__uniqueTarget || "";
      if (!node?.xpath && !targetLabel && !node?.html) return "";
      return `
        <div class="debug-block">
          <div class="debug-title">Node Details</div>
          ${node.xpath ? `<div><strong>XPath:</strong> ${escapeHtml(node.xpath)}</div>` : ""}
          ${!node.xpath && targetLabel ? `<div><strong>Target:</strong> ${escapeHtml(targetLabel)}</div>` : ""}
          ${node.html ? `<div><strong>HTML:</strong></div><pre class="debug-code">${escapeHtml(node.html)}</pre>` : ""}
        </div>
      `;
    }

    function renderConsistentIdentificationGroups(nodes) {
      const groups = [];
      const indexByKey = new Map();

      nodes.forEach((node, index) => {
        const data = getConsistentIdentificationData(node);
        const key = data?.key || `__unknown_${index}`;
        let groupIndex = indexByKey.get(key);
        if (groupIndex === undefined) {
          groupIndex = groups.length;
          indexByKey.set(key, groupIndex);
          groups.push({ key, data: data || null, nodes: [] });
        }
        const group = groups[groupIndex];
        if (!group.data && data) group.data = data;
        group.nodes.push(node);
      });

      return `
        <div class="group-list">
          ${groups.map((group, idx) => `
            <details>
              <summary>Group ${idx + 1}: ${group.nodes.length} element(s)</summary>
              ${showDebugDetails ? renderConsistentIdentificationGroupDebug(group.data, group.nodes.length) : ""}
              <ul>
                ${group.nodes.map((node) => `
                  <li>
                    ${renderStatusBadge(ruleId, node)}
                    ${renderNodeDetails(node)}
                  </li>
                `).join("")}
              </ul>
            </details>
          `).join("")}
        </div>
      `;
    }

    function renderTargetLabel(node) {
      if (node?.target) return node.target.join(" ");
      return "";
    }

    if (ruleId === "custom-wcag22-sc-324-consistent-identification") {
      return renderConsistentIdentificationGroups(nodes);
    }

    const filteredCount = isNormalized
      ? nodes.filter((node) => {
          const ruleMap = filterIndex.get(ruleId);
          if (!ruleMap) return false;
          return ruleMap.has(targetKey(nodeTargetValue(node)));
        }).length
      : 0;
    const removedCount = isNormalized
      ? nodes.filter((node) => {
          const ruleMap = suppressionIndex.get(ruleId);
          if (!ruleMap) return false;
          return ruleMap.has(targetKey(nodeTargetValue(node)));
        }).length
      : 0;
    const visibleCount = nodes.length - filteredCount - removedCount;
    const countLabel = isNormalized && (filteredCount > 0 || removedCount > 0)
      ? `${visibleCount} of ${nodes.length} element(s)`
      : `${nodes.length} element(s)`;

    return `
      <details>
        <summary>${countLabel}</summary>
        <ul>
          ${nodes.map(n => `
            <li>
              ${renderStatusBadge(ruleId, n)}
              ${(() => {
                const shouldHide = hideFailureSummary;
                return !shouldHide && n.failureSummary
                  ? `<div class="failure">${escapeHtml(n.failureSummary)}</div>`
                  : "";
              })()}
              ${renderNodeDetails(n)}
              ${showDebugDetails ? renderRuleDebug(n, ruleId) : ""}
            </li>
          `).join("")}
        </ul>
      </details>
    `;
  }

  function renderTable(title, items) {
    if (!items || !items.length) {
      return `
        <h2>${title} (0)</h2>
        <p class="empty">No ${title.toLowerCase()} found.</p>
      `;
    }

    return `
      <h2>${title} (${items.length})</h2>
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>Rule ID</th>
            <th>Description</th>
            <th>Impact</th>
            <th>Tags</th>
            <th>Affected Elements</th>
            <th>Help</th>
          </tr>
        </thead>
        <tbody>
          ${items.map((item, index) => `
            <tr>
              <td>${index + 1}</td>
              <td>${escapeHtml(item.id)}</td>
              <td>${escapeHtml(item.description)}</td>
              <td class="impact ${item.impact || "none"}">
                ${item.impact || ""}
              </td>
              <td>
                ${item.tags.map(t => `<span class="tag">${t}</span>`).join("")}
              </td>
              <td>${renderNodes(item.nodes, item.id)}</td>
              <td>
                <a href="${item.helpUrl}" target="_blank">Reference</a>
              </td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    `;
  }

  const manualReview = (results.incomplete || []).filter(
    item => item.tags && item.tags.includes("manual-review")
  );
  const incompleteNonManual = (results.incomplete || []).filter(
    item => !item.tags || !item.tags.includes("manual-review")
  );

  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Accessibility Report</title>

  <style>
    body {
      font-family: Arial, sans-serif;
      padding: 20px;
      background: #fafafa;
    }

    h1 {
      margin-bottom: 5px;
    }

    .meta {
      color: #555;
      margin-bottom: 30px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 40px;
      background: #fff;
    }

    th, td {
      border: 1px solid #ddd;
      padding: 8px;
      vertical-align: top;
      font-size: 14px;
    }

    th {
      background: #f0f0f0;
      text-align: left;
    }

    .impact.critical { color: #b00020; font-weight: bold; }
    .impact.serious  { color: #e65100; font-weight: bold; }
    .impact.moderate { color: #f9a825; font-weight: bold; }
    .impact.minor    { color: #2e7d32; font-weight: bold; }

    .tag {
      display: inline-block;
      background: #e0e0e0;
      padding: 2px 6px;
      margin: 2px;
      border-radius: 4px;
      font-size: 12px;
    }

    details summary {
      cursor: pointer;
      color: #1565c0;
    }

    .failure {
      margin-top: 4px;
      color: #c62828;
      font-size: 13px;
    }

    .badge {
      display: inline-block;
      margin-bottom: 6px;
      padding: 2px 6px;
      border-radius: 10px;
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.3px;
    }

    .badge-sub {
      font-size: 11px;
      color: #546e7a;
      margin: 0 0 6px 2px;
      word-break: break-word;
    }

    .badge.removed {
      background: #ffebee;
      color: #c62828;
      border: 1px solid #ef9a9a;
    }

    .badge.normalized {
      background: #e8f5e9;
      color: #2e7d32;
      border: 1px solid #a5d6a7;
    }

    .badge.filtered {
      background: #fff3e0;
      color: #ef6c00;
      border: 1px solid #ffcc80;
    }

    .debug-block {
      margin-top: 8px;
      background: #f7f9fb;
      border: 1px solid #dfe6ee;
      border-radius: 6px;
      padding: 8px 10px;
      font-size: 12px;
      color: #263238;
    }

    .debug-title {
      font-weight: 600;
      margin-bottom: 6px;
      color: #1f2d3d;
    }

    .debug-grid {
      display: grid;
      grid-template-columns: 120px 1fr;
      gap: 4px 10px;
      margin: 0;
    }

    .debug-grid div {
      display: contents;
    }

    .debug-grid dt {
      font-weight: 600;
      color: #455a64;
    }

    .debug-grid dd {
      margin: 0;
      color: #263238;
      word-break: break-word;
    }

    .debug-code {
      margin: 0;
      white-space: pre-wrap;
      word-break: break-word;
      font-family: "Courier New", Courier, monospace;
      color: #37474f;
    }

    .empty {
      font-style: italic;
      color: #777;
      margin-bottom: 40px;
    }

    details {
      margin-bottom: 30px;
    }

    summary {
      background: #e3f2fd;
      padding: 10px;
      border-radius: 6px;
    }

    details[open] summary {
      margin-bottom: 15px;
    }

  </style>
</head>

<body>

  <h1>Accessibility Scan Report</h1>
  <div class="meta">
    <div><strong>URL:</strong> ${escapeHtml(url)}</div>
    <div><strong>Generated:</strong> ${new Date().toLocaleString()}</div>
    <div><strong>Extension Version:</strong>${extVersion}</div>
    <div><strong>Output:</strong> ${isNormalized ? "NORMALIZED" : "RAW"}</div>
  </div>

  ${renderTable("Violations", results.violations)}
  ${renderTable("Passes", results.passes)}
  ${renderTable("Manual Review", manualReview)}
  ${renderTable("Incomplete", incompleteNonManual)}
  ${renderTable("Inapplicable", results.inapplicable)}

</body>
</html>
`;
}

/**
 * Send START_SCAN to the currently active tab
 */
function triggerScanOnActiveTab(scanContext) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs || !tabs.length) return;
    const tab = tabs[0];
    const context = Object.assign({}, scanContext, { url: tab.url });
    sendStartScan(tab.id, context);
  });
}

function sendStartScan(tabId, scanContext) {
  chrome.tabs.sendMessage(
    tabId,
    {
      type: "START_SCAN",
      scanId: scanContext.scanId,
      scanContext,
      manual: scanContext.manual === true
    },
    () => {
      if (chrome.runtime.lastError) {
        console.warn(
          "[BG] START_SCAN failed:",
          chrome.runtime.lastError.message
        );
      } else {
        console.log("[BG] START_SCAN sent to tab", tabId);
      }
    }
  );
}

function setScanState(active) {
  chrome.storage.local.set({ scanState: { active } });
}

function getScanState(callback) {
  chrome.storage.local.get("scanState", (data) => {
    callback(data.scanState?.active === true);
  });
}

function buildSummaryHtmlReport(pages, options = {}) {
  const showDebugDetails = options.showDebugDetails !== false;
  const isNormalized = options.showNormalizedOutput === true;

  function escapeHtml(str) {
    if (!str) return "";
    return str.replace(/[&<>"']/g, m => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      "\"": "&quot;",
      "'": "&#039;"
    }[m]));
  }

  function targetKey(target) {
    if (Array.isArray(target)) return JSON.stringify(target);
    if (target === null || target === undefined) return "";
    return String(target);
  }

  function nodeTargetValue(node) {
    if (Array.isArray(node?.target) && node.target.length) return node.target;
    if (typeof node?.xpath === "string" && node.xpath) return [node.xpath];
    return [];
  }

  function buildFilterIndex(items) {
    const index = new Map();
    if (!Array.isArray(items)) return index;
    items.forEach((entry) => {
      if (!entry || !entry.ruleId) return;
      const key = targetKey(nodeTargetValue(entry.node || {}));
      if (!key) return;
      if (!index.has(entry.ruleId)) index.set(entry.ruleId, new Map());
      index.get(entry.ruleId).set(key, entry.reason || "FILTERED:CSS_HIDDEN");
    });
    return index;
  }

  function formatFilterReason(reason) {
    if (!reason) return "UNKNOWN";
    return String(reason).replace(/^FILTERED:/, "");
  }

  function buildSuppressionIndex(metadata) {
    const index = new Map();
    if (!Array.isArray(metadata)) return index;
    metadata.forEach((entry) => {
      if (!entry || !entry.ruleId) return;
      if (!index.has(entry.ruleId)) index.set(entry.ruleId, new Map());
      const ruleMap = index.get(entry.ruleId);
      const key = targetKey(entry.suppressedNodeTarget);
      if (!key) return;
      ruleMap.set(key, {
        reason: entry.reason || "ANCESTOR_SUPPRESSED",
        keptNodeXPath: entry.keptNodeXPath || "",
        keptNodeTarget: entry.keptNodeTarget || []
      });
    });
    return index;
  }

  function getNodeStatus(ruleId, node, suppressionIndex, filterIndex) {
    if (!isNormalized) return null;
    const filterMap = filterIndex.get(ruleId);
    const filterKey = targetKey(nodeTargetValue(node));
    if (filterMap && filterMap.has(filterKey)) {
      return {
        status: "filtered",
        reason: filterMap.get(filterKey)
      };
    }
    const ruleMap = suppressionIndex.get(ruleId);
    const key = targetKey(nodeTargetValue(node));
    if (ruleMap && ruleMap.has(key)) {
      const detail = ruleMap.get(key);
      return {
        status: "removed",
        reason: detail.reason,
        keptNodeXPath: detail.keptNodeXPath,
        keptNodeTarget: detail.keptNodeTarget
      };
    }
    return { status: "normalized" };
  }

  function formatTarget(target) {
    if (Array.isArray(target)) return target.join(", ");
    if (target === null || target === undefined) return "";
    return String(target);
  }

  function renderStatusBadge(ruleId, node, suppressionIndex, filterIndex) {
    const status = getNodeStatus(ruleId, node, suppressionIndex, filterIndex);
    if (!status) return "";
    if (status.status === "filtered") {
      return `<span class="badge filtered">filtering: ${escapeHtml(formatFilterReason(status.reason))}</span>`;
    }
    if (status.status === "removed") {
      const kept = status.keptNodeXPath || "";
      const keptTarget = formatTarget(status.keptNodeTarget);
      const keptLabel = kept
        ? escapeHtml(kept)
        : keptTarget
        ? escapeHtml(keptTarget)
        : "xpath unavailable";
      return `
        <span class="badge removed">removed: ${escapeHtml(status.reason)}</span>
        <div class="badge-sub">kept: ${keptLabel}</div>
      `;
    }
    return `<span class="badge normalized">normalized</span>`;
  }

  function renderNodes(nodes, ruleId, suppressionMetadata, phase1Filtered) {
    if (!nodes || !nodes.length) return "";
    const suppressionIndex = buildSuppressionIndex(suppressionMetadata);
    const filterIndex = buildFilterIndex(phase1Filtered);
    const hideFailureSummary =
      ruleId === "custom-wcag22-sc-1412-text-spacing" ||
      ruleId === "custom-wcag22-sc-1410-reflow" ||
      ruleId === "custom-wcag22-sc-246-headings-labels" ||
      ruleId === "custom-wcag22-sc-321-on-focus" ||
      ruleId === "custom-wcag22-sc-322-on-input" ||
      ruleId === "custom-wcag22-sc-2411-focus-not-obscured-minimum" ||
      ruleId === "custom-wcag22-sc-324-consistent-identification" ||
      ruleId === "custom-wcag22-sc-1411-non-text-contrast";

    function findTextSpacingData(node) {
      const checks = []
        .concat(node.any || [], node.all || [], node.none || []);
      return checks.find((check) =>
        check.id === "sc-1412-text-spacing-no-clipping" && check.data
      )?.data;
    }

    function renderTextSpacingDebug(data) {
      if (!data) return "";
      const style = data.style || {};
      const metrics = data.metrics || {};
      const clipping = data.clipping || {};
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "Clipped after spacing")}</dd></div>
            <div><dt>ClipX</dt><dd>${clipping.clippedX}</dd></div>
            <div><dt>ClipY</dt><dd>${clipping.clippedY}</dd></div>
            <div><dt>OverflowX</dt><dd>${escapeHtml(style.overflowX || "")}</dd></div>
            <div><dt>OverflowY</dt><dd>${escapeHtml(style.overflowY || "")}</dd></div>
            <div><dt>Width</dt><dd>${escapeHtml(style.width || "")}</dd></div>
            <div><dt>MaxWidth</dt><dd>${escapeHtml(style.maxWidth || "")}</dd></div>
            <div><dt>Height</dt><dd>${escapeHtml(style.height || "")}</dd></div>
            <div><dt>MaxHeight</dt><dd>${escapeHtml(style.maxHeight || "")}</dd></div>
            <div><dt>ScrollH</dt><dd>${metrics.scrollHeight}</dd></div>
            <div><dt>ClientH</dt><dd>${metrics.clientHeight}</dd></div>
            <div><dt>ScrollW</dt><dd>${metrics.scrollWidth}</dd></div>
            <div><dt>ClientW</dt><dd>${metrics.clientWidth}</dd></div>
          </dl>
        </div>
      `;
    }

    function renderOnFocusDebug(node) {
      const checks = []
        .concat(node.any || [], node.all || [], node.none || []);
      const data = checks.find((check) =>
        check.id === "sc-321-inline-onfocus-context-change" && check.data
      )?.data;
      if (!data) return "";
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "")}</dd></div>
            <div><dt>Matched Patterns</dt><dd>${escapeHtml((data.patterns || []).join(", "))}</dd></div>
          </dl>
          ${data.handler ? `<div><strong>Handler</strong></div><pre class="debug-code">${escapeHtml(data.handler)}</pre>` : ""}
        </div>
      `;
    }

    function getConsistentIdentificationData(node) {
      const checks = []
        .concat(node.any || [], node.all || [], node.none || []);
      return checks.find((check) =>
        check.id === "sc-324-consistent-identification" && check.data
      )?.data;
    }

    function renderConsistentIdentificationDebug(node) {
      const data = getConsistentIdentificationData(node);
      if (!data) return "";
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "")}</dd></div>
            <div><dt>Key</dt><dd>${escapeHtml(data.key || "")}</dd></div>
            <div><dt>Current Name</dt><dd>${escapeHtml(data.currentName || "")}</dd></div>
            <div><dt>Group Size</dt><dd>${escapeHtml(String(data.groupSize ?? ""))}</dd></div>
            <div><dt>Distinct Names</dt><dd>${escapeHtml((data.distinctNames || []).join(", "))}</dd></div>
          </dl>
        </div>
      `;
    }

    function renderConsistentIdentificationGroupDebug(data, groupSize) {
      if (!data) return "";
      const size = data.groupSize ?? groupSize ?? "";
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "")}</dd></div>
            <div><dt>Key</dt><dd>${escapeHtml(data.key || "")}</dd></div>
            <div><dt>Group Size</dt><dd>${escapeHtml(String(size))}</dd></div>
            <div><dt>Distinct Names</dt><dd>${escapeHtml((data.distinctNames || []).join(", "))}</dd></div>
          </dl>
        </div>
      `;
    }

    function renderHeadingsLabelsDebug(node) {
      const checks = []
        .concat(node.any || [], node.all || [], node.none || []);
      const data = checks.find((check) =>
        check.id === "sc-246-heading-label-has-text" && check.data
      )?.data;
      if (!data) return "";
      const labelled = data.ariaLabelledby || {};
      const labelledIds = Array.isArray(labelled.ids) ? labelled.ids.join(", ") : "";
      const labelledTexts = Array.isArray(labelled.texts) ? labelled.texts.join(", ") : "";
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "")}</dd></div>
            <div><dt>Hidden</dt><dd>${escapeHtml(String(data.hidden ?? ""))}</dd></div>
            <div><dt>Source</dt><dd>${escapeHtml(data.source || "")}</dd></div>
            <div><dt>Text</dt><dd>${escapeHtml(data.textContent || "")}</dd></div>
            <div><dt>Aria Label</dt><dd>${escapeHtml(data.ariaLabel || "")}</dd></div>
            <div><dt>Aria Labelledby Ids</dt><dd>${escapeHtml(labelledIds)}</dd></div>
            <div><dt>Aria Labelledby Text</dt><dd>${escapeHtml(labelledTexts)}</dd></div>
          </dl>
        </div>
      `;
    }

    function renderNonTextContrastDebug(node) {
      const checks = []
        .concat(node.any || [], node.all || [], node.none || []);
      const check = checks.find((item) =>
        item.id === "sc-1411-non-text-contrast-min-3"
      );
      const data = check?.data || node?.__nonTextContrastDebug;
      const fallbackReason = check?.message || node?.failureSummary || "";
      const elementXPath = data?.elementXPath || node?.xpath || "";
      const parentXPath = data?.parentXPath || node?.parentXPath || "";

      if (!data && !fallbackReason) return "";

      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data?.reason || fallbackReason || "")}</dd></div>
            ${data ? `
              <div><dt>Ratio</dt><dd>${escapeHtml(String(data.ratio ?? ""))}</dd></div>
              <div><dt>Min Contrast</dt><dd>${escapeHtml(String(data.minContrast ?? ""))}</dd></div>
              <div><dt>Source</dt><dd>${escapeHtml(data.source || "")}</dd></div>
              <div><dt>Component Color</dt><dd>${escapeHtml(data.componentColor || "")}</dd></div>
              <div><dt>Parent Background</dt><dd>${escapeHtml(data.parentBackground || "")}</dd></div>
              <div><dt>Border Top Width</dt><dd>${escapeHtml(data.style?.borderTopWidth || "")}</dd></div>
              <div><dt>Border Top Color</dt><dd>${escapeHtml(data.style?.borderTopColor || "")}</dd></div>
              <div><dt>Background Color</dt><dd>${escapeHtml(data.style?.backgroundColor || "")}</dd></div>
            ` : ""}
            ${elementXPath ? `<div><dt>Element XPath</dt><dd>${escapeHtml(elementXPath)}</dd></div>` : ""}
            ${parentXPath ? `<div><dt>Parent XPath</dt><dd>${escapeHtml(parentXPath)}</dd></div>` : ""}
          </dl>
        </div>
      `;
    }

    function hasNonTextContrastData(node) {
      const checks = []
        .concat(node.any || [], node.all || [], node.none || []);
      return Boolean(
        checks.find((check) =>
          check.id === "sc-1411-non-text-contrast-min-3" && check.data
        )
      );
    }

    function renderRuleDebug(node, ruleId) {
      if (ruleId === "custom-wcag22-sc-1412-text-spacing") {
        return renderTextSpacingDebug(findTextSpacingData(node));
      }
      if (ruleId === "custom-wcag22-sc-1410-reflow") {
        const checks = []
          .concat(node.any || [], node.all || [], node.none || []);
        const data = checks.find((check) =>
          check.id === "sc-1410-reflow-min-width-over-320" && check.data
        )?.data;
        if (!data) return "";
        return `
          <div class="debug-block">
            <div class="debug-title">Debug Details</div>
            <dl class="debug-grid">
              <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "")}</dd></div>
              <div><dt>MinWidth</dt><dd>${escapeHtml(String(data.minWidth ?? ""))}</dd></div>
              <div><dt>InlineWidth</dt><dd>${escapeHtml(String(data.inlineWidth ?? ""))}</dd></div>
              <div><dt>Limit</dt><dd>${escapeHtml(String(data.limit ?? ""))}</dd></div>
              <div><dt>Display</dt><dd>${escapeHtml(data.style?.display || "")}</dd></div>
              <div><dt>Style MinWidth</dt><dd>${escapeHtml(data.style?.minWidth || "")}</dd></div>
              <div><dt>Style Width</dt><dd>${escapeHtml(data.style?.width || "")}</dd></div>
            </dl>
          </div>
        `;
      }
      if (ruleId === "custom-wcag22-sc-246-headings-labels") {
        return renderHeadingsLabelsDebug(node);
      }
      if (ruleId === "custom-wcag22-sc-321-on-focus") {
        return renderOnFocusDebug(node);
      }
      if (ruleId === "custom-wcag22-sc-324-consistent-identification") {
        return renderConsistentIdentificationDebug(node);
      }
      if (ruleId === "custom-wcag22-sc-1411-non-text-contrast") {
        return renderNonTextContrastDebug(node);
      }
      return "";
    }

    function renderNodeDetails(node) {
      const targetLabel = node?.__uniqueTarget || "";
      if (!node?.xpath && !targetLabel && !node?.html) return "";
      return `
        <div class="debug-block">
          <div class="debug-title">Node Details</div>
          ${node.xpath ? `<div><strong>XPath:</strong> ${escapeHtml(node.xpath)}</div>` : ""}
          ${!node.xpath && targetLabel ? `<div><strong>Target:</strong> ${escapeHtml(targetLabel)}</div>` : ""}
          ${node.html ? `<div><strong>HTML:</strong></div><pre class="debug-code">${escapeHtml(node.html)}</pre>` : ""}
        </div>
      `;
    }

    function renderConsistentIdentificationGroups(nodes, suppressionIndex, filterIndex) {
      const groups = [];
      const indexByKey = new Map();

      nodes.forEach((node, index) => {
        const data = getConsistentIdentificationData(node);
        const key = data?.key || `__unknown_${index}`;
        let groupIndex = indexByKey.get(key);
        if (groupIndex === undefined) {
          groupIndex = groups.length;
          indexByKey.set(key, groupIndex);
          groups.push({ key, data: data || null, nodes: [] });
        }
        const group = groups[groupIndex];
        if (!group.data && data) group.data = data;
        group.nodes.push(node);
      });

      return `
        <div class="group-list">
          ${groups.map((group, idx) => `
            <details>
              <summary>Group ${idx + 1}: ${group.nodes.length} element(s)</summary>
              ${showDebugDetails ? renderConsistentIdentificationGroupDebug(group.data, group.nodes.length) : ""}
              <ul>
                ${group.nodes.map((node) => `
                  <li>
                    ${renderStatusBadge(ruleId, node, suppressionIndex, filterIndex)}
                    ${renderNodeDetails(node)}
                  </li>
                `).join("")}
              </ul>
            </details>
          `).join("")}
        </div>
      `;
    }

    function renderTargetLabel(node) {
      if (node?.target) return node.target.join(" ");
      return "";
    }

    if (ruleId === "custom-wcag22-sc-324-consistent-identification") {
      return renderConsistentIdentificationGroups(nodes, suppressionIndex, filterIndex);
    }

    const filteredCount = isNormalized
      ? nodes.filter((node) => {
          const ruleMap = filterIndex.get(ruleId);
          if (!ruleMap) return false;
          return ruleMap.has(targetKey(nodeTargetValue(node)));
        }).length
      : 0;
    const removedCount = isNormalized
      ? nodes.filter((node) => {
          const ruleMap = suppressionIndex.get(ruleId);
          if (!ruleMap) return false;
          return ruleMap.has(targetKey(nodeTargetValue(node)));
        }).length
      : 0;
    const visibleCount = nodes.length - filteredCount - removedCount;
    const countLabel = isNormalized && (filteredCount > 0 || removedCount > 0)
      ? `${visibleCount} of ${nodes.length} element(s)`
      : `${nodes.length} element(s)`;

    return `
      <details>
        <summary>${countLabel}</summary>
        <ul>
          ${nodes.map(n => `
            <li>
              ${renderStatusBadge(ruleId, n, suppressionIndex, filterIndex)}
              ${(() => {
                const shouldHide = hideFailureSummary;
                return !shouldHide && n.failureSummary
                  ? `<div class="failure">${escapeHtml(n.failureSummary)}</div>`
                  : "";
              })()}
              ${renderNodeDetails(n)}
              ${showDebugDetails ? renderRuleDebug(n, ruleId) : ""}
            </li>
          `).join("")}
        </ul>
      </details>
    `;
  }

  // ------------------------------------------------------
  // [ADDED] Flatten results across ALL pages
  // ------------------------------------------------------
  function flatten(type) {
    return pages.flatMap(p =>
      (p.results[type] || []).map(item => ({
        ...item,
        pageUrl: p.url,
        suppressionMetadata: p.suppressionMetadata || [],
        phase1Filtered: p.phase1Filtered || []
      }))
    );
  }

  function renderSummaryByPage(pages) {
    return `
      <h2>Summary by Page</h2>
      <table>
        <thead>
          <tr>
            <th>Page URL</th>
            <th>Violations</th>
            <th>Passes</th>
            <th>Incomplete</th>
            <th>Inapplicable</th>
          </tr>
        </thead>
        <tbody>
          ${pages.map(p => `
            <tr>
              <td class="url">${escapeHtml(p.url)}</td>
              <td>${p.results.violations?.length || 0}</td>
              <td>${p.results.passes?.length || 0}</td>
              <td>${p.results.incomplete?.length || 0}</td>
              <td>${p.results.inapplicable?.length || 0}</td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    `;
  }

  function aggregateByRule(pages) {
    const ruleMap = {};

    pages.forEach(page => {
      const url = page.url;

      ["violations", "passes", "incomplete", "inapplicable"].forEach(type => {
        (page.results[type] || []).forEach(rule => {
          if (!ruleMap[rule.id]) {
            ruleMap[rule.id] = {
              id: rule.id,
              description: rule.description,
              impact: rule.impact || "",
              tags: rule.tags || [],
              occurrences: 0,
              pages: new Set()
            };
          }

          ruleMap[rule.id].occurrences += rule.nodes?.length || 1;
          ruleMap[rule.id].pages.add(url);
        });
      });
    });

    return Object.values(ruleMap).map(r => ({
      ...r,
      pageCount: r.pages.size
    }));
  }

  function renderSummaryByRule(rules) {

    if (!Array.isArray(rules)) {
      console.warn("[BG] Rule summary skipped - invalid data");
      return "";
    }

    if (!rules.length) {
      return `<h2>Summary by Rule</h2><p class="empty">No rules found.</p>`;
    }

    return `
      <h2>Summary by Rule</h2>
      <table>
        <thead>
          <tr>
            <th>Rule ID</th>
            <th>Description</th>
            <th>Impact</th>
            <th>Tags</th>
            <th>Occurrences</th>
            <th>Pages Affected</th>
          </tr>
        </thead>
        <tbody>
          ${rules.map(r => `
            <tr>
              <td>${escapeHtml(r.id)}</td>
              <td>${escapeHtml(r.description)}</td>
              <td class="impact ${r.impact}">${r.impact}</td>
              <td>
                ${(r.tags || []).map(t => `<span class="tag">${t}</span>`).join("")}
              </td>
              <td>${r.occurrences}</td>
              <td>${r.pageCount || 0}</td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    `;
  }

  function renderTable(title, items) {
    if (!items.length) {
      return `
        <h2>${title} (0)</h2>
        <p class="empty">No ${title.toLowerCase()} found.</p>
      `;
    }

    return `
      <h2>${title} (${items.length})</h2>
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>Rule ID</th>
            <th>Description</th>
            <th>Impact</th>
            <th>Tags</th>
            <th>Page URL</th>
            <th>Affected Elements</th>
            <th>Help</th>
          </tr>
        </thead>
        <tbody>
          ${items.map((item, index) => `
            <tr>
              <td>${index + 1}</td>
              <td>${escapeHtml(item.id)}</td>
              <td>${escapeHtml(item.description)}</td>
              <td class="impact ${item.impact || "none"}">
                ${item.impact || ""}
              </td>
              <td>
                ${item.tags.map(t => `<span class="tag">${t}</span>`).join("")}
              </td>
              <td class="url">${escapeHtml(item.pageUrl)}</td>
              <td>${renderNodes(item.nodes, item.id, item.suppressionMetadata, item.phase1Filtered)}</td>
              <td>
                <a href="${item.helpUrl}" target="_blank">Reference</a>
              </td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    `;
  }

  const violations = flatten("violations");
  const passes = flatten("passes");
  const incomplete = flatten("incomplete");
  const inapplicable = flatten("inapplicable");

  const rulesSummary = aggregateByRule(pages);

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>Accessibility Summary Report</title>

      <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #fafafa; }
        h1 { margin-bottom: 10px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 40px; background: #fff; }
        th, td { border: 1px solid #ddd; padding: 8px; font-size: 14px; vertical-align: top; }
        th { background: #f0f0f0; }
        .impact.critical { color: #b00020; font-weight: bold; }
        .impact.serious  { color: #e65100; font-weight: bold; }
        .impact.moderate { color: #f9a825; font-weight: bold; }
        .impact.minor    { color: #2e7d32; font-weight: bold; }
        .tag { background: #e0e0e0; padding: 2px 6px; margin: 2px; border-radius: 4px; font-size: 12px; display: inline-block; }
        .url { font-size: 12px; word-break: break-all; color: #1565c0; }
        .empty { font-style: italic; color: #777; }
        details summary { cursor: pointer; color: #1565c0; }
        .failure { margin-top: 4px; color: #c62828; }
        .badge { display: inline-block; margin-bottom: 6px; padding: 2px 6px; border-radius: 10px; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.3px; }
        .badge-sub { font-size: 11px; color: #546e7a; margin: 0 0 6px 2px; word-break: break-word; }
        .badge.removed { background: #ffebee; color: #c62828; border: 1px solid #ef9a9a; }
        .badge.normalized { background: #e8f5e9; color: #2e7d32; border: 1px solid #a5d6a7; }
        .badge.filtered { background: #fff3e0; color: #ef6c00; border: 1px solid #ffcc80; }
        .debug-list { margin: 6px 0 0 16px; padding: 0; }
        .debug-list li { margin: 2px 0; }
    .debug-list { margin: 6px 0 0 16px; padding: 0; }
    .debug-list li { margin: 2px 0; }
        .debug-block { margin-top: 8px; background: #f7f9fb; border: 1px solid #dfe6ee; border-radius: 6px; padding: 8px 10px; font-size: 12px; color: #263238; }
        .debug-title { font-weight: 600; margin-bottom: 6px; color: #1f2d3d; }
        .debug-grid { display: grid; grid-template-columns: 120px 1fr; gap: 4px 10px; margin: 0; }
        .debug-grid div { display: contents; }
        .debug-grid dt { font-weight: 600; color: #455a64; }
        .debug-grid dd { margin: 0; color: #263238; word-break: break-word; }
        .debug-code { margin: 0; white-space: pre-wrap; word-break: break-word; font-family: "Courier New", Courier, monospace; color: #37474f; }
      </style>
    </head>

    <body>

    <h1>Accessibility Summary Report</h1>
    <p><strong>Generated:</strong> ${new Date().toLocaleString()}</p>
    <p><strong>Total Pages Scanned:</strong> ${pages.length}</p>
    <p><strong>Extension Version:</strong>${extVersion}</p>
    <p><strong>Output:</strong> ${isNormalized ? "NORMALIZED" : "RAW"}</p>

    <details>
      <summary style="font-size:18px;font-weight:bold;cursor:pointer;">
        Summary by Rule
      </summary>
      ${renderSummaryByRule(rulesSummary)}
    </details>

    <details>
      <summary style="font-size:18px;font-weight:bold;cursor:pointer;">
        Summary by Page
      </summary>
      ${renderSummaryByPage(pages)}
    </details>

    ${renderTable("Violations", violations)}
    ${renderTable("Passes", passes)}
    ${renderTable("Incomplete", incomplete)}
    ${renderTable("Inapplicable", inapplicable)}

  </body>
  </html>
    `;
}

chrome.runtime.onMessage.addListener((msg, sender) => {

  /**
   * ---------------------------------------------------------
   * Popup -> Start scanning
   * ---------------------------------------------------------
   */
  if (msg.action === "START") {
    aggregatedResults = [];
    setScanState(true);
    console.log("[BG] Scanning session STARTED");

    const scanId = createScanId();
    triggerScanOnActiveTab({
      scanId,
      manual: false
    });
  }

  /**
   * ---------------------------------------------------------
   * Popup -> Stop scanning
   * ---------------------------------------------------------
   */
  if (msg.action === "STOP") {
    setScanState(false);
    console.log("[BG] Scanning session STOPPED");

    if (!aggregatedResults.length) {
      console.warn("[BG] No pages scanned. Summary report not generated.");
      return;
    }

    getReportSettings((reportSettings) => {
      const pagesSnapshot = aggregatedResults.map((page) => ({
        url: page.url,
        results: page.rawResults,
        suppressionMetadata: page.suppressionMetadata,
        phase1Filtered: page.phase1Filtered
      }));
      const summaryHtml = buildSummaryHtmlReport(
        pagesSnapshot,
        reportSettings
      );

      const dataUrl =
        "data:text/html;charset=utf-8," + encodeURIComponent(summaryHtml);

      chrome.downloads.download(
        {
          url: dataUrl,
          filename: `accessibility-summary-report-${Date.now()}.html`,
          saveAs: false
        },
        (downloadId) => {
          if (chrome.runtime.lastError) {
            console.error(
              "[BG] Summary Report download failed:",
              chrome.runtime.lastError.message
            );
          } else {
            console.log("[BG] Summary Report downloaded, ID:", downloadId);
          }
        }
      );
      aggregatedResults = [];
    });
  }

  if (msg.action === "SCAN_CURRENT_PAGE") {
    console.log("[BG] Scan current page requested");
    manualScanInProgress = true;

    manualScanId = createScanId();
    triggerScanOnActiveTab({
      scanId: manualScanId,
      manual: true
    });
  }

  /**
   * ---------------------------------------------------------
   * Content script -> Page ready
   * Auto-scan on navigation if session active
   * ---------------------------------------------------------
   */
  if (msg.type === "PAGE_READY") {
    console.log("[BG] PAGE_READY:", msg.url);

    // Skip auto-scan if manual scan is running
    if (manualScanInProgress) {
      console.log("[BG] Skipping auto-scan due to manual scan in progress");
      return;
    }

    getScanState((isActive) => {
      if (isActive && sender.tab?.id) {
        const scanId = createScanId();
        sendStartScan(sender.tab.id, {
          scanId,
          manual: false,
          url: msg.url
        });
        console.log("[BG] START_SCAN sent due to PAGE_READY");
      }
    });
  }

  /**
   * ---------------------------------------------------------
   * Content script -> Axe results received
   * ---------------------------------------------------------
   */
  if (msg.type === "AXE_RESULTS") {
    console.log("[BG] AXE_RESULTS received for:", msg.url);

    const scanId = msg.scanId || msg.payload?.__debug?.scanId || manualScanId;

    getScanState((isActive) => {

      // Allow download for manual OR automated scan
      if (!isActive && !manualScanInProgress) {
        console.log("[BG] Ignoring AXE_RESULTS - no active scan");
        return;
      }

      // -----------------------------------------------------
      // 1. Aggregate results for summary
      // -----------------------------------------------------
      const rawResults = msg.payload?.rawResults || msg.payload;
      const phase2InputResults = msg.payload?.phase2InputResults || rawResults;
      const phase1Filtered =
        msg.payload?.phase1Filtered || msg.payload?.phase1?.filtered || [];
      const providedSuppression = msg.payload?.phase2SuppressionMetadata;

      let suppressionMetadata = [];
      let phase2DedupedResults = phase2InputResults;

      if (Array.isArray(providedSuppression) && providedSuppression.length) {
        suppressionMetadata = providedSuppression;
      } else {
        const phase2Output = normalizeAxeResults(phase2InputResults);
        phase2DedupedResults = phase2Output.normalizedResults;
        suppressionMetadata = phase2Output.suppressionMetadata;
      }

      aggregatedResults.push({
        url: msg.url,
        rawResults,
        phase1Filtered,
        phase2DedupedResults,
        normalizedResults: phase2DedupedResults,
        suppressionMetadata
      });

      console.log("[BG] Results aggregated for:", msg.url,
        "Total pages:", aggregatedResults.length
      );

      getReportSettings((reportSettings) => {
        const html = buildHtmlReport(
          {
            url: msg.url,
            results: rawResults,
            suppressionMetadata,
            phase1Filtered
          },
          reportSettings
        );

        const dataUrl =
          "data:text/html;charset=utf-8," + encodeURIComponent(html);

        chrome.downloads.download(
          {
            url: dataUrl,
            filename: `accessibility-report-${Date.now()}.html`,
            saveAs: false
          },
          (downloadId) => {
            if (chrome.runtime.lastError) {
              console.error(
                "[BG] Page Report download failed:",
                chrome.runtime.lastError.message
              );
            } else {
              console.log("[BG] Page Report downloaded, ID:", downloadId);
            }

            if (manualScanInProgress) {
              manualScanInProgress = false;
              console.log("[BG] Manual scan completed");
            }
          }
        );
      });
    });
    return true;
  }
});
