# Changelog

All notable changes to this project will be documented in this file.  
This format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)  
and adheres to [Semantic Versioning](https://semver.org/).


---

## [1.0.5] - 18-05-2026
### Changed
- SC 3.3.1 (Error Identification): Improved detection algorithm and added fix 
  guidance for developers.
- SC 1.4.11 (Non-text Contrast): Elements with a contrast ratio of 1 are now 
  moved to the Incomplete section for manual review instead of being reported as violations.
- Built-in SC Violations: Replaced the Details section with three dedicated       
  sections - Node Details, Fix Guidance, and Debug Details.
- Built-in SC Incomplete: 
    - Removed the Debug Details section
    - Node Details section is updated to show additional Remarks field
- Custom Rule Incomplete: 
    - Removed the Debug Details section
    - Node Details section is updated to show additional Remarks field with 'Manual 
      review required' note.
- Built-in SC Passes: 
    - Removed the Debug Details section
    - Node Details section is updated to show additional Remarks field
- Custom Rule Passes: 
    - Removed the Debug Details section
    - Node Details section is updated to show additional Remarks field
- Service Worker: Cleaned up duplicate code for maintainability.
- HTML Report: 
    - Removed the Inapplicable section from report
    - Reordered sections to follow the sequence — Violations → Incomplete → Passes.
    - Full UI/UX revamp for improved readability and layout.
- Extension Popup: UI/UX revamp for a cleaner and more consistent interface.
- Code Quality: Resolved SAST defects across the service worker and axe runner content script.

---

## [1.0.4.1] - 05-03-2026
### Changed
- Maintenance build: removed unused dev dependencies, cleaned lockfile, and added an internal `update:axe` helper for vendored axe-core updates.
---

## [1.0.4] - 23-02-2026
### Changed
- Summary Report: Fixed Report Generation and display improvements.
- Summary Report: Pagination added to Summary by Rule section.
- Reports: Consistent pagination behavior across summary and page-level reports.
- Fix Guidance Added: SC 1.4.11, SC 1.4.12, SC 2.4.11, SC 3.2.4, SC 1.4.13, SC 2.4.6.
- SC 1.4.11 (Non-text Contrast): Boundary detection now requires outline, border, pseudo-element, or child boundary; element background alone is no longer used as a fallback.
- SC 1.4.11 (Non-text Contrast): Controls with no detectable boundary are marked INCOMPLETE (native and non-native) for manual review.
- SC 1.4.11 (Non-text Contrast): Debug details now show color names alongside RGB values for boundary/background colors.
- SC 1.4.11 (Non-text Contrast): Updated metadata and test cases to reflect new boundary-detection behavior.
- SC 1.4.12 (Text Spacing): Debug data enhanced with baseline metrics, baseline clipping, text style, and bounding box.
- Fix Guidance Updated (format/sections/copy actions): SC 1.4.11, SC 1.4.12, SC 2.4.11, SC 3.2.4, SC 1.4.13, SC 2.4.6.
---

## [1.0.3] - 19-02-2026
### Changed
- SC 1.4.11 (Non-text Contrast): Element background is now treated as deterministic only when it is confirmed as the visible boundary; non-deterministic cases are marked INCOMPLETE to reduce false positives.
- SC 1.4.11 (Non-text Contrast): Debug details now include boundary/background colors and determinism checks for Fail and Incomplete outcomes.
- SC 3.2.4 (Consistent Identification): Placeholder hrefs (#, empty, javascript:void(0), and specific hash anchors) are excluded from evaluation to reduce false positives.
---

## [1.0.2] - 16-02-2026
### Changed
- SC 1.4.11 (Non-text Contrast): Native form controls with non-deterministic boundaries are now marked INCOMPLETE (moved from Pass) for manual review.
- SC 1.4.12 (Text Spacing): Only flags clipping that appears after applying spacing adjustments; baseline clipping no longer triggers failure.
- SC 1.4.13 (Hover/Focus Content): Improved tooltip/hover detection and filtering to reduce noise in Passes and use Incomplete for ambiguous cases.
- SC 3.2.4 (Consistent Identification): Hidden elements excluded from grouping; case-only href conflicts marked INCOMPLETE; state-dependent content flagged for manual review.
- Built-in violations now show a minimal details block (Target + Failure Summary) in reports.

### Added
- Expanded Debug Details in reports for custom rule diagnostics (rule-specific fields to aid manual verification).
- HTML report tables now paginate per section (5 rules per page), with “Showing X–Y of Z entries” and compact page links.
---

## [1.0.1] - 20-01-2026
### Added
- Summary Report generation after Stop Scan button is clicked
---

## [1.0.0] - 19-01-2026
### Added
- Automatic accessibility scan on every navigation
- Manual scan option
- Page Level Reports
