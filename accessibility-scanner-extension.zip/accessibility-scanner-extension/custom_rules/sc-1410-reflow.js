/**
 * SC 1.4.10 Reflow
 * Automatable subset: Flag visible non-inline elements (excluding known
 * two-dimensional content) that set min-width greater than 320px.
 * Limitations:
 * - Does not measure actual horizontal scrolling or layout at 320px.
 * - Does not evaluate reflow failures caused by fixed widths, positioning,
 *   or long unbreakable strings.
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-1410-reflow";
  const CHECK_ID = "sc-1410-reflow-min-width-over-320";
  const MAX_REFLOW_WIDTH = 320;

  const EXCEPTION_TAGS = new Set([
    "IMG",
    "SVG",
    "CANVAS",
    "VIDEO",
    "IFRAME",
    "OBJECT",
    "EMBED",
    "TABLE"
  ]);

  function isVisible(style) {
    if (!style) return false;
    if (style.display === "none") return false;
    if (style.visibility === "hidden") return false;
    return true;
  }

  function isInline(style) {
    return style && style.display === "inline";
  }

  function parsePx(value) {
    if (!value) return null;
    if (value === "auto") return null;
    const num = parseFloat(value);
    return Number.isFinite(num) ? num : null;
  }

  function isExceptionTag(node) {
    return EXCEPTION_TAGS.has(node.tagName);
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector: "*",
        impact: "serious",
        tags: ["wcag2aa", "wcag22aa", "wcag1410", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Content should reflow at 320 CSS pixels without horizontal scrolling",
          help:
            "Ensure containers do not enforce min-width greater than 320px (except for two-dimensional content)",
          helpUrl: "https://www.w3.org/TR/WCAG22/#reflow",
          messages: {
            pass: "1.4.10 - Reflow - Pass",
            fail: "1.4.10 - Reflow - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          const style = window.getComputedStyle(node);

          if (!isVisible(style)) return true;
          if (isInline(style)) return true;
          if (isExceptionTag(node)) return true;

          const minWidth = parsePx(style.minWidth);
          if (minWidth === null || minWidth <= MAX_REFLOW_WIDTH) return true;

          return false;
        },
        metadata: {
          impact: "serious",
          messages: {
            pass: "1.4.10 - Reflow - min-width at or below 320px - Pass",
            fail: "1.4.10 - Reflow - min-width greater than 320px - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-1410-reflow loaded");
})();
