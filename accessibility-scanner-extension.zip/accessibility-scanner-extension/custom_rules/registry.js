(function () {
  if (window.__AXE_CUSTOM_RULES_REGISTRY__) return;
  window.__AXE_CUSTOM_RULES_REGISTRY__ = true;

  console.log("[AXE_CUSTOM_RULES] registry loaded");

  const ruleFiles = [
    "custom_rules/headings-labels.js",
    "custom_rules/sc-246-headings-labels.js",
    "custom_rules/sc-331-error-identification.js",
    "custom_rules/sc-413-status-messages.js",
    "custom_rules/sc-1412-text-spacing.js",
    "custom_rules/sc-1410-reflow.js",
    "custom_rules/sc-1411-non-text-contrast.js",
    "custom_rules/sc-1413-hover-focus-content.js",
    "custom_rules/sc-212-no-keyboard-trap.js",
    "custom_rules/sc-214-character-key-shortcuts.js",
    "custom_rules/sc-2411-focus-not-obscured-minimum.js"
  ];

  window.dispatchEvent(
    new CustomEvent("AXE_CUSTOM_RULES_REGISTRY_READY", {
      detail: ruleFiles
    })
  );
})();
