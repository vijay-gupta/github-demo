(function () {
  axe.configure({
    rules: [
      {
        id: "custom-heading-has-label",
        selector: "h1, h2, h3, h4, h5, h6",
        impact: "serious",
        tags: ["wcag2a", "wcag131", "custom"],
        any: ["heading-has-text"],
        enabled: true,
        metadata: {
          description: "Headings must have accessible text",
          help: "Ensure headings are not empty and have accessible text",
          helpUrl: 'https://dequeuniversity.com/rules/axe/4.11/custom-heading-has-label?application=axeAPI',
          messages: {
            pass: '2.4.6 - Headings and Labels - Pass', 
            fail: '2.4.6 - Headings and Labels - Fail'
          }
        }
      }
    ],
    checks: [
      {
        id: "heading-has-text",
        evaluate: function (node) {
          return node.textContent.trim().length > 0;
        },
        metadata: {
          impact: 'serious',
          messages: {
            pass: '2.4.6 - Headings and Labels - heading-has-text - Pass',
            fail: '2.4.6 - Headings and Labels - heading-has-text - Fail'
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] headings-labels loaded");
})();