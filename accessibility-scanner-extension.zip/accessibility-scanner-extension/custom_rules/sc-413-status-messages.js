/**
 * SC 4.1.3 Status Messages
 * Fully automated: None.
 * Review-only: Detect elements that expose status messages via role or aria-live.
 * Limitations:
 * - Cannot determine which DOM updates are status messages.
 * - Cannot verify whether focus was moved.
 * - Cannot confirm all status messages are programmatically exposed.
 */
(function () {
  const REVIEW_RULE_ID = "custom-wcag22-sc-413-status-messages-manual-review";
  const REVIEW_CHECK_ID = "sc-413-status-messages-cant-tell";

  axe.configure({
    rules: [
      {
        id: REVIEW_RULE_ID,
        selector: '[role="status"], [role="alert"], [aria-live]:not([aria-live="off"])',
        impact: "moderate",
        tags: ["wcag2aa", "wcag22aa", "wcag413", "custom", "manual-review"],
        any: [REVIEW_CHECK_ID],
        enabled: true,
        metadata: {
          description: "Status messages should be programmatically determinable without receiving focus",
          help: "Manual Review Required: Status messages are programmatically determinable through role or properties so assistive technologies can announce them.",
          helpUrl: "https://www.w3.org/TR/WCAG22/#status-messages",
          messages: {
            incomplete: "4.1.3 - Status Messages - Manual review required"
          }
        }
      }
    ],
    checks: [
      {
        id: REVIEW_CHECK_ID,
        evaluate: function () {
          return { result: "cantTell" };
        },
        metadata: {
          impact: "moderate",
          messages: {
            cantTell: "4.1.3 - Status Messages - Manual review required"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-413-status-messages loaded");
})();
