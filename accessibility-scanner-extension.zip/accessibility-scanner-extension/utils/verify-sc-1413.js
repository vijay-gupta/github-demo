const fs = require("fs");
const path = require("path");
const { Builder } = require("selenium-webdriver");
const chrome = require("selenium-webdriver/chrome");
require("chromedriver");
const { SeleniumBridge } = require("./selenium.bridge");

const TARGET_RULE_IDS = ["custom-wcag22-sc-1413-hover-focus-content"];

const ROOT_DIR = path.resolve(__dirname, "..");
const TEST_PAGE_PATH = path.join(
  ROOT_DIR,
  "tests",
  "sc-1413",
  "test-cases-sc-1413.html"
);
const AXE_PATH = path.join(ROOT_DIR, "lib", "axe-core", "axe.min.js");
const REGISTRY_PATH = path.join(ROOT_DIR, "custom_rules", "registry.js");

function toFileUrl(filePath) {
  const resolved = path.resolve(filePath);
  return "file:///" + resolved.replace(/\\/g, "/");
}

function readFile(filePath) {
  return fs.readFileSync(filePath, "utf8");
}

function nodeMatchesElement(node, elementId) {
  const selectorTarget = `#${elementId}`;
  const hasTargetMatch = (target) => {
    if (typeof target === "string") {
      return target === selectorTarget || target.endsWith(selectorTarget);
    }
    if (Array.isArray(target)) {
      return target.some(hasTargetMatch);
    }
    return false;
  };

  if (Array.isArray(node.target) && node.target.some(hasTargetMatch)) {
    return true;
  }

  if (node.html && node.html.includes(`id="${elementId}"`)) {
    return true;
  }

  return false;
}

async function main() {
  const bridge = new SeleniumBridge();
  bridge.start();

  const options = new chrome.Options();
  options.addArguments("--headless=new");

  const driver = await new Builder()
    .forBrowser("chrome")
    .setChromeOptions(options)
    .build();

  try {
    await driver.get(toFileUrl(TEST_PAGE_PATH));
    await driver.wait(async () => {
      const state = await driver.executeScript("return document.readyState");
      return state === "complete";
    }, 10000);

    const seleniumBridgeSource = readFile(
      path.join(ROOT_DIR, "utils", "selenium.bridge.js")
    );
    await driver.executeScript(function (source) {
      const script = document.createElement("script");
      script.text = source;
      document.documentElement.appendChild(script);
    }, seleniumBridgeSource);
    await driver.executeScript(
      "if (window.SeleniumBridge) { new window.SeleniumBridge().start(); }"
    );

    const axeSource = readFile(AXE_PATH);
    await driver.executeScript(function (source) {
      const script = document.createElement("script");
      script.text = source;
      document.documentElement.appendChild(script);
    }, axeSource);

    await driver.executeScript(function () {
      window.__AXE_CUSTOM_RULES_REGISTRY_PROMISE__ = new Promise((resolve) => {
        window.addEventListener(
          "AXE_CUSTOM_RULES_REGISTRY_READY",
          (e) => resolve(e.detail || []),
          { once: true }
        );
      });
    });

    const registrySource = readFile(REGISTRY_PATH);
    await driver.executeScript(function (source) {
      const script = document.createElement("script");
      script.text = source;
      document.documentElement.appendChild(script);
    }, registrySource);

    const ruleFiles = await driver.executeAsyncScript(function () {
      const done = arguments[0];
      window.__AXE_CUSTOM_RULES_REGISTRY_PROMISE__.then((files) => done(files));
    });

    for (const ruleFile of ruleFiles) {
      const ruleSource = readFile(path.join(ROOT_DIR, ruleFile));
      await driver.executeScript(function (source) {
        const script = document.createElement("script");
        script.text = source;
        document.documentElement.appendChild(script);
      }, ruleSource);
    }

    const results = await driver.executeAsyncScript(function () {
      const done = arguments[0];
      if (!window.axe) {
        done({ error: "axe-core not found on page" });
        return;
      }
      window.axe
        .run(document)
        .then((res) => done(res))
        .catch((err) => done({ error: String(err) }));
    });

    if (results && results.error) {
      throw new Error(results.error);
    }

    const testCases = await driver.executeScript(function () {
      const re = /^TC-\d{3}-(PASS|FAIL)$/;
      return Array.from(document.querySelectorAll("[id]"))
        .filter((el) => re.test(el.id))
        .map((el) => {
          const parts = el.id.split("-");
          return {
            testCaseId: `${parts[0]}-${parts[1]}`,
            elementId: el.id,
            expected: el.getAttribute("data-expected")
          };
        });
    });

    console.log("TARGET_RULE_IDS:", TARGET_RULE_IDS.join(", "));

    const discrepancies = [];
    const rows = [];

    for (const ruleId of TARGET_RULE_IDS) {
      const filteredViolations = results.violations.filter(
        (r) => r.id === ruleId
      );

      for (const testCase of testCases) {
        const elementId = testCase.elementId;

        const hasViolation = filteredViolations.some((result) =>
          result.nodes.some((node) => nodeMatchesElement(node, elementId))
        );

        let observed = "none";
        if (hasViolation) observed = "violation";

        let status = "OK";
        if (testCase.expected === "fail" && !hasViolation) {
          status = "DISCREPANCY";
          discrepancies.push(
            `${testCase.testCaseId} expected fail for ${ruleId} but observed ${observed}`
          );
        }
        if (testCase.expected === "pass" && hasViolation) {
          status = "DISCREPANCY";
          discrepancies.push(
            `${testCase.testCaseId} expected pass for ${ruleId} but observed ${observed}`
          );
        }

        rows.push({
          testCaseId: testCase.testCaseId,
          elementId: testCase.elementId,
          expected: testCase.expected,
          ruleId,
          observed,
          status
        });
      }
    }

    console.log(
      "Test Case ID | elementId | data-expected | Rule ID | observed (violation/none) | status (OK/DISCREPANCY)"
    );
    for (const row of rows) {
      console.log(
        `${row.testCaseId} | ${row.elementId} | ${row.expected} | ${row.ruleId} | ${row.observed} | ${row.status}`
      );
    }

    console.log("total test cases checked:", rows.length);
    console.log("total discrepancies:", discrepancies.length);
    if (discrepancies.length) {
      console.log("failing Test Case IDs with reason:");
      for (const message of discrepancies) {
        console.log(`- ${message}`);
      }
      process.exit(1);
    }

    process.exit(0);
  } finally {
    await driver.quit();
    bridge.stop();
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
