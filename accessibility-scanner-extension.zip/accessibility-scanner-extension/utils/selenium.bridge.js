class SeleniumBridge {
  start() {
    if (typeof chrome === "undefined" || !chrome.storage) return;
    chrome.storage.local.set({ selenium: true });
  }
  stop() {
    if (typeof chrome === "undefined" || !chrome.storage) return;
    chrome.storage.local.remove("selenium");
  }
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { SeleniumBridge };
} else if (typeof window !== "undefined") {
  window.SeleniumBridge = SeleniumBridge;
}
