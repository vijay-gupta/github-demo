/**
 * =========================================================
 * ACCESSIBILITY SCANNER – INJECTOR
 * ---------------------------------------------------------
 * ROLE:
 *  - Runs as CONTENT SCRIPT
 *  - Uses chrome.runtime APIs
 *  - Injects PAGE-CONTEXT scripts
 * =========================================================
 */

(function () {

  console.log("[INJECTOR] Running on:", window.location.href);

  /**
   * ---------------------------------------------------------
   * 1. Notify background that page is ready
   * ---------------------------------------------------------
   */
  try {
    chrome.runtime.sendMessage({
      type: "PAGE_READY",
      url: window.location.href
    });
    console.log("[INJECTOR] PAGE_READY sent");
  } catch (e) {
    console.error("[INJECTOR] Failed to send PAGE_READY", e);
  }

  /**
   * ---------------------------------------------------------
   * 2. Listen for START_SCAN from background / popup
   * ---------------------------------------------------------
   */
  chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {

    if (message.type === "START_SCAN") {
      console.log("[INJECTOR] START_SCAN received");

      injectAxePipeline();

      sendResponse({ status: "SCAN_TRIGGERED" });
      return true;
    }
  });

  /**
   * =========================================================
   * AXE PIPELINE ORCHESTRATION
   * =========================================================
   */

  function injectAxePipeline() {

    // -------------------------------------------------------
    // [MODIFIED] Separate flags for core and custom rules
    // -------------------------------------------------------
    if (window.__AXE_PIPELINE_READY__) {
      console.log("[INJECTOR] Axe pipeline already ready, re-running scan");
      window.dispatchEvent(new Event("AXE_RUN_SCAN"));
      return;
    }

    window.__AXE_PIPELINE_READY__ = true;

    // -------------------------------------------------------
    // STEP 1: Inject axe-core
    // -------------------------------------------------------
    const axeScript = document.createElement("script");
    axeScript.src = chrome.runtime.getURL("lib/axe-core/axe.min.js");

    axeScript.onload = function () {
      console.log("[INJECTOR] axe-core injected");

      injectCustomRulesRegistry();
    };

    axeScript.onerror = function (e) {
      console.error("[INJECTOR] Failed to inject axe-core", e);
    };

    document.documentElement.appendChild(axeScript);
  }

  /**
   * ---------------------------------------------------------
   * STEP 2: Inject custom rules registry
   * ---------------------------------------------------------
   */
  function injectCustomRulesRegistry() {

    const registryScript = document.createElement("script");
    registryScript.src = chrome.runtime.getURL("custom_rules/registry.js");

    registryScript.onload = function () {
      console.log("[INJECTOR] custom rules registry injected");
    };

    document.documentElement.appendChild(registryScript);

    // -------------------------------------------------------
    // [ADDED] Wait for registry readiness signal
    // -------------------------------------------------------
    window.addEventListener(
      "AXE_CUSTOM_RULES_REGISTRY_READY",
        function (e) {
          injectCustomRules(e.detail || []);
        },
        { once: true }
    );
  }

  /**
   * ---------------------------------------------------------
   * STEP 3: Inject each custom rule file sequentially
   * ---------------------------------------------------------
   */
  function injectCustomRules(rules) {
  let index = 0;

    function loadNextRule() {
      if (index >= rules.length) {
        injectAxeRunner();
        return;
      }

      const script = document.createElement("script");
      script.src = chrome.runtime.getURL(rules[index]);

      script.onload = function () {
        console.log("[INJECTOR] custom rule loaded:", rules[index]);
        index++;
        loadNextRule();
      };

      document.documentElement.appendChild(script);
    }

    loadNextRule();
  }


  /**
   * ---------------------------------------------------------
   * STEP 4: Inject axe-runner and trigger scan
   * ---------------------------------------------------------
   */
  function injectAxeRunner() {

    const runnerScript = document.createElement("script");
    runnerScript.src = chrome.runtime.getURL("content-scripts/axe-runner.js");

    runnerScript.onload = function () {
      console.log("[INJECTOR] axe-runner injected successfully");
      window.dispatchEvent(new Event("AXE_RUN_SCAN"));
      console.log("[INJECTOR] AXE_RUN_SCAN dispatched");
    };

    runnerScript.onerror = function (e) {
      console.error("[INJECTOR] Failed to inject axe-runner", e);
    };

    document.documentElement.appendChild(runnerScript);
  }

  /**
   * ---------------------------------------------------------
   * 5. Bridge AXE results from PAGE → EXTENSION
   * ---------------------------------------------------------
   */
  window.addEventListener("AXE_RESULTS", function (event) {

    console.log("[INJECTOR] AXE_RESULTS received");

    chrome.runtime.sendMessage({
      type: "AXE_RESULTS",
      payload: event.detail,
      url: window.location.href
    });
  });

})();
