Implemented SC 4.1.3 as a review-only axe rule with supporting test cases, an HTML test page, and a selenium-based verification runner.

# Files Added/Changed
- custom_rules/sc-413-status-messages.js
- custom_rules/registry.js
- tests/sc-413/test-cases-sc-413.html
- tests/sc-413/test-cases-sc-413.xlsx
- utils/verify-sc-413.js
- package.json
- package-lock.json
- tests/sc-413/sc-413-final-output.md

# SC Analysis and Atomic Parameters (SC 4.1.3 Status Messages)
Restatement: Status messages should be exposed in code so assistive technologies can announce them without moving focus.

Atomic Parameters (canonical):
- Status messages are programmatically determinable through role or properties so assistive technologies can announce them. Label: Partially automatable. Reason: The DOM can expose roles/aria-live signals, but automation cannot confirm which updates are true status messages or whether all status messages are marked. Automatable Sub-part: Detect elements that expose role="status", role="alert", or aria-live not "off". Manual Review Sub-part: Confirm these elements are used for status messages and that all status messages on the page use programmatic signals.
- Status messages are presented to assistive technologies without receiving focus. Label: Not automatable. Reason: Requires runtime observation of focus management and announcement behavior during updates.

# Coverage Breakdown
## Expected Coverage (canonical atomic parameters)
- Status messages are programmatically determinable through role or properties so assistive technologies can announce them.
- Status messages are presented to assistive technologies without receiving focus.

## Actual Coverage (mapped to rule outputs)
Automated Pass/Fail Coverage (violations/passes):
- None (no fully automatable rules for this SC).

Review-only Coverage (Manual Review / axe "incomplete"):
- Manual Review Required: Status messages are programmatically determinable through role or properties so assistive technologies can announce them. Automated signal: elements with role="status", role="alert", or aria-live not "off". Manual verify: confirm these elements are true status messages and that all status messages are exposed without moving focus.

## Missed Coverage (what remains untested / manual)
- Status messages are presented to assistive technologies without receiving focus. (Not automatable) Requires runtime focus/announcement behavior across updates.

# Custom Rule Code (Review-only only; manual review support, no automated pass/fail checks)
```js
/**
 * SC 4.1.3 Status Messages
 * Fully automated: None.
 * Review-only: Detect elements that expose status messages via role or aria-live.
 * Limitations:
 * - Cannot determine which DOM updates are status messages.
 * - Cannot verify whether focus was moved.
 * - Cannot confirm all status messages are programmatically exposed.
 */
(function () {
  const REVIEW_RULE_ID = "custom-wcag22-sc-413-status-messages-manual-review";
  const REVIEW_CHECK_ID = "sc-413-status-messages-cant-tell";

  axe.configure({
    rules: [
      {
        id: REVIEW_RULE_ID,
        selector: '[role="status"], [role="alert"], [aria-live]:not([aria-live="off"])',
        impact: "moderate",
        tags: ["wcag2aa", "wcag22aa", "wcag413", "custom", "manual-review"],
        any: [REVIEW_CHECK_ID],
        enabled: true,
        metadata: {
          description: "Status messages should be programmatically determinable without receiving focus",
          help: "Manual Review Required: Status messages are programmatically determinable through role or properties so assistive technologies can announce them.",
          helpUrl: "https://www.w3.org/TR/WCAG22/#status-messages",
          messages: {
            incomplete: "4.1.3 - Status Messages - Manual review required"
          }
        }
      }
    ],
    checks: [
      {
        id: REVIEW_CHECK_ID,
        evaluate: function () {
          return { result: "cantTell" };
        },
        metadata: {
          impact: "moderate",
          messages: {
            cantTell: "4.1.3 - Status Messages - Manual review required"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-413-status-messages loaded");
})();
```

# Registry Changes
```js
const ruleFiles = [
  "custom_rules/headings-labels.js",
  "custom_rules/sc-413-status-messages.js"
];
```

# Test Case Summary
Manual review support only; no automated pass/fail checks.
- TC-001: role="status" live region signal. Expected INCOMPLETE. Validates: Status messages are programmatically determinable through role or properties so assistive technologies can announce them.

# Mapping Tables
## Automated Pass/Fail Coverage Mapping
No automated pass/fail rules for this SC.

| Rule ID | Actual Coverage bullet (verbatim) | PASS Test Case IDs | FAIL Test Case IDs | EDGE Test Case IDs |
| --- | --- | --- | --- | --- |
| N/A | N/A | N/A | N/A | N/A |

## Review-only Coverage Mapping (axe `incomplete` only)
| Rule ID | Actual Coverage bullet (verbatim) | INCOMPLETE Test Case IDs |
| --- | --- | --- |
| custom-wcag22-sc-413-status-messages-manual-review | Status messages are programmatically determinable through role or properties so assistive technologies can announce them. | TC-001 |

# HTML Test Page Content
```html
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>SC 4.1.3 Status Messages - Test Cases</title>
    <style>
      body { font-family: Arial, sans-serif; padding: 16px; }
      section { margin: 16px 0; padding: 12px; border: 1px solid #ccc; }
    </style>
  </head>
  <body>
    <h1>SC 4.1.3 Status Messages - Test Cases</h1>

    <!-- TC-001 | Expected: INCOMPLETE | Status messages are programmatically determinable through role or properties so assistive technologies can announce them. -->
    <section>
      <div id="TC-001-INCOMPLETE" data-expected="incomplete" role="status">
        Your settings have been saved.
      </div>
    </section>
  </body>
</html>
```

# Verification Runner Summary/Output
Run:
- node utils/verify-sc-413.js

Output (sample):
```
TARGET_RULE_IDS: custom-wcag22-sc-413-status-messages-manual-review
Test Case ID | elementId | data-expected | Rule ID | observed (violation/incomplete/none) | status (OK/DISCREPANCY)
TC-001 | TC-001-INCOMPLETE | incomplete | custom-wcag22-sc-413-status-messages-manual-review | incomplete | OK
total test cases checked: 1
total discrepancies: 0
```

# Edit Count Summary
- utils/verify-sc-413.js: 1 iteration changed

# Assumptions and Limitations (SC 4.1.3)
- Assumption: Elements with role="status", role="alert", or aria-live not "off" are intended as status message mechanisms.
- Limitation: Automation cannot determine which updates are true status messages or whether all status messages are programmatically exposed.
- Manual-review notes: Confirm that each detected live region corresponds to a genuine status message and is announced without moving focus.
- Out-of-scope/external-context: Focus management and assistive technology announcement timing require human verification.
