# Changelog

All notable changes to this project will be documented in this file.  
This format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)  
and adheres to [Semantic Versioning](https://semver.org/).


---

## [1.0.3] - 19-02-2026
### Changed
- SC 1.4.11 (Non-text Contrast): Element background is now treated as deterministic only when it is confirmed as the visible boundary; non-deterministic cases are marked INCOMPLETE to reduce false positives.
- SC 1.4.11 (Non-text Contrast): Debug details now include boundary/background colors and determinism checks for Fail and Incomplete outcomes.
- SC 3.2.4 (Consistent Identification): Placeholder hrefs (#, empty, javascript:void(0), and specific hash anchors) are excluded from evaluation to reduce false positives.
- Summary report generation and display improvements.
- Consistent pagination behavior across summary and page-level reports.
- Added pagination to the Summary by Rule section in Summary Report.
---

## [1.0.2] - 16-02-2026
### Changed
- SC 1.4.11 (Non-text Contrast): Native form controls with non-deterministic boundaries are now marked INCOMPLETE (moved from Pass) for manual review.
- SC 1.4.12 (Text Spacing): Only flags clipping that appears after applying spacing adjustments; baseline clipping no longer triggers failure.
- SC 1.4.13 (Hover/Focus Content): Improved tooltip/hover detection and filtering to reduce noise in Passes and use Incomplete for ambiguous cases.
- SC 3.2.4 (Consistent Identification): Hidden elements excluded from grouping; case-only href conflicts marked INCOMPLETE; state-dependent content flagged for manual review.
- Built-in violations now show a minimal details block (Target + Failure Summary) in reports.

### Added
- Expanded Debug Details in reports for custom rule diagnostics (rule-specific fields to aid manual verification).
- HTML report tables now paginate per section (5 rules per page), with “Showing X–Y of Z entries” and compact page links.
---

## [1.0.1] - 20-01-2026
### Added
- Summary Report generation after Stop Scan button is clicked
---

## [1.0.0] - 19-01-2026
### Added
- Automatic accessibility scan on every navigation
- Manual scan option
- Page Level Reports
