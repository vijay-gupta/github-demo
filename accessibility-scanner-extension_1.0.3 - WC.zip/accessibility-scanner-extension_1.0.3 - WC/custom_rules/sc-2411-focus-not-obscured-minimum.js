/**
 * SC 2.4.11 Focus Not Obscured (Minimum)
 * Automatable subset: Focusable, visible elements in the viewport must not be
 * entirely obscured by author-created content (checked via elementFromPoint).
 * Limitations:
 * - Does not force focus/scroll into view.
 * - Cannot detect dynamic overlays that appear only on focus.
 * - Cannot distinguish author-created vs. UA chrome/assistive tech overlays.
 * Version: 1.0
 * Author: Vijay Gupta  
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-2411-focus-not-obscured-minimum";
  const CHECK_ID = "sc-2411-focus-not-obscured-minimum-visible";

  const FOCUSABLE_SELECTOR = [
    "a[href]",
    "button",
    "input:not([type=\"hidden\"])",
    "select",
    "textarea",
    "[contenteditable=\"true\"]",
    "[contenteditable=\"\"]",
    "[tabindex]:not([tabindex=\"-1\"])"
  ].join(", ");

  function isVisible(node) {
    const style = window.getComputedStyle(node);
    if (!style) return false;
    if (style.display === "none") return false;
    if (style.visibility === "hidden") return false;
    if (parseFloat(style.opacity || "1") === 0) return false;
    return true;
  }

  function isFocusable(node) {
    if (!node || typeof node.matches !== "function") return false;
    if (!node.matches(FOCUSABLE_SELECTOR)) return false;
    if ("disabled" in node && node.disabled === true) return false;
    if ((node.getAttribute("aria-disabled") || "").toLowerCase() === "true") {
      return false;
    }
    return true;
  }

  function rectInViewport(rect) {
    const vw = window.innerWidth || document.documentElement.clientWidth;
    const vh = window.innerHeight || document.documentElement.clientHeight;
    return rect.right > 0 && rect.bottom > 0 && rect.left < vw && rect.top < vh;
  }

  function pointInViewport(point) {
    const vw = window.innerWidth || document.documentElement.clientWidth;
    const vh = window.innerHeight || document.documentElement.clientHeight;
    return (
      point.x >= 0 &&
      point.y >= 0 &&
      point.x <= vw - 1 &&
      point.y <= vh - 1
    );
  }

  function getSamplePoints(rect) {
    const inset = 1;
    const points = [
      { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 },
      { x: rect.left + inset, y: rect.top + inset },
      { x: rect.right - inset, y: rect.top + inset },
      { x: rect.left + inset, y: rect.bottom - inset },
      { x: rect.right - inset, y: rect.bottom - inset }
    ];

    return points.filter(
      (p) =>
        p.x >= rect.left &&
        p.x <= rect.right &&
        p.y >= rect.top &&
        p.y <= rect.bottom
    );
  }

  function getEdgeMidpoints(rect) {
    const inset = 1;
    const midX = rect.left + rect.width / 2;
    const midY = rect.top + rect.height / 2;
    const points = [
      { x: rect.left + inset, y: midY },
      { x: rect.right - inset, y: midY },
      { x: midX, y: rect.top + inset },
      { x: midX, y: rect.bottom - inset }
    ];
    return points.filter(
      (p) =>
        p.x >= rect.left &&
        p.x <= rect.right &&
        p.y >= rect.top &&
        p.y <= rect.bottom
    );
  }

  function classifyPoint(node, point) {
    const topElement = document.elementFromPoint(point.x, point.y);
    if (!topElement) {
      return { status: "incomplete", reason: "NO_TOP_ELEMENT", topElement: null };
    }

    if (topElement === node || node.contains(topElement)) {
      return { status: "visible", topElement };
    }

    if (topElement.tagName === "IFRAME") {
      return { status: "incomplete", reason: "IFRAME_BLOCK", topElement };
    }

    const style = window.getComputedStyle(topElement);
    if (!style) {
      return { status: "incomplete", reason: "NO_STYLE", topElement };
    }
    if (
      style.opacity === "0" ||
      style.visibility === "hidden" ||
      style.pointerEvents === "none"
    ) {
      return { status: "incomplete", reason: "TOP_TRANSPARENT", topElement };
    }

    return { status: "blocked", topElement };
  }

  function describeElement(el) {
    if (!el || !el.tagName) return "";
    const tag = el.tagName.toLowerCase();
    const id = el.id ? `#${el.id}` : "";
    const classes = el.classList && el.classList.length
      ? "." + Array.from(el.classList).join(".")
      : "";
    return `${tag}${id}${classes}`;
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector:
          'a[href], button, input, select, textarea, [tabindex], [contenteditable=""], [contenteditable="true"]',
        impact: "serious",
        tags: ["wcag2aa", "wcag22aa", "wcag2411", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Focusable elements should not be entirely obscured by other content",
          help:
            "Ensure focusable elements remain at least partially visible when in view",
          helpUrl:
            "https://www.w3.org/TR/WCAG22/#focus-not-obscured-minimum",
          messages: {
            pass: "2.4.11 - Focus Not Obscured (Minimum) - Pass",
            fail: "2.4.11 - Focus Not Obscured (Minimum) - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          if (!isFocusable(node)) return true;
          if (!isVisible(node)) return true;

          const rect = node.getBoundingClientRect();
          if (!rect || rect.width <= 0 || rect.height <= 0) return true;
          if (!rectInViewport(rect)) return true;

          const defaultPoints = getSamplePoints(rect).filter(pointInViewport);
          if (!defaultPoints.length) return true;

          const samplePoints = [];
          let visibleFound = false;
          let blockedCount = 0;
          let incompleteCount = 0;

          for (const point of defaultPoints) {
            const outcome = classifyPoint(node, point);
            samplePoints.push({
              x: Math.round(point.x),
              y: Math.round(point.y),
              status: outcome.status,
              reason: outcome.reason || "",
              topElement: describeElement(outcome.topElement)
            });
            if (outcome.status === "visible") {
              visibleFound = true;
              break;
            }
            if (outcome.status === "blocked") blockedCount += 1;
            if (outcome.status === "incomplete") incompleteCount += 1;
          }

          if (visibleFound) return true;

          if (blockedCount === defaultPoints.length) {
            const extendedPoints = getEdgeMidpoints(rect).filter(pointInViewport);
            for (const point of extendedPoints) {
              const outcome = classifyPoint(node, point);
              samplePoints.push({
                x: Math.round(point.x),
                y: Math.round(point.y),
                status: outcome.status,
                reason: outcome.reason || "",
                topElement: describeElement(outcome.topElement)
              });
              if (outcome.status === "visible") {
                visibleFound = true;
                break;
              }
              if (outcome.status === "blocked") blockedCount += 1;
              if (outcome.status === "incomplete") incompleteCount += 1;
            }
          }

          if (visibleFound) return true;

          const totalPoints = samplePoints.length;
          const vw = window.innerWidth || document.documentElement.clientWidth;
          const vh = window.innerHeight || document.documentElement.clientHeight;

          this.data = {
            viewport: { width: vw, height: vh },
            boundingBox: {
              left: rect.left,
              top: rect.top,
              right: rect.right,
              bottom: rect.bottom,
              width: rect.width,
              height: rect.height
            },
            samplePoints
          };

          if (incompleteCount === totalPoints) {
            this.data.reason = "Focus visibility could not be confirmed at sampled points.";
            this.data.outcome = "incomplete";
            return undefined;
          }

          if (blockedCount === totalPoints) {
            this.data.reason = "Focusable element is fully covered at sampled points.";
            this.data.outcome = "fail";
            return false;
          }

          this.data.reason = "Focusable element visibility is inconclusive due to incomplete samples.";
          this.data.outcome = "incomplete";
          return undefined;
        },
        metadata: {
          impact: "serious",
          messages: {
            pass:
              "2.4.11 - Focus Not Obscured (Minimum) - focusable element not fully covered - Pass",
            fail:
              "2.4.11 - Focus Not Obscured (Minimum) - focusable element fully covered - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-2411-focus-not-obscured-minimum loaded");
})();
