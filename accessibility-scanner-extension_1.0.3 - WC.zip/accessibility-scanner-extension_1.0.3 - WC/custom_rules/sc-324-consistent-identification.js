/**
 * SC 3.2.4 Consistent Identification
 * Automatable subset: Elements that point to the same destination (same href)
 * or share an explicit data-consistent-id must use the same accessible name.
 * Limitations:
 * - Does not evaluate consistency across multiple pages.
 * - Cannot infer identical functionality without shared href or data-consistent-id.
 * Version: 1.0
 * Author: Vijay Gupta  
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-324-consistent-identification";
  const CHECK_ID = "sc-324-consistent-identification";
  const SELECTOR = 'a[href], [data-consistent-id]';
  const EXCLUDED_HREFS = new Set([
    "#",
    "",
    "javascript:void(0)",
    "javascript:void(0);",
    "#top",
    "#section",
    "#main"
  ]);
  const STATE_DEPENDENT_CLASS_MARKERS = [
    "collapsed",
    "collapse",
    "accordion",
    "accordion-collapse",
    "dropdown-menu"
  ];

  function normalizeText(text) {
    if (!text) return "";
    return text.replace(/\s+/g, " ").trim().toLowerCase();
  }

  function getLabelledbyText(node) {
    const raw = (node.getAttribute("aria-labelledby") || "").trim();
    if (!raw) return "";
    const ids = raw.split(/\s+/).filter(Boolean);
    const parts = [];
    for (const id of ids) {
      const el = document.getElementById(id);
      if (!el) continue;
      const text = (el.textContent || "").trim();
      if (text) parts.push(text);
    }
    return parts.join(" ").trim();
  }

  function getAltText(node) {
    const imgs = Array.from(node.querySelectorAll("img[alt]"));
    const parts = imgs
      .map((img) => (img.getAttribute("alt") || "").trim())
      .filter(Boolean);
    return parts.join(" ").trim();
  }

  function getAccessibleName(node) {
    const ariaLabel = (node.getAttribute("aria-label") || "").trim();
    if (ariaLabel) return normalizeText(ariaLabel);

    const labelledby = getLabelledbyText(node);
    if (labelledby) return normalizeText(labelledby);

    if (node.tagName && node.tagName.toLowerCase() === "input") {
      const type = (node.getAttribute("type") || "").toLowerCase();
      if (type === "submit" || type === "button" || type === "reset") {
        const value = (node.getAttribute("value") || "").trim();
        if (value) return normalizeText(value);
      }
    }

    const textContent = (node.textContent || "").trim();
    if (textContent) return normalizeText(textContent);

    const altText = getAltText(node);
    if (altText) return normalizeText(altText);

    return "";
  }

  function isHiddenByAttribute(node) {
    if (!node) return false;
    if (node.hasAttribute("hidden")) return true;
    if (node.hasAttribute("inert")) return true;
    const ariaHidden = (node.getAttribute("aria-hidden") || "").toLowerCase();
    return ariaHidden === "true";
  }

  function isHiddenByStyle(node) {
    if (!node) return false;
    const style = window.getComputedStyle(node);
    if (style.display === "none") return true;
    if (style.visibility === "hidden") return true;
    if (parseFloat(style.opacity) === 0) return true;
    return false;
  }

  function isHiddenByGeometry(node) {
    if (!node) return false;
    const rects = node.getClientRects();
    if (!rects || rects.length === 0) return true;
    const rect = node.getBoundingClientRect();
    return rect.width <= 0 || rect.height <= 0;
  }

  function isStateDependentNode(node) {
    if (!node) return false;
    const ariaExpanded = (node.getAttribute("aria-expanded") || "").toLowerCase();
    if (ariaExpanded === "false") return true;
    const dataExpanded = (node.getAttribute("data-expanded") || "").toLowerCase();
    if (dataExpanded === "false") return true;
    const dataState = (node.getAttribute("data-state") || "").toLowerCase();
    if (dataState === "closed") return true;
    const className = (node.className || "").toString().toLowerCase();
    return STATE_DEPENDENT_CLASS_MARKERS.some((marker) => className.includes(marker));
  }

  function getVisibilityStatus(node) {
    if (!node || node.nodeType !== 1) {
      return { status: "hidden", reason: "not-element" };
    }

    if (isHiddenByAttribute(node)) {
      return { status: "hidden", reason: "hidden-attribute" };
    }

    if (node.closest && node.closest('[aria-expanded=\"false\"]')) {
      return { status: "state-dependent", reason: "aria-expanded-false" };
    }

    let current = node.parentElement;
    while (current) {
      if (isHiddenByAttribute(current)) {
        return { status: "hidden", reason: "ancestor-hidden-attribute" };
      }
      if (isStateDependentNode(current)) {
        return { status: "state-dependent", reason: "state-dependent-ancestor" };
      }
      current = current.parentElement;
    }

    if (isStateDependentNode(node)) {
      return { status: "state-dependent", reason: "state-dependent-self" };
    }

    if (isHiddenByStyle(node)) {
      return { status: "hidden", reason: "css-hidden" };
    }
    if (isHiddenByGeometry(node)) {
      return { status: "hidden", reason: "no-rect" };
    }

    return { status: "visible", reason: "visible" };
  }

  function normalizeHref(href) {
    if (!href) return "";
    if (href.length > 1 && href.endsWith("/")) {
      return href.slice(0, -1);
    }
    return href;
  }

  function isExcludedHref(href) {
    if (href === null || href === undefined) return false;
    const normalized = String(href).trim().toLowerCase();
    return EXCLUDED_HREFS.has(normalized);
  }

  function getConsistencyKey(node) {
    const dataId = (node.getAttribute("data-consistent-id") || "").trim();
    if (dataId) return `data:${dataId}`;

    if (node.tagName && node.tagName.toLowerCase() === "a") {
      let href = (node.getAttribute("href") || "").trim();
      if (!href) return null;
      if (isExcludedHref(href)) return null;
      if (/^\s*javascript:/i.test(href)) return null;
      href = normalizeHref(href);
      return `href:${href}`;
    }

    return null;
  }

  function buildGroups() {
    const groups = new Map();
    const caseIndex = new Map();
    const caseConflicts = new Set();
    const nodes = Array.from(document.querySelectorAll(SELECTOR));
    for (const node of nodes) {
      const key = getConsistencyKey(node);
      if (!key) continue;
      const visibility = getVisibilityStatus(node);
      if (visibility.status !== "visible") continue;
      const name = getAccessibleName(node);
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push({ node, name });

      if (key.startsWith("href:")) {
        const hrefValue = key.slice(5);
        const caseKey = hrefValue.toLowerCase();
        if (!caseIndex.has(caseKey)) {
          caseIndex.set(caseKey, { originals: new Set(), nodes: [] });
        }
        const entry = caseIndex.get(caseKey);
        entry.originals.add(hrefValue);
        entry.nodes.push(node);
      }
    }

    for (const entry of caseIndex.values()) {
      if (entry.originals.size > 1) {
        entry.nodes.forEach((node) => caseConflicts.add(node));
      }
    }

    return { groups, caseConflicts };
  }

  function getConsistencyInfo(node) {
    const key = getConsistencyKey(node);
    if (!key) return { pass: true };
    const visibility = getVisibilityStatus(node);
    if (visibility.status === "hidden") {
      return { pass: true };
    }
    if (visibility.status === "state-dependent") {
      return {
        status: "incomplete",
        data: {
          reason:
            "Element appears in collapsed or state-dependent content (aria-expanded=false, closed details, or similar); evaluate after it is visible.",
          key,
          currentName: getAccessibleName(node),
          visibilityState: "state-dependent",
          visibilityReason: visibility.reason,
          outcome: "incomplete"
        }
      };
    }
    const { groups, caseConflicts } = buildGroups();
    if (caseConflicts.has(node) && key.startsWith("href:")) {
      return {
        status: "incomplete",
        data: {
          reason:
            "Href differs only by letter case within the same page. Grouping is inconclusive.",
          key: `href-ci:${key.slice(5).toLowerCase()}`,
          currentName: getAccessibleName(node),
          visibilityState: "visible",
          outcome: "incomplete"
        }
      };
    }
    const group = groups.get(key) || [];
    if (group.length < 2) return { pass: true };

    const names = group.map((item) => item.name).filter(Boolean);
    if (names.length < 2) return { pass: true };

    const first = names[0];
    const distinct = Array.from(new Set(names));
    if (distinct.length <= 1) return { pass: true };

    return {
      pass: false,
      data: {
        reason: "Elements sharing the same destination/id have inconsistent names.",
        key,
        currentName: getAccessibleName(node),
        groupSize: group.length,
        distinctNames: distinct,
        outcome: "fail"
      }
    };
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector: SELECTOR,
        matches: function (node) {
          if (!node || node.nodeType !== 1) return false;
          if (node.tagName && node.tagName.toLowerCase() === "a") {
            const href = node.getAttribute("href");
            if (isExcludedHref(href)) return false;
          }
          return true;
        },
        impact: "moderate",
        tags: ["wcag2aa", "wcag22aa", "wcag324", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Components that point to the same destination must be identified consistently",
          help:
            "Ensure repeated links or explicitly grouped controls use the same accessible name",
          helpUrl:
            "https://www.w3.org/TR/WCAG22/#consistent-identification",
          messages: {
            pass: "3.2.4 - Consistent Identification - Pass",
            fail: "3.2.4 - Consistent Identification - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          const info = getConsistencyInfo(node);
          if (info.pass) return true;
          if (info.status === "incomplete") {
            this.data = info.data;
            return undefined;
          }
          this.data = info.data;
          return false;
        },
        metadata: {
          impact: "moderate",
          messages: {
            pass:
              "3.2.4 - Consistent Identification - shared targets have consistent names - Pass",
            fail:
              "3.2.4 - Consistent Identification - shared targets have inconsistent names - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-324-consistent-identification loaded");
})();
