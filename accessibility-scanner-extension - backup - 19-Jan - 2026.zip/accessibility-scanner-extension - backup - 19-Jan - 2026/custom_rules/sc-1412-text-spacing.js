/**
 * SC 1.4.12 Text Spacing
 * Automatable subset: Detect text elements with fixed height/max-height or
 * fixed width/max-width plus overflow hidden/clip that clip when user spacing
 * values are applied.
 * Limitations:
 * - Cannot verify paragraph spacing changes between elements.
 * - Cannot verify all user stylesheet override behaviors.
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-1412-text-spacing";
  const CHECK_ID = "sc-1412-text-spacing-no-clipping";

  function hasMeaningfulText(node) {
    const text = (node.textContent || "").replace(/\s+/g, " ").trim();
    return text.length > 0;
  }

  function isVisible(style) {
    if (!style) return false;
    if (style.display === "none") return false;
    if (style.visibility === "hidden") return false;
    return true;
  }

  function isFixedSize(value) {
    if (!value) return false;
    if (value === "auto" || value === "none") return false;
    const num = parseFloat(value);
    return Number.isFinite(num);
  }

  function clipsOverflow(value) {
    return value === "hidden" || value === "clip";
  }

  function checkClipping(node, clipX, clipY) {
    const original = {
      lineHeight: node.style.lineHeight,
      letterSpacing: node.style.letterSpacing,
      wordSpacing: node.style.wordSpacing
    };

    node.style.lineHeight = "1.5";
    node.style.letterSpacing = "0.12em";
    node.style.wordSpacing = "0.16em";

    let clippedY = false;
    let clippedX = false;

    if (clipY) {
      clippedY = node.scrollHeight - node.clientHeight > 1;
    }
    if (clipX) {
      clippedX = node.scrollWidth - node.clientWidth > 1;
    }

    node.style.lineHeight = original.lineHeight;
    node.style.letterSpacing = original.letterSpacing;
    node.style.wordSpacing = original.wordSpacing;

    return clippedY || clippedX;
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector: "*",
        impact: "moderate",
        tags: ["wcag2aa", "wcag22aa", "wcag1412", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Text containers should not clip content when WCAG text spacing values are applied",
          help:
            "Ensure fixed-size text containers with overflow clipping still show content when line-height, letter-spacing, and word-spacing are increased",
          helpUrl: "https://www.w3.org/TR/WCAG22/#text-spacing",
          messages: {
            pass: "1.4.12 - Text Spacing - Pass",
            fail: "1.4.12 - Text Spacing - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          const style = window.getComputedStyle(node);

          if (!isVisible(style)) return true;
          if (style.display === "inline") return true;
          if (!hasMeaningfulText(node)) return true;

          const overflowX = style.overflowX || style.overflow;
          const overflowY = style.overflowY || style.overflow;

          const clipX = clipsOverflow(overflowX);
          const clipY = clipsOverflow(overflowY);

          const fixedHeight =
            isFixedSize(style.height) || isFixedSize(style.maxHeight);
          const fixedWidth =
            isFixedSize(style.width) || isFixedSize(style.maxWidth);

          const shouldCheckY = clipY && fixedHeight;
          const shouldCheckX = clipX && fixedWidth;

          if (!shouldCheckY && !shouldCheckX) return true;

          const clipped = checkClipping(node, shouldCheckX, shouldCheckY);
          return !clipped;
        },
        metadata: {
          impact: "moderate",
          messages: {
            pass:
              "1.4.12 - Text Spacing - no clipping after spacing adjustments - Pass",
            fail:
              "1.4.12 - Text Spacing - clipped content after spacing adjustments - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-1412-text-spacing loaded");
})();
