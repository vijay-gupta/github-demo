/**
 * SC 2.1.2 No Keyboard Trap
 * Automatable subset: Focusable elements with inline key handlers that explicitly
 * block the Tab key via preventDefault or return false.
 * Limitations:
 * - Does not detect traps created via addEventListener, shadow DOM, or scripts.
 * - Does not confirm whether a non-Tab escape mechanism exists.
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-212-no-keyboard-trap";
  const CHECK_ID = "sc-212-inline-tab-block";

  const FOCUSABLE_SELECTOR = [
    "a[href]",
    "button",
    "input:not([type=\"hidden\"])",
    "select",
    "textarea",
    "summary",
    "[role=\"button\"]",
    "[role=\"link\"]",
    "[role=\"menuitem\"]",
    "[role=\"tab\"]",
    "[role=\"switch\"]",
    "[role=\"checkbox\"]",
    "[role=\"radio\"]",
    "[role=\"option\"]",
    "[role=\"textbox\"]",
    "[contenteditable=\"true\"]",
    "[tabindex]:not([tabindex=\"-1\"])"
  ].join(", ");

  const INLINE_HANDLER_SELECTOR = "[onkeydown],[onkeypress]";

  const TAB_KEY_REGEX =
    /(key\s*={1,3}\s*['"]Tab['"]|keyCode\s*={1,3}\s*9|which\s*={1,3}\s*9)/i;
  const PREVENT_REGEX = /(preventDefault\s*\(|return\s+false\b)/i;

  function isVisible(node) {
    const style = window.getComputedStyle(node);
    if (!style) return false;
    if (style.display === "none") return false;
    if (style.visibility === "hidden") return false;
    if (parseFloat(style.opacity) === 0) return false;
    return true;
  }

  function isDisabled(node) {
    return node.matches("button[disabled], input[disabled], select[disabled], textarea[disabled]");
  }

  function getInlineHandler(node) {
    const onkeydown = node.getAttribute("onkeydown") || "";
    const onkeypress = node.getAttribute("onkeypress") || "";
    return `${onkeydown} ${onkeypress}`.trim();
  }

  function blocksTabKey(handler) {
    if (!handler) return false;
    return TAB_KEY_REGEX.test(handler) && PREVENT_REGEX.test(handler);
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector: INLINE_HANDLER_SELECTOR,
        impact: "serious",
        tags: ["wcag2aa", "wcag22aa", "wcag212", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Focusable elements should not trap keyboard focus by blocking the Tab key",
          help:
            "Ensure inline keyboard handlers do not prevent Tab from moving focus away",
          helpUrl: "https://www.w3.org/TR/WCAG22/#no-keyboard-trap",
          messages: {
            pass: "2.1.2 - No Keyboard Trap - Pass",
            fail: "2.1.2 - No Keyboard Trap - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          if (!node || typeof node.matches !== "function") return true;
          if (!node.matches(FOCUSABLE_SELECTOR)) return true;
          if (!node.matches(INLINE_HANDLER_SELECTOR)) return true;
          if (!isVisible(node)) return true;
          if (isDisabled(node)) return true;

          const handler = getInlineHandler(node);
          if (!handler) return true;

          return !blocksTabKey(handler);
        },
        metadata: {
          impact: "serious",
          messages: {
            pass:
              "2.1.2 - No Keyboard Trap - inline handler does not block Tab - Pass",
            fail:
              "2.1.2 - No Keyboard Trap - inline handler blocks Tab - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-212-no-keyboard-trap loaded");
})();
