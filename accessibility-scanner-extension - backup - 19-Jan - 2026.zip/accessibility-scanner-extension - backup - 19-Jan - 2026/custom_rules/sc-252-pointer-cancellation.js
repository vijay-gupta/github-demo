/**
 * SC 2.5.2 Pointer Cancellation
 * Automatable subset: Inline pointer-down handlers that appear to trigger
 * activation (submit/click/navigation/window.open) must also have an inline
 * pointer-up/cancel/click handler on the same element.
 * Limitations:
 * - Does not detect handlers added via addEventListener or external scripts.
 * - Cannot determine whether an action is essential.
 * - Cannot verify undo/abort mechanisms provided elsewhere.
 * - Activation intent detection is limited to simple inline patterns.
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-252-pointer-cancellation";
  const CHECK_ID = "sc-252-pointerdown-has-cancel-up";

  const DOWN_ATTRS = ["onpointerdown", "onmousedown", "ontouchstart"];
  const UP_CANCEL_ATTRS = [
    "onpointerup",
    "onpointercancel",
    "onmouseup",
    "ontouchend",
    "ontouchcancel",
    "onclick"
  ];

  const DOWN_SELECTOR = DOWN_ATTRS.map((attr) => `[${attr}]`).join(", ");

  const ACTIVATION_PATTERNS = [
    /\bsubmit\s*\(/i,
    /\bclick\s*\(/i,
    /\blocation\s*=\s*/i,
    /\blocation\.href\s*=\s*/i,
    /\bwindow\.location\b/i,
    /\bdocument\.location\b/i,
    /\bwindow\.open\s*\(/i
  ];

  function isVisible(node) {
    const style = window.getComputedStyle(node);
    if (!style) return false;
    if (style.display === "none") return false;
    if (style.visibility === "hidden") return false;
    if (parseFloat(style.opacity) === 0) return false;
    return true;
  }

  function getInlineHandler(node, attr) {
    const value = node.getAttribute(attr);
    return value ? value.trim() : "";
  }

  function getInlineHandlers(node, attrs) {
    return attrs.map((attr) => getInlineHandler(node, attr)).join(" ");
  }

  function hasActivationIntent(handler) {
    if (!handler || !handler.trim()) return false;
    return ACTIVATION_PATTERNS.some((regex) => regex.test(handler));
  }

  function hasInlineUpCancelAlternative(node) {
    return UP_CANCEL_ATTRS.some((attr) => getInlineHandler(node, attr).length);
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector: DOWN_SELECTOR,
        impact: "serious",
        tags: ["wcag2aa", "wcag22aa", "wcag252", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Pointer down activation should have an up/cancel or click alternative",
          help:
            "Ensure pointer-down activation includes an up/cancel/click handler on the same element",
          helpUrl: "https://www.w3.org/TR/WCAG22/#pointer-cancellation",
          messages: {
            pass: "2.5.2 - Pointer Cancellation - Pass",
            fail: "2.5.2 - Pointer Cancellation - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          if (!node || typeof node.matches !== "function") return true;
          if (!node.matches(DOWN_SELECTOR)) return true;
          if (!isVisible(node)) return true;

          const downHandlers = getInlineHandlers(node, DOWN_ATTRS);
          if (!hasActivationIntent(downHandlers)) return true;

          return hasInlineUpCancelAlternative(node);
        },
        metadata: {
          impact: "serious",
          messages: {
            pass:
              "2.5.2 - Pointer Cancellation - inline down activation has up/cancel/click - Pass",
            fail:
              "2.5.2 - Pointer Cancellation - inline down activation missing up/cancel/click - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-252-pointer-cancellation loaded");
})();
