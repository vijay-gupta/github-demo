/**
 * SC 4.1.3 Status Messages
 * Automatable subset: Elements explicitly marked as status messages via
 * role="status"/role="alert" or aria-live (not off) must not be hidden
 * from assistive technologies via aria-hidden="true".
 * Limitations:
 * - Cannot determine which DOM updates are status messages.
 * - Cannot verify whether focus was moved.
 * - Cannot confirm all status messages are programmatically exposed.
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-413-status-messages";
  const CHECK_ID = "sc-413-status-message-exposed";

  function isAriaHiddenFromAT(node) {
    let current = node;
    while (current && current.getAttribute) {
      const value = (current.getAttribute("aria-hidden") || "").trim();
      if (value && value.toLowerCase() === "true") return true;
      current = current.parentElement;
    }
    return false;
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector:
          '[role="status"], [role="alert"], [aria-live]:not([aria-live="off"])',
        impact: "serious",
        excludeHidden: false,
        tags: ["wcag2aa", "wcag22aa", "wcag413", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Status messages must not be hidden from assistive technologies",
          help:
            "Ensure status message containers are not marked aria-hidden=\"true\"",
          helpUrl: "https://www.w3.org/TR/WCAG22/#status-messages",
          messages: {
            pass: "4.1.3 - Status Messages - Pass",
            fail: "4.1.3 - Status Messages - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          return !isAriaHiddenFromAT(node);
        },
        metadata: {
          impact: "serious",
          messages: {
            pass:
              "4.1.3 - Status Messages - status message not aria-hidden - Pass",
            fail:
              "4.1.3 - Status Messages - status message hidden from AT - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-413-status-messages loaded");
})();
