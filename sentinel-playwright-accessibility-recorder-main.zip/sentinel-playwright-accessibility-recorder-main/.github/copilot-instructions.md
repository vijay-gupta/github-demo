# Copilot Instructions for Sentinel Playwright Accessibility Recorder

## Project Overview
- **Purpose:** Automated accessibility scanning using Playwright and axe-core, supporting recording, replay, crawling, and reporting for WCAG compliance.
- **Key Modes:**
  - **Recording:** Capture user/page interactions (web UI or CLI)
  - **Replay & Scan:** Re-run recordings with accessibility checks
  - **Crawl:** Automated site traversal and scanning
  - **Scripted:** Custom test flows
  - **ZeroCode Tool:** Web UI for non-technical users

## Architecture & Data Flow
- **Entry Scripts:** All workflows start from `scripts/` (e.g., `runCrawl.ts`, `runRecorder.ts`, `runReplay.ts`, `webRecorder.ts`, `zeroCodeTool.ts`).
- **Core Components:**
  - `src/crawler/`: Site traversal logic (`crawler.ts`, `urlUtils.ts`)
  - `src/scanner/`: Accessibility scanning and report generation (`axeScanner.ts`, `reportWriter.ts`, `summaryWriter.ts`)
  - `src/hooks/pageRecorder.ts`: Captures screenshots, logs, and errors per page
- **Artifacts:**
  - `reports/`: Per-run reports (HTML/JSON)
  - `recordings/`: Saved user/page interaction flows
  - `logs/`, `screenshots/`: Diagnostics and visual evidence

## Developer Workflows
- **Install:** `npm install` and `npx playwright install`
- **Record (Web):** `npm run record:web` (UI at http://localhost:3000)
- **Record (CLI):** `BASE_URL=... npm run record`
- **Crawl & Scan:** `BASE_URL=... npm run scan:crawl`
- **Replay:** `RECORDING_FILE=... npm run replay`
- **Scripted:** `npm run scan:scripted`
- **ZeroCode:** `npm run zerocode`
- **View Reports:** `npm run report:open`

## Patterns & Conventions
- **Environment Variables:** Used for config (e.g., `BASE_URL`, `STANDARD`, `CONFORMANCE`, `MAX_PAGES`, `RECORDING_FILE`)
- **Report Structure:** Each run creates a timestamped folder in `reports/` with per-page and summary reports
- **Page Naming:** Filenames use zero-padded indices and sanitized titles
- **Extensibility:** Add new scan types or report formats by extending `src/scanner/` and updating entry scripts

## Integration & Dependencies
- **Playwright:** Browser automation
- **axe-core:** Accessibility engine
- **Express:** Used for web-based tools
- **TypeScript:** All code is typed; scripts run via `ts-node`

## Examples
- To crawl and scan 5 pages from a site:
  ```sh
  BASE_URL=https://example.com MAX_PAGES=5 npm run scan:crawl
  ```
- To replay a recording and generate a report:
  ```sh
  RECORDING_FILE=recordings/recording_123.json npm run replay
  ```

## Key Files
- `scripts/runCrawl.ts`, `scripts/runRecorder.ts`, `scripts/runReplay.ts`, `scripts/webRecorder.ts`, `scripts/zeroCodeTool.ts`
- `src/crawler/crawler.ts`, `src/scanner/axeScanner.ts`, `src/scanner/reportWriter.ts`, `src/hooks/pageRecorder.ts`

---
If any workflow, config, or pattern is unclear, ask for clarification or check the README for up-to-date usage.
