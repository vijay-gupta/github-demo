import * as fs from 'fs-extra';
import * as path from 'path';
import { AxeResult } from './axeScanner';

export class ReportWriter {
  private baseDir: string;

  constructor(baseDir: string) {
    this.baseDir = baseDir;
  }

  async writePageReport(pageIndex: number, slug: string, result: AxeResult): Promise<void> {
    const pageDir = path.join(this.baseDir, 'pages', `${pageIndex.toString().padStart(3, '0')}_${slug}`);
    await fs.ensureDir(pageDir);

    // Raw JSON
    await fs.writeJson(path.join(pageDir, 'raw.json'), result.raw, { spaces: 2 });

    // Normalized JSON
    await fs.writeJson(path.join(pageDir, 'normalized.json'), result.normalized, { spaces: 2 });

    // HTML report
    const html = this.generatePageHtml(result.normalized, slug);
    await fs.writeFile(path.join(pageDir, 'report.html'), html);
  }

  private generatePageHtml(normalized: any, title: string): string {
    return `
<!DOCTYPE html>
<html>
<head>
  <title>Accessibility Report - ${title}</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
    .summary { background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; }
    .issue { background: white; margin: 10px 0; padding: 15px; border-left: 4px solid #007acc; }
    .impact-critical { border-left-color: #d13438; }
    .impact-serious { border-left-color: #ff8c00; }
    .impact-moderate { border-left-color: #ffcc00; }
    .impact-minor { border-left-color: #00cc44; }
  </style>
</head>
<body>
  <h1>Accessibility Report - ${title}</h1>
  <div class="summary">
    <h2>Summary</h2>
    <p>Total Issues: ${normalized.summary.total}</p>
    <ul>
      ${Object.entries(normalized.summary.byImpact).map(([impact, count]) => 
        `<li>${impact}: ${count}</li>`
      ).join('')}
    </ul>
  </div>
  <h2>Issues</h2>
  ${normalized.issues.map((issue: any) => `
    <div class="issue impact-${issue.impact}">
      <h3>${issue.help}</h3>
      <p><strong>Impact:</strong> ${issue.impact}</p>
      <p><strong>Description:</strong> ${issue.description}</p>
      <p><a href="${issue.moreInfo}" target="_blank">More Info</a></p>
      <details>
        <summary>Details (${issue.nodes.length} instances)</summary>
        ${issue.nodes.map((node: any) => `
          <div>
            <p><strong>Target:</strong> ${node.target}</p>
            <p><strong>Summary:</strong> ${node.failureSummary}</p>
          </div>
        `).join('')}
      </details>
    </div>
  `).join('')}
</body>
</html>`;
  }
}