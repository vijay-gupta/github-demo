import * as fs from 'fs-extra';
import * as path from 'path';
import { AxeResult } from './axeScanner';

export interface PageSummary {
  index: number;
  url: string;
  title: string;
  timestamp: string;
  issues: {
    total: number;
    byImpact: Record<string, number>;
  };
}

export interface SummaryReport {
  metadata: {
    runId: string;
    standard: string;
    conformance: string;
    scanType: string;
    selector?: string;
    startTime: string;
    endTime: string;
  };
  pages: PageSummary[];
  totals: {
    totalPages: number;
    totalIssues: number;
    byImpact: Record<string, number>;
    topRules: { rule: string; count: number }[];
  };
  guidedResults?: any[];
}

export class SummaryWriter {
  private baseDir: string;

  constructor(baseDir: string) {
    this.baseDir = baseDir;
  }

  async writeSummary(report: SummaryReport): Promise<void> {
    await fs.ensureDir(this.baseDir);

    // JSON
    await fs.writeJson(path.join(this.baseDir, 'summary.json'), report, { spaces: 2 });

    // HTML
    const html = this.generateSummaryHtml(report);
    await fs.writeFile(path.join(this.baseDir, 'summary.html'), html);
  }

  private generateSummaryHtml(report: SummaryReport): string {
    return `
<!DOCTYPE html>
<html>
<head>
  <title>Sentinel Accessibility Summary</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 0; background: linear-gradient(to bottom, #1e3a8a, #334155); color: white; }
    .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
    .header { text-align: center; padding: 40px 0; }
    .card { background: rgba(255,255,255,0.1); padding: 20px; border-radius: 8px; margin: 20px 0; backdrop-filter: blur(10px); }
    .summary-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; }
    .badge { display: inline-block; padding: 4px 8px; border-radius: 4px; font-size: 0.8em; }
    .badge-critical { background: #d13438; }
    .badge-serious { background: #ff8c00; }
    .badge-moderate { background: #ffcc00; color: black; }
    .badge-minor { background: #00cc44; }
    table { width: 100%; border-collapse: collapse; background: rgba(255,255,255,0.1); }
    th, td { padding: 10px; text-align: left; border-bottom: 1px solid rgba(255,255,255,0.2); }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Sentinel Accessibility Summary</h1>
      <p>Run ID: ${report.metadata.runId}</p>
      <p>Standard: ${report.metadata.standard} | Conformance: ${report.metadata.conformance}</p>
    </div>

    <div class="card">
      <h2>Overall Summary</h2>
      <div class="summary-grid">
        <div>Total Pages: ${report.totals.totalPages}</div>
        <div>Total Issues: ${report.totals.totalIssues}</div>
        ${Object.entries(report.totals.byImpact).map(([impact, count]) => 
          `<div><span class="badge badge-${impact}">${impact}: ${count}</span></div>`
        ).join('')}
      </div>
    </div>

    <div class="card">
      <h2>Pages</h2>
      <table>
        <thead>
          <tr>
            <th>Index</th>
            <th>Title</th>
            <th>Issues</th>
            <th>Timestamp</th>
          </tr>
        </thead>
        <tbody>
          ${report.pages.map(page => `
            <tr>
              <td>${page.index}</td>
              <td>${page.title}</td>
              <td>${page.issues.total}</td>
              <td>${page.timestamp}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>

    <div class="card">
      <h2>Top Rules</h2>
      <ul>
        ${report.totals.topRules.map(rule => `<li>${rule.rule}: ${rule.count}</li>`).join('')}
      </ul>
    </div>
  </div>
</body>
</html>`;
  }
}