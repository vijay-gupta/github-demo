import { Page } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import * as fs from 'fs-extra';
import * as path from 'path';

export interface ScanConfig {
  standard: 'wcag21' | 'wcag22';
  conformance: 'A' | 'AA' | 'AAA';
  scanType: 'full' | 'component';
  selector?: string;
  includeBestPractices?: boolean;
  includeExperimental?: boolean;
}

export interface AxeResult {
  raw: any;
  normalized: NormalizedResult;
}

export interface NormalizedResult {
  summary: {
    total: number;
    byImpact: Record<string, number>;
  };
  issues: NormalizedIssue[];
}

export interface NormalizedIssue {
  id: string;
  help: string;
  description: string;
  impact: string;
  wcagTags: string[];
  nodes: {
    target: string;
    failureSummary: string;
    html: string;
  }[];
  moreInfo: string;
}

export class AxeScanner {
  private config: ScanConfig;

  constructor(config: ScanConfig) {
    this.config = config;
  }

  async scan(page: Page): Promise<AxeResult | null> {
    try {
      const axeBuilder = new AxeBuilder({ page });

      // Set standard
      if (this.config.standard === 'wcag22') {
        axeBuilder.withTags(['wcag22a', 'wcag22aa', 'wcag22aaa']);
      } else {
        axeBuilder.withTags(['wcag21a', 'wcag21aa', 'wcag21aaa']);
      }

      // Add best practices if requested
      if (this.config.includeBestPractices) {
        axeBuilder.withTags(['best-practice']);
      }

      // Add experimental rules if requested
      if (this.config.includeExperimental) {
        axeBuilder.withTags(['experimental']);
      }

      // Component scan
      if (this.config.scanType === 'component' && this.config.selector) {
        const element = await page.$(this.config.selector);
        if (!element) {
          console.warn(`Selector ${this.config.selector} not found`);
          return null;
        }
        axeBuilder.include(this.config.selector);
      }

      const results = await axeBuilder.analyze();

      return {
        raw: results,
        normalized: this.normalizeResults(results)
      };
    } catch (error) {
      console.error('Axe scan failed:', error);
      return null;
    }
  }

  private getImpactLevels(conformance: string): string[] {
    switch (conformance) {
      case 'A': return ['minor'];
      case 'AA': return ['minor', 'moderate'];
      case 'AAA': return ['minor', 'moderate', 'serious'];
      default: return ['minor', 'moderate', 'serious'];
    }
  }

  private normalizeResults(results: any): NormalizedResult {
    const allowedImpacts = this.getImpactLevels(this.config.conformance);
    const issues: NormalizedIssue[] = results.violations
      .filter((violation: any) => allowedImpacts.includes(violation.impact))
      .map((violation: any) => ({
        id: violation.id,
        help: violation.help,
        description: violation.description,
        impact: violation.impact,
        wcagTags: violation.tags.filter((tag: string) => tag.startsWith('wcag')),
        nodes: violation.nodes.map((node: any) => ({
          target: node.target.join(', '),
          failureSummary: node.failureSummary,
          html: node.html
        })),
        moreInfo: `https://dequeuniversity.com/search?q=${violation.id}`
      }));

    const summary = {
      total: issues.length,
      byImpact: issues.reduce((acc, issue) => {
        acc[issue.impact] = (acc[issue.impact] || 0) + 1;
        return acc;
      }, {} as Record<string, number>)
    };

    return { summary, issues };
  }
}