BASE_URL=https://ww.google.com npm run scan:crawlimport { Page } from '@playwright/test';
import { UrlUtils } from './urlUtils';

export interface CrawlConfig {
  baseUrl: string;
  maxPages: number;
  waitStrategy: 'networkidle' | 'load' | 'domcontentloaded';
}

export interface CrawledPage {
  url: string;
  title: string;
  index: number;
}

export class Crawler {
  private config: CrawlConfig;
  private visited = new Set<string>();
  private urlUtils: UrlUtils;

  constructor(config: CrawlConfig) {
    this.config = config;
    this.urlUtils = new UrlUtils(config.baseUrl);
  }

  async crawl(page: Page, onPage: (pageInfo: CrawledPage) => Promise<void>): Promise<void> {
    const queue: string[] = [this.config.baseUrl];
    let index = 1;

    while (queue.length > 0 && index <= this.config.maxPages) {
      const currentUrl = queue.shift()!;
      
      if (this.visited.has(currentUrl)) continue;
      this.visited.add(currentUrl);

      try {
        await page.goto(currentUrl, { waitUntil: this.config.waitStrategy });
        await page.waitForTimeout(2000); // Allow time for recording/visual inspection
        const title = await page.title();

        const pageInfo: CrawledPage = {
          url: currentUrl,
          title,
          index
        };

        await onPage(pageInfo);

        // Find new links
        const links = await page.$$eval('a[href]', (anchors: HTMLAnchorElement[]) =>
          anchors.map(a => a.href).filter(href => href && !href.includes('#'))
        );

        for (const link of links) {
          if (this.urlUtils.isAllowed(link) && !this.visited.has(link)) {
            queue.push(link);
          }
        }

        index++;
      } catch (error) {
        console.error(`Failed to crawl ${currentUrl}:`, error);
      }
    }
  }
}