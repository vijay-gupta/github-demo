import * as url from 'url';

export class UrlUtils {
  private baseUrl: string;
  private baseDomain: string;

  constructor(baseUrl: string) {
    this.baseUrl = baseUrl;
    this.baseDomain = new url.URL(baseUrl).hostname;
  }

  isAllowed(link: string): boolean {
    try {
      const parsed = new URL(link, this.baseUrl);
      
      // Same domain
      if (parsed.hostname !== this.baseDomain) return false;
      
      // Not logout or similar
      const path = parsed.pathname.toLowerCase();
      if (path.includes('logout') || path.includes('signout')) return false;
      
      // Not mailto, tel, etc.
      if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return false;
      
      return true;
    } catch {
      return false;
    }
  }

  sanitizeForFilename(url: string): string {
    return url
      .replace(/^https?:\/\//, '')
      .replace(/[^a-zA-Z0-9]/g, '_')
      .substring(0, 50);
  }
}