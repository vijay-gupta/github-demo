import { Page } from '@playwright/test';
import * as fs from 'fs-extra';
import * as path from 'path';
const sanitize = require('sanitize-filename');

export class PageRecorder {
  private baseDir: string;
  private pageIndex = 1;

  constructor(baseDir: string) {
    this.baseDir = baseDir;
  }

  async setupPage(page: Page): Promise<void> {
    // Capture console errors
    const consoleMessages: string[] = [];
    page.on('console', msg => {
      if (msg.type() === 'error') {
        consoleMessages.push(`[${new Date().toISOString()}] ${msg.text()}`);
      }
    });

    // Capture network failures
    const networkErrors: string[] = [];
    page.on('response', response => {
      if (!response.ok()) {
        networkErrors.push(`[${new Date().toISOString()}] ${response.status()} ${response.url()}`);
      }
    });

    // Save logs on page close
    page.on('close', async () => {
      const logDir = path.join(this.baseDir, 'logs');
      await fs.ensureDir(logDir);
      await fs.writeFile(path.join(logDir, `page_${this.pageIndex}.log`), 
        [...consoleMessages, ...networkErrors].join('\n'));
    });
  }

  async recordPage(page: Page, pageInfo: { url: string; title: string; index: number }): Promise<void> {
    const sanitizedTitle = sanitize(pageInfo.title || 'untitled').substring(0, 30);
    const filename = `${pageInfo.index.toString().padStart(3, '0')}_${sanitizedTitle}`;

    // Screenshot
    await page.screenshot({ 
      path: path.join(this.baseDir, 'screenshots', `${filename}.png`), 
      fullPage: true 
    });

    this.pageIndex++;
  }
}