import express, { Request, Response } from 'express';
import * as path from 'path';
import { chromium } from '@playwright/test';
import { spawn } from 'child_process';
import { AxeScanner, ScanConfig } from '../src/scanner/axeScanner';
import { ReportWriter } from '../src/scanner/reportWriter';
import { SummaryWriter, SummaryReport } from '../src/scanner/summaryWriter';
import { PageRecorder } from '../src/hooks/pageRecorder';
import * as fs from 'fs-extra';

const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT) : 3000;

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

app.get('/', (req: Request, res: Response) => {
  res.send(`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sentinel Accessibility ZeroCode Tool</title>
  <style>
    * { box-sizing: border-box; }
    body { 
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
      margin: 0; 
      padding: 0; 
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
      min-height: 100vh;
      color: #333;
    }
    .container { 
      max-width: 800px; 
      margin: 0 auto; 
      padding: 20px; 
    }
    .header { 
      text-align: center; 
      background: rgba(255,255,255,0.95); 
      padding: 30px; 
      border-radius: 15px; 
      margin-bottom: 30px; 
      box-shadow: 0 8px 32px rgba(0,0,0,0.1);
      backdrop-filter: blur(10px);
    }
    .header h1 { 
      margin: 0; 
      color: #2c3e50; 
      font-size: 2.5em; 
      font-weight: 300;
    }
    .header p { 
      margin: 10px 0 0 0; 
      color: #7f8c8d; 
      font-size: 1.1em;
    }
    .form-card { 
      background: rgba(255,255,255,0.95); 
      padding: 30px; 
      border-radius: 15px; 
      box-shadow: 0 8px 32px rgba(0,0,0,0.1);
      backdrop-filter: blur(10px);
    }
    .form-group { 
      margin-bottom: 20px; 
    }
    label { 
      display: block; 
      margin-bottom: 8px; 
      font-weight: 600; 
      color: #2c3e50;
    }
    input[type="url"], select { 
      width: 100%; 
      padding: 12px; 
      border: 2px solid #e1e8ed; 
      border-radius: 8px; 
      font-size: 16px; 
      transition: border-color 0.3s;
    }
    input[type="url"]:focus, select:focus { 
      outline: none; 
      border-color: #667eea; 
    }
    .checkbox-group { 
      display: flex; 
      flex-wrap: wrap; 
      gap: 15px; 
      margin-top: 10px;
    }
    .checkbox-item { 
      display: flex; 
      align-items: center; 
      background: #f8f9fa; 
      padding: 10px 15px; 
      border-radius: 8px; 
      border: 2px solid #e1e8ed;
      cursor: pointer;
      transition: all 0.3s;
    }
    .checkbox-item:hover { 
      background: #e9ecef; 
      border-color: #667eea;
    }
    .checkbox-item.selected { 
      background: #667eea; 
      color: white; 
      border-color: #667eea;
    }
    .checkbox-item input { 
      margin-right: 8px; 
    }
    .btn { 
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
      color: white; 
      padding: 15px 30px; 
      border: none; 
      border-radius: 8px; 
      font-size: 16px; 
      font-weight: 600; 
      cursor: pointer; 
      transition: transform 0.2s;
      width: 100%;
    }
    .btn:hover { 
      transform: translateY(-2px); 
      box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
    }
    .results { 
      margin-top: 30px; 
      background: rgba(255,255,255,0.95); 
      padding: 30px; 
      border-radius: 15px; 
      box-shadow: 0 8px 32px rgba(0,0,0,0.1);
      display: none;
    }
    .loading { 
      text-align: center; 
      color: #667eea; 
      font-size: 18px;
    }
    .badge { 
      display: inline-block; 
      padding: 4px 8px; 
      border-radius: 12px; 
      font-size: 12px; 
      font-weight: 600; 
      margin: 2px;
    }
    .badge-critical { background: #e74c3c; color: white; }
    .badge-serious { background: #e67e22; color: white; }
    .badge-moderate { background: #f39c12; color: white; }
    .badge-minor { background: #27ae60; color: white; }
    .summary-grid { 
      display: grid; 
      grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); 
      gap: 15px; 
      margin: 20px 0;
    }
    .summary-item { 
      background: #f8f9fa; 
      padding: 15px; 
      border-radius: 8px; 
      text-align: center;
    }
    .summary-item .number { 
      font-size: 2em; 
      font-weight: bold; 
      color: #667eea;
    }
    .summary-item .label { 
      font-size: 0.9em; 
      color: #7f8c8d; 
      margin-top: 5px;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>🛡️ Sentinel</h1>
      <p>ZeroCode Accessibility Automation Tool</p>
    </div>

    <form class="form-card" id="scanForm">
      <div class="form-group">
        <label for="url">Target URL</label>
        <input type="url" id="url" name="url" placeholder="https://example.com" required>
      </div>

      <div class="form-group">
        <label>WCAG Standards</label>
        <div class="checkbox-group" id="standards">
          <div class="checkbox-item" data-value="wcag21">
            <input type="checkbox" id="wcag21" name="standards" value="wcag21" checked>
            <label for="wcag21">WCAG 2.1</label>
          </div>
          <div class="checkbox-item" data-value="wcag22">
            <input type="checkbox" id="wcag22" name="standards" value="wcag22">
            <label for="wcag22">WCAG 2.2</label>
          </div>
        </div>
      </div>

      <div class="form-group">
        <label for="conformance">Conformance Level</label>
        <select id="conformance" name="conformance">
          <option value="A">A - Basic</option>
          <option value="AA" selected>AA - Standard</option>
          <option value="AAA">AAA - Strict</option>
        </select>
      </div>

      <div class="form-group">
        <label for="scanType">Scan Type</label>
        <select id="scanType" name="scanType">
          <option value="full" selected>Full Page Scan</option>
          <option value="component">Component Scan</option>
        </select>
      </div>

      <div class="form-group" id="selectorGroup" style="display: none;">
        <label for="selector">CSS Selector (for component scan)</label>
        <input type="text" id="selector" name="selector" placeholder="#main-content">
      </div>

      <div class="form-group">
        <label>Additional Options</label>
        <div class="checkbox-group">
          <div class="checkbox-item" data-value="bestPractices">
            <input type="checkbox" id="bestPractices" name="includeBestPractices" value="true">
            <label for="bestPractices">Include Best Practices</label>
          </div>
          <div class="checkbox-item" data-value="experimental">
            <input type="checkbox" id="experimental" name="includeExperimental" value="true">
            <label for="experimental">Include Experimental Rules</label>
          </div>
        </div>
      </div>

      <button type="submit" class="btn">🚀 Run Accessibility Scan</button>
    </form>

      <div class="form-card" style="margin-top: 30px;">
      <h3 style="color: #667eea; margin-bottom: 20px;">🎬 Record User Interactions</h3>
      <p style="color: #666; margin-bottom: 20px;">Record your interactions with the website to create automated test scripts for accessibility scanning. <strong>Note: Recording will automatically stop after 2 minutes.</strong></p>
      
      <div class="form-group">
        <label for="recordUrl">Recording URL</label>
        <input type="url" id="recordUrl" name="recordUrl" placeholder="https://example.com" required>
      </div>

      <button type="button" class="btn" id="startRecording" style="background: linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%);">🎬 Start Recording</button>
    </div>

    <div class="results" id="results">
      <div class="loading" id="loading">Scanning in progress...</div>
      <div id="scanResults" style="display: none;"></div>
    </div>
  </div>

  <script>
    // Handle checkbox selection
    document.querySelectorAll('.checkbox-item').forEach(item => {
      item.addEventListener('click', function() {
        const checkbox = this.querySelector('input[type="checkbox"]');
        checkbox.checked = !checkbox.checked;
        this.classList.toggle('selected', checkbox.checked);
      });
    });

    // Show/hide selector field
    document.getElementById('scanType').addEventListener('change', function() {
      const selectorGroup = document.getElementById('selectorGroup');
      selectorGroup.style.display = this.value === 'component' ? 'block' : 'none';
    });

    // Handle form submission
    document.getElementById('scanForm').addEventListener('submit', async function(e) {
      e.preventDefault();
      
      const formData = new FormData(this);
      const data = {
        url: formData.get('url'),
        standards: Array.from(formData.getAll('standards')),
        conformance: formData.get('conformance'),
        scanType: formData.get('scanType'),
        selector: formData.get('selector'),
        includeBestPractices: formData.get('includeBestPractices'),
        includeExperimental: formData.get('includeExperimental')
      };

      // Show loading
      document.getElementById('results').style.display = 'block';
      document.getElementById('loading').style.display = 'block';
      document.getElementById('scanResults').style.display = 'none';

      try {
        const response = await fetch('/run-scan', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data)
        });

        const result = await response.json();
        
        document.getElementById('loading').style.display = 'none';
        document.getElementById('scanResults').style.display = 'block';
        
        displayResults(result);
      } catch (error) {
        document.getElementById('loading').style.display = 'none';
        document.getElementById('scanResults').innerHTML = '<p style="color: red;">Error: ' + error.message + '</p>';
        document.getElementById('scanResults').style.display = 'block';
      }
    });

    function displayResults(result) {
      const html = \`
        <h2>Scan Results</h2>
        <div class="summary-grid">
          <div class="summary-item">
            <div class="number">\${result.summary.total}</div>
            <div class="label">Total Issues</div>
          </div>
          <div class="summary-item">
            <div class="number">\${result.summary.byImpact.critical || 0}</div>
            <div class="label">Critical</div>
          </div>
          <div class="summary-item">
            <div class="number">\${result.summary.byImpact.serious || 0}</div>
            <div class="label">Serious</div>
          </div>
          <div class="summary-item">
            <div class="number">\${result.summary.byImpact.moderate || 0}</div>
            <div class="label">Moderate</div>
          </div>
          <div class="summary-item">
            <div class="number">\${result.summary.byImpact.minor || 0}</div>
            <div class="label">Minor</div>
          </div>
        </div>
        
        <h3>Issues by Impact</h3>
        \${Object.entries(result.summary.byImpact).map(([impact, count]) => 
          \`<span class="badge badge-\${impact}">\${impact}: \${count}</span>\`
        ).join('')}
        
        <h3>Detailed Issues</h3>
        \${result.issues.slice(0, 10).map(issue => \`
          <div style="margin: 15px 0; padding: 15px; background: #f8f9fa; border-radius: 8px; border-left: 4px solid #667eea;">
            <h4>\${issue.help}</h4>
            <p><strong>Impact:</strong> <span class="badge badge-\${issue.impact}">\${issue.impact}</span></p>
            <p>\${issue.description}</p>
            <p><a href="\${issue.moreInfo}" target="_blank">Learn More</a></p>
          </div>
        \`).join('')}
        
        \${result.issues.length > 10 ? '<p>... and ' + (result.issues.length - 10) + ' more issues</p>' : ''}
      \`;
      
      document.getElementById('scanResults').innerHTML = html;
    }

    // Handle recording
    document.getElementById('startRecording').addEventListener('click', async function() {
      const recordUrl = document.getElementById('recordUrl').value;
      if (!recordUrl) {
        alert('Please enter a URL to record');
        return;
      }

      this.disabled = true;
      this.textContent = '🎬 Recording... (2 min auto-stop)';

      try {
        const response = await fetch('/start-recording', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ baseUrl: recordUrl })
        });

        if (response.ok) {
          alert('Recording started! A browser window has opened. Perform your actions and the recording will automatically stop after 2 minutes and save your interactions.');
        } else {
          const error = await response.json();
          alert('Failed to start recording: ' + (error.error || 'Unknown error'));
        }
      } catch (error) {
        alert('Error starting recording: ' + error.message);
      }

      this.disabled = false;
      this.textContent = '🎬 Start Recording';
    });
  </script>
</body>
</html>
  `);
});

app.post('/run-scan', async (req: Request, res: Response) => {
  try {
    const { url, standards, conformance, scanType, selector, includeBestPractices, includeExperimental } = req.body;

    // Use the first selected standard
    const standard = standards.includes('wcag22') ? 'wcag22' : 'wcag21';

    const config: ScanConfig = {
      standard: standard as 'wcag21' | 'wcag22',
      conformance: conformance as 'A' | 'AA' | 'AAA',
      scanType: scanType as 'full' | 'component',
      selector: selector || undefined,
      includeBestPractices: includeBestPractices === 'true',
      includeExperimental: includeExperimental === 'true'
    };

    const browser = await chromium.launch({ headless: true });
    const context = await browser.newContext();
    const page = await context.newPage();

    const recorder = new PageRecorder('');
    await recorder.setupPage(page);

    const scanner = new AxeScanner(config);

    await page.goto(url, { waitUntil: 'networkidle' });
    await page.waitForTimeout(1000);

    const result = await scanner.scan(page);
    
    await browser.close();

    if (result) {
      res.json(result.normalized);
    } else {
      res.status(500).json({ error: 'Scan failed' });
    }
  } catch (error) {
    console.error('Scan error:', error);
    res.status(500).json({ error: error instanceof Error ? error.message : 'Unknown error' });
  }
});

app.post('/start-recording', async (req: Request, res: Response) => {
  try {
    const { baseUrl } = req.body;
    
    if (!baseUrl) {
      return res.status(400).json({ error: 'Base URL is required' });
    }

    // Start the recorder process
    const recorder = spawn('npm', ['run', 'record'], {
      stdio: ['pipe', 'pipe', 'pipe'],
      env: { ...process.env, BASE_URL: baseUrl },
      cwd: path.join(__dirname, '..')
    });

    recorder.stdout.on('data', (data) => {
      console.log(`Recorder stdout: ${data}`);
    });

    recorder.stderr.on('data', (data) => {
      console.error(`Recorder stderr: ${data}`);
    });

    recorder.on('close', (code) => {
      console.log(`Recording process exited with code ${code}`);
    });

    recorder.on('error', (error) => {
      console.error('Failed to start recording process:', error);
    });

    res.json({ message: 'Recording started successfully' });
  } catch (error) {
    console.error('Recording error:', error);
    res.status(500).json({ error: error instanceof Error ? error.message : 'Unknown error' });
  }
});

app.listen(port, () => {
  console.log(`🚀 Sentinel Accessibility ZeroCode Tool running at http://localhost:${port}`);
  console.log('Open this URL in your browser to start scanning.');
});