import { chromium } from '@playwright/test';
import * as fs from 'fs-extra';
import * as path from 'path';

interface RecordedAction {
  type: 'navigation';
  url: string;
  timestamp: string;
}

async function main() {
  const baseUrl = process.env.BASE_URL || 'https://example.com';
  const recordFile = path.join(__dirname, '..', 'recordings', `recording_${Date.now()}.json`);

  await fs.ensureDir(path.dirname(recordFile));

  const browser = await chromium.launch({ headless: false });
  const context = await browser.newContext();
  const page = await context.newPage();

  const actions: RecordedAction[] = [];

  // Record navigations
  page.on('framenavigated', frame => {
    if (frame === page.mainFrame()) {
      actions.push({
        type: 'navigation',
        url: frame.url(),
        timestamp: new Date().toISOString()
      });
      console.log(`Recorded navigation to: ${frame.url()}`);
    }
  });

  console.log(`Recording started. Navigate to ${baseUrl} and interact with the application.`);
  console.log('Press Ctrl+C to stop recording and save.');

  await page.goto(baseUrl);

  // Auto-stop after 2 minutes
  const timeout = setTimeout(async () => {
    await fs.writeJson(recordFile, actions, { spaces: 2 });
    console.log(`Recording auto-saved to: ${recordFile}`);
    await browser.close();
    process.exit(0);
  }, 2 * 60 * 1000); // 2 minutes

  // Wait for user to interact or timeout
  process.on('SIGINT', async () => {
    clearTimeout(timeout);
    await fs.writeJson(recordFile, actions, { spaces: 2 });
    console.log(`Recording saved to: ${recordFile}`);
    await browser.close();
    process.exit(0);
  });

  // Keep running
  await new Promise(() => {}); // Wait indefinitely
}

main().catch(console.error);