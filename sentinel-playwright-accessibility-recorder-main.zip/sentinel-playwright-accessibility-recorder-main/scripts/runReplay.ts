import { chromium } from '@playwright/test';
import * as fs from 'fs-extra';
import * as path from 'path';
import { AxeScanner, ScanConfig } from '../src/scanner/axeScanner';
import { ReportWriter } from '../src/scanner/reportWriter';
import { SummaryWriter, SummaryReport } from '../src/scanner/summaryWriter';
import { PageRecorder } from '../src/hooks/pageRecorder';

interface RecordedAction {
  type: 'navigation';
  url: string;
  timestamp: string;
}

async function main() {
  const recordFile = process.env.RECORDING_FILE || path.join(__dirname, '..', 'recordings', 'recording_latest.json');
  const config: ScanConfig = {
    standard: (process.env.STANDARD as 'wcag21' | 'wcag22') || 'wcag21',
    conformance: (process.env.CONFORMANCE as 'A' | 'AA' | 'AAA') || 'AA',
    scanType: 'full'
  };

  const runId = `replay_${Date.now()}`;
  const reportsDir = path.join(__dirname, '..', 'reports', runId);
  await fs.ensureDir(reportsDir);

  const actions: RecordedAction[] = await fs.readJson(recordFile);

  const browser = await chromium.launch({ headless: false });
  const context = await browser.newContext();
  const page = await context.newPage();

  const recorder = new PageRecorder(reportsDir);
  await recorder.setupPage(page);

  const scanner = new AxeScanner(config);
  const reportWriter = new ReportWriter(reportsDir);

  const pages: any[] = [];
  let pageIndex = 1;

  for (const action of actions) {
    if (action.type === 'navigation') {
      console.log(`Replaying navigation to: ${action.url}`);

      await page.goto(action.url, { waitUntil: 'networkidle' });
      await page.waitForTimeout(2000);

      await recorder.recordPage(page, { url: action.url, title: await page.title(), index: pageIndex });

      const result = await scanner.scan(page);
      if (result) {
        await reportWriter.writePageReport(pageIndex, await page.title(), result);
        pages.push({
          index: pageIndex,
          url: action.url,
          title: await page.title(),
          timestamp: action.timestamp,
          issues: result.normalized.summary
        });
      }
      pageIndex++;
    }
  }

  // Generate summary
  const summaryWriter = new SummaryWriter(reportsDir);
  const summary: SummaryReport = {
    metadata: {
      runId,
      standard: config.standard,
      conformance: config.conformance,
      scanType: config.scanType,
      startTime: new Date().toISOString(),
      endTime: new Date().toISOString()
    },
    pages,
    totals: {
      totalPages: pages.length,
      totalIssues: pages.reduce((sum, p) => sum + p.issues.total, 0),
      byImpact: pages.reduce((acc, p) => {
        Object.entries(p.issues.byImpact).forEach(([impact, count]) => {
          acc[impact] = (acc[impact] || 0) + (count as number);
        });
        return acc;
      }, {} as Record<string, number>),
      topRules: []
    }
  };

  await summaryWriter.writeSummary(summary);

  await browser.close();
  console.log(`Replay and scan complete. Reports in ${reportsDir}`);
}

main().catch(console.error);