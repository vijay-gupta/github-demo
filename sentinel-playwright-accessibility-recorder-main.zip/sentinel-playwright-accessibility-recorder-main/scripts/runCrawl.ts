import { chromium } from '@playwright/test';
import * as path from 'path';
import * as fs from 'fs-extra';
import { Crawler } from '../src/crawler/crawler';
import { AxeScanner, ScanConfig } from '../src/scanner/axeScanner';
import { ReportWriter } from '../src/scanner/reportWriter';
import { SummaryWriter, SummaryReport } from '../src/scanner/summaryWriter';
import { PageRecorder } from '../src/hooks/pageRecorder';

async function main() {
  const config: ScanConfig & { baseUrl: string; maxPages: number; waitStrategy: 'networkidle' | 'load' | 'domcontentloaded' } = {
    baseUrl: process.env.BASE_URL || 'https://example.com',
    standard: (process.env.STANDARD as 'wcag21' | 'wcag22') || 'wcag21',
    conformance: (process.env.CONFORMANCE as 'A' | 'AA' | 'AAA') || 'AA',
    scanType: 'full',
    maxPages: parseInt(process.env.MAX_PAGES || '10'),
    waitStrategy: (process.env.WAIT_STRATEGY as 'networkidle' | 'load' | 'domcontentloaded') || 'networkidle'
  };

  const runId = `run_${Date.now()}`;
  const reportsDir = path.join(__dirname, '..', 'reports', runId);
  await fs.ensureDir(reportsDir);

  const browser = await chromium.launch({ headless: false });
  const context = await browser.newContext();
  const page = await context.newPage();

  const recorder = new PageRecorder(reportsDir);
  await recorder.setupPage(page);

  const scanner = new AxeScanner(config);
  const reportWriter = new ReportWriter(reportsDir);

  const crawler = new Crawler(config);
  const pages: any[] = [];

  await crawler.crawl(page, async (pageInfo) => {
    console.log(`Scanning page ${pageInfo.index}: ${pageInfo.title}`);

    await recorder.recordPage(page, pageInfo);

    const result = await scanner.scan(page);
    if (result) {
      await reportWriter.writePageReport(pageInfo.index, pageInfo.title, result);
      pages.push({
        index: pageInfo.index,
        url: pageInfo.url,
        title: pageInfo.title,
        timestamp: new Date().toISOString(),
        issues: result.normalized.summary
      });
    }
  });

  // Generate summary
  const summaryWriter = new SummaryWriter(reportsDir);
  const summary: SummaryReport = {
    metadata: {
      runId,
      standard: config.standard,
      conformance: config.conformance,
      scanType: config.scanType,
      startTime: new Date().toISOString(),
      endTime: new Date().toISOString()
    },
    pages,
    totals: {
      totalPages: pages.length,
      totalIssues: pages.reduce((sum, p) => sum + p.issues.total, 0),
      byImpact: pages.reduce((acc, p) => {
        Object.entries(p.issues.byImpact).forEach(([impact, count]) => {
          acc[impact] = (acc[impact] || 0) + (count as number);
        });
        return acc;
      }, {} as Record<string, number>),
      topRules: [] // Would need to aggregate from individual reports
    }
  };

  await summaryWriter.writeSummary(summary);

  await browser.close();
  console.log(`Reports generated in ${reportsDir}`);
}

main().catch(console.error);