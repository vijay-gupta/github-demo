import express from 'express';
import * as path from 'path';
import { spawn } from 'child_process';

const app = express();
const port = 3000;

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.get('/', (req, res) => {
  res.send(`
<!DOCTYPE html>
<html>
<head>
  <title>Sentinel Accessibility Recorder</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 40px; background: linear-gradient(to bottom, #1e3a8a, #334155); color: white; }
    .container { max-width: 600px; margin: 0 auto; background: rgba(255,255,255,0.1); padding: 30px; border-radius: 10px; }
    h1 { text-align: center; }
    form { display: flex; flex-direction: column; gap: 20px; }
    label { font-weight: bold; }
    input { padding: 10px; border: none; border-radius: 5px; }
    button { padding: 12px; background: #007acc; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; }
    button:hover { background: #005999; }
    .status { margin-top: 20px; padding: 10px; background: rgba(0,0,0,0.2); border-radius: 5px; }
  </style>
</head>
<body>
  <div class="container">
    <h1>Sentinel Accessibility Recorder</h1>
    <form action="/start-recording" method="POST">
      <div>
        <label for="baseUrl">Enter the starting URL to record:</label>
        <input type="url" id="baseUrl" name="baseUrl" placeholder="https://example.com" required>
      </div>
      <button type="submit">Start Recording</button>
    </form>
    <div class="status" id="status">
      Enter a URL above and click "Start Recording" to begin capturing your application workflow.
    </div>
  </div>
</body>
</html>
  `);
});

app.post('/start-recording', (req, res) => {
  const baseUrl = req.body.baseUrl;
  if (!baseUrl) {
    return res.status(400).send('URL is required');
  }

  // Start the recorder process
  const recorder = spawn('npm', ['run', 'record'], {
    stdio: 'inherit',
    env: { ...process.env, BASE_URL: baseUrl },
    cwd: path.join(__dirname, '..')
  });

  res.send(`
<!DOCTYPE html>
<html>
<head>
  <title>Recording Started</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 40px; background: linear-gradient(to bottom, #1e3a8a, #334155); color: white; }
    .container { max-width: 600px; margin: 0 auto; background: rgba(255,255,255,0.1); padding: 30px; border-radius: 10px; text-align: center; }
  </style>
</head>
<body>
  <div class="container">
    <h1>Recording Started!</h1>
    <p>Browser has opened and is recording navigations from: <strong>${baseUrl}</strong></p>
    <p>Interact with your application. All page navigations will be recorded.</p>
    <p>When finished, press <code>Ctrl+C</code> in the terminal to save the recording.</p>
    <p>Then run: <code>npm run replay</code> to scan the recorded pages.</p>
    <br>
    <a href="/" style="color: #007acc;">Start New Recording</a>
  </div>
</body>
</html>
  `);

  recorder.on('close', (code) => {
    console.log(`Recorder process exited with code ${code}`);
  });
});

app.listen(port, () => {
  console.log(`Sentinel Recorder web interface available at http://localhost:${port}`);
  console.log('Open this URL in your browser to start recording.');
});