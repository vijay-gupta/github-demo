# Sentinel Playwright Accessibility Recorder

A Playwright-based enterprise accessibility scanning harness that records page visits, runs axe-core scans, and generates comprehensive WCAG reports.

## Features

- **Recording**: Capture user interactions and page navigations
- **Replay & Scan**: Automatically replay recordings with accessibility testing
- **Crawl Mode**: Automated site crawling with scans
- **Scripted Mode**: Custom test flows
- **Reporting**: JSON and HTML reports with WCAG compliance details

## Setup

1. Install dependencies:
   ```bash
   npm install
   ```

2. Install Playwright browsers:
   ```bash
   npx playwright install
   ```

## Configuration

Use environment variables:
- `BASE_URL`: Starting URL
- `STANDARD`: wcag21 | wcag22
- `CONFORMANCE`: A | AA | AAA
- `MAX_PAGES`: Number of pages to crawl
- `RECORDING_FILE`: Path to recording file for replay

## Running

### Recording Workflow
1. **Web-Based Recording**:
   ```bash
   npm run record:web
   ```
   - Opens web interface at http://localhost:3000
   - Enter starting URL in the browser form
   - Click "Start Recording" to launch browser and begin capturing
   - Navigate through your application
   - Recording automatically captures page navigations
   - Press Ctrl+C in terminal to save

2. **Command-Line Recording**:
   ```bash
   BASE_URL=https://your-app.com npm run record
   ```

3. **Replay and Scan**:
   ```bash
   RECORDING_FILE=recordings/recording_123.json npm run replay
   ```
   - Replays recorded navigations
   - Runs accessibility scans after each page
   - Generates full reports

### Other Modes
- **Crawl Mode**: `npm run scan:crawl`
- **Scripted Mode**: `npm run scan:scripted`

### View Reports
```bash
npm run report:open
```

## Artifacts

- `reports/`: Run-specific report directories
- `recordings/`: Saved interaction recordings
- `screenshots/`: Page screenshots
- `logs/`: Console and network logs

## ZeroCode Accessibility Tool

For organizations that need a user-friendly, code-free accessibility testing solution:

### Launch ZeroCode Tool
```bash
npm run zerocode
```
- Opens web interface at http://localhost:3000
- **Multi-select WCAG Standards**: Choose WCAG 2.1, 2.2, or both
- **Conformance Levels**: A, AA, or AAA
- **Scan Types**: Full page or component-specific
- **URL Input**: Enter target website URL
- **Instant Results**: Real-time accessibility scan with detailed reports

### Features
- 🎯 **User-Friendly Interface**: No technical knowledge required
- 📊 **Real-Time Results**: Immediate feedback on accessibility issues
- 🎨 **Professional UI**: Enterprise-grade design
- 📱 **Responsive**: Works on desktop and mobile browsers
- 🔒 **Standalone**: Can be packaged for distribution without source code

### Distribution
To create a distributable version for your organization:
1. Package the application using tools like `pkg` or Electron
2. Distribute the executable - users only need the tool, not the code
3. The web interface handles all configuration and execution