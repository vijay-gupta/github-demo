/**
 * SC 3.3.8 Accessible Authentication (Minimum)
 * Automatable subset: Authentication inputs must not block paste/copy/cut via
 * inline handlers that prevent default behavior.
 * Limitations:
 * - Only detects inline event handlers (not addEventListener bindings).
 * - Cannot confirm alternative authentication methods or cognitive load.
 */
(function () {
  const RULE_ID =
    "custom-wcag22-sc-338-accessible-authentication-minimum";
  const CHECK_ID = "sc-338-auth-input-allows-clipboard";
  const SELECTOR = 'input[type="password"], input[autocomplete]';
  const AUTH_AUTOCOMPLETE_TOKENS = new Set([
    "username",
    "current-password",
    "new-password",
    "one-time-code"
  ]);

  function getAutocompleteTokens(node) {
    const raw = (node.getAttribute("autocomplete") || "").trim().toLowerCase();
    if (!raw) return [];
    const tokens = raw.split(/\s+/).filter(Boolean);
    if (tokens.includes("off")) return [];
    return tokens.filter((token) => token !== "on");
  }

  function hasAuthToken(tokens) {
    return tokens.some((token) => AUTH_AUTOCOMPLETE_TOKENS.has(token));
  }

  function formHasAuthField(scopeRoot, currentNode) {
    const candidates = Array.from(scopeRoot.querySelectorAll(SELECTOR));
    return candidates.some((node) => {
      if (node === currentNode) return false;
      const type = (node.getAttribute("type") || "text").toLowerCase();
      if (type === "password") return true;
      const tokens = getAutocompleteTokens(node);
      return hasAuthToken(tokens);
    });
  }

  function isAuthInput(node) {
    if (node.tagName.toLowerCase() !== "input") return false;

    const type = (node.getAttribute("type") || "text").toLowerCase();
    if (type === "password") return true;

    const tokens = getAutocompleteTokens(node);
    if (!tokens.length) return false;
    if (hasAuthToken(tokens)) return true;

    if (tokens.includes("email")) {
      const scopeRoot = node.form || document;
      return formHasAuthField(scopeRoot, node);
    }

    return false;
  }

  function isEditable(node) {
    if (node.disabled === true) return false;
    if ((node.getAttribute("aria-disabled") || "").toLowerCase() === "true") {
      return false;
    }
    if (node.readOnly === true) return false;
    if ((node.getAttribute("aria-readonly") || "").toLowerCase() === "true") {
      return false;
    }
    return true;
  }

  function handlerBlocks(node, attrName) {
    const raw = node.getAttribute(attrName);
    if (!raw) return false;
    const normalized = raw.toLowerCase();
    return (
      normalized.includes("preventdefault") ||
      normalized.includes("return false")
    );
  }

  function blocksClipboard(node) {
    return (
      handlerBlocks(node, "onpaste") ||
      handlerBlocks(node, "oncopy") ||
      handlerBlocks(node, "oncut")
    );
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector: SELECTOR,
        impact: "serious",
        tags: ["wcag2aa", "wcag22aa", "wcag338", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Authentication inputs should not block clipboard operations needed for non-cognitive login",
          help:
            "Ensure authentication inputs do not block paste/copy/cut via inline handlers that prevent default behavior",
          helpUrl:
            "https://www.w3.org/TR/WCAG22/#accessible-authentication-minimum",
          messages: {
            pass: "3.3.8 - Accessible Authentication (Minimum) - Pass",
            fail: "3.3.8 - Accessible Authentication (Minimum) - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          if (!isAuthInput(node)) return true;
          if (!isEditable(node)) return true;
          return !blocksClipboard(node);
        },
        metadata: {
          impact: "serious",
          messages: {
            pass:
              "3.3.8 - Accessible Authentication - clipboard allowed for auth input - Pass",
            fail:
              "3.3.8 - Accessible Authentication - clipboard blocked for auth input - Fail"
          }
        }
      }
    ]
  });

  console.log(
    "[AXE_CUSTOM_RULE] sc-338-accessible-authentication-minimum loaded"
  );
})();
