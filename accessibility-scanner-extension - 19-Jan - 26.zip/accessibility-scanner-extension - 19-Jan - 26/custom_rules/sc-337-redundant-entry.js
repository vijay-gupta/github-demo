/**
 * SC 3.3.7 Redundant Entry
 * Automatable subset: Within the same form, if a later field repeats the same
 * autocomplete token as an earlier user-entry field, the later field should be
 * auto-populated, read-only/disabled, or offer a datalist selection.
 * Limitations:
 * - Only checks fields with explicit autocomplete tokens.
 * - Does not determine essential/security exceptions.
 * - Does not detect redundancy without autocomplete metadata.
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-337-redundant-entry";
  const CHECK_ID = "sc-337-redundant-entry-avoided";
  const SELECTOR =
    'input[autocomplete], select[autocomplete], textarea[autocomplete]';

  function getAutocompleteKey(node) {
    const raw = (node.getAttribute("autocomplete") || "").trim().toLowerCase();
    if (!raw) return null;

    const tokens = raw.split(/\s+/).filter(Boolean);
    if (!tokens.length) return null;
    if (tokens.includes("off")) return null;

    const normalized = tokens.filter((token) => token !== "on");
    if (!normalized.length) return null;

    if (normalized.some((token) => token.includes("password"))) {
      return null;
    }

    return normalized.join(" ");
  }

  function isDisabled(node) {
    return (
      node.disabled === true ||
      (node.getAttribute("aria-disabled") || "").toLowerCase() === "true"
    );
  }

  function isReadonly(node) {
    return (
      node.readOnly === true ||
      (node.getAttribute("aria-readonly") || "").toLowerCase() === "true"
    );
  }

  function isUserEntryField(node) {
    if (isDisabled(node) || isReadonly(node)) return false;

    if (node.tagName.toLowerCase() !== "input") return true;

    const type = (node.getAttribute("type") || "text").toLowerCase();
    if (
      type === "hidden" ||
      type === "submit" ||
      type === "button" ||
      type === "reset" ||
      type === "image" ||
      type === "password"
    ) {
      return false;
    }

    return true;
  }

  function isAutoPopulatedOrSelectable(node) {
    if (isDisabled(node) || isReadonly(node)) return true;

    const value = (node.value || "").trim();
    if (value.length > 0) return true;

    const listId = node.getAttribute("list");
    if (listId) {
      const listEl = document.getElementById(listId);
      if (listEl && listEl.tagName.toLowerCase() === "datalist") {
        const hasOptions = listEl.querySelectorAll("option").length > 0;
        if (hasOptions) return true;
      }
    }

    return false;
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector: SELECTOR,
        impact: "serious",
        tags: ["wcag2aa", "wcag22aa", "wcag337", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Avoid redundant entry by auto-populating or offering selection for repeated fields",
          help:
            "When a form repeats the same autocomplete field, ensure the later field is auto-populated, read-only/disabled, or offers a selection list",
          helpUrl: "https://www.w3.org/TR/WCAG22/#redundant-entry",
          messages: {
            pass: "3.3.7 - Redundant Entry - Pass",
            fail: "3.3.7 - Redundant Entry - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          const key = getAutocompleteKey(node);
          if (!key) return true;

          if (!isUserEntryField(node)) return true;

          const scopeRoot = node.form || document;
          const candidates = Array.from(scopeRoot.querySelectorAll(SELECTOR))
            .filter(isUserEntryField);

          const nodeIndex = candidates.indexOf(node);
          if (nodeIndex <= 0) return true;

          for (let i = 0; i < nodeIndex; i++) {
            const prior = candidates[i];
            const priorKey = getAutocompleteKey(prior);
            if (priorKey && priorKey === key) {
              return isAutoPopulatedOrSelectable(node);
            }
          }

          return true;
        },
        metadata: {
          impact: "serious",
          messages: {
            pass:
              "3.3.7 - Redundant Entry - repeated autocomplete field is auto-populated or selectable - Pass",
            fail:
              "3.3.7 - Redundant Entry - repeated autocomplete field requires re-entry - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-337-redundant-entry loaded");
})();
