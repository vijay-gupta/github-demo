/**
 * SC 3.2.2 On Input
 * Automatable subset: Input controls with inline oninput/onchange handlers must not
 * trigger obvious context changes like navigation, new windows, or form submit.
 * Limitations:
 * - Cannot detect handlers added via addEventListener or external scripts.
 * - Cannot determine whether users were advised about the behavior beforehand.
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-322-on-input";
  const CHECK_ID = "sc-322-inline-oninput-context-change";

  const INPUT_CONTROL_SELECTOR = [
    "input:not([type=\"hidden\"])",
    "select",
    "textarea",
    "[contenteditable=\"true\"]",
    "[role=\"combobox\"]",
    "[role=\"textbox\"]",
    "[role=\"spinbutton\"]",
    "[role=\"slider\"]",
    "[role=\"checkbox\"]",
    "[role=\"radio\"]",
    "[role=\"switch\"]",
    "[role=\"listbox\"]"
  ].join(", ");

  const CONTEXT_CHANGE_PATTERNS = [
    { id: "location-assign", regex: /\blocation\.assign\s*\(/i },
    { id: "location-replace", regex: /\blocation\.replace\s*\(/i },
    { id: "location-href", regex: /\blocation\.href\s*=/i },
    { id: "window-location", regex: /\bwindow\.location\s*=/i },
    { id: "document-location", regex: /\bdocument\.location\s*=/i },
    { id: "location-equals", regex: /\blocation\s*=\s*/i },
    { id: "window-open", regex: /\bwindow\.open\s*\(/i },
    { id: "document-open", regex: /\bdocument\.open\s*\(/i },
    { id: "form-submit", regex: /\bsubmit\s*\(/i }
  ];

  function isInputControl(node) {
    if (!node || typeof node.matches !== "function") return false;
    return node.matches(INPUT_CONTROL_SELECTOR);
  }

  function getInlineHandlers(node) {
    const handlers = [];
    const onInput = (node.getAttribute("oninput") || "").trim();
    const onChange = (node.getAttribute("onchange") || "").trim();
    if (onInput) handlers.push(onInput);
    if (onChange) handlers.push(onChange);
    return handlers;
  }

  function hasContextChange(handler) {
    if (!handler) return false;
    return CONTEXT_CHANGE_PATTERNS.some((pattern) => pattern.regex.test(handler));
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector: "[oninput], [onchange]",
        impact: "serious",
        tags: ["wcag2aa", "wcag22aa", "wcag322", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Input changes must not automatically trigger a change of context",
          help:
            "Ensure inline oninput/onchange handlers do not navigate, open new windows, or submit forms",
          helpUrl: "https://www.w3.org/TR/WCAG22/#on-input",
          messages: {
            pass: "3.2.2 - On Input - Pass",
            fail: "3.2.2 - On Input - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          if (!isInputControl(node)) return true;

          const handlers = getInlineHandlers(node);
          if (!handlers.length) return true;

          return handlers.every((handler) => !hasContextChange(handler));
        },
        metadata: {
          impact: "serious",
          messages: {
            pass:
              "3.2.2 - On Input - inline oninput/onchange does not change context - Pass",
            fail:
              "3.2.2 - On Input - inline oninput/onchange changes context - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-322-on-input loaded");
})();
