/**
 * SC 2.4.6 Headings and Labels
 * Automatable subset: Visible headings and labels must expose non-empty
 * accessible text via text content, aria-label, or aria-labelledby.
 * Limitations:
 * - Cannot determine whether text accurately describes topic or purpose.
 * - Does not compute full accessible name beyond simple text sources.
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-246-headings-labels";
  const CHECK_ID = "sc-246-heading-label-has-text";

  function isHidden(node) {
    if (!node || typeof node.matches !== "function") return true;
    if (node.matches("[hidden]")) return true;
    if (node.closest('[aria-hidden="true"]')) return true;

    const style = window.getComputedStyle(node);
    if (!style) return false;
    if (style.display === "none") return true;
    if (style.visibility === "hidden") return true;
    if (parseFloat(style.opacity) === 0) return true;
    return false;
  }

  function getReferencedText(node, attr) {
    const raw = node.getAttribute(attr) || "";
    const ids = raw.trim().split(/\s+/).filter(Boolean);
    const texts = [];

    for (const id of ids) {
      const el = document.getElementById(id);
      if (!el) continue;
      const text = (el.textContent || "").trim();
      if (text.length) texts.push(text);
    }

    return {
      ids,
      texts,
      hasText: texts.length > 0
    };
  }

  function getAccessibleText(node) {
    const textContent = (node.textContent || "").trim();
    if (textContent.length) return { hasText: true, source: "text" };

    const ariaLabel = (node.getAttribute("aria-label") || "").trim();
    if (ariaLabel.length) return { hasText: true, source: "aria-label" };

    const labelledBy = getReferencedText(node, "aria-labelledby");
    if (labelledBy.hasText) return { hasText: true, source: "aria-labelledby" };

    return { hasText: false, source: "none" };
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector: "h1, h2, h3, h4, h5, h6, label",
        impact: "moderate",
        tags: ["wcag2aa", "wcag22aa", "wcag246", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Headings and labels should expose non-empty accessible text",
          help:
            "Ensure headings and labels have visible text or an accessible name",
          helpUrl: "https://www.w3.org/TR/WCAG22/#headings-and-labels",
          messages: {
            pass: "2.4.6 - Headings and Labels - Pass",
            fail: "2.4.6 - Headings and Labels - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          if (isHidden(node)) return true;
          const accessible = getAccessibleText(node);
          return accessible.hasText;
        },
        metadata: {
          impact: "moderate",
          messages: {
            pass:
              "2.4.6 - Headings and Labels - heading/label has accessible text - Pass",
            fail:
              "2.4.6 - Headings and Labels - heading/label missing accessible text - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-246-headings-labels loaded");
})();
