/**
 * SC 2.5.7 Dragging Movements
 * Automatable subset: Elements with inline drag event handlers must provide
 * an inline single-pointer alternative on the same element.
 * Limitations:
 * - Does not detect handlers added via addEventListener or external scripts.
 * - Cannot verify alternatives provided on different elements.
 * - Cannot determine whether dragging is essential.
 * - Only inspects explicit drag event handler attributes.
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-257-dragging-movements";
  const CHECK_ID = "sc-257-dragging-has-single-pointer-alt";

  const DRAG_HANDLER_ATTRS = [
    "ondragstart",
    "ondrag",
    "ondragend",
    "ondragover",
    "ondragenter",
    "ondragleave",
    "ondrop"
  ];

  const DRAG_SELECTOR = DRAG_HANDLER_ATTRS.map((attr) => `[${attr}]`).join(", ");

  const SINGLE_POINTER_ALT_ATTRS = [
    "onclick",
    "onpointerdown",
    "onpointerup",
    "onmousedown",
    "onmouseup",
    "ontouchstart",
    "ontouchend"
  ];

  const KEY_HANDLER_ATTRS = ["onkeydown", "onkeyup", "onkeypress"];

  const FOCUSABLE_SELECTOR = [
    "a[href]",
    "button",
    "input:not([type=\"hidden\"])",
    "select",
    "textarea",
    "summary",
    "[role=\"button\"]",
    "[role=\"link\"]",
    "[role=\"menuitem\"]",
    "[role=\"tab\"]",
    "[role=\"switch\"]",
    "[role=\"checkbox\"]",
    "[role=\"radio\"]",
    "[role=\"option\"]",
    "[role=\"textbox\"]",
    "[contenteditable=\"true\"]",
    "[tabindex]:not([tabindex=\"-1\"])"
  ].join(", ");

  function isVisible(node) {
    const style = window.getComputedStyle(node);
    if (!style) return false;
    if (style.display === "none") return false;
    if (style.visibility === "hidden") return false;
    if (parseFloat(style.opacity) === 0) return false;
    return true;
  }

  function getInlineHandler(node, attr) {
    const value = node.getAttribute(attr);
    return value ? value.trim() : "";
  }

  function hasInlineHandler(node, attrs) {
    return attrs.some((attr) => getInlineHandler(node, attr).length > 0);
  }

  function hasKeyboardAlternative(node) {
    if (!hasInlineHandler(node, KEY_HANDLER_ATTRS)) return false;
    if (typeof node.matches !== "function") return false;
    return node.matches(FOCUSABLE_SELECTOR);
  }

  function hasSinglePointerAlternative(node) {
    if (hasInlineHandler(node, SINGLE_POINTER_ALT_ATTRS)) return true;
    return hasKeyboardAlternative(node);
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector: DRAG_SELECTOR,
        impact: "serious",
        tags: ["wcag2aa", "wcag22aa", "wcag257", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Dragging movements must have a single-pointer alternative",
          help:
            "Ensure elements using drag handlers also provide an inline single-pointer alternative on the same element",
          helpUrl: "https://www.w3.org/TR/WCAG22/#dragging-movements",
          messages: {
            pass: "2.5.7 - Dragging Movements - Pass",
            fail: "2.5.7 - Dragging Movements - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          if (!node || typeof node.matches !== "function") return true;
          if (!node.matches(DRAG_SELECTOR)) return true;
          if (!isVisible(node)) return true;

          return hasSinglePointerAlternative(node);
        },
        metadata: {
          impact: "serious",
          messages: {
            pass:
              "2.5.7 - Dragging Movements - drag handler has single-pointer alternative - Pass",
            fail:
              "2.5.7 - Dragging Movements - drag handler lacks single-pointer alternative - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-257-dragging-movements loaded");
})();
