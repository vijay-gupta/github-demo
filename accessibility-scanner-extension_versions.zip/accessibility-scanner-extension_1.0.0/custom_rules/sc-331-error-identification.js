/**
 * SC 3.3.1 Error Identification
 * Automatable subset: Elements marked aria-invalid="true" must reference
 * a non-empty error message via aria-describedby or aria-errormessage.
 * Limitations:
 * - Cannot verify the error description quality or accuracy.
 * - Cannot detect purely visual error indicators.
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-331-error-identification";
  const CHECK_ID = "sc-331-error-message-present";

  function getReferencedText(node, attr) {
    const raw = node.getAttribute(attr) || "";
    const ids = raw.trim().split(/\s+/).filter(Boolean);
    const texts = [];

    for (const id of ids) {
      const el = document.getElementById(id);
      if (!el) continue;
      const text = (el.textContent || "").trim();
      if (text.length) texts.push(text);
    }

    return {
      ids,
      texts,
      hasText: texts.length > 0
    };
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector:
          'input[aria-invalid="true"], select[aria-invalid="true"], textarea[aria-invalid="true"]',
        impact: "serious",
        tags: ["wcag2aa", "wcag22aa", "wcag331", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Inputs marked invalid must reference a non-empty error message",
          help:
            "Ensure aria-invalid inputs reference an error message via aria-describedby or aria-errormessage",
          helpUrl: "https://www.w3.org/TR/WCAG22/#error-identification",
          messages: {
            pass: "3.3.1 - Error Identification - Pass",
            fail: "3.3.1 - Error Identification - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          const describedBy = getReferencedText(node, "aria-describedby");
          const errorMessage = getReferencedText(node, "aria-errormessage");
          return describedBy.hasText || errorMessage.hasText;
        },
        metadata: {
          impact: "serious",
          messages: {
            pass:
              "3.3.1 - Error Identification - aria-invalid has error text reference - Pass",
            fail:
              "3.3.1 - Error Identification - aria-invalid lacks error text reference - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-331-error-identification loaded");
})();
