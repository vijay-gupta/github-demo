/**
 * SC 2.5.4 Motion Actuation
 * Automatable subset: Elements with inline device motion handlers must also
 * provide an inline UI alternative on the same element (native control, pointer
 * handler, or focusable keyboard handler).
 * Limitations:
 * - Does not detect handlers added via addEventListener or external scripts.
 * - Cannot verify motion alternatives provided on different elements.
 * - Cannot determine if motion actuation is essential.
 * - Does not verify the ability to disable motion-based activation.
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-254-motion-actuation";
  const CHECK_ID = "sc-254-motion-has-ui-alternative";

  const MOTION_ATTRS = [
    "ondevicemotion",
    "ondeviceorientation",
    "ondeviceorientationabsolute"
  ];
  const MOTION_SELECTOR = MOTION_ATTRS.map((attr) => `[${attr}]`).join(", ");

  const POINTER_HANDLER_ATTRS = [
    "onclick",
    "onpointerdown",
    "onpointerup",
    "onmousedown",
    "onmouseup",
    "ontouchstart",
    "ontouchend"
  ];

  const KEY_HANDLER_ATTRS = ["onkeydown", "onkeyup", "onkeypress"];

  const FOCUSABLE_SELECTOR = [
    "a[href]",
    "button",
    "input:not([type=\"hidden\"])",
    "select",
    "textarea",
    "summary",
    "[role=\"button\"]",
    "[role=\"link\"]",
    "[role=\"menuitem\"]",
    "[role=\"tab\"]",
    "[role=\"switch\"]",
    "[role=\"checkbox\"]",
    "[role=\"radio\"]",
    "[role=\"option\"]",
    "[role=\"textbox\"]",
    "[contenteditable=\"true\"]",
    "[tabindex]:not([tabindex=\"-1\"])"
  ].join(", ");

  const NATIVE_INTERACTIVE_TAGS = new Set([
    "A",
    "BUTTON",
    "INPUT",
    "SELECT",
    "TEXTAREA",
    "SUMMARY"
  ]);

  function isVisible(node) {
    const style = window.getComputedStyle(node);
    if (!style) return false;
    if (style.display === "none") return false;
    if (style.visibility === "hidden") return false;
    if (parseFloat(style.opacity || "1") === 0) return false;
    return true;
  }

  function isDisabled(node) {
    return "disabled" in node && node.disabled === true;
  }

  function isHiddenInput(node) {
    return node.tagName === "INPUT" && node.type === "hidden";
  }

  function isNativeInteractive(node) {
    if (isDisabled(node)) return false;
    if (!NATIVE_INTERACTIVE_TAGS.has(node.tagName)) return false;
    if (node.tagName === "A") return node.hasAttribute("href");
    if (node.tagName === "INPUT") return !isHiddenInput(node);
    return true;
  }

  function isFocusable(node) {
    if (isHiddenInput(node)) return false;
    if (isDisabled(node)) return false;

    if (node.isContentEditable) return true;
    if (node.tabIndex >= 0) return true;

    if (NATIVE_INTERACTIVE_TAGS.has(node.tagName)) {
      if (node.tagName === "A") return node.hasAttribute("href");
      return true;
    }

    if (typeof node.matches !== "function") return false;
    return node.matches(FOCUSABLE_SELECTOR);
  }

  function getInlineHandler(node, attr) {
    const value = node.getAttribute(attr);
    return value ? value.trim() : "";
  }

  function hasInlineHandler(node, attrs) {
    return attrs.some((attr) => getInlineHandler(node, attr).length > 0);
  }

  function hasUiAlternative(node) {
    if (isNativeInteractive(node)) return true;
    if (node.isContentEditable) return true;
    if (hasInlineHandler(node, POINTER_HANDLER_ATTRS)) return true;
    if (hasInlineHandler(node, KEY_HANDLER_ATTRS) && isFocusable(node)) {
      return true;
    }
    return false;
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector: MOTION_SELECTOR,
        impact: "serious",
        tags: ["wcag2aa", "wcag22aa", "wcag254", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Motion-actuated functionality should have an inline UI alternative",
          help:
            "Ensure elements using device motion events also provide a UI alternative on the same element",
          helpUrl: "https://www.w3.org/TR/WCAG22/#motion-actuation",
          messages: {
            pass: "2.5.4 - Motion Actuation - Pass",
            fail: "2.5.4 - Motion Actuation - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          if (!node || typeof node.matches !== "function") return true;
          if (!node.matches(MOTION_SELECTOR)) return true;
          if (!isVisible(node)) return true;

          return hasUiAlternative(node);
        },
        metadata: {
          impact: "serious",
          messages: {
            pass:
              "2.5.4 - Motion Actuation - motion handler has UI alternative - Pass",
            fail:
              "2.5.4 - Motion Actuation - motion handler lacks UI alternative - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-254-motion-actuation loaded");
})();
