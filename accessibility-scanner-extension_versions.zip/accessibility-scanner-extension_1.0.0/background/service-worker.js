/**
 * Accessibility Scanner – Background Service Worker (MV3)
 */

let scanningActive = false;
const extVersion = chrome.runtime.getManifest().version;


/**
 * Inline HTML report builder (MV3-safe)
 */
/*function buildHtmlReport(payload) {
  const { url, results } = payload;

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Accessibility Report</title>
  <style>
    body { font-family: Arial, sans-serif; padding: 20px; }
    h1 { margin-bottom: 10px; }
    h2 { margin-top: 30px; }
    pre { background: #f5f5f5; padding: 10px; overflow: auto; }
  </style>
</head>
<body>
  <h1>Accessibility Report</h1>
  <p><strong>URL:</strong> ${url}</p>
  <p><strong>Generated:</strong> ${new Date().toLocaleString()}</p>

  <h2>Violations (${results.violations.length})</h2>
  <pre>${JSON.stringify(results.violations, null, 2)}</pre>

  <h2>Passes (${results.passes.length})</h2>
  <pre>${JSON.stringify(results.passes, null, 2)}</pre>

  <h2>Incomplete (${results.incomplete.length})</h2>
  <pre>${JSON.stringify(results.incomplete, null, 2)}</pre>

  <h2>Inapplicable (${results.inapplicable.length})</h2>
  <pre>${JSON.stringify(results.inapplicable, null, 2)}</pre>
</body>
</html>`;
}*/

function buildHtmlReport(payload) {
  const { url, results } = payload;

  function escapeHtml(str) {
    if (!str) return "";
    return str.replace(/[&<>"']/g, m => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      "\"": "&quot;",
      "'": "&#039;"
    }[m]));
  }

  function renderNodes(nodes) {
    if (!nodes || !nodes.length) return "—";

    return `
      <details>
        <summary>${nodes.length} element(s)</summary>
        <ul>
          ${nodes.map(n => `
            <li>
              <code>${escapeHtml(n.target.join(" "))}</code>
              ${n.failureSummary ? `<div class="failure">${escapeHtml(n.failureSummary)}</div>` : ""}
            </li>
          `).join("")}
        </ul>
      </details>
    `;
  }

  function renderTable(title, items) {
    if (!items || !items.length) {
      return `
        <h2>${title} (0)</h2>
        <p class="empty">No ${title.toLowerCase()} found.</p>
      `;
    }

    return `
      <h2>${title} (${items.length})</h2>
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>Rule ID</th>
            <th>Description</th>
            <th>Impact</th>
            <th>Tags</th>
            <th>Affected Elements</th>
            <th>Help</th>
          </tr>
        </thead>
        <tbody>
          ${items.map((item, index) => `
            <tr>
              <td>${index + 1}</td>
              <td>${escapeHtml(item.id)}</td>
              <td>${escapeHtml(item.description)}</td>
              <td class="impact ${item.impact || "none"}">
                ${item.impact || "—"}
              </td>
              <td>
                ${item.tags.map(t => `<span class="tag">${t}</span>`).join("")}
              </td>
              <td>${renderNodes(item.nodes)}</td>
              <td>
                <a href="${item.helpUrl}" target="_blank">Reference</a>
              </td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    `;
  }

  const manualReview = (results.incomplete || []).filter(
    item => item.tags && item.tags.includes("manual-review")
  );
  const incompleteNonManual = (results.incomplete || []).filter(
    item => !item.tags || !item.tags.includes("manual-review")
  );

  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Accessibility Report</title>

  <style>
    body {
      font-family: Arial, sans-serif;
      padding: 20px;
      background: #fafafa;
    }

    h1 {
      margin-bottom: 5px;
    }

    .meta {
      color: #555;
      margin-bottom: 30px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 40px;
      background: #fff;
    }

    th, td {
      border: 1px solid #ddd;
      padding: 8px;
      vertical-align: top;
      font-size: 14px;
    }

    th {
      background: #f0f0f0;
      text-align: left;
    }

    .impact.critical { color: #b00020; font-weight: bold; }
    .impact.serious  { color: #e65100; font-weight: bold; }
    .impact.moderate { color: #f9a825; font-weight: bold; }
    .impact.minor    { color: #2e7d32; font-weight: bold; }

    .tag {
      display: inline-block;
      background: #e0e0e0;
      padding: 2px 6px;
      margin: 2px;
      border-radius: 4px;
      font-size: 12px;
    }

    details summary {
      cursor: pointer;
      color: #1565c0;
    }

    .failure {
      margin-top: 4px;
      color: #c62828;
      font-size: 13px;
    }

    .empty {
      font-style: italic;
      color: #777;
      margin-bottom: 40px;
    }
  </style>
</head>

<body>

  <h1>Accessibility Scan Report</h1>
  <div class="meta">
    <div><strong>URL:</strong> ${escapeHtml(url)}</div>
    <div><strong>Generated:</strong> ${new Date().toLocaleString()}</div>
    <div><strong>Extension Version:</strong>${extVersion}</div>
  </div>

  ${renderTable("Violations", results.violations)}
  ${renderTable("Passes", results.passes)}
  ${renderTable("Manual Review", manualReview)}
  ${renderTable("Incomplete", incompleteNonManual)}
  ${renderTable("Inapplicable", results.inapplicable)}

</body>
</html>
`;
}


/**
 * Send START_SCAN to the currently active tab
 */
function triggerScanOnActiveTab() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs || !tabs.length) return;

    chrome.tabs.sendMessage(
      tabs[0].id,
      { type: "START_SCAN" },
      () => {
        if (chrome.runtime.lastError) {
          console.warn(
            "[BG] START_SCAN failed:",
            chrome.runtime.lastError.message
          );
        } else {
          console.log("[BG] START_SCAN sent to active tab");
        }
      }
    );
  });
}

function setScanState(active) {
  chrome.storage.local.set({ scanState: { active } });
}

function getScanState(callback) {
  chrome.storage.local.get("scanState", (data) => {
    callback(data.scanState?.active === true);
  });
}


chrome.runtime.onMessage.addListener((msg, sender) => {

  /**
   * ---------------------------------------------------------
   * Popup → Start scanning
   * ---------------------------------------------------------
   */
  if (msg.action === "START") {
    scanningActive = true;
    setScanState(true);
    console.log("[BG] Scanning session STARTED");

    // 🔴 CRITICAL FIX: trigger scan immediately
    triggerScanOnActiveTab();
  }

  /**
   * ---------------------------------------------------------
   * Popup → Stop scanning
   * ---------------------------------------------------------
   */
  if (msg.action === "STOP") {
    scanningActive = false;
    setScanState(false);
    console.log("[BG] Scanning session STOPPED");
  }

  if (msg.action === "SCAN_CURRENT_PAGE") {
    console.log("[BG] Scan current page requested");
    triggerScanOnActiveTab();
  }

  /**
   * ---------------------------------------------------------
   * Content script → Page ready
   * Auto-scan on navigation if session active
   * ---------------------------------------------------------
   */
  if (msg.type === "PAGE_READY") {
    console.log("[BG] PAGE_READY:", msg.url);

    if (scanningActive && sender.tab?.id) {
      chrome.tabs.sendMessage(sender.tab.id, { type: "START_SCAN" });
      console.log("[BG] START_SCAN sent due to PAGE_READY");
    }
  }

  /**
   * ---------------------------------------------------------
   * Content script → Axe results received
   * ---------------------------------------------------------
   */
  if (msg.type === "AXE_RESULTS") {
    console.log("[BG] AXE_RESULTS received for:", msg.url);

    const html = buildHtmlReport({
      url: msg.url,
      results: msg.payload
    });

    const dataUrl =
      "data:text/html;charset=utf-8," + encodeURIComponent(html);

    chrome.downloads.download(
      {
        url: dataUrl,
        filename: `accessibility-report-${Date.now()}.html`,
        saveAs: false
      },
      (downloadId) => {
        if (chrome.runtime.lastError) {
          console.error(
            "[BG] Download failed:",
            chrome.runtime.lastError.message
          );
        } else {
          console.log("[BG] Report downloaded, ID:", downloadId);
        }
      }
    );
  }
});
