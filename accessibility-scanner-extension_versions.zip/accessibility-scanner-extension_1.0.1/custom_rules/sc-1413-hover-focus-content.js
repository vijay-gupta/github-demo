/**
 * SC 1.4.13 Content on Hover or Focus
 * Automatable subset: Interactive elements with non-empty title attributes
 * produce native tooltips that are not dismissible, hoverable, or persistent.
 * Limitations:
 * - Does not detect custom hover/focus content created via scripts/CSS.
 * - Does not determine whether tooltip content is essential.
 * Version: 1.0
 * Author: Vijay Gupta  
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-1413-hover-focus-content";
  const CHECK_ID = "sc-1413-title-tooltip-disallowed";

  const INTERACTIVE_SELECTOR = [
    "a[href]",
    "button",
    "input:not([type=\"hidden\"])",
    "select",
    "textarea",
    "summary",
    "[role=\"button\"]",
    "[role=\"link\"]",
    "[role=\"menuitem\"]",
    "[role=\"tab\"]",
    "[role=\"switch\"]",
    "[role=\"checkbox\"]",
    "[role=\"radio\"]",
    "[role=\"option\"]",
    "[role=\"textbox\"]",
    "[tabindex]:not([tabindex=\"-1\"])"
  ].join(", ");

  function isVisible(style) {
    if (!style) return false;
    if (style.display === "none") return false;
    if (style.visibility === "hidden") return false;
    if (parseFloat(style.opacity) === 0) return false;
    return true;
  }

  function hasNonEmptyTitle(node) {
    const title = node.getAttribute("title");
    return typeof title === "string" && title.trim().length > 0;
  }

  function isInteractive(node) {
    if (!node || typeof node.matches !== "function") return false;
    return node.matches(INTERACTIVE_SELECTOR);
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector: "a[href][title], button[title], input:not([type=\"hidden\"])[title], select[title], textarea[title], summary[title], [role=\"button\"][title], [role=\"link\"][title], [role=\"menuitem\"][title], [role=\"tab\"][title], [role=\"switch\"][title], [role=\"checkbox\"][title], [role=\"radio\"][title], [role=\"option\"][title], [role=\"textbox\"][title], [tabindex]:not([tabindex=\"-1\"])[title]",
        impact: "moderate",
        tags: ["wcag2aa", "wcag22aa", "wcag1413", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Interactive elements should not rely on native title tooltips for hover/focus content",
          help:
            "Ensure interactive elements do not use title attributes that trigger native tooltips",
          helpUrl: "https://www.w3.org/TR/WCAG22/#content-on-hover-or-focus",
          messages: {
            pass: "1.4.13 - Content on Hover or Focus - Pass",
            fail: "1.4.13 - Content on Hover or Focus - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          const style = window.getComputedStyle(node);

          if (!isVisible(style)) return true;
          if (!hasNonEmptyTitle(node)) return true;
          if (!isInteractive(node)) return true;

          return false;
        },
        metadata: {
          impact: "moderate",
          messages: {
            pass:
              "1.4.13 - Content on Hover or Focus - no disallowed title tooltip - Pass",
            fail:
              "1.4.13 - Content on Hover or Focus - native title tooltip detected - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-1413-hover-focus-content loaded");
})();
