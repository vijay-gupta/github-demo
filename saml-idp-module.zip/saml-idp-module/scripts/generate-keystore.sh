#!/bin/bash

# =============================================================================
# Script to generate SAML IdP signing keystore
# Run this script to create the keystore for your SAML IdP
# =============================================================================

# Configuration - MODIFY THESE VALUES
KEYSTORE_DIR="src/main/resources/saml"
KEYSTORE_FILE="$KEYSTORE_DIR/idp-keystore.jks"
CERT_FILE="$KEYSTORE_DIR/idp-certificate.crt"
KEY_ALIAS="idp-signing-key"
KEYSTORE_PASSWORD="changeit"
KEY_PASSWORD="changeit"
VALIDITY_DAYS=3650  # 10 years

# Certificate DN - MODIFY THESE VALUES
CN="SAML IdP"
OU="IT Department"
O="Your Organization"
L="Your City"
ST="Your State"
C="IN"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  SAML IdP Keystore Generator${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""

# Create directory if not exists
if [ ! -d "$KEYSTORE_DIR" ]; then
    echo -e "${YELLOW}Creating directory: $KEYSTORE_DIR${NC}"
    mkdir -p "$KEYSTORE_DIR"
fi

# Check if keystore already exists
if [ -f "$KEYSTORE_FILE" ]; then
    echo -e "${YELLOW}Warning: Keystore already exists at $KEYSTORE_FILE${NC}"
    read -p "Do you want to overwrite it? (y/N): " confirm
    if [ "$confirm" != "y" ] && [ "$confirm" != "Y" ]; then
        echo "Aborted."
        exit 0
    fi
    rm -f "$KEYSTORE_FILE"
    rm -f "$CERT_FILE"
fi

# Generate keystore with RSA key pair
echo -e "${GREEN}Generating RSA key pair and keystore...${NC}"
keytool -genkeypair \
    -alias "$KEY_ALIAS" \
    -keyalg RSA \
    -keysize 2048 \
    -keystore "$KEYSTORE_FILE" \
    -storepass "$KEYSTORE_PASSWORD" \
    -keypass "$KEY_PASSWORD" \
    -validity "$VALIDITY_DAYS" \
    -dname "CN=$CN, OU=$OU, O=$O, L=$L, ST=$ST, C=$C" \
    -sigalg SHA256withRSA

if [ $? -ne 0 ]; then
    echo -e "${RED}Failed to generate keystore!${NC}"
    exit 1
fi

echo -e "${GREEN}Keystore generated successfully!${NC}"
echo ""

# Export the certificate
echo -e "${GREEN}Exporting certificate...${NC}"
keytool -exportcert \
    -alias "$KEY_ALIAS" \
    -keystore "$KEYSTORE_FILE" \
    -storepass "$KEYSTORE_PASSWORD" \
    -file "$CERT_FILE" \
    -rfc

if [ $? -ne 0 ]; then
    echo -e "${RED}Failed to export certificate!${NC}"
    exit 1
fi

echo -e "${GREEN}Certificate exported successfully!${NC}"
echo ""

# Display keystore info
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  Keystore Information${NC}"
echo -e "${GREEN}========================================${NC}"
keytool -list -v -keystore "$KEYSTORE_FILE" -storepass "$KEYSTORE_PASSWORD" -alias "$KEY_ALIAS" 2>/dev/null | head -20

echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  Summary${NC}"
echo -e "${GREEN}========================================${NC}"
echo -e "Keystore:    ${YELLOW}$KEYSTORE_FILE${NC}"
echo -e "Certificate: ${YELLOW}$CERT_FILE${NC}"
echo -e "Alias:       ${YELLOW}$KEY_ALIAS${NC}"
echo -e "Password:    ${YELLOW}$KEYSTORE_PASSWORD${NC}"
echo -e "Validity:    ${YELLOW}$VALIDITY_DAYS days${NC}"
echo ""
echo -e "${GREEN}Update your application.yml with these values:${NC}"
echo ""
echo "saml:"
echo "  idp:"
echo "    keystore:"
echo "      path: classpath:saml/idp-keystore.jks"
echo "      password: $KEYSTORE_PASSWORD"
echo "      alias: $KEY_ALIAS"
echo "      key-password: $KEY_PASSWORD"
echo ""
echo -e "${YELLOW}IMPORTANT: Change the passwords in production!${NC}"
