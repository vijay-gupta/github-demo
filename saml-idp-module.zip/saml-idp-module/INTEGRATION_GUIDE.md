# SAML IdP Integration Guide for Developers

## Overview

This guide explains how to integrate the SAML 2.0 IdP module into your existing User Management system **without affecting the existing JWT flow**. The SAML module runs as a parallel authentication mechanism - JWT applications continue to work exactly as before.

---

## Architecture: How JWT and SAML Coexist

```
                        ┌─────────────────────────────────────────┐
                        │         USER MANAGEMENT SYSTEM          │
                        │                                         │
                        │  ┌───────────────────────────────────┐  │
                        │  │     Your Existing Auth Layer      │  │
                        │  │   (SSO / DB Auth / 2FA)           │  │
                        │  └───────────────┬───────────────────┘  │
                        │                  │                      │
                        │                  ▼                      │
                        │  ┌───────────────────────────────────┐  │
                        │  │      Authenticated User Session   │  │
                        │  └───────────────┬───────────────────┘  │
                        │                  │                      │
                        │    ┌─────────────┴─────────────┐        │
                        │    │                           │        │
                        │    ▼                           ▼        │
                        │  ┌─────────────┐     ┌──────────────┐   │
                        │  │ JWT Service │     │ SAML Service │   │
                        │  │ (EXISTING)  │     │    (NEW)     │   │
                        │  │             │     │              │   │
                        │  │ No changes  │     │ Independent  │   │
                        │  │ required!   │     │ module       │   │
                        │  └──────┬──────┘     └──────┬───────┘   │
                        │         │                   │           │
                        └─────────┼───────────────────┼───────────┘
                                  │                   │
                                  ▼                   ▼
                        ┌─────────────────┐  ┌─────────────────┐
                        │   JWT Apps      │  │   SAML Apps     │
                        │                 │  │                 │
                        │ - Your existing │  │ - Legacy apps   │
                        │   microservices │  │ - Enterprise    │
                        │ - Internal apps │  │   software      │
                        │ - Mobile apps   │  │ - Third-party   │
                        └─────────────────┘  └─────────────────┘
```

### Key Principle: Zero Impact on JWT Flow

| Aspect | JWT Flow | SAML Flow |
|--------|----------|-----------|
| Authentication | Your existing auth (unchanged) | Same - uses your existing auth |
| Token Generation | Your JWT Service (unchanged) | New SAML Service |
| Token Validation | Your JAR file in apps (unchanged) | SP handles validation |
| Database | Your existing tables (unchanged) | New `saml_service_providers` table |
| Endpoints | Your existing endpoints (unchanged) | New `/saml/*` endpoints |

---

## Step-by-Step Integration

### Phase 1: Setup (No Code Changes to Existing System)

#### Step 1.1: Add Maven Dependencies

Add to your existing `pom.xml` (or create a new module):

```xml
<!-- Add to your pom.xml - these don't conflict with existing dependencies -->

<!-- OpenSAML 4.x Dependencies -->
<dependency>
    <groupId>org.opensaml</groupId>
    <artifactId>opensaml-core</artifactId>
    <version>4.3.0</version>
</dependency>
<dependency>
    <groupId>org.opensaml</groupId>
    <artifactId>opensaml-saml-api</artifactId>
    <version>4.3.0</version>
</dependency>
<dependency>
    <groupId>org.opensaml</groupId>
    <artifactId>opensaml-saml-impl</artifactId>
    <version>4.3.0</version>
</dependency>
<dependency>
    <groupId>org.opensaml</groupId>
    <artifactId>opensaml-messaging-api</artifactId>
    <version>4.3.0</version>
</dependency>
<dependency>
    <groupId>org.opensaml</groupId>
    <artifactId>opensaml-messaging-impl</artifactId>
    <version>4.3.0</version>
</dependency>
<dependency>
    <groupId>org.opensaml</groupId>
    <artifactId>opensaml-soap-api</artifactId>
    <version>4.3.0</version>
</dependency>
<dependency>
    <groupId>org.opensaml</groupId>
    <artifactId>opensaml-soap-impl</artifactId>
    <version>4.3.0</version>
</dependency>
<dependency>
    <groupId>org.opensaml</groupId>
    <artifactId>opensaml-security-api</artifactId>
    <version>4.3.0</version>
</dependency>
<dependency>
    <groupId>org.opensaml</groupId>
    <artifactId>opensaml-security-impl</artifactId>
    <version>4.3.0</version>
</dependency>
<dependency>
    <groupId>org.opensaml</groupId>
    <artifactId>opensaml-xmlsec-api</artifactId>
    <version>4.3.0</version>
</dependency>
<dependency>
    <groupId>org.opensaml</groupId>
    <artifactId>opensaml-xmlsec-impl</artifactId>
    <version>4.3.0</version>
</dependency>
<dependency>
    <groupId>net.shibboleth.utilities</groupId>
    <artifactId>java-support</artifactId>
    <version>8.4.0</version>
</dependency>
<dependency>
    <groupId>org.apache.santuario</groupId>
    <artifactId>xmlsec</artifactId>
    <version>3.0.3</version>
</dependency>
```

Add Shibboleth repository:

```xml
<repositories>
    <!-- Your existing repositories -->
    <repository>
        <id>shibboleth</id>
        <name>Shibboleth Repository</name>
        <url>https://build.shibboleth.net/maven/releases/</url>
    </repository>
</repositories>
```

#### Step 1.2: Copy SAML Module Files

Copy the following packages to your project:

```
src/main/java/com/usermanagement/saml/
├── config/
│   ├── OpenSamlConfig.java
│   ├── SamlIdpProperties.java
│   └── CredentialManager.java
├── controller/
│   ├── SamlSsoController.java
│   └── ServiceProviderApiController.java
├── dto/
│   └── ServiceProviderDto.java
├── entity/
│   └── ServiceProviderEntity.java
├── model/
│   ├── AuthenticatedUser.java
│   └── SsoResult.java
├── repository/
│   └── ServiceProviderRepository.java
├── service/
│   ├── SamlSsoService.java
│   ├── SamlAssertionBuilder.java
│   ├── SamlResponseBuilder.java
│   ├── IdpMetadataGenerator.java
│   └── ServiceProviderService.java
└── util/
    └── SamlUtils.java
```

**NOTE:** Do NOT copy `SecurityConfig.java` - we'll integrate with your existing security config instead.

#### Step 1.3: Add Configuration

Add to your `application.yml`:

```yaml
# SAML IdP Configuration - Add this section
# This does NOT affect any existing configuration
saml:
  idp:
    entity-id: https://your-domain.com/usermanagement/saml/idp
    base-url: https://your-domain.com/usermanagement
    sso-url: ${saml.idp.base-url}/saml/sso
    slo-url: ${saml.idp.base-url}/saml/slo
    metadata-url: ${saml.idp.base-url}/saml/metadata
    keystore:
      path: classpath:saml/idp-keystore.jks
      password: ${SAML_KEYSTORE_PASSWORD:changeit}
      alias: idp-signing-key
      key-password: ${SAML_KEY_PASSWORD:changeit}
    assertion-validity-seconds: 300
    session-validity-seconds: 28800
    organization:
      name: Your Organization
      display-name: Your Organization
      url: https://your-domain.com
    contact:
      type: technical
      company: Your Organization
      given-name: Admin
      email: admin@your-domain.com
```

#### Step 1.4: Generate Signing Keystore

```bash
# Create directory
mkdir -p src/main/resources/saml

# Generate keystore
keytool -genkeypair \
    -alias idp-signing-key \
    -keyalg RSA \
    -keysize 2048 \
    -keystore src/main/resources/saml/idp-keystore.jks \
    -storepass changeit \
    -keypass changeit \
    -validity 3650 \
    -dname "CN=SAML IdP, OU=IT, O=Your Organization, L=City, ST=State, C=IN"

# Export certificate (to share with SPs)
keytool -exportcert \
    -alias idp-signing-key \
    -keystore src/main/resources/saml/idp-keystore.jks \
    -storepass changeit \
    -file src/main/resources/saml/idp-certificate.crt \
    -rfc
```

#### Step 1.5: Create Database Table

Run this SQL (the table is independent - doesn't touch your existing tables):

```sql
-- New table for SAML Service Providers
-- This is INDEPENDENT of your existing application/user tables

CREATE TABLE saml_service_providers (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    entity_id VARCHAR(500) NOT NULL UNIQUE,
    application_name VARCHAR(255) NOT NULL,
    description VARCHAR(1000),
    acs_url VARCHAR(500) NOT NULL,
    slo_url VARCHAR(500),
    sp_certificate TEXT,
    sign_assertions BOOLEAN DEFAULT TRUE,
    encrypt_assertions BOOLEAN DEFAULT FALSE,
    name_id_format VARCHAR(255) DEFAULT 'urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress',
    acs_binding VARCHAR(255) DEFAULT 'urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST',
    default_relay_state VARCHAR(500),
    attribute_mappings TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    metadata_xml TEXT,
    auth_type VARCHAR(50) NOT NULL DEFAULT 'SAML',
    icon_url VARCHAR(500),
    application_url VARCHAR(500),
    display_order INT DEFAULT 0,
    category VARCHAR(100),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP,
    created_by VARCHAR(255),
    updated_by VARCHAR(255)
);

CREATE TABLE sp_allowed_roles (
    sp_id BIGINT NOT NULL,
    role VARCHAR(255) NOT NULL,
    FOREIGN KEY (sp_id) REFERENCES saml_service_providers(id) ON DELETE CASCADE
);

CREATE INDEX idx_sp_entity_id ON saml_service_providers(entity_id);
CREATE INDEX idx_sp_active ON saml_service_providers(is_active);
CREATE INDEX idx_sp_auth_type ON saml_service_providers(auth_type);
```

---

### Phase 2: Integration with Your Auth System

#### Step 2.1: Create the Authentication Bridge

Create a new class that bridges your existing authentication to the SAML module:

```java
package com.usermanagement.saml.adapter;

import com.usermanagement.saml.model.AuthenticatedUser;
// Import your existing user/session classes
import com.yourapp.security.YourUserPrincipal;
import com.yourapp.service.YourSessionService;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import jakarta.servlet.http.HttpSession;
import java.util.stream.Collectors;

/**
 * Bridges your existing authentication to the SAML module.
 * 
 * This class reads from YOUR EXISTING auth system and converts
 * to the AuthenticatedUser model needed by SAML.
 * 
 * NO CHANGES to your existing auth code required!
 */
@Component
public class YourAuthenticationBridge {

    // Inject your existing services if needed
    // private final YourSessionService sessionService;
    // private final YourUserRepository userRepository;

    /**
     * Convert your authenticated user to SAML AuthenticatedUser.
     * 
     * MODIFY THIS METHOD to match your authentication system.
     */
    public AuthenticatedUser getAuthenticatedUser(HttpSession session) {
        
        // =====================================================
        // OPTION 1: If you use Spring Security
        // =====================================================
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        
        if (auth == null || !auth.isAuthenticated()) {
            return null;
        }
        
        // If your principal is a custom class
        if (auth.getPrincipal() instanceof YourUserPrincipal) {
            YourUserPrincipal principal = (YourUserPrincipal) auth.getPrincipal();
            
            return AuthenticatedUser.builder()
                    .userId(principal.getId())
                    .email(principal.getEmail())
                    .username(principal.getUsername())
                    .firstName(principal.getFirstName())
                    .lastName(principal.getLastName())
                    .department(principal.getDepartment())
                    .title(principal.getTitle())
                    .employeeId(principal.getEmployeeId())
                    .roles(principal.getRoles())  // Set<String>
                    .groups(principal.getGroups()) // Set<String>
                    .sessionId(session.getId())
                    .authMethod(principal.getAuthMethod()) // "SSO", "DATABASE", "2FA"
                    .ssoAuthenticated(principal.isSsoAuthenticated())
                    .ssoProvider(principal.getSsoProvider())
                    .build();
        }
        
        // =====================================================
        // OPTION 2: If you store user in session attributes
        // =====================================================
        /*
        Object userObj = session.getAttribute("loggedInUser");
        if (userObj instanceof YourUserEntity) {
            YourUserEntity user = (YourUserEntity) userObj;
            
            return AuthenticatedUser.builder()
                    .userId(user.getId().toString())
                    .email(user.getEmail())
                    .username(user.getUsername())
                    .firstName(user.getFirstName())
                    .lastName(user.getLastName())
                    .roles(user.getRoles().stream()
                            .map(r -> r.getName())
                            .collect(Collectors.toSet()))
                    .sessionId(session.getId())
                    .build();
        }
        */
        
        // =====================================================
        // OPTION 3: If you use a session service
        // =====================================================
        /*
        String sessionToken = (String) session.getAttribute("sessionToken");
        if (sessionToken != null) {
            YourUserSession userSession = sessionService.getSession(sessionToken);
            if (userSession != null && !userSession.isExpired()) {
                YourUser user = userSession.getUser();
                return AuthenticatedUser.builder()
                        .userId(user.getId())
                        .email(user.getEmail())
                        // ... map other fields
                        .build();
            }
        }
        */
        
        return null;
    }
    
    /**
     * Check if current request is authenticated.
     */
    public boolean isAuthenticated() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return auth != null && auth.isAuthenticated() 
                && !(auth.getPrincipal() instanceof String 
                     && "anonymousUser".equals(auth.getPrincipal()));
    }
    
    /**
     * Get your login URL.
     */
    public String getLoginUrl(String returnUrl) {
        // Return your existing login URL
        return "/login?returnUrl=" + 
               java.net.URLEncoder.encode(returnUrl, java.nio.charset.StandardCharsets.UTF_8);
    }
}
```

#### Step 2.2: Update SamlSsoController to Use Your Bridge

Modify `SamlSsoController.java` to use your authentication bridge:

```java
// In SamlSsoController.java, add:

@Autowired
private YourAuthenticationBridge authBridge;

// Replace the getAuthenticatedUser method:
private AuthenticatedUser getAuthenticatedUser(HttpSession session) {
    return authBridge.getAuthenticatedUser(session);
}
```

#### Step 2.3: Update Security Configuration

Add SAML endpoints to your EXISTING security configuration:

```java
// In YOUR EXISTING SecurityConfig.java, add these permit rules:

@Bean
public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
    http
        .authorizeHttpRequests(auth -> auth
            // Your existing rules...
            .requestMatchers("/your-existing-public-endpoints/**").permitAll()
            
            // ADD THESE for SAML (does not affect your existing rules)
            .requestMatchers("/saml/metadata").permitAll()  // IdP metadata is public
            .requestMatchers("/saml/sso/**").permitAll()    // SSO endpoint handles auth internally
            .requestMatchers("/saml/slo/**").permitAll()    // Logout endpoint
            
            // SP Management APIs - require admin role
            .requestMatchers("/api/saml/service-providers/**").hasRole("ADMIN")
            
            // Your existing authenticated rules...
            .anyRequest().authenticated()
        )
        // ADD THIS - Disable CSRF for SAML POST endpoints
        .csrf(csrf -> csrf
            .ignoringRequestMatchers("/saml/**")
        )
        // Your existing configuration...
        ;
    
    return http.build();
}
```

---

### Phase 3: Application Launcher Integration

This is where you decide whether to launch a JWT app or SAML app.

#### Step 3.1: Create Application Type Checker Service

```java
package com.usermanagement.service;

import com.usermanagement.saml.entity.ServiceProviderEntity;
import com.usermanagement.saml.repository.ServiceProviderRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * Service to check application type and route accordingly.
 * This service helps your existing launcher decide JWT vs SAML.
 */
@Service
public class ApplicationTypeService {

    private final ServiceProviderRepository samlSpRepository;

    public ApplicationTypeService(ServiceProviderRepository samlSpRepository) {
        this.samlSpRepository = samlSpRepository;
    }

    /**
     * Check if an application uses SAML authentication.
     * 
     * @param applicationId Your application's ID (could be entityId or database ID)
     * @return true if SAML, false if JWT (default)
     */
    public boolean isSamlApplication(String applicationId) {
        Optional<ServiceProviderEntity> sp = samlSpRepository.findByEntityId(applicationId);
        return sp.map(s -> "SAML".equals(s.getAuthType()) && s.getIsActive()).orElse(false);
    }

    public boolean isSamlApplicationById(Long spId) {
        Optional<ServiceProviderEntity> sp = samlSpRepository.findById(spId);
        return sp.map(s -> "SAML".equals(s.getAuthType()) && s.getIsActive()).orElse(false);
    }

    /**
     * Get SAML SP details if exists.
     */
    public Optional<ServiceProviderEntity> getSamlServiceProvider(String entityId) {
        return samlSpRepository.findByEntityId(entityId);
    }
}
```

#### Step 3.2: Modify Your Existing Application Launcher

In your EXISTING application launcher code, add the SAML routing:

```java
// In your EXISTING ApplicationLauncherController or similar:

@Autowired
private ApplicationTypeService appTypeService;

@Autowired
private SamlSsoService samlSsoService;  // From SAML module

@Autowired
private YourJwtService jwtService;  // Your EXISTING JWT service

/**
 * Modified launch endpoint - routes to JWT or SAML based on app type.
 */
@GetMapping("/launch/{applicationId}")
public String launchApplication(
        @PathVariable String applicationId,
        HttpSession session,
        Model model) {
    
    // Get authenticated user (your existing code)
    YourUser user = getAuthenticatedUser(session);
    if (user == null) {
        return "redirect:/login?returnUrl=/launch/" + applicationId;
    }
    
    // Check if this is a SAML application
    if (appTypeService.isSamlApplication(applicationId)) {
        // ===== SAML FLOW (NEW) =====
        return launchSamlApplication(user, applicationId, model);
    } else {
        // ===== JWT FLOW (YOUR EXISTING CODE - UNCHANGED) =====
        return launchJwtApplication(user, applicationId);
    }
}

/**
 * NEW: Launch SAML application
 */
private String launchSamlApplication(YourUser user, String applicationId, Model model) {
    // Convert your user to SAML AuthenticatedUser
    AuthenticatedUser samlUser = AuthenticatedUser.builder()
            .userId(user.getId())
            .email(user.getEmail())
            .username(user.getUsername())
            .firstName(user.getFirstName())
            .lastName(user.getLastName())
            .roles(user.getRoles())
            .build();
    
    // Get SAML response
    SsoResult result = samlSsoService.initiateIdpSso(samlUser, applicationId, null);
    
    if (!result.isSuccess()) {
        model.addAttribute("error", result.getErrorMessage());
        return "error";
    }
    
    // Return SAML POST form
    model.addAttribute("acsUrl", result.getAcsUrl());
    model.addAttribute("samlResponse", result.getSamlResponse());
    model.addAttribute("relayState", result.getRelayState());
    
    return "saml/post-binding";  // Template from SAML module
}

/**
 * EXISTING: Launch JWT application (YOUR EXISTING CODE - NO CHANGES)
 */
private String launchJwtApplication(YourUser user, String applicationId) {
    // Your existing JWT generation logic
    String token = jwtService.generateTokenForApplication(user, applicationId);
    String targetUrl = getApplicationUrl(applicationId);
    
    return "redirect:" + targetUrl + "?token=" + token;
}
```

#### Step 3.3: Alternative - Separate Endpoint for SAML Apps

If you prefer not to modify existing code, add a NEW endpoint:

```java
/**
 * NEW endpoint specifically for SAML applications.
 * Your existing /launch/{id} endpoint remains COMPLETELY UNCHANGED.
 */
@GetMapping("/saml-launch/{spId}")
public String launchSamlApp(
        @PathVariable Long spId,
        @RequestParam(required = false) String relayState,
        HttpSession session,
        Model model) {
    
    // Get user from your auth system
    YourUser user = getAuthenticatedUser(session);
    if (user == null) {
        return "redirect:/login?returnUrl=/saml-launch/" + spId;
    }
    
    // Convert to SAML user
    AuthenticatedUser samlUser = convertToSamlUser(user);
    
    // Generate SAML response
    SsoResult result = samlSsoService.initiateIdpSsoById(samlUser, spId, relayState);
    
    if (!result.isSuccess()) {
        model.addAttribute("error", result.getErrorMessage());
        return "error";
    }
    
    model.addAttribute("acsUrl", result.getAcsUrl());
    model.addAttribute("samlResponse", result.getSamlResponse());
    model.addAttribute("relayState", result.getRelayState());
    
    return "saml/post-binding";
}

private AuthenticatedUser convertToSamlUser(YourUser user) {
    return AuthenticatedUser.builder()
            .userId(user.getId())
            .email(user.getEmail())
            .username(user.getUsername())
            .firstName(user.getFirstName())
            .lastName(user.getLastName())
            .department(user.getDepartment())
            .roles(user.getRoles())
            .groups(user.getGroups())
            .build();
}
```

---

### Phase 4: Frontend Integration

#### Step 4.1: Update Application List Display

In your frontend, when displaying the application list, include the auth type:

```javascript
// Fetch applications (your existing API + SAML info)
async function loadApplications() {
    // Your existing application list
    const jwtApps = await fetch('/api/applications').then(r => r.json());
    
    // SAML applications (new)
    const samlApps = await fetch('/api/saml/service-providers').then(r => r.json());
    
    // Combine and display
    const allApps = [
        ...jwtApps.map(app => ({ ...app, authType: 'JWT' })),
        ...samlApps.map(app => ({ ...app, authType: 'SAML' }))
    ];
    
    displayApplications(allApps);
}

function displayApplications(apps) {
    const container = document.getElementById('app-list');
    
    apps.forEach(app => {
        const card = document.createElement('div');
        card.className = 'app-card';
        card.innerHTML = `
            <img src="${app.iconUrl || '/images/default-app.png'}" alt="${app.applicationName}">
            <h3>${app.applicationName}</h3>
            <p>${app.description || ''}</p>
            <span class="auth-badge ${app.authType.toLowerCase()}">${app.authType}</span>
        `;
        card.onclick = () => launchApp(app);
        container.appendChild(card);
    });
}
```

#### Step 4.2: Launch Handler

```javascript
function launchApp(app) {
    if (app.authType === 'SAML') {
        launchSamlApp(app);
    } else {
        launchJwtApp(app);
    }
}

// NEW: SAML launch
function launchSamlApp(app) {
    // Option 1: Direct redirect to SAML SSO init
    window.location.href = `/saml/sso/init?spId=${app.id}`;
    
    // Option 2: API call then form submit (for more control)
    /*
    fetch(`/api/saml/launch/${app.id}`, { method: 'POST' })
        .then(r => r.json())
        .then(result => {
            if (result.success) {
                submitSamlForm(result.acsUrl, result.samlResponse, result.relayState);
            } else {
                alert('Error: ' + result.errorMessage);
            }
        });
    */
}

// EXISTING: JWT launch (your existing code - no changes)
function launchJwtApp(app) {
    // Your existing JWT launch logic
    window.location.href = `/launch/${app.id}`;
}

// Helper for SAML POST binding
function submitSamlForm(acsUrl, samlResponse, relayState) {
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = acsUrl;
    form.style.display = 'none';
    
    const responseInput = document.createElement('input');
    responseInput.type = 'hidden';
    responseInput.name = 'SAMLResponse';
    responseInput.value = samlResponse;
    form.appendChild(responseInput);
    
    if (relayState) {
        const relayInput = document.createElement('input');
        relayInput.type = 'hidden';
        relayInput.name = 'RelayState';
        relayInput.value = relayState;
        form.appendChild(relayInput);
    }
    
    document.body.appendChild(form);
    form.submit();
}
```

---

### Phase 5: Register SAML Applications

#### Step 5.1: Using the Admin API

```bash
# Register a new SAML application
curl -X POST https://your-domain.com/usermanagement/api/saml/service-providers \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN" \
  -d '{
    "entityId": "https://salesforce.example.com",
    "applicationName": "Salesforce CRM",
    "description": "Customer Relationship Management",
    "acsUrl": "https://login.salesforce.com/saml/acs",
    "nameIdFormat": "email",
    "signAssertions": true,
    "attributeMappings": "{\"email\": \"User.Email\", \"firstName\": \"User.FirstName\"}",
    "iconUrl": "/images/salesforce.png",
    "category": "Sales",
    "allowedRoles": ["ROLE_SALES", "ROLE_ADMIN"]
  }'
```

#### Step 5.2: From SP Metadata File

```bash
# Register from SP's metadata XML
curl -X POST https://your-domain.com/usermanagement/api/saml/service-providers/from-metadata \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN" \
  -F "metadata=@salesforce-metadata.xml" \
  -F "applicationName=Salesforce CRM" \
  -F "description=Customer Relationship Management"
```

#### Step 5.3: Share IdP Metadata with SP

Get your IdP metadata to share with the Service Provider:

```bash
curl https://your-domain.com/usermanagement/saml/metadata > idp-metadata.xml
```

Send this `idp-metadata.xml` to the SP administrator for configuration.

---

### Phase 6: Testing

#### Step 6.1: Verify JWT Still Works

```bash
# Test existing JWT application launch
curl -X GET https://your-domain.com/usermanagement/launch/jwt-app-id \
  -H "Cookie: JSESSIONID=your-session-id" \
  -v

# Should redirect to JWT app with token
```

#### Step 6.2: Test SAML Metadata

```bash
# Get IdP metadata
curl https://your-domain.com/usermanagement/saml/metadata

# Should return XML with EntityDescriptor
```

#### Step 6.3: Test SAML SSO

1. Log in to your portal
2. Click on a registered SAML application
3. Verify you're redirected to the SP with SAML assertion
4. Verify you're logged in to the SP

#### Step 6.4: Test SP-Initiated SSO

1. Go directly to a SAML SP
2. SP should redirect to your IdP
3. If already logged in, should auto-redirect back to SP
4. If not logged in, should show login page, then redirect to SP

---

## Troubleshooting Guide

### Issue: JWT Apps Still Working?

**Check:** JWT flow should be COMPLETELY UNCHANGED. If JWT apps break:
- Verify you didn't modify any JWT-related code
- Check security configuration hasn't blocked JWT endpoints
- Verify JWT service is still injected properly

### Issue: SAML Metadata Not Loading

**Check:**
- `/saml/metadata` endpoint is permitted in security config
- OpenSAML initialized correctly (check logs for "OpenSAML initialized successfully")
- Keystore file exists and is readable

### Issue: "User not authenticated" in SAML flow

**Check:**
- `YourAuthenticationBridge.getAuthenticatedUser()` returns user correctly
- Session is being maintained across requests
- SAML endpoints are checking auth correctly

### Issue: SP Says "Invalid Signature"

**Check:**
- SP has your current IdP certificate
- Certificate hasn't expired
- Signature algorithm is supported by SP

### Issue: SP Says "Invalid Audience"

**Check:**
- SP Entity ID in your registration matches what SP expects
- Check case sensitivity

---

## Summary Checklist

### Before You Start
- [ ] Backup existing code
- [ ] Document current JWT flow

### Phase 1: Setup
- [ ] Add Maven dependencies
- [ ] Copy SAML module files (except SecurityConfig)
- [ ] Add SAML configuration to application.yml
- [ ] Generate keystore
- [ ] Create database table

### Phase 2: Auth Integration
- [ ] Create YourAuthenticationBridge class
- [ ] Update SamlSsoController to use your bridge
- [ ] Add SAML endpoints to your security config

### Phase 3: Launcher Integration
- [ ] Create ApplicationTypeService
- [ ] Modify launcher to route JWT vs SAML (or add new SAML endpoint)

### Phase 4: Frontend
- [ ] Update application list to show auth type
- [ ] Add SAML launch handler

### Phase 5: Registration
- [ ] Register test SAML application
- [ ] Share IdP metadata with SP

### Phase 6: Testing
- [ ] Verify JWT apps still work
- [ ] Test SAML metadata endpoint
- [ ] Test IdP-initiated SSO
- [ ] Test SP-initiated SSO

---

## Support Contacts

If you encounter issues:
1. Check application logs for errors
2. Enable DEBUG logging: `logging.level.com.usermanagement.saml=DEBUG`
3. Verify SAML messages using browser developer tools (Network tab)
4. Use SAML debugging tools like https://www.samltool.com/

