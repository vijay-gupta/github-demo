-- =============================================================================
-- Sample Data for SAML Service Providers
-- This creates sample SP registrations for testing
-- =============================================================================

-- Sample SAML Service Provider - Generic App
INSERT INTO saml_service_providers (
    entity_id, application_name, description, acs_url, slo_url,
    sign_assertions, encrypt_assertions, name_id_format, acs_binding,
    is_active, auth_type, icon_url, application_url, display_order, category,
    created_at, updated_at, created_by
) VALUES (
    'https://app1.example.com/saml/metadata',
    'Sample Application 1',
    'A sample SAML application for testing',
    'https://app1.example.com/saml/acs',
    'https://app1.example.com/saml/slo',
    true, false,
    'urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress',
    'urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST',
    true, 'SAML',
    '/images/app1.png',
    'https://app1.example.com',
    1, 'Business',
    CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 'admin'
);

-- Sample SAML Service Provider - Salesforce-like
INSERT INTO saml_service_providers (
    entity_id, application_name, description, acs_url,
    sign_assertions, encrypt_assertions, name_id_format, acs_binding,
    attribute_mappings, is_active, auth_type, icon_url, display_order, category,
    created_at, updated_at, created_by
) VALUES (
    'https://crm.example.com/saml/metadata',
    'CRM System',
    'Customer Relationship Management',
    'https://crm.example.com/saml/acs',
    true, false,
    'urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress',
    'urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST',
    '{"email": "User.Email", "firstName": "User.FirstName", "lastName": "User.LastName", "roles": "User.Profile"}',
    true, 'SAML',
    '/images/crm.png',
    2, 'Sales',
    CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 'admin'
);

-- Sample JWT Application (for comparison)
INSERT INTO saml_service_providers (
    entity_id, application_name, description, acs_url,
    sign_assertions, is_active, auth_type, icon_url, application_url, display_order, category,
    created_at, updated_at, created_by
) VALUES (
    'jwt-app-001',
    'Internal Dashboard',
    'Internal analytics dashboard using JWT',
    'https://dashboard.internal.com/auth/callback',
    false, true, 'JWT',
    '/images/dashboard.png',
    'https://dashboard.internal.com',
    3, 'Analytics',
    CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 'admin'
);

-- Sample ServiceNow-like SP
INSERT INTO saml_service_providers (
    entity_id, application_name, description, acs_url,
    sign_assertions, encrypt_assertions, name_id_format, acs_binding,
    is_active, auth_type, icon_url, display_order, category,
    created_at, updated_at, created_by
) VALUES (
    'https://itsm.example.com/navpage.do',
    'IT Service Management',
    'IT Help Desk and Service Management',
    'https://itsm.example.com/consumer.do',
    true, false,
    'urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress',
    'urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST',
    true, 'SAML',
    '/images/itsm.png',
    4, 'IT',
    CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 'admin'
);

-- Add roles for Sample Application 1
INSERT INTO sp_allowed_roles (sp_id, role) VALUES (1, 'ROLE_USER');
INSERT INTO sp_allowed_roles (sp_id, role) VALUES (1, 'ROLE_ADMIN');

-- Add roles for CRM System
INSERT INTO sp_allowed_roles (sp_id, role) VALUES (2, 'ROLE_SALES');
INSERT INTO sp_allowed_roles (sp_id, role) VALUES (2, 'ROLE_ADMIN');

-- Add roles for Dashboard (JWT app)
INSERT INTO sp_allowed_roles (sp_id, role) VALUES (3, 'ROLE_USER');
INSERT INTO sp_allowed_roles (sp_id, role) VALUES (3, 'ROLE_ANALYST');
INSERT INTO sp_allowed_roles (sp_id, role) VALUES (3, 'ROLE_ADMIN');

-- Add roles for ITSM
INSERT INTO sp_allowed_roles (sp_id, role) VALUES (4, 'ROLE_USER');
INSERT INTO sp_allowed_roles (sp_id, role) VALUES (4, 'ROLE_IT_SUPPORT');
INSERT INTO sp_allowed_roles (sp_id, role) VALUES (4, 'ROLE_ADMIN');
