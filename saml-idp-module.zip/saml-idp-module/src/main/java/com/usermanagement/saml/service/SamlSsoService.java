package com.usermanagement.saml.service;

import com.usermanagement.saml.config.SamlIdpProperties;
import com.usermanagement.saml.entity.ServiceProviderEntity;
import com.usermanagement.saml.model.AuthenticatedUser;
import com.usermanagement.saml.model.SsoResult;
import com.usermanagement.saml.repository.ServiceProviderRepository;
import com.usermanagement.saml.util.SamlUtils;
import lombok.RequiredArgsConstructor;
import org.opensaml.core.xml.XMLObject;
import org.opensaml.saml.saml2.core.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.zip.Inflater;

/**
 * Main SAML SSO Service that orchestrates the SSO flow.
 * This service handles both IdP-initiated and SP-initiated SSO.
 */
@Service
@RequiredArgsConstructor
public class SamlSsoService {

    private static final Logger logger = LoggerFactory.getLogger(SamlSsoService.class);

    private final SamlIdpProperties samlIdpProperties;
    private final ServiceProviderRepository spRepository;
    private final SamlResponseBuilder responseBuilder;

    /**
     * Initiate IdP-initiated SSO.
     * Called when user clicks on an application link from your portal.
     *
     * @param user The authenticated user
     * @param spEntityId The Entity ID of the target SP
     * @param relayState Optional relay state
     * @return SsoResult containing the SAML Response and target URL
     */
    public SsoResult initiateIdpSso(AuthenticatedUser user, String spEntityId, String relayState) {
        logger.info("Initiating IdP-initiated SSO for user: {} to SP: {}", user.getEmail(), spEntityId);

        // Get SP configuration
        ServiceProviderEntity sp = spRepository.findByEntityId(spEntityId)
                .orElseThrow(() -> new IllegalArgumentException("Service Provider not found: " + spEntityId));

        if (!sp.getIsActive()) {
            throw new IllegalStateException("Service Provider is not active: " + sp.getApplicationName());
        }

        // Build SAML Response
        Response response = responseBuilder.buildIdpInitiatedResponse(user, sp);

        // Encode for POST binding
        String encodedResponse = responseBuilder.encodeResponseForPost(response);

        // Use provided relay state or default
        String finalRelayState = relayState != null ? relayState : sp.getDefaultRelayState();

        logger.info("Successfully generated IdP-initiated SSO response for user: {} to: {}",
                user.getEmail(), sp.getApplicationName());

        return SsoResult.builder()
                .samlResponse(encodedResponse)
                .acsUrl(sp.getAcsUrl())
                .relayState(finalRelayState)
                .binding(sp.getAcsBinding())
                .success(true)
                .build();
    }

    /**
     * Initiate IdP-initiated SSO by SP ID (database ID).
     */
    public SsoResult initiateIdpSsoById(AuthenticatedUser user, Long spId, String relayState) {
        ServiceProviderEntity sp = spRepository.findById(spId)
                .orElseThrow(() -> new IllegalArgumentException("Service Provider not found: " + spId));

        return initiateIdpSso(user, sp.getEntityId(), relayState);
    }

    /**
     * Process SP-initiated SSO (AuthnRequest).
     * Called when SP redirects user to IdP for authentication.
     *
     * @param user The authenticated user
     * @param samlRequest Base64 encoded SAMLRequest
     * @param relayState Relay state from SP
     * @param isDeflated Whether the request is deflated (HTTP-Redirect binding)
     * @return SsoResult containing the SAML Response
     */
    public SsoResult processSpInitiatedSso(AuthenticatedUser user, String samlRequest,
                                            String relayState, boolean isDeflated) {
        logger.info("Processing SP-initiated SSO for user: {}", user.getEmail());

        try {
            // Decode and parse AuthnRequest
            String xmlRequest = decodeRequest(samlRequest, isDeflated);
            XMLObject xmlObject = SamlUtils.unmarshal(xmlRequest);

            if (!(xmlObject instanceof AuthnRequest)) {
                throw new IllegalArgumentException("Invalid SAML request: expected AuthnRequest");
            }

            AuthnRequest authnRequest = (AuthnRequest) xmlObject;
            String inResponseTo = authnRequest.getID();
            String spEntityId = authnRequest.getIssuer().getValue();
            String acsUrl = authnRequest.getAssertionConsumerServiceURL();

            logger.debug("AuthnRequest ID: {}, Issuer: {}, ACS: {}", inResponseTo, spEntityId, acsUrl);

            // Get SP configuration
            ServiceProviderEntity sp = spRepository.findByEntityId(spEntityId)
                    .orElseThrow(() -> new IllegalArgumentException("Unknown Service Provider: " + spEntityId));

            if (!sp.getIsActive()) {
                throw new IllegalStateException("Service Provider is not active: " + sp.getApplicationName());
            }

            // Validate ACS URL matches registered SP
            String targetAcsUrl = acsUrl != null ? acsUrl : sp.getAcsUrl();
            if (!targetAcsUrl.equals(sp.getAcsUrl())) {
                logger.warn("ACS URL mismatch. Requested: {}, Registered: {}", acsUrl, sp.getAcsUrl());
                // For security, you might want to reject this or only allow registered ACS URLs
            }

            // Build SAML Response
            Response response = responseBuilder.buildSpInitiatedResponse(user, sp, inResponseTo);

            // Encode for POST binding
            String encodedResponse = responseBuilder.encodeResponseForPost(response);

            logger.info("Successfully generated SP-initiated SSO response for user: {} to: {}",
                    user.getEmail(), sp.getApplicationName());

            return SsoResult.builder()
                    .samlResponse(encodedResponse)
                    .acsUrl(targetAcsUrl)
                    .relayState(relayState)
                    .binding(sp.getAcsBinding())
                    .inResponseTo(inResponseTo)
                    .success(true)
                    .build();

        } catch (Exception e) {
            logger.error("Failed to process SP-initiated SSO", e);
            return SsoResult.builder()
                    .success(false)
                    .errorMessage(e.getMessage())
                    .build();
        }
    }

    /**
     * Decode SAML Request (Base64, optionally deflated).
     */
    private String decodeRequest(String samlRequest, boolean isDeflated) throws Exception {
        byte[] decoded = Base64.getDecoder().decode(samlRequest);

        if (isDeflated) {
            // Inflate
            Inflater inflater = new Inflater(true);
            inflater.setInput(decoded);
            byte[] result = new byte[10000];
            int length = inflater.inflate(result);
            inflater.end();
            return new String(result, 0, length, StandardCharsets.UTF_8);
        }

        return new String(decoded, StandardCharsets.UTF_8);
    }

    /**
     * Generate error response for SP.
     */
    public SsoResult generateErrorResponse(String spEntityId, String inResponseTo,
                                           String statusCode, String message) {
        ServiceProviderEntity sp = spRepository.findByEntityId(spEntityId)
                .orElseThrow(() -> new IllegalArgumentException("Service Provider not found: " + spEntityId));

        Response response = responseBuilder.buildErrorResponse(sp, inResponseTo, statusCode, message);
        String encodedResponse = responseBuilder.encodeResponseForPost(response);

        return SsoResult.builder()
                .samlResponse(encodedResponse)
                .acsUrl(sp.getAcsUrl())
                .binding(sp.getAcsBinding())
                .success(false)
                .errorMessage(message)
                .build();
    }

    /**
     * Check if an application requires SAML SSO.
     */
    public boolean isSamlApplication(String entityId) {
        return spRepository.findByEntityId(entityId)
                .map(sp -> "SAML".equals(sp.getAuthType()) && sp.getIsActive())
                .orElse(false);
    }

    /**
     * Check if an application requires SAML SSO by ID.
     */
    public boolean isSamlApplicationById(Long spId) {
        return spRepository.findById(spId)
                .map(sp -> "SAML".equals(sp.getAuthType()) && sp.getIsActive())
                .orElse(false);
    }
}
