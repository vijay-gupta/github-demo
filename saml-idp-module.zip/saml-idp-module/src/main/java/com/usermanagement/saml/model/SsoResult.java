package com.usermanagement.saml.model;

import lombok.*;

/**
 * Result of a SAML SSO operation.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SsoResult {

    /**
     * Base64 encoded SAML Response
     */
    private String samlResponse;

    /**
     * Target Assertion Consumer Service URL
     */
    private String acsUrl;

    /**
     * Relay state to pass to SP
     */
    private String relayState;

    /**
     * SAML Binding type (POST or Redirect)
     */
    private String binding;

    /**
     * InResponseTo ID (for SP-initiated SSO)
     */
    private String inResponseTo;

    /**
     * Whether the operation was successful
     */
    private boolean success;

    /**
     * Error message if not successful
     */
    private String errorMessage;

    /**
     * Check if this is a POST binding
     */
    public boolean isPostBinding() {
        return binding != null && binding.contains("POST");
    }

    /**
     * Check if this is a Redirect binding
     */
    public boolean isRedirectBinding() {
        return binding != null && binding.contains("Redirect");
    }
}
