package com.usermanagement.saml.controller;

import com.usermanagement.saml.dto.ServiceProviderDto;
import com.usermanagement.saml.entity.ServiceProviderEntity;
import com.usermanagement.saml.service.ServiceProviderService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

/**
 * REST API Controller for managing Service Providers.
 */
@RestController
@RequestMapping("/api/saml/service-providers")
@RequiredArgsConstructor
public class ServiceProviderApiController {

    private static final Logger logger = LoggerFactory.getLogger(ServiceProviderApiController.class);

    private final ServiceProviderService spService;

    /**
     * Register a new Service Provider manually.
     */
    @PostMapping
    public ResponseEntity<ServiceProviderEntity> registerServiceProvider(
            @Valid @RequestBody ServiceProviderDto dto) {
        logger.info("Registering new Service Provider: {}", dto.getApplicationName());

        try {
            ServiceProviderEntity sp = spService.registerServiceProvider(dto);
            return ResponseEntity.status(HttpStatus.CREATED).body(sp);
        } catch (IllegalArgumentException e) {
            logger.warn("Failed to register SP: {}", e.getMessage());
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * Register a Service Provider from metadata XML file.
     */
    @PostMapping(value = "/from-metadata", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<ServiceProviderEntity> registerFromMetadata(
            @RequestParam("metadata") MultipartFile metadataFile,
            @RequestParam("applicationName") String applicationName,
            @RequestParam(value = "description", required = false) String description,
            @RequestParam(value = "createdBy", required = false) String createdBy) {

        logger.info("Registering Service Provider from metadata: {}", applicationName);

        try {
            String metadataXml = new String(metadataFile.getBytes(), StandardCharsets.UTF_8);
            ServiceProviderEntity sp = spService.registerFromMetadata(
                    metadataXml, applicationName, description, createdBy);
            return ResponseEntity.status(HttpStatus.CREATED).body(sp);
        } catch (Exception e) {
            logger.error("Failed to register SP from metadata", e);
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * Register a Service Provider from metadata XML string.
     */
    @PostMapping("/from-metadata-xml")
    public ResponseEntity<ServiceProviderEntity> registerFromMetadataXml(
            @RequestBody Map<String, String> request) {

        String metadataXml = request.get("metadataXml");
        String applicationName = request.get("applicationName");
        String description = request.get("description");
        String createdBy = request.get("createdBy");

        logger.info("Registering Service Provider from metadata XML: {}", applicationName);

        try {
            ServiceProviderEntity sp = spService.registerFromMetadata(
                    metadataXml, applicationName, description, createdBy);
            return ResponseEntity.status(HttpStatus.CREATED).body(sp);
        } catch (Exception e) {
            logger.error("Failed to register SP from metadata XML", e);
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * Get all active Service Providers.
     */
    @GetMapping
    public ResponseEntity<List<ServiceProviderEntity>> getAllServiceProviders() {
        List<ServiceProviderEntity> providers = spService.getAllActive();
        return ResponseEntity.ok(providers);
    }

    /**
     * Get all SAML Service Providers.
     */
    @GetMapping("/saml")
    public ResponseEntity<List<ServiceProviderEntity>> getSamlServiceProviders() {
        List<ServiceProviderEntity> providers = spService.getAllSamlProviders();
        return ResponseEntity.ok(providers);
    }

    /**
     * Get Service Provider by ID.
     */
    @GetMapping("/{id}")
    public ResponseEntity<ServiceProviderEntity> getServiceProvider(@PathVariable Long id) {
        return spService.getById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Get Service Provider by Entity ID.
     */
    @GetMapping("/by-entity-id")
    public ResponseEntity<ServiceProviderEntity> getByEntityId(@RequestParam String entityId) {
        return spService.getByEntityId(entityId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Get Service Providers accessible by user roles.
     */
    @GetMapping("/by-roles")
    public ResponseEntity<List<ServiceProviderEntity>> getByRoles(@RequestParam List<String> roles) {
        List<ServiceProviderEntity> providers = spService.getByUserRoles(roles);
        return ResponseEntity.ok(providers);
    }

    /**
     * Search Service Providers.
     */
    @GetMapping("/search")
    public ResponseEntity<List<ServiceProviderEntity>> search(@RequestParam String query) {
        List<ServiceProviderEntity> providers = spService.search(query);
        return ResponseEntity.ok(providers);
    }

    /**
     * Update a Service Provider.
     */
    @PutMapping("/{id}")
    public ResponseEntity<ServiceProviderEntity> updateServiceProvider(
            @PathVariable Long id,
            @Valid @RequestBody ServiceProviderDto dto) {
        logger.info("Updating Service Provider: {}", id);

        try {
            ServiceProviderEntity sp = spService.updateServiceProvider(id, dto);
            return ResponseEntity.ok(sp);
        } catch (IllegalArgumentException e) {
            logger.warn("Failed to update SP: {}", e.getMessage());
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Delete a Service Provider.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteServiceProvider(@PathVariable Long id) {
        logger.info("Deleting Service Provider: {}", id);

        try {
            spService.delete(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            logger.error("Failed to delete SP", e);
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Activate a Service Provider.
     */
    @PostMapping("/{id}/activate")
    public ResponseEntity<Void> activateServiceProvider(@PathVariable Long id) {
        logger.info("Activating Service Provider: {}", id);

        try {
            spService.activate(id);
            return ResponseEntity.ok().build();
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Deactivate a Service Provider.
     */
    @PostMapping("/{id}/deactivate")
    public ResponseEntity<Void> deactivateServiceProvider(@PathVariable Long id) {
        logger.info("Deactivating Service Provider: {}", id);

        try {
            spService.deactivate(id);
            return ResponseEntity.ok().build();
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Check if an application requires SAML.
     */
    @GetMapping("/{id}/is-saml")
    public ResponseEntity<Map<String, Boolean>> isSamlApplication(@PathVariable Long id) {
        boolean isSaml = spService.getById(id)
                .map(sp -> "SAML".equals(sp.getAuthType()) && sp.getIsActive())
                .orElse(false);
        return ResponseEntity.ok(Map.of("isSaml", isSaml));
    }
}
