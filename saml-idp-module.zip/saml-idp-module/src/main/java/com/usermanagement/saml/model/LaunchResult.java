package com.usermanagement.saml.model;

import lombok.*;

/**
 * Result of an application launch request.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LaunchResult {

    /**
     * Whether the launch was successful
     */
    private boolean success;

    /**
     * Authentication type used (SAML or JWT)
     */
    private String authType;

    /**
     * Target URL to redirect/post to
     */
    private String targetUrl;

    /**
     * SAML Response (for SAML apps)
     */
    private String samlResponse;

    /**
     * Relay state (for SAML apps)
     */
    private String relayState;

    /**
     * JWT Token (for JWT apps)
     */
    private String jwtToken;

    /**
     * Whether to use POST binding (true) or redirect (false)
     */
    private boolean usePostBinding;

    /**
     * Error message if not successful
     */
    private String errorMessage;

    /**
     * Check if this is a SAML application
     */
    public boolean isSaml() {
        return "SAML".equalsIgnoreCase(authType);
    }

    /**
     * Check if this is a JWT application
     */
    public boolean isJwt() {
        return "JWT".equalsIgnoreCase(authType);
    }
}
