package com.usermanagement.saml.adapter;

import com.usermanagement.saml.model.AuthenticatedUser;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * Adapter interface for integrating with your existing authentication system.
 * 
 * IMPORTANT: Implement this interface to connect the SAML module 
 * with your existing user authentication mechanism.
 */
public interface UserAuthenticationAdapter {

    /**
     * Get the currently authenticated user from the request/session.
     * 
     * @param request The HTTP request
     * @return AuthenticatedUser if user is authenticated, null otherwise
     */
    AuthenticatedUser getAuthenticatedUser(HttpServletRequest request);

    /**
     * Get the currently authenticated user from session.
     * 
     * @param session The HTTP session
     * @return AuthenticatedUser if user is authenticated, null otherwise
     */
    AuthenticatedUser getAuthenticatedUser(HttpSession session);

    /**
     * Check if the current request is authenticated.
     * 
     * @param request The HTTP request
     * @return true if authenticated
     */
    boolean isAuthenticated(HttpServletRequest request);

    /**
     * Get the login URL for redirecting unauthenticated users.
     * 
     * @param returnUrl URL to return to after login
     * @return Login URL with return parameter
     */
    String getLoginUrl(String returnUrl);
}
