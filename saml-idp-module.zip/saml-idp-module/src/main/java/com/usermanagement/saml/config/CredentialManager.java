package com.usermanagement.saml.config;

import lombok.RequiredArgsConstructor;
import org.opensaml.security.credential.Credential;
import org.opensaml.security.credential.CredentialSupport;
import org.opensaml.security.x509.BasicX509Credential;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.Base64;

/**
 * Manages cryptographic credentials for SAML signing and encryption.
 */
@Component
@RequiredArgsConstructor
public class CredentialManager {

    private static final Logger logger = LoggerFactory.getLogger(CredentialManager.class);

    private final SamlIdpProperties samlIdpProperties;
    private final ResourceLoader resourceLoader;

    private Credential signingCredential;
    private X509Certificate signingCertificate;

    @PostConstruct
    public void init() throws Exception {
        loadSigningCredential();
    }

    /**
     * Load the signing credential from keystore.
     */
    private void loadSigningCredential() throws Exception {
        SamlIdpProperties.KeystoreConfig keystoreConfig = samlIdpProperties.getKeystore();

        logger.info("Loading signing credential from keystore: {}", keystoreConfig.getPath());

        Resource keystoreResource = resourceLoader.getResource(keystoreConfig.getPath());

        if (!keystoreResource.exists()) {
            logger.warn("Keystore not found at {}. Generating self-signed certificate...", keystoreConfig.getPath());
            generateSelfSignedCredential();
            return;
        }

        try (InputStream is = keystoreResource.getInputStream()) {
            KeyStore keyStore = KeyStore.getInstance("JKS");
            keyStore.load(is, keystoreConfig.getPassword().toCharArray());

            PrivateKey privateKey = (PrivateKey) keyStore.getKey(
                    keystoreConfig.getAlias(),
                    keystoreConfig.getKeyPassword().toCharArray()
            );

            X509Certificate certificate = (X509Certificate) keyStore.getCertificate(keystoreConfig.getAlias());

            BasicX509Credential credential = new BasicX509Credential(certificate, privateKey);
            credential.setEntityId(samlIdpProperties.getEntityId());

            this.signingCredential = credential;
            this.signingCertificate = certificate;

            logger.info("Successfully loaded signing credential. Certificate Subject: {}",
                    certificate.getSubjectX500Principal().getName());
        }
    }

    /**
     * Generate a self-signed credential for development/testing.
     */
    private void generateSelfSignedCredential() throws Exception {
        logger.info("Generating self-signed certificate for development...");

        java.security.KeyPairGenerator keyPairGenerator = java.security.KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(2048);
        java.security.KeyPair keyPair = keyPairGenerator.generateKeyPair();

        // Create self-signed certificate
        long now = System.currentTimeMillis();
        java.util.Date startDate = new java.util.Date(now);
        java.util.Date endDate = new java.util.Date(now + 365L * 24 * 60 * 60 * 1000); // 1 year

        sun.security.x509.X500Name owner = new sun.security.x509.X500Name(
                "CN=SAML IdP, OU=IT, O=Organization, L=City, ST=State, C=US");

        sun.security.x509.X509CertInfo info = new sun.security.x509.X509CertInfo();
        info.set(sun.security.x509.X509CertInfo.VALIDITY,
                new sun.security.x509.CertificateValidity(startDate, endDate));
        info.set(sun.security.x509.X509CertInfo.SERIAL_NUMBER,
                new sun.security.x509.CertificateSerialNumber(new java.math.BigInteger(64, new java.security.SecureRandom())));
        info.set(sun.security.x509.X509CertInfo.SUBJECT, owner);
        info.set(sun.security.x509.X509CertInfo.ISSUER, owner);
        info.set(sun.security.x509.X509CertInfo.KEY, new sun.security.x509.CertificateX509Key(keyPair.getPublic()));
        info.set(sun.security.x509.X509CertInfo.VERSION, new sun.security.x509.CertificateVersion(sun.security.x509.CertificateVersion.V3));
        info.set(sun.security.x509.X509CertInfo.ALGORITHM_ID,
                new sun.security.x509.CertificateAlgorithmId(sun.security.x509.AlgorithmId.get("SHA256withRSA")));

        sun.security.x509.X509CertImpl cert = new sun.security.x509.X509CertImpl(info);
        cert.sign(keyPair.getPrivate(), "SHA256withRSA");

        BasicX509Credential credential = new BasicX509Credential(cert, keyPair.getPrivate());
        credential.setEntityId(samlIdpProperties.getEntityId());

        this.signingCredential = credential;
        this.signingCertificate = cert;

        logger.warn("Using self-signed certificate. For production, please configure a proper keystore!");
    }

    /**
     * Get the signing credential.
     */
    public Credential getSigningCredential() {
        return signingCredential;
    }

    /**
     * Get the signing certificate.
     */
    public X509Certificate getSigningCertificate() {
        return signingCertificate;
    }

    /**
     * Get the signing certificate as Base64 encoded string (for metadata).
     */
    public String getSigningCertificateBase64() throws Exception {
        return Base64.getEncoder().encodeToString(signingCertificate.getEncoded());
    }

    /**
     * Get certificate as PEM format.
     */
    public String getSigningCertificatePEM() throws Exception {
        StringBuilder pem = new StringBuilder();
        pem.append("-----BEGIN CERTIFICATE-----\n");

        String base64 = getSigningCertificateBase64();
        int index = 0;
        while (index < base64.length()) {
            pem.append(base64, index, Math.min(index + 64, base64.length()));
            pem.append("\n");
            index += 64;
        }

        pem.append("-----END CERTIFICATE-----\n");
        return pem.toString();
    }
}
