package com.usermanagement.saml.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usermanagement.saml.config.CredentialManager;
import com.usermanagement.saml.config.SamlIdpProperties;
import com.usermanagement.saml.entity.ServiceProviderEntity;
import com.usermanagement.saml.model.AuthenticatedUser;
import com.usermanagement.saml.util.SamlUtils;
import lombok.RequiredArgsConstructor;
import org.opensaml.saml.saml2.core.*;
import org.opensaml.security.credential.Credential;
import org.opensaml.xmlsec.signature.Signature;
import org.opensaml.xmlsec.signature.support.SignatureConstants;
import org.opensaml.xmlsec.signature.support.Signer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Map;
import java.util.Set;

/**
 * Service for building SAML Assertions.
 */
@Service
@RequiredArgsConstructor
public class SamlAssertionBuilder {

    private static final Logger logger = LoggerFactory.getLogger(SamlAssertionBuilder.class);

    private final SamlIdpProperties samlIdpProperties;
    private final CredentialManager credentialManager;
    private final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Build a SAML Assertion for the given user and service provider.
     */
    public Assertion buildAssertion(AuthenticatedUser user, ServiceProviderEntity sp, String inResponseTo) {
        logger.debug("Building SAML assertion for user: {} and SP: {}", user.getEmail(), sp.getEntityId());

        Instant now = Instant.now();
        Instant notOnOrAfter = now.plusSeconds(samlIdpProperties.getAssertionValiditySeconds());

        // Build Assertion
        Assertion assertion = SamlUtils.buildSamlObject(Assertion.class);
        assertion.setID(SamlUtils.generateId());
        assertion.setIssueInstant(now);
        assertion.setVersion(org.opensaml.saml.common.SAMLVersion.VERSION_20);

        // Issuer
        assertion.setIssuer(SamlUtils.buildIssuer(samlIdpProperties.getEntityId()));

        // Subject
        String nameIdFormat = SamlUtils.resolveNameIdFormat(sp.getNameIdFormat());
        String nameIdValue = user.getNameIdValue(nameIdFormat);

        assertion.setSubject(SamlUtils.buildSubject(
                nameIdValue,
                nameIdFormat,
                sp.getAcsUrl(),
                notOnOrAfter,
                inResponseTo
        ));

        // Conditions
        assertion.setConditions(SamlUtils.buildConditions(
                now,
                notOnOrAfter,
                sp.getEntityId()
        ));

        // AuthnStatement
        assertion.getAuthnStatements().add(
                SamlUtils.buildAuthnStatement(now, SamlUtils.generateId())
        );

        // AttributeStatement
        assertion.getAttributeStatements().add(
                buildAttributeStatement(user, sp)
        );

        // Sign the assertion if required
        if (Boolean.TRUE.equals(sp.getSignAssertions())) {
            signAssertion(assertion);
        }

        logger.debug("Built SAML assertion with ID: {}", assertion.getID());
        return assertion;
    }

    /**
     * Build AttributeStatement with user attributes.
     */
    private AttributeStatement buildAttributeStatement(AuthenticatedUser user, ServiceProviderEntity sp) {
        AttributeStatement attributeStatement = SamlUtils.buildSamlObject(AttributeStatement.class);

        // Parse attribute mappings from SP configuration
        Map<String, String> attributeMappings = parseAttributeMappings(sp.getAttributeMappings());

        // Add standard attributes
        addAttribute(attributeStatement, "email", "mail", user.getEmail(), attributeMappings);
        addAttribute(attributeStatement, "firstName", "givenName", user.getFirstName(), attributeMappings);
        addAttribute(attributeStatement, "lastName", "sn", user.getLastName(), attributeMappings);
        addAttribute(attributeStatement, "displayName", "displayName", user.getFullName(), attributeMappings);
        addAttribute(attributeStatement, "username", "uid", user.getUsername(), attributeMappings);
        addAttribute(attributeStatement, "userId", "userId", user.getUserId(), attributeMappings);

        // Optional attributes
        if (user.getDepartment() != null) {
            addAttribute(attributeStatement, "department", "department", user.getDepartment(), attributeMappings);
        }
        if (user.getTitle() != null) {
            addAttribute(attributeStatement, "title", "title", user.getTitle(), attributeMappings);
        }
        if (user.getEmployeeId() != null) {
            addAttribute(attributeStatement, "employeeId", "employeeNumber", user.getEmployeeId(), attributeMappings);
        }
        if (user.getPhoneNumber() != null) {
            addAttribute(attributeStatement, "phone", "telephoneNumber", user.getPhoneNumber(), attributeMappings);
        }
        if (user.getOrganization() != null) {
            addAttribute(attributeStatement, "organization", "o", user.getOrganization(), attributeMappings);
        }

        // Roles
        if (user.getRoles() != null && !user.getRoles().isEmpty()) {
            addMultiValueAttribute(attributeStatement, "roles", "role", user.getRoles(), attributeMappings);
        }

        // Groups
        if (user.getGroups() != null && !user.getGroups().isEmpty()) {
            addMultiValueAttribute(attributeStatement, "groups", "memberOf", user.getGroups(), attributeMappings);
        }

        // Additional custom attributes
        if (user.getAdditionalAttributes() != null) {
            for (Map.Entry<String, String> entry : user.getAdditionalAttributes().entrySet()) {
                String samlAttrName = attributeMappings.getOrDefault(entry.getKey(), entry.getKey());
                attributeStatement.getAttributes().add(
                        SamlUtils.buildAttribute(samlAttrName, entry.getKey(), Attribute.URI_REFERENCE, entry.getValue())
                );
            }
        }

        return attributeStatement;
    }

    /**
     * Add a single-value attribute.
     */
    private void addAttribute(AttributeStatement statement, String internalName, String defaultSamlName,
                              String value, Map<String, String> mappings) {
        if (value == null || value.isEmpty()) {
            return;
        }
        String samlName = mappings.getOrDefault(internalName, defaultSamlName);
        statement.getAttributes().add(
                SamlUtils.buildAttribute(samlName, internalName, Attribute.URI_REFERENCE, value)
        );
    }

    /**
     * Add a multi-value attribute.
     */
    private void addMultiValueAttribute(AttributeStatement statement, String internalName, String defaultSamlName,
                                         Set<String> values, Map<String, String> mappings) {
        if (values == null || values.isEmpty()) {
            return;
        }
        String samlName = mappings.getOrDefault(internalName, defaultSamlName);
        statement.getAttributes().add(
                SamlUtils.buildAttribute(samlName, internalName, Attribute.URI_REFERENCE,
                        values.toArray(new String[0]))
        );
    }

    /**
     * Parse attribute mappings JSON from SP configuration.
     */
    private Map<String, String> parseAttributeMappings(String json) {
        if (json == null || json.isEmpty()) {
            return Map.of();
        }
        try {
            return objectMapper.readValue(json, new TypeReference<>() {});
        } catch (Exception e) {
            logger.warn("Failed to parse attribute mappings: {}", e.getMessage());
            return Map.of();
        }
    }

    /**
     * Sign the SAML Assertion.
     */
    private void signAssertion(Assertion assertion) {
        try {
            Credential credential = credentialManager.getSigningCredential();

            Signature signature = SamlUtils.buildSamlObject(Signature.class);
            signature.setSigningCredential(credential);
            signature.setSignatureAlgorithm(SignatureConstants.ALGO_ID_SIGNATURE_RSA_SHA256);
            signature.setCanonicalizationAlgorithm(SignatureConstants.ALGO_ID_C14N_EXCL_OMIT_COMMENTS);

            assertion.setSignature(signature);

            // Marshal the assertion to prepare for signing
            SamlUtils.marshal(assertion);

            // Sign
            Signer.signObject(signature);

            logger.debug("Successfully signed SAML assertion");
        } catch (Exception e) {
            throw new RuntimeException("Failed to sign SAML assertion", e);
        }
    }
}
