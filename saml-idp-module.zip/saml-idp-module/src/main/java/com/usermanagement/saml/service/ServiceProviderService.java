package com.usermanagement.saml.service;

import com.usermanagement.saml.dto.ServiceProviderDto;
import com.usermanagement.saml.entity.ServiceProviderEntity;
import com.usermanagement.saml.repository.ServiceProviderRepository;
import com.usermanagement.saml.util.SamlUtils;
import lombok.RequiredArgsConstructor;
import org.opensaml.saml.saml2.metadata.*;
import org.opensaml.core.xml.XMLObject;
import org.opensaml.xmlsec.signature.KeyInfo;
import org.opensaml.xmlsec.signature.X509Data;
import org.opensaml.xmlsec.signature.X509Certificate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Service for managing Service Provider registrations.
 */
@Service
@RequiredArgsConstructor
public class ServiceProviderService {

    private static final Logger logger = LoggerFactory.getLogger(ServiceProviderService.class);

    private final ServiceProviderRepository spRepository;

    /**
     * Register a new Service Provider manually.
     */
    @Transactional
    public ServiceProviderEntity registerServiceProvider(ServiceProviderDto dto) {
        logger.info("Registering new Service Provider: {}", dto.getApplicationName());

        if (spRepository.existsByEntityId(dto.getEntityId())) {
            throw new IllegalArgumentException("Service Provider with entity ID already exists: " + dto.getEntityId());
        }

        ServiceProviderEntity sp = ServiceProviderEntity.builder()
                .entityId(dto.getEntityId())
                .applicationName(dto.getApplicationName())
                .description(dto.getDescription())
                .acsUrl(dto.getAcsUrl())
                .sloUrl(dto.getSloUrl())
                .spCertificate(dto.getSpCertificate())
                .signAssertions(dto.getSignAssertions() != null ? dto.getSignAssertions() : true)
                .encryptAssertions(dto.getEncryptAssertions() != null ? dto.getEncryptAssertions() : false)
                .nameIdFormat(dto.getNameIdFormat() != null ? dto.getNameIdFormat() : 
                        "urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress")
                .acsBinding(dto.getAcsBinding() != null ? dto.getAcsBinding() : 
                        "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST")
                .defaultRelayState(dto.getDefaultRelayState())
                .attributeMappings(dto.getAttributeMappings())
                .isActive(dto.getIsActive() != null ? dto.getIsActive() : true)
                .authType("SAML")
                .iconUrl(dto.getIconUrl())
                .applicationUrl(dto.getApplicationUrl())
                .displayOrder(dto.getDisplayOrder() != null ? dto.getDisplayOrder() : 0)
                .category(dto.getCategory())
                .allowedRoles(dto.getAllowedRoles() != null ? dto.getAllowedRoles() : Set.of())
                .createdBy(dto.getCreatedBy())
                .build();

        ServiceProviderEntity saved = spRepository.save(sp);
        logger.info("Successfully registered Service Provider: {} with ID: {}", 
                saved.getApplicationName(), saved.getId());

        return saved;
    }

    /**
     * Register a Service Provider from SP Metadata XML.
     */
    @Transactional
    public ServiceProviderEntity registerFromMetadata(String metadataXml, String applicationName,
                                                       String description, String createdBy) {
        logger.info("Registering Service Provider from metadata: {}", applicationName);

        try {
            XMLObject xmlObject = SamlUtils.unmarshal(metadataXml);

            EntityDescriptor entityDescriptor;
            if (xmlObject instanceof EntitiesDescriptor) {
                EntitiesDescriptor entitiesDescriptor = (EntitiesDescriptor) xmlObject;
                if (entitiesDescriptor.getEntityDescriptors().isEmpty()) {
                    throw new IllegalArgumentException("No EntityDescriptor found in metadata");
                }
                entityDescriptor = entitiesDescriptor.getEntityDescriptors().get(0);
            } else if (xmlObject instanceof EntityDescriptor) {
                entityDescriptor = (EntityDescriptor) xmlObject;
            } else {
                throw new IllegalArgumentException("Invalid SAML metadata format");
            }

            String entityId = entityDescriptor.getEntityID();

            if (spRepository.existsByEntityId(entityId)) {
                throw new IllegalArgumentException("Service Provider with entity ID already exists: " + entityId);
            }

            // Find SPSSODescriptor
            SPSSODescriptor spDescriptor = entityDescriptor.getSPSSODescriptor(
                    "urn:oasis:names:tc:SAML:2.0:protocol");

            if (spDescriptor == null) {
                throw new IllegalArgumentException("No SPSSODescriptor found in metadata");
            }

            // Extract ACS URL
            String acsUrl = null;
            String acsBinding = null;
            for (AssertionConsumerService acs : spDescriptor.getAssertionConsumerServices()) {
                if (acs.isDefault() || acsUrl == null) {
                    acsUrl = acs.getLocation();
                    acsBinding = acs.getBinding();
                }
            }

            if (acsUrl == null) {
                throw new IllegalArgumentException("No AssertionConsumerService found in metadata");
            }

            // Extract SLO URL (optional)
            String sloUrl = null;
            for (SingleLogoutService slo : spDescriptor.getSingleLogoutServices()) {
                sloUrl = slo.getLocation();
                break;
            }

            // Extract NameID Format
            String nameIdFormat = null;
            if (!spDescriptor.getNameIDFormats().isEmpty()) {
                nameIdFormat = spDescriptor.getNameIDFormats().get(0).getURI();
            }

            // Extract SP Certificate
            String spCertificate = extractCertificateFromMetadata(spDescriptor);

            ServiceProviderEntity sp = ServiceProviderEntity.builder()
                    .entityId(entityId)
                    .applicationName(applicationName)
                    .description(description)
                    .acsUrl(acsUrl)
                    .sloUrl(sloUrl)
                    .acsBinding(acsBinding)
                    .nameIdFormat(nameIdFormat)
                    .spCertificate(spCertificate)
                    .metadataXml(metadataXml)
                    .signAssertions(true)
                    .encryptAssertions(spCertificate != null)
                    .isActive(true)
                    .authType("SAML")
                    .createdBy(createdBy)
                    .build();

            ServiceProviderEntity saved = spRepository.save(sp);
            logger.info("Successfully registered Service Provider from metadata: {} with ID: {}",
                    saved.getApplicationName(), saved.getId());

            return saved;
        } catch (Exception e) {
            logger.error("Failed to parse SP metadata", e);
            throw new RuntimeException("Failed to parse SP metadata: " + e.getMessage(), e);
        }
    }

    /**
     * Extract certificate from SP metadata.
     */
    private String extractCertificateFromMetadata(SPSSODescriptor spDescriptor) {
        for (KeyDescriptor keyDescriptor : spDescriptor.getKeyDescriptors()) {
            KeyInfo keyInfo = keyDescriptor.getKeyInfo();
            if (keyInfo != null) {
                for (X509Data x509Data : keyInfo.getX509Datas()) {
                    for (X509Certificate cert : x509Data.getX509Certificates()) {
                        return cert.getValue();
                    }
                }
            }
        }
        return null;
    }

    /**
     * Update an existing Service Provider.
     */
    @Transactional
    public ServiceProviderEntity updateServiceProvider(Long id, ServiceProviderDto dto) {
        ServiceProviderEntity sp = spRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Service Provider not found: " + id));

        if (dto.getApplicationName() != null) sp.setApplicationName(dto.getApplicationName());
        if (dto.getDescription() != null) sp.setDescription(dto.getDescription());
        if (dto.getAcsUrl() != null) sp.setAcsUrl(dto.getAcsUrl());
        if (dto.getSloUrl() != null) sp.setSloUrl(dto.getSloUrl());
        if (dto.getSpCertificate() != null) sp.setSpCertificate(dto.getSpCertificate());
        if (dto.getSignAssertions() != null) sp.setSignAssertions(dto.getSignAssertions());
        if (dto.getEncryptAssertions() != null) sp.setEncryptAssertions(dto.getEncryptAssertions());
        if (dto.getNameIdFormat() != null) sp.setNameIdFormat(dto.getNameIdFormat());
        if (dto.getAcsBinding() != null) sp.setAcsBinding(dto.getAcsBinding());
        if (dto.getDefaultRelayState() != null) sp.setDefaultRelayState(dto.getDefaultRelayState());
        if (dto.getAttributeMappings() != null) sp.setAttributeMappings(dto.getAttributeMappings());
        if (dto.getIsActive() != null) sp.setIsActive(dto.getIsActive());
        if (dto.getIconUrl() != null) sp.setIconUrl(dto.getIconUrl());
        if (dto.getApplicationUrl() != null) sp.setApplicationUrl(dto.getApplicationUrl());
        if (dto.getDisplayOrder() != null) sp.setDisplayOrder(dto.getDisplayOrder());
        if (dto.getCategory() != null) sp.setCategory(dto.getCategory());
        if (dto.getAllowedRoles() != null) sp.setAllowedRoles(dto.getAllowedRoles());
        if (dto.getUpdatedBy() != null) sp.setUpdatedBy(dto.getUpdatedBy());

        return spRepository.save(sp);
    }

    /**
     * Get Service Provider by ID.
     */
    public Optional<ServiceProviderEntity> getById(Long id) {
        return spRepository.findById(id);
    }

    /**
     * Get Service Provider by Entity ID.
     */
    public Optional<ServiceProviderEntity> getByEntityId(String entityId) {
        return spRepository.findByEntityId(entityId);
    }

    /**
     * Get all active Service Providers.
     */
    public List<ServiceProviderEntity> getAllActive() {
        return spRepository.findByIsActiveTrueOrderByDisplayOrderAsc();
    }

    /**
     * Get all SAML Service Providers.
     */
    public List<ServiceProviderEntity> getAllSamlProviders() {
        return spRepository.findByAuthTypeAndIsActiveTrue("SAML");
    }

    /**
     * Get Service Providers accessible by user roles.
     */
    public List<ServiceProviderEntity> getByUserRoles(List<String> roles) {
        return spRepository.findByAllowedRolesIn(roles);
    }

    /**
     * Delete a Service Provider.
     */
    @Transactional
    public void delete(Long id) {
        spRepository.deleteById(id);
        logger.info("Deleted Service Provider with ID: {}", id);
    }

    /**
     * Deactivate a Service Provider.
     */
    @Transactional
    public void deactivate(Long id) {
        ServiceProviderEntity sp = spRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Service Provider not found: " + id));
        sp.setIsActive(false);
        spRepository.save(sp);
        logger.info("Deactivated Service Provider: {}", sp.getApplicationName());
    }

    /**
     * Activate a Service Provider.
     */
    @Transactional
    public void activate(Long id) {
        ServiceProviderEntity sp = spRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Service Provider not found: " + id));
        sp.setIsActive(true);
        spRepository.save(sp);
        logger.info("Activated Service Provider: {}", sp.getApplicationName());
    }

    /**
     * Search Service Providers.
     */
    public List<ServiceProviderEntity> search(String query) {
        return spRepository.searchByNameOrDescription(query);
    }
}
