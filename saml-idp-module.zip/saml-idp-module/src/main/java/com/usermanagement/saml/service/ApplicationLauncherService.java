package com.usermanagement.saml.service;

import com.usermanagement.saml.entity.ServiceProviderEntity;
import com.usermanagement.saml.model.AuthenticatedUser;
import com.usermanagement.saml.model.LaunchResult;
import com.usermanagement.saml.model.SsoResult;
import com.usermanagement.saml.repository.ServiceProviderRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Service for launching applications - decides between JWT and SAML flow.
 * This integrates with your existing application launcher.
 */
@Service
@RequiredArgsConstructor
public class ApplicationLauncherService {

    private static final Logger logger = LoggerFactory.getLogger(ApplicationLauncherService.class);

    private final ServiceProviderRepository spRepository;
    private final SamlSsoService samlSsoService;
    // Inject your existing JWT service
    // private final JwtService jwtService;

    /**
     * Launch an application for a user.
     * Determines if SAML or JWT flow should be used.
     *
     * @param user The authenticated user
     * @param applicationId The application/SP ID
     * @return LaunchResult with the appropriate authentication mechanism
     */
    public LaunchResult launchApplication(AuthenticatedUser user, Long applicationId) {
        logger.info("Launching application {} for user {}", applicationId, user.getEmail());

        ServiceProviderEntity app = spRepository.findById(applicationId)
                .orElseThrow(() -> new IllegalArgumentException("Application not found: " + applicationId));

        if (!app.getIsActive()) {
            return LaunchResult.builder()
                    .success(false)
                    .errorMessage("Application is not active")
                    .build();
        }

        // Check if user has access to this application
        if (!hasAccess(user, app)) {
            return LaunchResult.builder()
                    .success(false)
                    .errorMessage("Access denied to this application")
                    .build();
        }

        // Determine authentication type
        if ("SAML".equalsIgnoreCase(app.getAuthType())) {
            return launchSamlApplication(user, app);
        } else {
            return launchJwtApplication(user, app);
        }
    }

    /**
     * Launch a SAML application.
     */
    private LaunchResult launchSamlApplication(AuthenticatedUser user, ServiceProviderEntity app) {
        logger.debug("Launching SAML application: {}", app.getApplicationName());

        SsoResult ssoResult = samlSsoService.initiateIdpSso(user, app.getEntityId(), app.getDefaultRelayState());

        if (!ssoResult.isSuccess()) {
            return LaunchResult.builder()
                    .success(false)
                    .errorMessage(ssoResult.getErrorMessage())
                    .build();
        }

        return LaunchResult.builder()
                .success(true)
                .authType("SAML")
                .targetUrl(ssoResult.getAcsUrl())
                .samlResponse(ssoResult.getSamlResponse())
                .relayState(ssoResult.getRelayState())
                .usePostBinding(ssoResult.isPostBinding())
                .build();
    }

    /**
     * Launch a JWT application.
     * 
     * IMPORTANT: Replace this with your actual JWT generation logic.
     */
    private LaunchResult launchJwtApplication(AuthenticatedUser user, ServiceProviderEntity app) {
        logger.debug("Launching JWT application: {}", app.getApplicationName());

        // TODO: Replace with your actual JWT service call
        // String jwtToken = jwtService.generateToken(user, app);

        // Placeholder - replace with your actual JWT logic
        String jwtToken = generateJwtToken(user, app);

        // Build the target URL with JWT
        String targetUrl = buildJwtTargetUrl(app, jwtToken);

        return LaunchResult.builder()
                .success(true)
                .authType("JWT")
                .targetUrl(targetUrl)
                .jwtToken(jwtToken)
                .usePostBinding(false) // JWT typically uses redirect
                .build();
    }

    /**
     * Check if user has access to the application.
     */
    private boolean hasAccess(AuthenticatedUser user, ServiceProviderEntity app) {
        // If no roles are specified, allow all authenticated users
        if (app.getAllowedRoles() == null || app.getAllowedRoles().isEmpty()) {
            return true;
        }

        // Check if user has any of the allowed roles
        if (user.getRoles() != null) {
            for (String userRole : user.getRoles()) {
                if (app.getAllowedRoles().contains(userRole)) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Generate JWT token - PLACEHOLDER.
     * Replace with your actual JWT generation logic.
     */
    private String generateJwtToken(AuthenticatedUser user, ServiceProviderEntity app) {
        // TODO: Replace with your actual JWT service
        // This is just a placeholder
        /*
        return jwtService.builder()
                .subject(user.getUserId())
                .claim("email", user.getEmail())
                .claim("name", user.getFullName())
                .claim("roles", user.getRoles())
                .audience(app.getEntityId())
                .expiration(Duration.ofHours(8))
                .sign();
        */
        throw new UnsupportedOperationException("Replace with your actual JWT generation logic");
    }

    /**
     * Build target URL with JWT token.
     */
    private String buildJwtTargetUrl(ServiceProviderEntity app, String jwtToken) {
        String baseUrl = app.getApplicationUrl();
        if (baseUrl == null) {
            baseUrl = app.getAcsUrl(); // Fallback to ACS URL
        }

        // Append JWT as query parameter or however your apps expect it
        String separator = baseUrl.contains("?") ? "&" : "?";
        return baseUrl + separator + "token=" + jwtToken;
    }

    /**
     * Get all applications accessible by user.
     */
    public List<ServiceProviderEntity> getAccessibleApplications(AuthenticatedUser user) {
        List<ServiceProviderEntity> allApps = spRepository.findByIsActiveTrueOrderByDisplayOrderAsc();

        return allApps.stream()
                .filter(app -> hasAccess(user, app))
                .collect(Collectors.toList());
    }

    /**
     * Get applications by category for the user.
     */
    public List<ServiceProviderEntity> getApplicationsByCategory(AuthenticatedUser user, String category) {
        List<ServiceProviderEntity> apps = spRepository.findByCategoryAndIsActiveTrue(category);

        return apps.stream()
                .filter(app -> hasAccess(user, app))
                .collect(Collectors.toList());
    }
}
