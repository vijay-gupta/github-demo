package com.usermanagement.saml;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import com.usermanagement.saml.config.SamlIdpProperties;

/**
 * Main Spring Boot Application.
 * 
 * This module provides SAML 2.0 IdP functionality for the User Management System.
 * 
 * Features:
 * - SAML 2.0 Identity Provider (IdP)
 * - Service Provider (SP) registration and management
 * - IdP-initiated SSO (user clicks app from portal)
 * - SP-initiated SSO (SP sends AuthnRequest)
 * - IdP Metadata generation
 * - Support for both SAML and JWT applications
 * 
 * Integration Points:
 * - Integrate with your existing authentication system
 * - Modify getAuthenticatedUser() methods to use your auth context
 * - Integrate ApplicationLauncherService with your JWT service
 * 
 * Endpoints:
 * - GET  /saml/metadata           - IdP Metadata XML
 * - GET  /saml/sso/init           - IdP-initiated SSO
 * - GET  /saml/sso                - SP-initiated SSO (Redirect binding)
 * - POST /saml/sso                - SP-initiated SSO (POST binding)
 * - GET  /saml/slo                - Single Logout
 * - POST /api/saml/service-providers         - Register SP
 * - GET  /api/saml/service-providers         - List SPs
 * - GET  /api/saml/service-providers/{id}    - Get SP
 * - PUT  /api/saml/service-providers/{id}    - Update SP
 * - DELETE /api/saml/service-providers/{id}  - Delete SP
 * - GET  /applications/launch/{appId}        - Launch application
 * - POST /applications/api/launch/{appId}    - Launch application API
 */
@SpringBootApplication
@EnableConfigurationProperties(SamlIdpProperties.class)
public class SamlIdpApplication {

    public static void main(String[] args) {
        SpringApplication.run(SamlIdpApplication.class, args);
    }
}
