package com.usermanagement.saml.service;

import com.usermanagement.saml.config.CredentialManager;
import com.usermanagement.saml.config.SamlIdpProperties;
import com.usermanagement.saml.entity.ServiceProviderEntity;
import com.usermanagement.saml.model.AuthenticatedUser;
import com.usermanagement.saml.util.SamlUtils;
import lombok.RequiredArgsConstructor;
import org.opensaml.saml.saml2.core.*;
import org.opensaml.security.credential.Credential;
import org.opensaml.xmlsec.signature.Signature;
import org.opensaml.xmlsec.signature.support.SignatureConstants;
import org.opensaml.xmlsec.signature.support.Signer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Base64;
import java.nio.charset.StandardCharsets;

/**
 * Service for building SAML Responses.
 */
@Service
@RequiredArgsConstructor
public class SamlResponseBuilder {

    private static final Logger logger = LoggerFactory.getLogger(SamlResponseBuilder.class);

    private final SamlIdpProperties samlIdpProperties;
    private final CredentialManager credentialManager;
    private final SamlAssertionBuilder assertionBuilder;

    /**
     * Build a complete SAML Response for IdP-initiated SSO.
     * This is used when user clicks on an application from your portal.
     */
    public Response buildIdpInitiatedResponse(AuthenticatedUser user, ServiceProviderEntity sp) {
        return buildResponse(user, sp, null);
    }

    /**
     * Build a complete SAML Response for SP-initiated SSO.
     * This is used when responding to an AuthnRequest from the SP.
     */
    public Response buildSpInitiatedResponse(AuthenticatedUser user, ServiceProviderEntity sp, String inResponseTo) {
        return buildResponse(user, sp, inResponseTo);
    }

    /**
     * Build the SAML Response.
     */
    private Response buildResponse(AuthenticatedUser user, ServiceProviderEntity sp, String inResponseTo) {
        logger.debug("Building SAML response for user: {} to SP: {}", user.getEmail(), sp.getEntityId());

        Instant now = Instant.now();

        // Build Response
        Response response = SamlUtils.buildSamlObject(Response.class);
        response.setID(SamlUtils.generateId());
        response.setIssueInstant(now);
        response.setVersion(org.opensaml.saml.common.SAMLVersion.VERSION_20);
        response.setDestination(sp.getAcsUrl());

        if (inResponseTo != null) {
            response.setInResponseTo(inResponseTo);
        }

        // Issuer
        response.setIssuer(SamlUtils.buildIssuer(samlIdpProperties.getEntityId()));

        // Status
        response.setStatus(SamlUtils.buildSuccessStatus());

        // Assertion
        Assertion assertion = assertionBuilder.buildAssertion(user, sp, inResponseTo);
        response.getAssertions().add(assertion);

        // Sign the Response
        signResponse(response);

        logger.info("Built SAML response with ID: {} for user: {} to SP: {}",
                response.getID(), user.getEmail(), sp.getApplicationName());

        return response;
    }

    /**
     * Build a SAML Error Response.
     */
    public Response buildErrorResponse(ServiceProviderEntity sp, String inResponseTo,
                                        String statusCode, String statusMessage) {
        Response response = SamlUtils.buildSamlObject(Response.class);
        response.setID(SamlUtils.generateId());
        response.setIssueInstant(Instant.now());
        response.setVersion(org.opensaml.saml.common.SAMLVersion.VERSION_20);
        response.setDestination(sp.getAcsUrl());

        if (inResponseTo != null) {
            response.setInResponseTo(inResponseTo);
        }

        response.setIssuer(SamlUtils.buildIssuer(samlIdpProperties.getEntityId()));

        // Error Status
        Status status = SamlUtils.buildSamlObject(Status.class);
        StatusCode statusCodeElement = SamlUtils.buildSamlObject(StatusCode.class);
        statusCodeElement.setValue(statusCode);
        status.setStatusCode(statusCodeElement);

        if (statusMessage != null) {
            StatusMessage statusMessageElement = SamlUtils.buildSamlObject(StatusMessage.class);
            statusMessageElement.setValue(statusMessage);
            status.setStatusMessage(statusMessageElement);
        }

        response.setStatus(status);

        signResponse(response);

        return response;
    }

    /**
     * Sign the SAML Response.
     */
    private void signResponse(Response response) {
        try {
            Credential credential = credentialManager.getSigningCredential();

            Signature signature = SamlUtils.buildSamlObject(Signature.class);
            signature.setSigningCredential(credential);
            signature.setSignatureAlgorithm(SignatureConstants.ALGO_ID_SIGNATURE_RSA_SHA256);
            signature.setCanonicalizationAlgorithm(SignatureConstants.ALGO_ID_C14N_EXCL_OMIT_COMMENTS);

            response.setSignature(signature);

            // Marshal to prepare for signing
            SamlUtils.marshal(response);

            // Sign
            Signer.signObject(signature);

            logger.debug("Successfully signed SAML response");
        } catch (Exception e) {
            throw new RuntimeException("Failed to sign SAML response", e);
        }
    }

    /**
     * Convert Response to Base64 encoded string for POST binding.
     */
    public String encodeResponseForPost(Response response) {
        try {
            String xml = SamlUtils.marshalToString(response);
            return Base64.getEncoder().encodeToString(xml.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            throw new RuntimeException("Failed to encode SAML response", e);
        }
    }

    /**
     * Get the SAML Response as XML string.
     */
    public String getResponseAsXml(Response response) {
        try {
            return SamlUtils.marshalToString(response);
        } catch (Exception e) {
            throw new RuntimeException("Failed to marshal SAML response", e);
        }
    }
}
