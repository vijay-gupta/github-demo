package com.usermanagement.saml.config;

import net.shibboleth.utilities.java.support.component.ComponentInitializationException;
import net.shibboleth.utilities.java.support.xml.BasicParserPool;
import net.shibboleth.utilities.java.support.xml.ParserPool;
import org.opensaml.core.config.ConfigurationService;
import org.opensaml.core.config.InitializationException;
import org.opensaml.core.config.InitializationService;
import org.opensaml.core.xml.config.XMLObjectProviderRegistry;
import org.opensaml.xmlsec.config.impl.JavaCryptoValidationInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import jakarta.annotation.PostConstruct;
import java.security.Provider;
import java.security.Security;
import java.util.HashMap;
import java.util.Map;

/**
 * Configuration class to initialize OpenSAML library.
 */
@Configuration
public class OpenSamlConfig {

    private static final Logger logger = LoggerFactory.getLogger(OpenSamlConfig.class);

    @PostConstruct
    public void init() throws InitializationException, ComponentInitializationException {
        logger.info("Initializing OpenSAML...");

        // Initialize Java Cryptography
        JavaCryptoValidationInitializer javaCryptoValidationInitializer = new JavaCryptoValidationInitializer();
        javaCryptoValidationInitializer.init();

        // Log available security providers
        for (Provider jceProvider : Security.getProviders()) {
            logger.debug("Available JCE Provider: {}", jceProvider.getName());
        }

        // Initialize OpenSAML
        InitializationService.initialize();

        // Get or create XMLObjectProviderRegistry
        XMLObjectProviderRegistry registry = ConfigurationService.get(XMLObjectProviderRegistry.class);
        if (registry == null) {
            registry = new XMLObjectProviderRegistry();
            ConfigurationService.register(XMLObjectProviderRegistry.class, registry);
        }

        // Set up parser pool
        registry.setParserPool(parserPool());

        logger.info("OpenSAML initialized successfully");
    }

    @Bean
    public ParserPool parserPool() throws ComponentInitializationException {
        BasicParserPool parserPool = new BasicParserPool();
        parserPool.setMaxPoolSize(100);
        parserPool.setCoalescing(true);
        parserPool.setIgnoreComments(true);
        parserPool.setIgnoreElementContentWhitespace(true);
        parserPool.setNamespaceAware(true);
        parserPool.setExpandEntityReferences(false);
        parserPool.setXincludeAware(false);

        // Security features to prevent XXE attacks
        Map<String, Boolean> features = new HashMap<>();
        features.put("http://xml.org/sax/features/external-general-entities", Boolean.FALSE);
        features.put("http://xml.org/sax/features/external-parameter-entities", Boolean.FALSE);
        features.put("http://apache.org/xml/features/disallow-doctype-decl", Boolean.TRUE);
        features.put("http://apache.org/xml/features/nonvalidating/load-external-dtd", Boolean.FALSE);
        parserPool.setBuilderFeatures(features);

        parserPool.initialize();
        return parserPool;
    }
}
