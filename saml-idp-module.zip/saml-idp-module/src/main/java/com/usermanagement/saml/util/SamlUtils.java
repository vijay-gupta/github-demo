package com.usermanagement.saml.util;

import org.opensaml.core.xml.XMLObject;
import org.opensaml.core.xml.XMLObjectBuilderFactory;
import org.opensaml.core.xml.config.XMLObjectProviderRegistrySupport;
import org.opensaml.core.xml.io.Marshaller;
import org.opensaml.core.xml.io.MarshallerFactory;
import org.opensaml.core.xml.io.MarshallingException;
import org.opensaml.core.xml.io.Unmarshaller;
import org.opensaml.core.xml.io.UnmarshallerFactory;
import org.opensaml.core.xml.io.UnmarshallingException;
import org.opensaml.core.xml.util.XMLObjectSupport;
import org.opensaml.saml.common.SAMLObject;
import org.opensaml.saml.saml2.core.*;
import org.opensaml.saml.saml2.metadata.*;
import org.opensaml.xmlsec.signature.KeyInfo;
import org.opensaml.xmlsec.signature.X509Certificate;
import org.opensaml.xmlsec.signature.X509Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.ByteArrayInputStream;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Base64;
import java.util.UUID;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import java.io.ByteArrayOutputStream;

/**
 * Utility class for SAML operations.
 */
public class SamlUtils {

    private static final Logger logger = LoggerFactory.getLogger(SamlUtils.class);

    private static final XMLObjectBuilderFactory builderFactory =
            XMLObjectProviderRegistrySupport.getBuilderFactory();

    private static final MarshallerFactory marshallerFactory =
            XMLObjectProviderRegistrySupport.getMarshallerFactory();

    private static final UnmarshallerFactory unmarshallerFactory =
            XMLObjectProviderRegistrySupport.getUnmarshallerFactory();

    private SamlUtils() {
        // Utility class
    }

    /**
     * Generate a unique SAML ID.
     */
    public static String generateId() {
        return "_" + UUID.randomUUID().toString();
    }

    /**
     * Build a SAML object of the specified type.
     */
    @SuppressWarnings("unchecked")
    public static <T extends XMLObject> T buildSamlObject(Class<T> clazz) {
        try {
            QName defaultElementName = (QName) clazz.getDeclaredField("DEFAULT_ELEMENT_NAME").get(null);
            return (T) builderFactory.getBuilder(defaultElementName).buildObject(defaultElementName);
        } catch (Exception e) {
            throw new RuntimeException("Failed to build SAML object: " + clazz.getName(), e);
        }
    }

    /**
     * Build a SAML object with specified QName.
     */
    @SuppressWarnings("unchecked")
    public static <T extends XMLObject> T buildSamlObject(QName qName) {
        return (T) builderFactory.getBuilder(qName).buildObject(qName);
    }

    /**
     * Marshal a SAML object to XML string.
     */
    public static String marshalToString(XMLObject xmlObject) throws MarshallingException {
        try {
            Element element = marshal(xmlObject);
            return elementToString(element);
        } catch (Exception e) {
            throw new MarshallingException("Failed to marshal SAML object", e);
        }
    }

    /**
     * Marshal a SAML object to DOM Element.
     */
    public static Element marshal(XMLObject xmlObject) throws MarshallingException {
        Marshaller marshaller = marshallerFactory.getMarshaller(xmlObject);
        if (marshaller == null) {
            throw new MarshallingException("No marshaller found for: " + xmlObject.getElementQName());
        }
        return marshaller.marshall(xmlObject);
    }

    /**
     * Unmarshal XML string to SAML object.
     */
    public static XMLObject unmarshal(String xml) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        // Security: Disable external entities
        factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
        factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
        factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);

        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));

        return unmarshal(document.getDocumentElement());
    }

    /**
     * Unmarshal DOM Element to SAML object.
     */
    public static XMLObject unmarshal(Element element) throws UnmarshallingException {
        Unmarshaller unmarshaller = unmarshallerFactory.getUnmarshaller(element);
        if (unmarshaller == null) {
            throw new UnmarshallingException("No unmarshaller found for: " + element.getLocalName());
        }
        return unmarshaller.unmarshall(element);
    }

    /**
     * Convert DOM Element to String.
     */
    public static String elementToString(Element element) throws Exception {
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        // Security: Disable external entities
        transformerFactory.setAttribute("http://javax.xml.XMLConstants/property/accessExternalDTD", "");
        transformerFactory.setAttribute("http://javax.xml.XMLConstants/property/accessExternalStylesheet", "");

        Transformer transformer = transformerFactory.newTransformer();
        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");

        StringWriter writer = new StringWriter();
        transformer.transform(new DOMSource(element), new StreamResult(writer));
        return writer.toString();
    }

    /**
     * Base64 encode a string.
     */
    public static String base64Encode(String value) {
        return Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

    /**
     * Base64 decode a string.
     */
    public static String base64Decode(String value) {
        return new String(Base64.getDecoder().decode(value), StandardCharsets.UTF_8);
    }

    /**
     * Deflate and Base64 encode (for HTTP-Redirect binding).
     */
    public static String deflateAndEncode(String value) throws Exception {
        ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
        Deflater deflater = new Deflater(Deflater.DEFLATED, true);
        DeflaterOutputStream deflaterStream = new DeflaterOutputStream(bytesOut, deflater);
        deflaterStream.write(value.getBytes(StandardCharsets.UTF_8));
        deflaterStream.finish();

        return Base64.getEncoder().encodeToString(bytesOut.toByteArray());
    }

    /**
     * Build an Issuer element.
     */
    public static Issuer buildIssuer(String issuerValue) {
        Issuer issuer = buildSamlObject(Issuer.class);
        issuer.setValue(issuerValue);
        issuer.setFormat(NameIDType.ENTITY);
        return issuer;
    }

    /**
     * Build a NameID element.
     */
    public static NameID buildNameId(String value, String format) {
        NameID nameId = buildSamlObject(NameID.class);
        nameId.setValue(value);
        nameId.setFormat(format);
        return nameId;
    }

    /**
     * Build a Subject element.
     */
    public static Subject buildSubject(String nameIdValue, String nameIdFormat,
                                        String recipient, Instant notOnOrAfter,
                                        String inResponseTo) {
        Subject subject = buildSamlObject(Subject.class);

        // NameID
        NameID nameId = buildNameId(nameIdValue, nameIdFormat);
        subject.setNameID(nameId);

        // SubjectConfirmation
        SubjectConfirmation subjectConfirmation = buildSamlObject(SubjectConfirmation.class);
        subjectConfirmation.setMethod(SubjectConfirmation.METHOD_BEARER);

        SubjectConfirmationData subjectConfirmationData = buildSamlObject(SubjectConfirmationData.class);
        subjectConfirmationData.setRecipient(recipient);
        subjectConfirmationData.setNotOnOrAfter(notOnOrAfter);
        if (inResponseTo != null) {
            subjectConfirmationData.setInResponseTo(inResponseTo);
        }

        subjectConfirmation.setSubjectConfirmationData(subjectConfirmationData);
        subject.getSubjectConfirmations().add(subjectConfirmation);

        return subject;
    }

    /**
     * Build Conditions element.
     */
    public static Conditions buildConditions(Instant notBefore, Instant notOnOrAfter, String audienceUri) {
        Conditions conditions = buildSamlObject(Conditions.class);
        conditions.setNotBefore(notBefore);
        conditions.setNotOnOrAfter(notOnOrAfter);

        // Audience Restriction
        AudienceRestriction audienceRestriction = buildSamlObject(AudienceRestriction.class);
        Audience audience = buildSamlObject(Audience.class);
        audience.setURI(audienceUri);
        audienceRestriction.getAudiences().add(audience);
        conditions.getAudienceRestrictions().add(audienceRestriction);

        return conditions;
    }

    /**
     * Build AuthnStatement element.
     */
    public static AuthnStatement buildAuthnStatement(Instant authnInstant, String sessionIndex) {
        AuthnStatement authnStatement = buildSamlObject(AuthnStatement.class);
        authnStatement.setAuthnInstant(authnInstant);
        authnStatement.setSessionIndex(sessionIndex);

        AuthnContext authnContext = buildSamlObject(AuthnContext.class);
        AuthnContextClassRef authnContextClassRef = buildSamlObject(AuthnContextClassRef.class);
        authnContextClassRef.setURI(AuthnContext.PASSWORD_AUTHN_CTX);
        authnContext.setAuthnContextClassRef(authnContextClassRef);
        authnStatement.setAuthnContext(authnContext);

        return authnStatement;
    }

    /**
     * Build an Attribute element.
     */
    public static Attribute buildAttribute(String name, String friendlyName, String nameFormat, String... values) {
        Attribute attribute = buildSamlObject(Attribute.class);
        attribute.setName(name);
        if (friendlyName != null) {
            attribute.setFriendlyName(friendlyName);
        }
        attribute.setNameFormat(nameFormat != null ? nameFormat : Attribute.URI_REFERENCE);

        for (String value : values) {
            if (value != null && !value.isEmpty()) {
                attribute.getAttributeValues().add(buildAttributeValue(value));
            }
        }

        return attribute;
    }

    /**
     * Build an AttributeValue element.
     */
    public static XMLObject buildAttributeValue(String value) {
        org.opensaml.core.xml.schema.XSString attributeValue =
                (org.opensaml.core.xml.schema.XSString) XMLObjectSupport.buildXMLObject(
                        org.opensaml.core.xml.schema.XSString.TYPE_NAME);
        attributeValue.setValue(value);
        return attributeValue;
    }

    /**
     * Build Status element.
     */
    public static Status buildStatus(String statusCode) {
        Status status = buildSamlObject(Status.class);
        StatusCode statusCodeElement = buildSamlObject(StatusCode.class);
        statusCodeElement.setValue(statusCode);
        status.setStatusCode(statusCodeElement);
        return status;
    }

    /**
     * Build successful Status.
     */
    public static Status buildSuccessStatus() {
        return buildStatus(StatusCode.SUCCESS);
    }

    /**
     * Parse NameID format string to full URI.
     */
    public static String resolveNameIdFormat(String format) {
        if (format == null) {
            return NameIDType.EMAIL;
        }

        return switch (format.toLowerCase()) {
            case "email", "emailaddress" -> NameIDType.EMAIL;
            case "persistent" -> NameIDType.PERSISTENT;
            case "transient" -> NameIDType.TRANSIENT;
            case "unspecified" -> NameIDType.UNSPECIFIED;
            case "x509" -> NameIDType.X509_SUBJECT;
            case "windows" -> NameIDType.WINDOWS_DOMAIN_QUALIFIED_NAME;
            case "kerberos" -> NameIDType.KERBEROS;
            case "entity" -> NameIDType.ENTITY;
            default -> {
                // If already a full URI, return as-is
                if (format.startsWith("urn:")) {
                    yield format;
                }
                yield NameIDType.EMAIL;
            }
        };
    }
}
