package com.usermanagement.saml.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.util.Set;

/**
 * DTO for Service Provider registration and updates.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ServiceProviderDto {

    /**
     * Service Provider Entity ID
     */
    @NotBlank(message = "Entity ID is required")
    @Size(max = 500, message = "Entity ID must not exceed 500 characters")
    private String entityId;

    /**
     * Human-readable application name
     */
    @NotBlank(message = "Application name is required")
    @Size(max = 255, message = "Application name must not exceed 255 characters")
    private String applicationName;

    /**
     * Application description
     */
    @Size(max = 1000, message = "Description must not exceed 1000 characters")
    private String description;

    /**
     * Assertion Consumer Service URL
     */
    @NotBlank(message = "ACS URL is required")
    @Size(max = 500, message = "ACS URL must not exceed 500 characters")
    private String acsUrl;

    /**
     * Single Logout URL (optional)
     */
    @Size(max = 500, message = "SLO URL must not exceed 500 characters")
    private String sloUrl;

    /**
     * SP Certificate for encryption (Base64)
     */
    private String spCertificate;

    /**
     * Whether to sign assertions
     */
    private Boolean signAssertions;

    /**
     * Whether to encrypt assertions
     */
    private Boolean encryptAssertions;

    /**
     * Name ID format
     */
    private String nameIdFormat;

    /**
     * ACS Binding type
     */
    private String acsBinding;

    /**
     * Default relay state
     */
    @Size(max = 500, message = "Relay state must not exceed 500 characters")
    private String defaultRelayState;

    /**
     * Attribute mappings JSON
     */
    private String attributeMappings;

    /**
     * Whether the SP is active
     */
    private Boolean isActive;

    /**
     * SP Metadata XML
     */
    private String metadataXml;

    /**
     * Icon URL for display
     */
    @Size(max = 500, message = "Icon URL must not exceed 500 characters")
    private String iconUrl;

    /**
     * Application URL
     */
    @Size(max = 500, message = "Application URL must not exceed 500 characters")
    private String applicationUrl;

    /**
     * Display order
     */
    private Integer displayOrder;

    /**
     * Category/Group
     */
    private String category;

    /**
     * Allowed roles
     */
    private Set<String> allowedRoles;

    /**
     * Created by user
     */
    private String createdBy;

    /**
     * Updated by user
     */
    private String updatedBy;
}
