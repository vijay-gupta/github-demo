package com.usermanagement.saml.repository;

import com.usermanagement.saml.entity.ServiceProviderEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository for managing Service Provider entities.
 */
@Repository
public interface ServiceProviderRepository extends JpaRepository<ServiceProviderEntity, Long> {

    /**
     * Find SP by entity ID.
     */
    Optional<ServiceProviderEntity> findByEntityId(String entityId);

    /**
     * Find SP by application name.
     */
    Optional<ServiceProviderEntity> findByApplicationName(String applicationName);

    /**
     * Check if SP exists by entity ID.
     */
    boolean existsByEntityId(String entityId);

    /**
     * Find all active SPs.
     */
    List<ServiceProviderEntity> findByIsActiveTrue();

    /**
     * Find all SAML SPs.
     */
    List<ServiceProviderEntity> findByAuthTypeAndIsActiveTrue(String authType);

    /**
     * Find SPs by category.
     */
    List<ServiceProviderEntity> findByCategoryAndIsActiveTrue(String category);

    /**
     * Find SPs accessible by a specific role.
     */
    @Query("SELECT sp FROM ServiceProviderEntity sp JOIN sp.allowedRoles r WHERE r = :role AND sp.isActive = true")
    List<ServiceProviderEntity> findByAllowedRole(@Param("role") String role);

    /**
     * Find SPs accessible by any of the given roles.
     */
    @Query("SELECT DISTINCT sp FROM ServiceProviderEntity sp JOIN sp.allowedRoles r WHERE r IN :roles AND sp.isActive = true ORDER BY sp.displayOrder")
    List<ServiceProviderEntity> findByAllowedRolesIn(@Param("roles") List<String> roles);

    /**
     * Find all SPs ordered by display order.
     */
    List<ServiceProviderEntity> findByIsActiveTrueOrderByDisplayOrderAsc();

    /**
     * Search SPs by name or description.
     */
    @Query("SELECT sp FROM ServiceProviderEntity sp WHERE sp.isActive = true AND " +
           "(LOWER(sp.applicationName) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
           "LOWER(sp.description) LIKE LOWER(CONCAT('%', :search, '%')))")
    List<ServiceProviderEntity> searchByNameOrDescription(@Param("search") String search);
}
