package com.usermanagement.saml.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

/**
 * Entity representing a registered SAML Service Provider (SP).
 * Each application that requires SAML authentication must be registered here.
 */
@Entity
@Table(name = "saml_service_providers")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ServiceProviderEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Unique identifier for the SP (Entity ID from SP metadata)
     */
    @Column(name = "entity_id", nullable = false, unique = true, length = 500)
    private String entityId;

    /**
     * Human-readable name for the application
     */
    @Column(name = "application_name", nullable = false)
    private String applicationName;

    /**
     * Description of the application
     */
    @Column(name = "description", length = 1000)
    private String description;

    /**
     * Assertion Consumer Service URL (where SAML Response is sent)
     */
    @Column(name = "acs_url", nullable = false, length = 500)
    private String acsUrl;

    /**
     * Single Logout Service URL (optional)
     */
    @Column(name = "slo_url", length = 500)
    private String sloUrl;

    /**
     * SP's public certificate for encryption (Base64 encoded)
     */
    @Column(name = "sp_certificate", columnDefinition = "TEXT")
    private String spCertificate;

    /**
     * Whether assertions should be signed
     */
    @Column(name = "sign_assertions")
    @Builder.Default
    private Boolean signAssertions = true;

    /**
     * Whether assertions should be encrypted
     */
    @Column(name = "encrypt_assertions")
    @Builder.Default
    private Boolean encryptAssertions = false;

    /**
     * Name ID format (e.g., email, persistent, transient)
     */
    @Column(name = "name_id_format")
    @Builder.Default
    private String nameIdFormat = "urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress";

    /**
     * SAML binding type for ACS (POST or Redirect)
     */
    @Column(name = "acs_binding")
    @Builder.Default
    private String acsBinding = "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST";

    /**
     * Relay state (optional default relay state)
     */
    @Column(name = "default_relay_state", length = 500)
    private String defaultRelayState;

    /**
     * Attribute mappings as JSON
     * Example: {"email": "mail", "firstName": "givenName", "lastName": "sn"}
     */
    @Column(name = "attribute_mappings", columnDefinition = "TEXT")
    private String attributeMappings;

    /**
     * Whether this SP is active
     */
    @Column(name = "is_active")
    @Builder.Default
    private Boolean isActive = true;

    /**
     * SP Metadata XML (if uploaded)
     */
    @Column(name = "metadata_xml", columnDefinition = "TEXT")
    private String metadataXml;

    /**
     * Authentication type: SAML or JWT
     */
    @Column(name = "auth_type", nullable = false)
    @Builder.Default
    private String authType = "SAML";

    /**
     * Icon URL for display in application launcher
     */
    @Column(name = "icon_url", length = 500)
    private String iconUrl;

    /**
     * Application URL (for display purposes)
     */
    @Column(name = "application_url", length = 500)
    private String applicationUrl;

    /**
     * Display order in application list
     */
    @Column(name = "display_order")
    @Builder.Default
    private Integer displayOrder = 0;

    /**
     * Category/Group for the application
     */
    @Column(name = "category")
    private String category;

    /**
     * Created timestamp
     */
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    /**
     * Last updated timestamp
     */
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    /**
     * Created by user
     */
    @Column(name = "created_by")
    private String createdBy;

    /**
     * Updated by user
     */
    @Column(name = "updated_by")
    private String updatedBy;

    /**
     * User roles that can access this application
     */
    @ElementCollection
    @CollectionTable(name = "sp_allowed_roles", joinColumns = @JoinColumn(name = "sp_id"))
    @Column(name = "role")
    @Builder.Default
    private Set<String> allowedRoles = new HashSet<>();

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
