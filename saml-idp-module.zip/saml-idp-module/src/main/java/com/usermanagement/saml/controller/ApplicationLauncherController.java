package com.usermanagement.saml.controller;

import com.usermanagement.saml.entity.ServiceProviderEntity;
import com.usermanagement.saml.model.AuthenticatedUser;
import com.usermanagement.saml.model.LaunchResult;
import com.usermanagement.saml.service.ApplicationLauncherService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;

/**
 * Controller for the application launcher.
 * This integrates with your existing portal to handle both SAML and JWT apps.
 */
@Controller
@RequestMapping("/applications")
@RequiredArgsConstructor
public class ApplicationLauncherController {

    private static final Logger logger = LoggerFactory.getLogger(ApplicationLauncherController.class);

    private final ApplicationLauncherService launcherService;

    /**
     * Get all accessible applications for the current user.
     * Call this from your application list page.
     */
    @GetMapping("/api/list")
    @ResponseBody
    public ResponseEntity<List<ServiceProviderEntity>> getApplicationList(HttpSession session) {
        AuthenticatedUser user = getAuthenticatedUser(session);

        if (user == null) {
            return ResponseEntity.status(401).build();
        }

        List<ServiceProviderEntity> apps = launcherService.getAccessibleApplications(user);
        return ResponseEntity.ok(apps);
    }

    /**
     * Get applications by category.
     */
    @GetMapping("/api/list/category/{category}")
    @ResponseBody
    public ResponseEntity<List<ServiceProviderEntity>> getApplicationsByCategory(
            @PathVariable String category,
            HttpSession session) {
        AuthenticatedUser user = getAuthenticatedUser(session);

        if (user == null) {
            return ResponseEntity.status(401).build();
        }

        List<ServiceProviderEntity> apps = launcherService.getApplicationsByCategory(user, category);
        return ResponseEntity.ok(apps);
    }

    /**
     * Launch an application - API endpoint.
     * Returns launch configuration for the frontend to handle.
     */
    @PostMapping("/api/launch/{appId}")
    @ResponseBody
    public ResponseEntity<LaunchResult> launchApplicationApi(
            @PathVariable Long appId,
            HttpSession session) {
        AuthenticatedUser user = getAuthenticatedUser(session);

        if (user == null) {
            return ResponseEntity.status(401).build();
        }

        try {
            LaunchResult result = launcherService.launchApplication(user, appId);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            logger.error("Failed to launch application", e);
            return ResponseEntity.ok(LaunchResult.builder()
                    .success(false)
                    .errorMessage(e.getMessage())
                    .build());
        }
    }

    /**
     * Launch an application - Direct navigation.
     * Handles the flow directly (for simple integration).
     */
    @GetMapping("/launch/{appId}")
    public String launchApplication(@PathVariable Long appId,
                                     HttpSession session,
                                     Model model) {
        AuthenticatedUser user = getAuthenticatedUser(session);

        if (user == null) {
            return "redirect:/login?returnUrl=/applications/launch/" + appId;
        }

        try {
            LaunchResult result = launcherService.launchApplication(user, appId);

            if (!result.isSuccess()) {
                model.addAttribute("error", result.getErrorMessage());
                return "applications/launch-error";
            }

            if (result.isSaml() && result.isUsePostBinding()) {
                // SAML POST binding - show auto-submit form
                model.addAttribute("acsUrl", result.getTargetUrl());
                model.addAttribute("samlResponse", result.getSamlResponse());
                model.addAttribute("relayState", result.getRelayState());
                return "saml/post-binding";
            } else {
                // JWT or SAML Redirect - simple redirect
                return "redirect:" + result.getTargetUrl();
            }

        } catch (Exception e) {
            logger.error("Failed to launch application", e);
            model.addAttribute("error", e.getMessage());
            return "applications/launch-error";
        }
    }

    /**
     * Check application auth type.
     */
    @GetMapping("/api/auth-type/{appId}")
    @ResponseBody
    public ResponseEntity<Map<String, String>> getAuthType(@PathVariable Long appId) {
        // This could be used by frontend to determine how to handle the launch
        return ResponseEntity.ok(Map.of(
                "authType", "SAML" // or "JWT" based on the app
        ));
    }

    /**
     * Get authenticated user from session.
     * Replace with your actual authentication mechanism.
     */
    private AuthenticatedUser getAuthenticatedUser(HttpSession session) {
        // Get from your existing session/security context
        Object userObj = session.getAttribute("authenticatedUser");
        if (userObj instanceof AuthenticatedUser) {
            return (AuthenticatedUser) userObj;
        }

        // Or get from Spring Security:
        // return authenticationService.getCurrentUser();

        return null;
    }
}
