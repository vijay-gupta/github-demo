package com.usermanagement.saml.controller;

import com.usermanagement.saml.model.AuthenticatedUser;
import com.usermanagement.saml.model.SsoResult;
import com.usermanagement.saml.service.IdpMetadataGenerator;
import com.usermanagement.saml.service.SamlSsoService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**
 * Controller for SAML SSO endpoints.
 */
@Controller
@RequestMapping("/saml")
@RequiredArgsConstructor
public class SamlSsoController {

    private static final Logger logger = LoggerFactory.getLogger(SamlSsoController.class);

    private final SamlSsoService ssoService;
    private final IdpMetadataGenerator metadataGenerator;

    /**
     * Serve IdP Metadata.
     */
    @GetMapping(value = "/metadata", produces = MediaType.APPLICATION_XML_VALUE)
    @ResponseBody
    public String getMetadata() {
        logger.debug("Serving IdP metadata");
        return metadataGenerator.getMetadataXml();
    }

    /**
     * IdP-initiated SSO - Called when user clicks on an application from the portal.
     * This endpoint should be called after user is authenticated.
     *
     * Usage from your application launcher:
     * When user clicks on a SAML app, redirect to: /saml/sso/init?spId=123
     */
    @GetMapping("/sso/init")
    public String initiateSso(@RequestParam(required = false) Long spId,
                               @RequestParam(required = false) String entityId,
                               @RequestParam(required = false) String relayState,
                               HttpSession session,
                               Model model) {
        logger.info("Initiating IdP SSO for SP: {}", spId != null ? spId : entityId);

        // Get authenticated user from session
        // In your real implementation, get this from your authentication system
        AuthenticatedUser user = getAuthenticatedUser(session);

        if (user == null) {
            logger.warn("No authenticated user found, redirecting to login");
            return "redirect:/login?returnUrl=/saml/sso/init?spId=" + spId;
        }

        try {
            SsoResult result;

            if (spId != null) {
                result = ssoService.initiateIdpSsoById(user, spId, relayState);
            } else if (entityId != null) {
                result = ssoService.initiateIdpSso(user, entityId, relayState);
            } else {
                throw new IllegalArgumentException("Either spId or entityId is required");
            }

            if (!result.isSuccess()) {
                model.addAttribute("error", result.getErrorMessage());
                return "saml/error";
            }

            // Return HTML form that auto-submits the SAML Response to SP's ACS URL
            model.addAttribute("acsUrl", result.getAcsUrl());
            model.addAttribute("samlResponse", result.getSamlResponse());
            model.addAttribute("relayState", result.getRelayState());

            return "saml/post-binding";

        } catch (Exception e) {
            logger.error("Failed to initiate SSO", e);
            model.addAttribute("error", e.getMessage());
            return "saml/error";
        }
    }

    /**
     * SP-initiated SSO endpoint (receives AuthnRequest).
     * SP redirects user here with SAMLRequest.
     */
    @GetMapping("/sso")
    public String handleSsoGet(@RequestParam("SAMLRequest") String samlRequest,
                                @RequestParam(value = "RelayState", required = false) String relayState,
                                @RequestParam(value = "SigAlg", required = false) String sigAlg,
                                @RequestParam(value = "Signature", required = false) String signature,
                                HttpSession session,
                                Model model) {
        logger.info("Received SP-initiated SSO request (GET/Redirect binding)");

        // Get authenticated user
        AuthenticatedUser user = getAuthenticatedUser(session);

        if (user == null) {
            // Store SAML request info in session and redirect to login
            session.setAttribute("pendingSamlRequest", samlRequest);
            session.setAttribute("pendingRelayState", relayState);
            session.setAttribute("isDeflated", true);
            return "redirect:/login?samlSso=true";
        }

        return processSsoRequest(user, samlRequest, relayState, true, model);
    }

    /**
     * SP-initiated SSO endpoint (POST binding).
     */
    @PostMapping("/sso")
    public String handleSsoPost(@RequestParam("SAMLRequest") String samlRequest,
                                 @RequestParam(value = "RelayState", required = false) String relayState,
                                 HttpSession session,
                                 Model model) {
        logger.info("Received SP-initiated SSO request (POST binding)");

        AuthenticatedUser user = getAuthenticatedUser(session);

        if (user == null) {
            session.setAttribute("pendingSamlRequest", samlRequest);
            session.setAttribute("pendingRelayState", relayState);
            session.setAttribute("isDeflated", false);
            return "redirect:/login?samlSso=true";
        }

        return processSsoRequest(user, samlRequest, relayState, false, model);
    }

    /**
     * Resume SSO after login (when user wasn't authenticated initially).
     */
    @GetMapping("/sso/resume")
    public String resumeSso(HttpSession session, Model model) {
        logger.info("Resuming SSO after authentication");

        AuthenticatedUser user = getAuthenticatedUser(session);

        if (user == null) {
            return "redirect:/login";
        }

        String samlRequest = (String) session.getAttribute("pendingSamlRequest");
        String relayState = (String) session.getAttribute("pendingRelayState");
        Boolean isDeflated = (Boolean) session.getAttribute("isDeflated");

        if (samlRequest == null) {
            model.addAttribute("error", "No pending SSO request found");
            return "saml/error";
        }

        // Clean up session
        session.removeAttribute("pendingSamlRequest");
        session.removeAttribute("pendingRelayState");
        session.removeAttribute("isDeflated");

        return processSsoRequest(user, samlRequest, relayState, isDeflated != null && isDeflated, model);
    }

    /**
     * Process the SSO request and generate response.
     */
    private String processSsoRequest(AuthenticatedUser user, String samlRequest,
                                      String relayState, boolean isDeflated, Model model) {
        try {
            SsoResult result = ssoService.processSpInitiatedSso(user, samlRequest, relayState, isDeflated);

            if (!result.isSuccess()) {
                model.addAttribute("error", result.getErrorMessage());
                return "saml/error";
            }

            model.addAttribute("acsUrl", result.getAcsUrl());
            model.addAttribute("samlResponse", result.getSamlResponse());
            model.addAttribute("relayState", result.getRelayState());

            return "saml/post-binding";

        } catch (Exception e) {
            logger.error("Failed to process SSO request", e);
            model.addAttribute("error", e.getMessage());
            return "saml/error";
        }
    }

    /**
     * Single Logout endpoint (optional).
     */
    @GetMapping("/slo")
    public String handleLogout(@RequestParam(value = "SAMLRequest", required = false) String logoutRequest,
                                @RequestParam(value = "RelayState", required = false) String relayState,
                                HttpSession session) {
        logger.info("Received logout request");

        // Invalidate local session
        session.invalidate();

        // For a complete implementation, you would:
        // 1. Parse the LogoutRequest
        // 2. Terminate the user's session
        // 3. Optionally send LogoutRequest to other SPs the user is logged into
        // 4. Send LogoutResponse back to the SP that initiated logout

        return "redirect:/login?logout=true";
    }

    /**
     * Get authenticated user from session.
     * 
     * IMPORTANT: Replace this with your actual authentication mechanism.
     * This should integrate with your existing user authentication system.
     */
    private AuthenticatedUser getAuthenticatedUser(HttpSession session) {
        // Option 1: Get from your existing session attribute
        Object userObj = session.getAttribute("authenticatedUser");
        if (userObj instanceof AuthenticatedUser) {
            return (AuthenticatedUser) userObj;
        }

        // Option 2: Get from Spring Security context
        // Replace with your actual implementation:
        /*
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.isAuthenticated() && !(auth instanceof AnonymousAuthenticationToken)) {
            // Convert your principal to AuthenticatedUser
            YourPrincipal principal = (YourPrincipal) auth.getPrincipal();
            return AuthenticatedUser.builder()
                    .userId(principal.getId())
                    .email(principal.getEmail())
                    .username(principal.getUsername())
                    .firstName(principal.getFirstName())
                    .lastName(principal.getLastName())
                    .roles(principal.getRoles())
                    .build();
        }
        */

        return null;
    }
}
