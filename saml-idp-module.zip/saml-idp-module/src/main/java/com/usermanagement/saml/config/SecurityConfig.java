package com.usermanagement.saml.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Security configuration for the SAML IdP module.
 * 
 * IMPORTANT: Modify this to integrate with your existing security configuration.
 * This is a basic configuration that allows the SAML endpoints to work.
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    @Order(1)
    public SecurityFilterChain samlSecurityFilterChain(HttpSecurity http) throws Exception {
        http
            // SAML metadata should be publicly accessible
            .securityMatcher("/saml/metadata")
            .authorizeHttpRequests(auth -> auth.anyRequest().permitAll())
            .csrf(csrf -> csrf.disable());

        return http.build();
    }

    @Bean
    @Order(2)
    public SecurityFilterChain apiSecurityFilterChain(HttpSecurity http) throws Exception {
        http
            .securityMatcher("/api/**")
            .authorizeHttpRequests(auth -> auth
                // SP management APIs require authentication
                .requestMatchers("/api/saml/service-providers/**").authenticated()
                // Application launcher APIs require authentication
                .requestMatchers("/applications/api/**").authenticated()
                .anyRequest().authenticated()
            )
            .csrf(csrf -> csrf.disable()); // Disable for API endpoints

        return http.build();
    }

    @Bean
    @Order(3)
    public SecurityFilterChain defaultSecurityFilterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(auth -> auth
                // Public endpoints
                .requestMatchers("/saml/metadata").permitAll()
                .requestMatchers("/h2-console/**").permitAll()
                .requestMatchers("/error").permitAll()
                
                // SSO endpoints need special handling
                // They check authentication internally and redirect to login if needed
                .requestMatchers("/saml/sso/**").permitAll()
                .requestMatchers("/saml/slo/**").permitAll()
                
                // Application launch requires authentication
                .requestMatchers("/applications/**").authenticated()
                
                // Everything else requires authentication
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .loginPage("/login")
                .permitAll()
            )
            .logout(logout -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("/login?logout")
                .permitAll()
            )
            // Disable CSRF for SAML POST endpoints (they have their own security)
            .csrf(csrf -> csrf
                .ignoringRequestMatchers("/saml/**")
            )
            // Allow H2 console frames
            .headers(headers -> headers
                .frameOptions(frame -> frame.sameOrigin())
            );

        return http.build();
    }
}
