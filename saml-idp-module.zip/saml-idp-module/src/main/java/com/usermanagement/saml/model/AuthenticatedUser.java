package com.usermanagement.saml.model;

import lombok.*;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Represents an authenticated user from your existing authentication system.
 * This model is used to generate SAML assertions.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuthenticatedUser {

    /**
     * Unique user identifier (used as NameID subject)
     */
    private String userId;

    /**
     * User's email address
     */
    private String email;

    /**
     * Username
     */
    private String username;

    /**
     * First name
     */
    private String firstName;

    /**
     * Last name
     */
    private String lastName;

    /**
     * Full display name
     */
    private String displayName;

    /**
     * User's department
     */
    private String department;

    /**
     * User's title/designation
     */
    private String title;

    /**
     * User's employee ID
     */
    private String employeeId;

    /**
     * User's phone number
     */
    private String phoneNumber;

    /**
     * User's organization
     */
    private String organization;

    /**
     * User's roles
     */
    @Builder.Default
    private Set<String> roles = new HashSet<>();

    /**
     * User's groups
     */
    @Builder.Default
    private Set<String> groups = new HashSet<>();

    /**
     * Authentication method (SSO, DATABASE, 2FA)
     */
    private String authMethod;

    /**
     * Session ID from your authentication system
     */
    private String sessionId;

    /**
     * Any additional attributes to include in SAML assertion
     */
    @Builder.Default
    private Map<String, String> additionalAttributes = new HashMap<>();

    /**
     * Whether the user authenticated via SSO
     */
    private boolean ssoAuthenticated;

    /**
     * SSO provider name (if applicable)
     */
    private String ssoProvider;

    /**
     * Get the NameID value based on format
     */
    public String getNameIdValue(String nameIdFormat) {
        return switch (nameIdFormat) {
            case "urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress" -> email;
            case "urn:oasis:names:tc:SAML:2.0:nameid-format:persistent" -> userId;
            case "urn:oasis:names:tc:SAML:2.0:nameid-format:transient" -> sessionId;
            case "urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified" -> username;
            default -> email != null ? email : userId;
        };
    }

    /**
     * Get full name
     */
    public String getFullName() {
        if (displayName != null && !displayName.isBlank()) {
            return displayName;
        }
        StringBuilder name = new StringBuilder();
        if (firstName != null) {
            name.append(firstName);
        }
        if (lastName != null) {
            if (name.length() > 0) {
                name.append(" ");
            }
            name.append(lastName);
        }
        return name.length() > 0 ? name.toString() : username;
    }
}
