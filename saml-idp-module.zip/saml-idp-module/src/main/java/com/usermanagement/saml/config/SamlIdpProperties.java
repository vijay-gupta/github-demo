package com.usermanagement.saml.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Configuration properties for SAML IdP.
 */
@Data
@Component
@ConfigurationProperties(prefix = "saml.idp")
public class SamlIdpProperties {

    /**
     * IdP Entity ID
     */
    private String entityId;

    /**
     * Base URL of the IdP
     */
    private String baseUrl;

    /**
     * SSO endpoint URL
     */
    private String ssoUrl;

    /**
     * SLO endpoint URL
     */
    private String sloUrl;

    /**
     * Metadata endpoint URL
     */
    private String metadataUrl;

    /**
     * Keystore configuration
     */
    private KeystoreConfig keystore = new KeystoreConfig();

    /**
     * Certificate configuration
     */
    private CertificateConfig certificate = new CertificateConfig();

    /**
     * Assertion validity in seconds
     */
    private int assertionValiditySeconds = 300;

    /**
     * Session validity in seconds
     */
    private int sessionValiditySeconds = 28800;

    /**
     * Organization details
     */
    private OrganizationConfig organization = new OrganizationConfig();

    /**
     * Contact person details
     */
    private ContactConfig contact = new ContactConfig();

    @Data
    public static class KeystoreConfig {
        private String path;
        private String password;
        private String alias;
        private String keyPassword;
    }

    @Data
    public static class CertificateConfig {
        private String path;
    }

    @Data
    public static class OrganizationConfig {
        private String name;
        private String displayName;
        private String url;
    }

    @Data
    public static class ContactConfig {
        private String type;
        private String company;
        private String givenName;
        private String email;
    }
}
