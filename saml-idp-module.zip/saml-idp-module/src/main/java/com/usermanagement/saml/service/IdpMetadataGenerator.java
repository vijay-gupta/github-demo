package com.usermanagement.saml.service;

import com.usermanagement.saml.config.CredentialManager;
import com.usermanagement.saml.config.SamlIdpProperties;
import com.usermanagement.saml.util.SamlUtils;
import lombok.RequiredArgsConstructor;
import org.opensaml.saml.common.xml.SAMLConstants;
import org.opensaml.saml.saml2.metadata.*;
import org.opensaml.security.credential.UsageType;
import org.opensaml.xmlsec.signature.KeyInfo;
import org.opensaml.xmlsec.signature.X509Certificate;
import org.opensaml.xmlsec.signature.X509Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import java.time.Instant;
import java.time.temporal.ChronoUnit;

/**
 * Service for generating IdP Metadata.
 */
@Service
@RequiredArgsConstructor
public class IdpMetadataGenerator {

    private static final Logger logger = LoggerFactory.getLogger(IdpMetadataGenerator.class);

    private final SamlIdpProperties samlIdpProperties;
    private final CredentialManager credentialManager;

    private String cachedMetadata;

    @PostConstruct
    public void init() {
        try {
            this.cachedMetadata = generateMetadataXml();
            logger.info("IdP metadata generated successfully");
        } catch (Exception e) {
            logger.error("Failed to generate IdP metadata on startup", e);
        }
    }

    /**
     * Get the IdP metadata as XML string.
     */
    public String getMetadataXml() {
        if (cachedMetadata == null) {
            cachedMetadata = generateMetadataXml();
        }
        return cachedMetadata;
    }

    /**
     * Regenerate metadata (call after configuration changes).
     */
    public void refreshMetadata() {
        this.cachedMetadata = generateMetadataXml();
    }

    /**
     * Generate IdP Metadata XML.
     */
    private String generateMetadataXml() {
        try {
            EntityDescriptor entityDescriptor = buildEntityDescriptor();
            return SamlUtils.marshalToString(entityDescriptor);
        } catch (Exception e) {
            throw new RuntimeException("Failed to generate IdP metadata", e);
        }
    }

    /**
     * Build the EntityDescriptor.
     */
    private EntityDescriptor buildEntityDescriptor() throws Exception {
        EntityDescriptor entityDescriptor = SamlUtils.buildSamlObject(EntityDescriptor.class);
        entityDescriptor.setEntityID(samlIdpProperties.getEntityId());
        entityDescriptor.setID(SamlUtils.generateId());

        // Set validity
        Instant now = Instant.now();
        entityDescriptor.setValidUntil(now.plus(365, ChronoUnit.DAYS));

        // Add IDPSSODescriptor
        entityDescriptor.getRoleDescriptors().add(buildIdpSsoDescriptor());

        // Add Organization (optional)
        entityDescriptor.setOrganization(buildOrganization());

        // Add ContactPerson (optional)
        entityDescriptor.getContactPersons().add(buildContactPerson());

        return entityDescriptor;
    }

    /**
     * Build IDPSSODescriptor.
     */
    private IDPSSODescriptor buildIdpSsoDescriptor() throws Exception {
        IDPSSODescriptor idpDescriptor = SamlUtils.buildSamlObject(IDPSSODescriptor.class);

        // Set protocols supported
        idpDescriptor.addSupportedProtocol(SAMLConstants.SAML20P_NS);

        // Want AuthnRequests Signed (optional, set to true for security)
        idpDescriptor.setWantAuthnRequestsSigned(false);

        // Add KeyDescriptor for signing
        idpDescriptor.getKeyDescriptors().add(buildKeyDescriptor(UsageType.SIGNING));

        // Add NameIDFormats supported
        idpDescriptor.getNameIDFormats().add(buildNameIdFormat("urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress"));
        idpDescriptor.getNameIDFormats().add(buildNameIdFormat("urn:oasis:names:tc:SAML:2.0:nameid-format:persistent"));
        idpDescriptor.getNameIDFormats().add(buildNameIdFormat("urn:oasis:names:tc:SAML:2.0:nameid-format:transient"));
        idpDescriptor.getNameIDFormats().add(buildNameIdFormat("urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified"));

        // Add SingleSignOnService endpoints
        idpDescriptor.getSingleSignOnServices().add(
                buildSingleSignOnService(SAMLConstants.SAML2_POST_BINDING_URI, samlIdpProperties.getSsoUrl())
        );
        idpDescriptor.getSingleSignOnServices().add(
                buildSingleSignOnService(SAMLConstants.SAML2_REDIRECT_BINDING_URI, samlIdpProperties.getSsoUrl())
        );

        // Add SingleLogoutService endpoints (optional)
        if (samlIdpProperties.getSloUrl() != null) {
            idpDescriptor.getSingleLogoutServices().add(
                    buildSingleLogoutService(SAMLConstants.SAML2_POST_BINDING_URI, samlIdpProperties.getSloUrl())
            );
            idpDescriptor.getSingleLogoutServices().add(
                    buildSingleLogoutService(SAMLConstants.SAML2_REDIRECT_BINDING_URI, samlIdpProperties.getSloUrl())
            );
        }

        return idpDescriptor;
    }

    /**
     * Build KeyDescriptor.
     */
    private KeyDescriptor buildKeyDescriptor(UsageType usageType) throws Exception {
        KeyDescriptor keyDescriptor = SamlUtils.buildSamlObject(KeyDescriptor.class);
        keyDescriptor.setUse(usageType);

        KeyInfo keyInfo = SamlUtils.buildSamlObject(KeyInfo.class);
        X509Data x509Data = SamlUtils.buildSamlObject(X509Data.class);
        X509Certificate x509Certificate = SamlUtils.buildSamlObject(X509Certificate.class);

        // Get certificate as Base64
        String certBase64 = credentialManager.getSigningCertificateBase64();
        x509Certificate.setValue(certBase64);

        x509Data.getX509Certificates().add(x509Certificate);
        keyInfo.getX509Datas().add(x509Data);
        keyDescriptor.setKeyInfo(keyInfo);

        return keyDescriptor;
    }

    /**
     * Build NameIDFormat.
     */
    private NameIDFormat buildNameIdFormat(String format) {
        NameIDFormat nameIdFormat = SamlUtils.buildSamlObject(NameIDFormat.class);
        nameIdFormat.setURI(format);
        return nameIdFormat;
    }

    /**
     * Build SingleSignOnService.
     */
    private SingleSignOnService buildSingleSignOnService(String binding, String location) {
        SingleSignOnService sso = SamlUtils.buildSamlObject(SingleSignOnService.class);
        sso.setBinding(binding);
        sso.setLocation(location);
        return sso;
    }

    /**
     * Build SingleLogoutService.
     */
    private SingleLogoutService buildSingleLogoutService(String binding, String location) {
        SingleLogoutService slo = SamlUtils.buildSamlObject(SingleLogoutService.class);
        slo.setBinding(binding);
        slo.setLocation(location);
        return slo;
    }

    /**
     * Build Organization.
     */
    private Organization buildOrganization() {
        SamlIdpProperties.OrganizationConfig orgConfig = samlIdpProperties.getOrganization();

        Organization org = SamlUtils.buildSamlObject(Organization.class);

        OrganizationName orgName = SamlUtils.buildSamlObject(OrganizationName.class);
        orgName.setValue(orgConfig.getName());
        orgName.setXMLLang("en");
        org.getOrganizationNames().add(orgName);

        OrganizationDisplayName orgDisplayName = SamlUtils.buildSamlObject(OrganizationDisplayName.class);
        orgDisplayName.setValue(orgConfig.getDisplayName());
        orgDisplayName.setXMLLang("en");
        org.getDisplayNames().add(orgDisplayName);

        OrganizationURL orgUrl = SamlUtils.buildSamlObject(OrganizationURL.class);
        orgUrl.setURI(orgConfig.getUrl());
        orgUrl.setXMLLang("en");
        org.getURLs().add(orgUrl);

        return org;
    }

    /**
     * Build ContactPerson.
     */
    private ContactPerson buildContactPerson() {
        SamlIdpProperties.ContactConfig contactConfig = samlIdpProperties.getContact();

        ContactPerson contact = SamlUtils.buildSamlObject(ContactPerson.class);
        contact.setType(ContactPersonTypeEnumeration.TECHNICAL);

        Company company = SamlUtils.buildSamlObject(Company.class);
        company.setValue(contactConfig.getCompany());
        contact.setCompany(company);

        GivenName givenName = SamlUtils.buildSamlObject(GivenName.class);
        givenName.setValue(contactConfig.getGivenName());
        contact.setGivenName(givenName);

        EmailAddress email = SamlUtils.buildSamlObject(EmailAddress.class);
        email.setURI(contactConfig.getEmail());
        contact.getEmailAddresses().add(email);

        return contact;
    }
}
