package com.usermanagement.saml.adapter;

import com.usermanagement.saml.model.AuthenticatedUser;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Set;

/**
 * Sample implementation of UserAuthenticationAdapter.
 * 
 * IMPORTANT: Replace this with your actual authentication integration!
 * 
 * This sample reads user info from session attributes.
 * Modify this to integrate with your existing authentication system
 * (Spring Security, custom SSO, database auth, etc.)
 */
@Component
public class DefaultUserAuthenticationAdapter implements UserAuthenticationAdapter {

    // Session attribute names - adjust to match your existing session structure
    private static final String USER_ID_ATTR = "userId";
    private static final String USER_EMAIL_ATTR = "userEmail";
    private static final String USER_NAME_ATTR = "userName";
    private static final String USER_FIRST_NAME_ATTR = "firstName";
    private static final String USER_LAST_NAME_ATTR = "lastName";
    private static final String USER_ROLES_ATTR = "userRoles";
    private static final String IS_AUTHENTICATED_ATTR = "isAuthenticated";

    @Override
    public AuthenticatedUser getAuthenticatedUser(HttpServletRequest request) {
        return getAuthenticatedUser(request.getSession(false));
    }

    @Override
    public AuthenticatedUser getAuthenticatedUser(HttpSession session) {
        if (session == null) {
            return null;
        }

        // Check if already have AuthenticatedUser object
        Object existingUser = session.getAttribute("authenticatedUser");
        if (existingUser instanceof AuthenticatedUser) {
            return (AuthenticatedUser) existingUser;
        }

        // Build from session attributes
        Boolean isAuthenticated = (Boolean) session.getAttribute(IS_AUTHENTICATED_ATTR);
        if (isAuthenticated == null || !isAuthenticated) {
            return null;
        }

        String userId = (String) session.getAttribute(USER_ID_ATTR);
        String email = (String) session.getAttribute(USER_EMAIL_ATTR);

        if (userId == null && email == null) {
            return null;
        }

        // Build AuthenticatedUser from session
        AuthenticatedUser user = AuthenticatedUser.builder()
                .userId(userId)
                .email(email)
                .username((String) session.getAttribute(USER_NAME_ATTR))
                .firstName((String) session.getAttribute(USER_FIRST_NAME_ATTR))
                .lastName((String) session.getAttribute(USER_LAST_NAME_ATTR))
                .sessionId(session.getId())
                .build();

        // Get roles
        Object rolesObj = session.getAttribute(USER_ROLES_ATTR);
        if (rolesObj instanceof Set) {
            @SuppressWarnings("unchecked")
            Set<String> roles = (Set<String>) rolesObj;
            user.setRoles(roles);
        } else if (rolesObj instanceof String) {
            // If roles stored as comma-separated string
            Set<String> roles = new HashSet<>();
            for (String role : ((String) rolesObj).split(",")) {
                roles.add(role.trim());
            }
            user.setRoles(roles);
        }

        return user;
    }

    @Override
    public boolean isAuthenticated(HttpServletRequest request) {
        return getAuthenticatedUser(request) != null;
    }

    @Override
    public String getLoginUrl(String returnUrl) {
        // Adjust this to your login URL
        String loginUrl = "/login";
        if (returnUrl != null && !returnUrl.isEmpty()) {
            loginUrl += "?returnUrl=" + java.net.URLEncoder.encode(returnUrl, java.nio.charset.StandardCharsets.UTF_8);
        }
        return loginUrl;
    }

    // =========================================================================
    // INTEGRATION EXAMPLES - Uncomment and modify based on your auth system
    // =========================================================================

    /*
    // Example: Integration with Spring Security
    public AuthenticatedUser getAuthenticatedUserFromSpringSecurity() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        
        if (auth == null || !auth.isAuthenticated() || auth instanceof AnonymousAuthenticationToken) {
            return null;
        }

        // If using UserDetails
        if (auth.getPrincipal() instanceof UserDetails) {
            UserDetails userDetails = (UserDetails) auth.getPrincipal();
            
            return AuthenticatedUser.builder()
                    .userId(userDetails.getUsername())
                    .username(userDetails.getUsername())
                    .roles(userDetails.getAuthorities().stream()
                            .map(GrantedAuthority::getAuthority)
                            .collect(Collectors.toSet()))
                    .build();
        }

        // If using custom principal
        if (auth.getPrincipal() instanceof YourCustomPrincipal) {
            YourCustomPrincipal principal = (YourCustomPrincipal) auth.getPrincipal();
            
            return AuthenticatedUser.builder()
                    .userId(principal.getId())
                    .email(principal.getEmail())
                    .username(principal.getUsername())
                    .firstName(principal.getFirstName())
                    .lastName(principal.getLastName())
                    .department(principal.getDepartment())
                    .roles(principal.getRoles())
                    .build();
        }

        return null;
    }
    */

    /*
    // Example: Integration with JWT Token
    public AuthenticatedUser getAuthenticatedUserFromJwt(HttpServletRequest request) {
        String authHeader = request.getHeader("Authorization");
        
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return null;
        }

        String token = authHeader.substring(7);
        
        try {
            // Parse your JWT token
            Claims claims = jwtService.parseToken(token);
            
            return AuthenticatedUser.builder()
                    .userId(claims.getSubject())
                    .email(claims.get("email", String.class))
                    .username(claims.get("username", String.class))
                    .firstName(claims.get("firstName", String.class))
                    .lastName(claims.get("lastName", String.class))
                    .roles(new HashSet<>(claims.get("roles", List.class)))
                    .build();
                    
        } catch (Exception e) {
            return null;
        }
    }
    */

    /*
    // Example: Integration with Database Session
    public AuthenticatedUser getAuthenticatedUserFromDatabase(HttpSession session) {
        String sessionToken = (String) session.getAttribute("sessionToken");
        
        if (sessionToken == null) {
            return null;
        }

        // Look up session in database
        UserSession dbSession = userSessionRepository.findByToken(sessionToken);
        
        if (dbSession == null || dbSession.isExpired()) {
            return null;
        }

        User user = dbSession.getUser();
        
        return AuthenticatedUser.builder()
                .userId(user.getId().toString())
                .email(user.getEmail())
                .username(user.getUsername())
                .firstName(user.getFirstName())
                .lastName(user.getLastName())
                .department(user.getDepartment())
                .title(user.getTitle())
                .employeeId(user.getEmployeeId())
                .roles(user.getRoles().stream()
                        .map(Role::getName)
                        .collect(Collectors.toSet()))
                .groups(user.getGroups().stream()
                        .map(Group::getName)
                        .collect(Collectors.toSet()))
                .sessionId(sessionToken)
                .authMethod(dbSession.getAuthMethod())
                .ssoAuthenticated(dbSession.isSsoAuthenticated())
                .ssoProvider(dbSession.getSsoProvider())
                .build();
    }
    */
}
