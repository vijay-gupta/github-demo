# SAML Integration Quick Reference Card

## 🎯 Golden Rule: JWT Flow Stays Untouched

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   YOUR EXISTING JWT CODE  ──────►  NO CHANGES NEEDED!       │
│                                                             │
│   SAML MODULE  ──────────────►  RUNS INDEPENDENTLY          │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 📁 What to Copy (Just These Files)

```
Copy to: src/main/java/com/usermanagement/saml/

├── config/
│   ├── OpenSamlConfig.java      ✅ Copy
│   ├── SamlIdpProperties.java   ✅ Copy
│   └── CredentialManager.java   ✅ Copy
│
├── controller/
│   ├── SamlSsoController.java          ✅ Copy
│   └── ServiceProviderApiController.java ✅ Copy
│
├── dto/
│   └── ServiceProviderDto.java  ✅ Copy
│
├── entity/
│   └── ServiceProviderEntity.java ✅ Copy
│
├── model/
│   ├── AuthenticatedUser.java   ✅ Copy
│   └── SsoResult.java           ✅ Copy
│
├── repository/
│   └── ServiceProviderRepository.java ✅ Copy
│
├── service/
│   ├── SamlSsoService.java         ✅ Copy
│   ├── SamlAssertionBuilder.java   ✅ Copy
│   ├── SamlResponseBuilder.java    ✅ Copy
│   ├── IdpMetadataGenerator.java   ✅ Copy
│   └── ServiceProviderService.java ✅ Copy
│
├── util/
│   └── SamlUtils.java           ✅ Copy
│
└── templates/saml/
    ├── post-binding.html        ✅ Copy to resources/templates/saml/
    └── error.html               ✅ Copy to resources/templates/saml/
```

**❌ DO NOT copy:** `SecurityConfig.java` (integrate with your existing config)

---

## 🔧 Configuration to Add

```yaml
# Add to your application.yml (doesn't affect existing config)

saml:
  idp:
    entity-id: https://your-domain.com/usermanagement/saml/idp
    base-url: https://your-domain.com/usermanagement
    sso-url: ${saml.idp.base-url}/saml/sso
    slo-url: ${saml.idp.base-url}/saml/slo
    metadata-url: ${saml.idp.base-url}/saml/metadata
    keystore:
      path: classpath:saml/idp-keystore.jks
      password: changeit
      alias: idp-signing-key
      key-password: changeit
```

---

## 🔌 The ONE Class You Must Create

Create `YourAuthenticationBridge.java` to connect your auth to SAML:

```java
@Component
public class YourAuthenticationBridge {
    
    public AuthenticatedUser getAuthenticatedUser(HttpSession session) {
        // Get your user from YOUR auth system
        YourUser user = /* your existing auth logic */;
        
        if (user == null) return null;
        
        // Convert to SAML format
        return AuthenticatedUser.builder()
                .userId(user.getId())
                .email(user.getEmail())
                .username(user.getUsername())
                .firstName(user.getFirstName())
                .lastName(user.getLastName())
                .roles(user.getRoles())
                .build();
    }
}
```

---

## 🔒 Security Config Updates

Add these to YOUR EXISTING security config:

```java
// In your SecurityConfig.java

.authorizeHttpRequests(auth -> auth
    // ... your existing rules ...
    
    // ADD these lines for SAML:
    .requestMatchers("/saml/metadata").permitAll()
    .requestMatchers("/saml/sso/**").permitAll()
    .requestMatchers("/saml/slo/**").permitAll()
    .requestMatchers("/api/saml/**").hasRole("ADMIN")
)
.csrf(csrf -> csrf
    .ignoringRequestMatchers("/saml/**")  // ADD this
)
```

---

## 🚀 Launch Logic (Choose One Approach)

### Approach A: Modify Existing Launcher (Minimal)

```java
@GetMapping("/launch/{appId}")
public String launch(@PathVariable String appId, HttpSession session, Model model) {
    
    if (isSamlApp(appId)) {
        // NEW: SAML flow
        return "redirect:/saml/sso/init?entityId=" + appId;
    } else {
        // EXISTING: JWT flow (unchanged)
        return yourExistingJwtLaunch(appId);
    }
}
```

### Approach B: Separate Endpoint (Zero Changes)

```java
// Add NEW endpoint, don't touch existing /launch
@GetMapping("/saml-launch/{spId}")
public String launchSaml(@PathVariable Long spId, HttpSession session, Model model) {
    AuthenticatedUser user = authBridge.getAuthenticatedUser(session);
    SsoResult result = samlSsoService.initiateIdpSsoById(user, spId, null);
    
    model.addAttribute("acsUrl", result.getAcsUrl());
    model.addAttribute("samlResponse", result.getSamlResponse());
    model.addAttribute("relayState", result.getRelayState());
    
    return "saml/post-binding";
}
```

---

## 📝 Register a SAML Application

```bash
curl -X POST http://localhost:8080/api/saml/service-providers \
  -H "Content-Type: application/json" \
  -d '{
    "entityId": "https://app.example.com/saml",
    "applicationName": "My SAML App",
    "acsUrl": "https://app.example.com/saml/acs",
    "nameIdFormat": "email"
  }'
```

---

## 🧪 Quick Test Commands

```bash
# 1. Check metadata is working
curl http://localhost:8080/saml/metadata

# 2. Check SP registered
curl http://localhost:8080/api/saml/service-providers

# 3. Test JWT still works (your existing endpoint)
curl http://localhost:8080/launch/your-jwt-app-id
```

---

## ⚠️ Common Mistakes to Avoid

| ❌ Don't | ✅ Do |
|----------|-------|
| Copy SecurityConfig.java | Integrate rules into YOUR existing config |
| Modify your JWT service | Keep JWT service completely untouched |
| Change existing /launch endpoint | Add SAML routing or create new endpoint |
| Store SAML apps in your existing app table | Use new saml_service_providers table |

---

## 📊 Flow Comparison

```
JWT APP (UNCHANGED):
User clicks app → Your launcher → JWT Service → Redirect with token → App validates JWT

SAML APP (NEW):
User clicks app → Your launcher → SAML Service → POST form → App validates SAML
                                       ↑
                           Uses YOUR auth session
                           (no new login required)
```

---

## 🆘 If Something Breaks

1. **JWT apps broken?** → You modified something you shouldn't have. Revert.
2. **SAML metadata empty?** → Check OpenSAML init logs
3. **"Not authenticated"?** → Check YourAuthenticationBridge
4. **SP rejects assertion?** → Check entity ID matches, cert is current

---

## 📞 Key Endpoints Reference

| Endpoint | Purpose | Auth Required |
|----------|---------|---------------|
| `GET /saml/metadata` | IdP metadata XML | No |
| `GET /saml/sso/init?spId=X` | Start IdP-initiated SSO | Yes (your auth) |
| `GET /saml/sso?SAMLRequest=X` | Handle SP-initiated SSO | Yes (your auth) |
| `POST /api/saml/service-providers` | Register new SP | Yes (admin) |
| `GET /api/saml/service-providers` | List all SPs | Yes (admin) |

