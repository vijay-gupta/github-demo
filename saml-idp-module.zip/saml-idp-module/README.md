# SAML 2.0 Identity Provider Module

This module adds SAML 2.0 Identity Provider (IdP) functionality to your User Management System. It allows you to create SAML assertions for users when they click on applications that require SAML authentication, while maintaining your existing JWT-based authentication for other applications.

## Features

- **SAML 2.0 IdP** - Full IdP implementation using OpenSAML 4.x
- **IdP-Initiated SSO** - User clicks app from portal → SAML assertion sent to SP
- **SP-Initiated SSO** - SP sends AuthnRequest → User authenticated → SAML assertion returned
- **Service Provider Management** - Register and manage SAML SPs via API
- **Metadata Generation** - Automatic IdP metadata generation
- **Dual Authentication** - Support both SAML and JWT applications in same portal
- **Attribute Mapping** - Configurable attribute mappings per SP
- **Role-Based Access** - Control which users can access which applications

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    User Management Module                        │
│                                                                  │
│  ┌─────────────┐  ┌─────────────┐  ┌────────────────────────┐  │
│  │ Your Auth   │  │ Your JWT    │  │ SAML IdP Module (NEW)  │  │
│  │ (SSO/DB)    │  │ Service     │  │                        │  │
│  └──────┬──────┘  └──────┬──────┘  └───────────┬────────────┘  │
│         │                │                      │                │
│         └────────────────┴──────────────────────┘                │
│                          │                                       │
│                   ┌──────▼──────┐                                │
│                   │ App Launcher│                                │
│                   │ (post-login)│                                │
│                   └──────┬──────┘                                │
│                          │                                       │
│              ┌───────────┴───────────┐                          │
│              ▼                       ▼                          │
│         JWT App                 SAML App                        │
│         (existing)              (new support)                   │
└─────────────────────────────────────────────────────────────────┘
```

## Quick Start

### 1. Add Dependencies

Copy the `pom.xml` dependencies to your project or include this as a module.

### 2. Generate Keystore

```bash
cd scripts
chmod +x generate-keystore.sh
./generate-keystore.sh
```

### 3. Configure Application

Update `application.yml`:

```yaml
saml:
  idp:
    entity-id: https://yourdomain.com/usermanagement/saml/idp
    base-url: https://yourdomain.com/usermanagement
    keystore:
      path: classpath:saml/idp-keystore.jks
      password: your-secure-password
      alias: idp-signing-key
      key-password: your-secure-password
```

### 4. Integrate with Your Authentication

Modify `DefaultUserAuthenticationAdapter.java` to integrate with your existing authentication system.

### 5. Register Service Providers

Use the API to register SAML applications:

```bash
curl -X POST http://localhost:8080/usermanagement/api/saml/service-providers \
  -H "Content-Type: application/json" \
  -d '{
    "entityId": "https://app.example.com/saml/metadata",
    "applicationName": "Example Application",
    "acsUrl": "https://app.example.com/saml/acs",
    "nameIdFormat": "email"
  }'
```

## API Endpoints

### IdP Metadata
```
GET /saml/metadata
```
Returns IdP metadata XML. Share this with Service Providers.

### SSO Endpoints
```
GET  /saml/sso/init?spId={id}     # IdP-initiated SSO
GET  /saml/sso?SAMLRequest=...    # SP-initiated SSO (Redirect)
POST /saml/sso                     # SP-initiated SSO (POST)
GET  /saml/slo                     # Single Logout
```

### Service Provider Management
```
POST   /api/saml/service-providers              # Register SP
POST   /api/saml/service-providers/from-metadata # Register from metadata
GET    /api/saml/service-providers              # List all SPs
GET    /api/saml/service-providers/{id}         # Get SP
PUT    /api/saml/service-providers/{id}         # Update SP
DELETE /api/saml/service-providers/{id}         # Delete SP
POST   /api/saml/service-providers/{id}/activate   # Activate SP
POST   /api/saml/service-providers/{id}/deactivate # Deactivate SP
```

### Application Launcher
```
GET  /applications/api/list                    # List accessible apps
POST /applications/api/launch/{appId}          # Launch app (API)
GET  /applications/launch/{appId}              # Launch app (redirect)
```

## Integration Guide

### 1. Integrating with Your Authentication System

Modify `DefaultUserAuthenticationAdapter.java`:

```java
@Override
public AuthenticatedUser getAuthenticatedUser(HttpSession session) {
    // Option 1: Spring Security
    Authentication auth = SecurityContextHolder.getContext().getAuthentication();
    if (auth != null && auth.isAuthenticated()) {
        YourPrincipal principal = (YourPrincipal) auth.getPrincipal();
        return AuthenticatedUser.builder()
                .userId(principal.getId())
                .email(principal.getEmail())
                .username(principal.getUsername())
                .firstName(principal.getFirstName())
                .lastName(principal.getLastName())
                .roles(principal.getRoles())
                .build();
    }
    
    // Option 2: Session-based
    YourUser user = (YourUser) session.getAttribute("currentUser");
    if (user != null) {
        return convertToAuthenticatedUser(user);
    }
    
    return null;
}
```

### 2. Frontend Integration

When displaying the application list:

```javascript
// Fetch applications
fetch('/usermanagement/applications/api/list')
    .then(response => response.json())
    .then(apps => {
        apps.forEach(app => {
            // Display app with click handler
            const link = document.createElement('a');
            link.href = '#';
            link.onclick = () => launchApp(app.id);
            link.textContent = app.applicationName;
            // Add to your UI
        });
    });

// Launch application
function launchApp(appId) {
    fetch(`/usermanagement/applications/api/launch/${appId}`, { method: 'POST' })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                if (result.authType === 'SAML' && result.usePostBinding) {
                    // Create and submit form for SAML POST binding
                    submitSamlForm(result.targetUrl, result.samlResponse, result.relayState);
                } else {
                    // JWT or SAML Redirect - simple redirect
                    window.location.href = result.targetUrl;
                }
            } else {
                alert('Launch failed: ' + result.errorMessage);
            }
        });
}

function submitSamlForm(acsUrl, samlResponse, relayState) {
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = acsUrl;
    
    const responseInput = document.createElement('input');
    responseInput.type = 'hidden';
    responseInput.name = 'SAMLResponse';
    responseInput.value = samlResponse;
    form.appendChild(responseInput);
    
    if (relayState) {
        const relayInput = document.createElement('input');
        relayInput.type = 'hidden';
        relayInput.name = 'RelayState';
        relayInput.value = relayState;
        form.appendChild(relayInput);
    }
    
    document.body.appendChild(form);
    form.submit();
}
```

### 3. Registering a SAML Application

#### Option A: Manual Registration

```bash
curl -X POST http://localhost:8080/usermanagement/api/saml/service-providers \
  -H "Content-Type: application/json" \
  -d '{
    "entityId": "https://salesforce.example.com",
    "applicationName": "Salesforce",
    "description": "CRM Application",
    "acsUrl": "https://salesforce.example.com/saml/acs",
    "nameIdFormat": "email",
    "signAssertions": true,
    "attributeMappings": "{\"email\": \"User.Email\", \"firstName\": \"User.FirstName\"}",
    "iconUrl": "/images/salesforce.png",
    "category": "CRM",
    "allowedRoles": ["ROLE_SALES", "ROLE_ADMIN"]
  }'
```

#### Option B: From SP Metadata

```bash
curl -X POST http://localhost:8080/usermanagement/api/saml/service-providers/from-metadata \
  -F "metadata=@sp-metadata.xml" \
  -F "applicationName=Salesforce" \
  -F "description=CRM Application"
```

## Attribute Mapping

Configure how user attributes are mapped to SAML attributes:

```json
{
  "email": "User.Email",
  "firstName": "User.FirstName",
  "lastName": "User.LastName",
  "displayName": "User.Name",
  "roles": "User.Roles",
  "department": "User.Department"
}
```

Default mappings if not specified:
- `email` → `mail`
- `firstName` → `givenName`
- `lastName` → `sn`
- `displayName` → `displayName`
- `username` → `uid`
- `roles` → `role`
- `groups` → `memberOf`

## Name ID Formats

Supported formats:
- `email` / `emailAddress` → User's email
- `persistent` → User's permanent ID
- `transient` → Session-based ID
- `unspecified` → Username

## Security Considerations

1. **Use strong passwords** for keystore in production
2. **Enable HTTPS** for all endpoints
3. **Validate SP certificates** when encryption is enabled
4. **Implement proper session management**
5. **Use role-based access control** for sensitive applications
6. **Rotate signing keys** periodically
7. **Monitor SSO logs** for suspicious activity

## Troubleshooting

### Common Issues

1. **"Service Provider not found"**
   - Ensure SP is registered with correct Entity ID
   - Check if SP is active

2. **"Signature validation failed" at SP**
   - Ensure SP has your IdP certificate
   - Check if certificate hasn't expired
   - Verify signature algorithm compatibility

3. **"User not authenticated"**
   - Check session configuration
   - Verify authentication adapter integration

4. **"Invalid ACS URL"**
   - Ensure ACS URL in request matches registered SP

### Debug Logging

Enable debug logging:

```yaml
logging:
  level:
    com.usermanagement.saml: DEBUG
    org.opensaml: DEBUG
```

## File Structure

```
saml-idp-module/
├── pom.xml
├── scripts/
│   └── generate-keystore.sh
├── src/main/java/com/usermanagement/saml/
│   ├── SamlIdpApplication.java
│   ├── adapter/
│   │   ├── UserAuthenticationAdapter.java
│   │   └── DefaultUserAuthenticationAdapter.java
│   ├── config/
│   │   ├── CredentialManager.java
│   │   ├── OpenSamlConfig.java
│   │   ├── SamlIdpProperties.java
│   │   └── SecurityConfig.java
│   ├── controller/
│   │   ├── ApplicationLauncherController.java
│   │   ├── SamlSsoController.java
│   │   └── ServiceProviderApiController.java
│   ├── dto/
│   │   └── ServiceProviderDto.java
│   ├── entity/
│   │   └── ServiceProviderEntity.java
│   ├── model/
│   │   ├── AuthenticatedUser.java
│   │   ├── LaunchResult.java
│   │   └── SsoResult.java
│   ├── repository/
│   │   └── ServiceProviderRepository.java
│   ├── service/
│   │   ├── ApplicationLauncherService.java
│   │   ├── IdpMetadataGenerator.java
│   │   ├── SamlAssertionBuilder.java
│   │   ├── SamlResponseBuilder.java
│   │   ├── SamlSsoService.java
│   │   └── ServiceProviderService.java
│   └── util/
│       └── SamlUtils.java
├── src/main/resources/
│   ├── application.yml
│   ├── saml/
│   │   ├── idp-keystore.jks (generated)
│   │   └── idp-certificate.crt (generated)
│   └── templates/saml/
│       ├── post-binding.html
│       └── error.html
└── README.md
```

## License

This module is provided as-is for integration with your User Management System.
