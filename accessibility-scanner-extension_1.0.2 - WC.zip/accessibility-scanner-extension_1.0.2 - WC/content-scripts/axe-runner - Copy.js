(function () {
  if (window.__AXE_RUNNER_LOADED__) return;
  window.__AXE_RUNNER_LOADED__ = true;

  if (!window.axe) {
    console.error("[AXE_RUNNER] axe-core not found on page");
    return;
  }

  console.log("[AXE_RUNNER] axe-core detected");

  window.addEventListener("AXE_RUN_SCAN", function () {

    const config = window.__AXE_RUN_CONFIG__ || {};
    const customOnly = config.customOnly === true;

    let options = {};

    if (customOnly) {
      // 🔴 Run ONLY custom rules
      const customRuleIds = axe.getRules()
        .map(r => r.ruleId)
        .filter(id => id.startsWith("custom"));

      console.log("[AXE_RUNNER] Running custom rules only:", customRuleIds);

      options.runOnly = {
        type: "rule",
        values: customRuleIds
      };
    }
    else {
      console.log(
      "[AXE_RUNNER] Running built-in + custom rules"
      );
    }

    console.log("[AXE_SCAN_STARTED]", window.location.href);

    axe.run(document, options).then(results => {
      window.dispatchEvent(
        new CustomEvent("AXE_RESULTS", { detail: results })
      );
      console.log("[AXE_SCAN_COMPLETED]", results);
    });

  });

  /*async function runScan() {
    console.log("[AXE_SCAN_STARTED]", window.location.href);

    const results = await window.axe.run(document);

    console.log("[AXE_SCAN_COMPLETED]", {
      violations: results.violations.length
    });

    // Send results back to injector
    window.dispatchEvent(
      new CustomEvent("AXE_RESULTS", { detail: results })
    );
  }*/

  // 🔴 THIS LISTENER IS REQUIRED
  //window.addEventListener("AXE_RUN_SCAN", runScan);
})();
