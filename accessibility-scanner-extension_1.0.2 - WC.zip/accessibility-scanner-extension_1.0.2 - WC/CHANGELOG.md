# Changelog

All notable changes to this project will be documented in this file.  
This format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)  
and adheres to [Semantic Versioning](https://semver.org/).


---

## [1.0.2] - 16-02-2026
### Changed
- SC 1.4.11 (Non-text Contrast): Native form controls with non-deterministic boundaries are now marked INCOMPLETE (moved from Pass) for manual review.
- SC 1.4.12 (Text Spacing): Only flags clipping that appears after applying spacing adjustments; baseline clipping no longer triggers failure.
- SC 1.4.13 (Hover/Focus Content): Improved tooltip/hover detection and filtering to reduce noise in Passes and use Incomplete for ambiguous cases.
- SC 3.2.4 (Consistent Identification): Hidden elements excluded from grouping; case-only href conflicts marked INCOMPLETE; state-dependent content flagged for manual review.

### Added
- Expanded Debug Details in reports for custom rule diagnostics (rule-specific fields to aid manual verification).
---

## [1.0.1] - 20-01-2026
### Added
- Summary Report generation after Stop Scan button is clicked
---

## [1.0.0] - 19-01-2026
### Added
- Automatic accessibility scan on every navigation
- Manual scan option
- Page Level Reports
