package tests;

import llm.HealingDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class HealingDemoTest {

    @Test
    public void testLoginButtonHealing() {

        WebDriver driver = new ChromeDriver();
        HealingDriver healingDriver = new HealingDriver(driver);

        driver.get("file:///C:/Users/Admin/Desktop/demo.html");

        healingDriver.findElement(
                By.id("loginBtn"),
                "Login button"
        ).click();

        driver.quit();
    }
}