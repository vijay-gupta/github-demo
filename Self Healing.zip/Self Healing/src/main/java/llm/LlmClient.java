package llm;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class LlmClient {

    // 🔴 HARD CODED FOR DEMO ONLY
    private static final String API_KEY = "AIzaSyBXtxo6FKkQ3boDrwXaLdZ6-7u-4ARs40k";

    public static String getHealedXpath(String dom, String failedLocator, String intent) {

        System.out.println("🤖 Calling Gemini LLM for healing...");

        try {
            String prompt = buildPrompt(dom, failedLocator, intent);
            String body = buildRequestBody(prompt);

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(
                            "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key="
                                    + API_KEY))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(body))
                    .build();

            HttpClient client = HttpClient.newHttpClient();
            HttpResponse<String> response =
                    client.send(request, HttpResponse.BodyHandlers.ofString());

            // 🔍 Raw response log
            System.out.println("🔍 Raw LLM Response: " + response.body());

            if (response.statusCode() != 200) {
                System.out.println("⚠️ Gemini API failed: " + response.body());
                String fallback = fallback(intent);
                System.out.println("🚀 Final Locator Used (Fallback): " + fallback);
                return fallback;
            }

            String xpath = extractXpath(response.body());

            System.out.println("🚀 Final Locator Used: " + xpath);
            System.out.println("📊 Confidence: ~0.85 (LLM)");

            return xpath;

        } catch (Exception e) {
            System.out.println("⚠️ LLM Exception: " + e.getMessage());

            String fallback = fallback(intent);
            System.out.println("🚀 Final Locator Used (Fallback): " + fallback);

            return fallback;
        }
    }

    // -------------------- PROMPT --------------------

    private static String buildPrompt(String dom, String failedLocator, String intent) {

        return "You are a Selenium locator repair tool.\n\n" +
                "Failed locator: " + failedLocator + "\n" +
                "Intent: " + intent + "\n\n" +
                "HTML:\n" + trim(dom) + "\n\n" +
                "Return ONLY XPath for the correct element. No explanation. No extra text.";
    }

    // -------------------- REQUEST BODY --------------------

    private static String buildRequestBody(String prompt) {

        return "{\n" +
                "  \"contents\": [\n" +
                "    {\n" +
                "      \"parts\": [{\"text\": \"" + escapeJson(prompt) + "\"}]\n" +
                "    }\n" +
                "  ]\n" +
                "}";
    }

    // -------------------- RESPONSE PARSER --------------------

    private static String extractXpath(String response) {

        JSONObject json = new JSONObject(response);

        JSONArray candidates = json.getJSONArray("candidates");
        JSONObject first = candidates.getJSONObject(0);

        JSONObject content = first.getJSONObject("content");
        JSONArray parts = content.getJSONArray("parts");

        String text = parts.getJSONObject(0).getString("text").trim();

        // 🧠 Log LLM interpreted output
        System.out.println("🧠 LLM Raw Output Text: " + text);

        // Extract XPath
        int start = text.indexOf("//");

        if (start != -1) {
            String xpath = text.substring(start).split("\n")[0].trim();

            System.out.println("🎯 Extracted XPath: " + xpath);

            return xpath;
        }

        System.out.println("⚠️ XPath not found in LLM output. Using fallback.");
        return fallback("generic");
    }

    // -------------------- UTILITIES --------------------

    private static String trim(String dom) {
        return dom.substring(0, Math.min(dom.length(), 5000));
    }

    private static String escapeJson(String text) {
        return text.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "");
    }

    // -------------------- FALLBACK --------------------

    private static String fallback(String intent) {

        System.out.println("🤖 Using fallback locator (resilience mode)");

        if (intent != null && intent.toLowerCase().contains("login")) {
            return "//button[contains(text(),'Login') or contains(text(),'Sign')]";
        }

        return "//button";
    }
}