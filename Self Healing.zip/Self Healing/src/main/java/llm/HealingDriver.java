package llm;

import org.openqa.selenium.*;

public class HealingDriver {

    private WebDriver driver;

    // 🔑 Toggle flag
    private static final boolean HEALING_ENABLED = true; // change to true later

    public HealingDriver(WebDriver driver) {
        this.driver = driver;
    }

    public WebElement findElement(By by, String intent) {

        try {
            return driver.findElement(by);

        } catch (Exception e) {

            System.out.println("❌ Locator failed: " + by);

            if (!HEALING_ENABLED) {
                System.out.println("🚫 Healing disabled → Test will fail");
                throw e; // FAIL TEST
            }

            System.out.println("🤖 Healing enabled → Trying LLM...");

            String healedXpath =
                    LlmClient.getHealedXpath(driver.getPageSource(), by.toString(), intent);

            return driver.findElement(By.xpath(healedXpath));
        }
    }
}
