(function () {

  const checks = [
    {
      id: 'sc231-flashing-check',
      evaluate: function (node) {
        const style = window.getComputedStyle(node);

        // Ignore non-visible elements
        if (style.display === 'none' || style.visibility === 'hidden') {
          return true;
        }

        const animationDuration = parseFloat(style.animationDuration) || 0;
        const animationIteration = style.animationIterationCount;

        // Flashing heuristic:
        // animation-duration <= 0.33s AND repeating
        const fastAnimation =
          animationDuration > 0 &&
          animationDuration <= 0.33 &&
          (animationIteration === 'infinite' || parseInt(animationIteration) > 1);

        // Reduced motion respected → PASS
        if (
          window.matchMedia &&
          window.matchMedia('(prefers-reduced-motion: reduce)').matches
        ) {
          return true;
        }

        return !fastAnimation;
      }
    }
  ];

  const rules = [
    {
      id: 'sc231-three-flashes-rule',
      impact: 'serious',
      selector: '*',
      enabled: true,
      tags: ['wcag2.1', 'wcag231', 'seizure'],
      description:
        'Detects rapidly flashing content that may exceed the three flashes per second threshold.',
      help:
        'Avoid content that flashes more than three times per second, or provide a reduced-motion alternative.',
      helpUrl:
        'https://www.w3.org/WAI/WCAG21/Understanding/three-flashes-or-below-threshold.html',
      all: ['sc231-flashing-check']
    }
  ];

  axe.configure({
    checks,
    rules
  });

})();
