(function () {

  const PRINTABLE_CHAR_REGEX = /^[a-zA-Z0-9`~!@#$%^&*()\-_=+\[\]{};:'",.<>/?\\|]$/;

  const checks = [
    {
      id: 'sc214-character-shortcut-check',
      evaluate: function () {
        const handlers = [];

        function collect(target, type) {
          const orig = target.addEventListener;
          if (!orig) return;

          target.addEventListener = function (event, listener, options) {
            if (event === 'keydown' || event === 'keypress') {
              handlers.push({ target, listener });
            }
            return orig.call(this, event, listener, options);
          };
        }

        collect(document, 'document');
        collect(window, 'window');
        collect(document.body, 'body');

        return handlers.some(h => {
          try {
            const fnSrc = h.listener.toString();
            return (
              fnSrc.includes('event.key') &&
              PRINTABLE_CHAR_REGEX.test(
                fnSrc.match(/event\.key\s*===?\s*['"](.)['"]/)?.[1] || ''
              ) &&
              !fnSrc.includes('ctrlKey') &&
              !fnSrc.includes('altKey') &&
              !fnSrc.includes('metaKey')
            );
          } catch (e) {
            return false;
          }
        });
      }
    }
  ];

  const rules = [
    {
      id: 'sc214-character-key-shortcut-rule',
      impact: 'serious',
      selector: 'html',
      enabled: true,
      tags: ['wcag2.1', 'wcag214', 'keyboard'],
      description: 'Detect global single-character keyboard shortcuts without modifiers.',
      help: 'Single character keyboard shortcuts must be turn-offable, remappable, or active only on focus.',
      helpUrl: 'https://www.w3.org/WAI/WCAG21/Understanding/character-key-shortcuts.html',
      all: ['sc214-character-shortcut-check']
    }
  ];

  axe.configure({
    checks,
    rules
  });

})();
