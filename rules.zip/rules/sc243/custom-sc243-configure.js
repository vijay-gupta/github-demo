(function () {

  const checks = [
    {
      id: 'sc243-focus-order-check',
      evaluate: function (node) {
        if (node.disabled) return true;

        const tabindex = node.getAttribute('tabindex');
        if (tabindex === null) return true;

        const tabIndexValue = parseInt(tabindex, 10);

        // tabindex > 0 is risky and often violates focus order
        if (tabIndexValue > 0) {
          return false;
        }

        return true;
      }
    }
  ];

  const rules = [
    {
      id: 'sc243-focus-order-rule',
      impact: 'moderate',
      selector: '[tabindex]',
      enabled: true,
      tags: ['wcag2.1', 'wcag243', 'focus'],
      description:
        'Detects potentially illogical keyboard focus order caused by positive tabindex.',
      help:
        'Ensure focus order follows a logical sequence that matches reading order.',
      helpUrl:
        'https://www.w3.org/WAI/WCAG21/Understanding/focus-order.html',
      all: ['sc243-focus-order-check']
    }
  ];

  axe.configure({
    checks,
    rules
  });

})();
