const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

const expectedFailures = [
  '#btn3',
  '#btn4',
  '#btn5'
];

(async () => {

  const browser = await puppeteer.launch({ headless: true });
  const page = await browser.newPage();

  const htmlPath = path.resolve(__dirname, 'sc243-test.html');
  await page.goto('file://' + htmlPath, { waitUntil: 'load' });

  await page.addScriptTag({
    path: require.resolve('axe-core/axe.min.js')
  });

  const customRuleJs = fs.readFileSync(
    path.resolve(__dirname, 'custom-sc243-configure.js'),
    'utf8'
  );

  const configResult = await page.evaluate(js => {
    try {
      eval(js);
      return { ok: true };
    } catch (e) {
      return { ok: false, err: e.stack || String(e) };
    }
  }, customRuleJs);

  if (!configResult.ok) {
    throw new Error(configResult.err);
  }

  console.log('✔ axe.configure executed successfully');

  const registeredRules = await page.evaluate(() =>
    axe.getRules().map(r => r.ruleId)
  );

  if (!registeredRules.includes('sc243-focus-order-rule')) {
    throw new Error('SC 2.4.3 rule not registered');
  }

  console.log('✔ SC 2.4.3 rule registered');

  const results = await page.evaluate(() =>
    axe.run(document, {
      runOnly: {
        type: 'rule',
        values: ['sc243-focus-order-rule']
      }
    })
  );

  const actualFailures = new Set();

  results.violations.forEach(v => {
    v.nodes.forEach(n => {
      n.target.forEach(t => actualFailures.add(t));
    });
  });

  const expectedSet = new Set(expectedFailures);

  const missing = [...expectedSet].filter(x => !actualFailures.has(x));
  const unexpected = [...actualFailures].filter(x => !expectedSet.has(x));

  if (missing.length === 0 && unexpected.length === 0) {
    console.log(
      '\nSUCCESS: All expected violations matched actual violations for SC 2.4.3 tests\n'
    );
  } else {
    console.error('\nVALIDATION FAILED');
    console.error('Missing expected:', missing);
    console.error('Unexpected:', unexpected);
  }

  await browser.close();
})();
