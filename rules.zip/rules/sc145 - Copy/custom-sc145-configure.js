// custom-sc145-configure.js
// axe.configure format for WCAG 2.2 SC 1.4.5 (Images of Text) - heuristic, non-OCR
// Updated: treat images as PASS when alt-like text is present nearby (sibling/parent)

axe.configure({
  checks: [

    {
      id: 'sc145-img-check',
      evaluate: function (node, options) {
        if (!node || node.nodeName.toLowerCase() !== 'img') return true;

        // Default options
        var defaultOptions = {
          detectTextLikeAlt: true,
          allowLogos: true
        };
        options = Object.assign({}, defaultOptions, options || {});

        try {
          var alt = node.getAttribute && node.getAttribute('alt');
          var role = node.getAttribute && node.getAttribute('role');

          // decorative
          if (alt === '') return true;
          if (role && role.toLowerCase() === 'presentation') return true;

          // logo exception
          if (options.allowLogos &&
              node.getAttribute &&
              node.getAttribute('data-is-logo') === 'true') {
            return true;
          }

          // If alt missing -> check for any nearby text (parent/siblings) ; if none -> violation
          if (alt === null) {
            var parent = node.parentElement;
            var foundText = false;
            if (parent) {
              var childNodes = Array.prototype.slice.call(parent.childNodes || []);
              for (var i = 0; i < childNodes.length; i++) {
                var n = childNodes[i];
                if (n === node) continue;
                if (n.nodeType === Node.TEXT_NODE &&
                    n.textContent &&
                    n.textContent.trim().length > 0) {
                  foundText = true; break;
                }
                if (n.nodeType === Node.ELEMENT_NODE &&
                    n !== node &&
                    n.textContent &&
                    n.textContent.trim().length > 0) {
                  foundText = true; break;
                }
              }
            }
            if (!foundText) return false;
          }

          // If alt looks like rendered text and detection enabled -> normally fail,
          // BUT first check if same text exists nearby (sibling/parent), in which case PASS.
          if (options.detectTextLikeAlt &&
              typeof alt === 'string' &&
              alt.trim().length > 0) {

            var trimmedAlt = alt.trim();
            var wc = trimmedAlt.split(/\s+/).length;

            var looksLikeText = wc >= 2 || /^[A-Z0-9\-%\s]{2,}$/.test(trimmedAlt);

            if (looksLikeText) {
              // SEARCH NEARBY TEXT: siblings, parent textContent, nextElementSibling, previousElementSibling
              var normalizedAlt = trimmedAlt.replace(/\s+/g, ' ').toLowerCase();

              // helper: normalize string
              function norm(s) {
                if (!s) return '';
                return s.toString().replace(/\s+/g, ' ').trim().toLowerCase();
              }

              // 1) check immediate siblings (element siblings and text node siblings)
              var parentEl = node.parentElement;
              var foundMatch = false;
              if (parentEl) {
                // search sibling nodes of node
                var sibs = Array.prototype.slice.call(parentEl.childNodes || []);
                for (var si = 0; si < sibs.length; si++) {
                  var sn = sibs[si];
                  if (sn === node) continue;
                  if (sn.nodeType === Node.TEXT_NODE) {
                    var txt = norm(sn.textContent);
                    if (txt && (txt === normalizedAlt || txt.indexOf(normalizedAlt) !== -1)) { foundMatch = true; break; }
                  }
                  if (sn.nodeType === Node.ELEMENT_NODE) {
                    var etxt = norm(sn.textContent);
                    if (etxt && (etxt === normalizedAlt || etxt.indexOf(normalizedAlt) !== -1)) { foundMatch = true; break; }
                  }
                }
              }

              // 2) check previous/next element sibling specifically
              function checkElSibling(el) {
                if (!el) return false;
                var pe = el.previousElementSibling;
                var ne = el.nextElementSibling;
                if (pe) {
                  var t = norm(pe.textContent);
                  if (t && (t === normalizedAlt || t.indexOf(normalizedAlt) !== -1)) return true;
                }
                if (ne) {
                  var t2 = norm(ne.textContent);
                  if (t2 && (t2 === normalizedAlt || t2.indexOf(normalizedAlt) !== -1)) return true;
                }
                return false;
              }
              if (!foundMatch) {
                if (checkElSibling(node)) foundMatch = true;
              }

              // 3) check parent element text (excluding the image's own alt)
              if (!foundMatch && parentEl) {
                var ptxt = norm(parentEl.textContent);
                if (ptxt && (ptxt === normalizedAlt || ptxt.indexOf(normalizedAlt) !== -1)) foundMatch = true;
              }

              // If we found matching nearby real text, treat as PASS
              if (foundMatch) return true;

              // Otherwise, treat as VIOLATION (image-of-text)
              return false;
            } // end looksLikeText
          } // end detectTextLikeAlt block

        } catch (e) {
          // in case of unexpected errors, pass to avoid breaking axe runs
          return true;
        }

        return true;
      },
      metadata: {
        impact: 'serious',
        messages: {
          pass: 'Image passed the images-of-text heuristic check.',
          fail: 'Image appears to be an image of text (heuristic).'
        }
      }
    },

    {
      id: 'sc145-bg-check',
      evaluate: function (node, options) {
        if (!node || node.nodeType !== 1) return true;

        var defaultOptions = {
          allowLogos: true
        };
        options = Object.assign({}, defaultOptions, options || {});

        try {
          var style = window.getComputedStyle(node);
          if (!style || !style.backgroundImage || style.backgroundImage === 'none') return true;

          // logo exception
          if (options.allowLogos &&
              node.getAttribute &&
              node.getAttribute('data-is-logo') === 'true') {
            return true;
          }

          // if the element contains real DOM text -> pass
          var txt = node.textContent || '';
          if (txt.trim().length > 0) return true;

          // no real text and background image present -> violation
          return false;

        } catch (e) {
          return true;
        }
      },
      metadata: {
        impact: 'moderate',
        messages: {
          pass: 'Background image is not serving text content or has real DOM text.',
          fail: 'Background image appears to be used in place of real text.'
        }
      }
    },

    {
      id: 'sc145-svg-check',
      evaluate: function (node, options) {
        if (!node || node.nodeName.toLowerCase() !== 'svg') return true;

        try {
          var textNode = node.querySelector && node.querySelector('text');
          if (!textNode) return true;

          var ariaLabel = node.getAttribute && node.getAttribute('aria-label');
          if (ariaLabel && ariaLabel.trim().length > 0) return true;

          var ariaLblBy = node.getAttribute && node.getAttribute('aria-labelledby');
          if (ariaLblBy) {
            var ref = document.getElementById(ariaLblBy);
            if (ref && ref.textContent && ref.textContent.trim().length > 0) return true;
          }

          var title = node.querySelector && node.querySelector('title');
          if (title && title.textContent && title.textContent.trim().length > 0) return true;

          return false;

        } catch (e) {
          return true;
        }
      },
      metadata: {
        impact: 'serious',
        messages: {
          pass: 'SVG with text has an accessible name.',
          fail: 'SVG contains text but lacks an accessible name.'
        }
      }
    }

  ],

  rules: [

    {
      id: 'sc145-img-rule',
      selector: 'img',
      enabled: true,
      tags: ['wcag2.2', 'wcag145', 'image-of-text'],
      all: ['sc145-img-check'],
      checks: [
        {
          id: 'sc145-img-check',
          options: {
            detectTextLikeAlt: true,
            allowLogos: true
          }
        }
      ],
      metadata: {
        description: 'Images of text should not be used to convey essential textual information (heuristic).',
        help: 'If text is essential, provide real text in the DOM or use proper accessible alternatives (logo exception allowed).',
        helpUrl: 'https://www.w3.org/WAI/WCAG22/Understanding/images-of-text.html',
        messages: {
          pass: 'Image is acceptable per SC 1.4.5 heuristics.',
          fail: 'Image looks like an image of text and lacks an acceptable exception.'
        }
      }
    },

    {
      id: 'sc145-bg-rule',
      selector: '*',
      enabled: true,
      tags: ['wcag2.2', 'wcag145', 'background-image'],
      any: ['sc145-bg-check'],
      checks: [
        {
          id: 'sc145-bg-check',
          options: {
            allowLogos: true
          }
        }
      ],
      metadata: {
        description: 'Detect background images used to present textual content (heuristic).',
        help: 'Provide real DOM text instead of using background images for text content.',
        helpUrl: 'https://www.w3.org/WAI/WCAG22/Understanding/images-of-text.html',
        messages: {
          pass: 'Background image is not serving text content.',
          fail: 'Background image appears to replace real text.'
        }
      }
    },

    {
      id: 'sc145-svg-rule',
      selector: 'svg',
      enabled: true,
      tags: ['wcag2.2', 'wcag145', 'svg-text'],
      all: ['sc145-svg-check'],
      checks: [
        {
          id: 'sc145-svg-check',
          options: { }
        }
      ],
      metadata: {
        description: 'SVGs containing text must have accessible names.',
        help: 'Provide <title> or aria-label/aria-labelledby for SVGs containing text.',
        helpUrl: 'https://www.w3.org/WAI/WCAG22/Understanding/images-of-text.html',
        messages: {
          pass: 'SVG has an accessible name.',
          fail: 'SVG contains text but lacks an accessible name.'
        }
      }
    }

  ]

});
