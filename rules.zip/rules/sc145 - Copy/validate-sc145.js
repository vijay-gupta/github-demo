// validate-sc145.js
const fs = require('fs');
const path = require('path');
const puppeteer = require('puppeteer');

const PAGE = 'file://' + path.join(__dirname, 'sc145-test.html');
const CUSTOM_FILE = path.join(__dirname, 'custom-sc145-configure.js');

// Expected mapping: ruleId -> array of expected target selectors (CSS)
const EXPECTED = {
  'sc145-img-rule': ['#img-text'],
  'sc145-bg-rule': ['#bg-text-no-real'],
  'sc145-svg-rule': ['#svg-text-no-title']
};

// helper: map violations to ruleId -> Set(targets)
function mapResults(results) {
  const m = {};
  (results.violations || []).forEach(v => {
    const id = v.id;
    m[id] = m[id] || new Set();
    (v.nodes || []).forEach(n => {
      // use first target entry if available
      let t = (n.target && n.target[0]) || n.html || '';
      // normalize common file:// or attribute formatting differences
      // keep as-is; expected selectors are CSS like "#id"
      m[id].add(t);
    });
  });
  return m;
}

(async () => {
  if (!fs.existsSync(CUSTOM_FILE)) {
    console.error('Missing file:', CUSTOM_FILE);
    process.exit(2);
  }

  const browser = await puppeteer.launch({ headless: true, args: ['--no-sandbox','--disable-setuid-sandbox'] });
  const page = await browser.newPage();

  await page.goto(PAGE, { waitUntil: 'load' });

  // inject axe-core from node_modules
  const axePath = require.resolve('axe-core/axe.min.js');
  const axeSource = fs.readFileSync(axePath, 'utf8');
  await page.evaluate(axeSource);

  // inject custom configure file content (it uses axe.configure directly)
  const customSource = fs.readFileSync(CUSTOM_FILE, 'utf8');
  await page.evaluate(customSource);

  // run axe for our custom rules only
  const ruleIds = Object.keys(EXPECTED);
  const results = await page.evaluate(async (ids) => {
    // run only the provided rule ids
    return await window.axe.run(document, { runOnly: { type: 'rule', values: ids } });
  }, ruleIds);

  await browser.close();

  const actualMap = mapResults(results);

  // Compare expected -> actual
  let ok = true;
  const diffs = [];

  for (const ruleId of Object.keys(EXPECTED)) {
    const expectedSet = new Set(EXPECTED[ruleId]);
    const actualSet = actualMap[ruleId] || new Set();

    // check missing expected violations
    expectedSet.forEach(sel => {
      if (!actualSet.has(sel)) {
        ok = false;
        diffs.push({ type: 'MISSING_EXPECTED', ruleId, selector: sel });
      }
    });

    // unexpected violations
    actualSet.forEach(sel => {
      if (!expectedSet.has(sel)) {
        ok = false;
        diffs.push({ type: 'UNEXPECTED_VIOLATION', ruleId, selector: sel });
      }
    });
  }

  if (ok) {
    console.log('SUCCESS: All expected violations matched actual violations for SC 1.4.5 tests.');
    process.exit(0);
  } else {
    console.error('VALIDATION FAILED. Diffs:');
    console.error(JSON.stringify(diffs, null, 2));
    console.error('\nFull axe violations output:');
    console.error(JSON.stringify(results.violations, null, 2));
    process.exit(1);
  }

})();
