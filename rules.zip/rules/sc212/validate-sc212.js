const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');
const expectedFailures = [
  '#trap-tab',
  '#focus-loop'
];


(async () => {
  /* -------------------------------------------------
     1. Launch browser (Chromium auto-managed)
  -------------------------------------------------- */
  const browser = await puppeteer.launch({
    headless: true,
    args: ['--disable-gpu']
  });

  const page = await browser.newPage();

  /* -------------------------------------------------
     2. Load SC 2.1.2 test page
  -------------------------------------------------- */
  const htmlPath = path.resolve(__dirname, 'sc212-test.html');
  await page.goto('file://' + htmlPath, { waitUntil: 'load' });

  /* -------------------------------------------------
     3. Inject axe-core
  -------------------------------------------------- */
  const axePath = require.resolve('axe-core/axe.min.js');
  await page.addScriptTag({ path: axePath });

  /* -------------------------------------------------
     4. Inject custom SC 2.1.2 rule (axe.configure)
  -------------------------------------------------- */
  const customRulePath = path.resolve(__dirname, 'custom-sc212-configure.js');
  const customRuleJs = fs.readFileSync(customRulePath, 'utf8');

  const configureResult = await page.evaluate(js => {
    try {
      eval(js); // must call axe.configure(...)
      return { ok: true };
    } catch (e) {
      return { ok: false, error: e.stack || String(e) };
    }
  }, customRuleJs);

  if (!configureResult.ok) {
    throw new Error('axe.configure failed:\n' + configureResult.error);
  }

  console.log('✔ axe.configure executed successfully');

  /* -------------------------------------------------
     5. Verify SC 2.1.2 rule registration
  -------------------------------------------------- */
  const registeredRuleIds = await page.evaluate(() =>
    axe.getRules().map(r => r.ruleId)
  );

  if (!registeredRuleIds.includes('sc212-no-keyboard-trap-rule')) {
    throw new Error(
      'Custom rule sc212-no-keyboard-trap-rule NOT registered.\n' +
      'Registered rules:\n' + JSON.stringify(registeredRuleIds, null, 2)
    );
  }

  console.log('✔ SC 2.1.2 rule registered');

  /* -------------------------------------------------
     6. Run axe scan (ONLY SC 2.1.2)
  -------------------------------------------------- */
  const results = await page.evaluate(() =>
    axe.run(document, {
      runOnly: {
        type: 'rule',
        values: ['sc212-no-keyboard-trap-rule']
      }
    })
  );

  // ---------------------------------------------
  // VALIDATION: Expected vs Actual (SC 2.1.2)
  // ---------------------------------------------

  const actualFailures = new Set();

  results.violations.forEach(v => {
    if (v.id === 'sc212-no-keyboard-trap-rule') {
      v.nodes.forEach(n => {
        n.target.forEach(sel => actualFailures.add(sel));
      });
    }
  });

  const expectedSet = new Set(expectedFailures);

  const missingExpected = [...expectedSet].filter(
    sel => !actualFailures.has(sel)
  );

  const unexpectedFailures = [...actualFailures].filter(
    sel => !expectedSet.has(sel)
  );

  if (missingExpected.length === 0 && unexpectedFailures.length === 0) {
    console.log(
      '\nSUCCESS: All expected violations matched actual violations for SC 2.1.2 tests\n'
    );
  } else {
    console.error('\nVALIDATION FAILED. Diffs:\n');

    if (missingExpected.length > 0) {
      console.error('MISSING EXPECTED:', missingExpected);
    }

    if (unexpectedFailures.length > 0) {
      console.error('UNEXPECTED VIOLATIONS:', unexpectedFailures);
    }

    /*console.error(
      '\nFull SC 2.1.2 axe output:\n',
      JSON.stringify(results.violations, null, 2)
    );*/
  }


  /* -------------------------------------------------
     7. Output results
  -------------------------------------------------- */
  /*console.log('\n=== SC 2.1.2 Violations ===\n');
  console.log(JSON.stringify(results.violations, null, 2));*/

  await browser.close();
})();
