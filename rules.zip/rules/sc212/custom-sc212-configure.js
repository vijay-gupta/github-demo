(function () {
  /**
   * SC 2.1.2 – No Keyboard Trap
   * Enterprise-balanced heuristic:
   * - Focus can enter
   * - TAB exit allowed → PASS
   * - ESC optional if TAB exit exists
   * - If TAB blocked, then ESC or accessible Close required
   */

  const checks = [
    {
      id: 'sc212-keyboard-trap-check',
      evaluate: function (node) {
        // 1. Only evaluate focusable elements
        if (!node || typeof node.tabIndex !== 'number' || node.tabIndex < 0) {
          return true;
        }

        // 2. Detect keydown interception
        const handler =
          node.onkeydown ||
          node.getAttribute('onkeydown');

        if (!handler) {
          return true; // no interception → not a trap
        }

        const handlerText = handler.toString();

        const blocksTab = /Tab/.test(handlerText);
        if (!blocksTab) {
          return true; // TAB not blocked → exit exists
        }

        // 3. ESC handling (optional escape)
        const handlesEsc = /Escape|Esc/.test(handlerText);

        // 4. Accessible close control inside container
        const closeControl = node.querySelector(
          'button[aria-label*="close" i],' +
          'button[aria-label*="dismiss" i],' +
          'a[aria-label*="close" i]'
        );

        if (handlesEsc || closeControl) {
          return true; // escape exists
        }

        // 5. Known-safe modal pattern
        const isModal =
          node.getAttribute('role') === 'dialog' &&
          node.getAttribute('aria-modal') === 'true';

        if (isModal && closeControl) {
          return true;
        }

        // Otherwise → keyboard trap
        return false;
      },
      metadata: {
        impact: 'serious',
        messages: {
          pass: 'Element does not appear to trap keyboard focus.',
          fail:
            'Potential keyboard trap: focus enters but no reliable keyboard exit ' +
            '(Tab blocked and no ESC or accessible Close).'
        }
      }
    }
  ];

  const rules = [
    {
      id: 'sc212-no-keyboard-trap-rule',
      selector:
        '[tabindex], [role="dialog"], [role="application"], [aria-modal="true"]',
      enabled: true,
      tags: ['wcag2.1', 'wcag212', 'keyboard'],
      all: ['sc212-keyboard-trap-check'],
      metadata: {
        description:
          'Detects potential keyboard traps where focus enters but cannot reliably exit using keyboard.',
        help:
          'Ensure users can move focus away from components using only the keyboard.',
        helpUrl:
          'https://www.w3.org/WAI/WCAG21/Understanding/no-keyboard-trap.html'
      }
    }
  ];

  axe.configure({
    checks: checks,
    rules: rules
  });
})();
