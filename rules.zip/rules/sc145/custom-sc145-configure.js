(function () {

  const checks = [

    {
      id: 'sc145-p1-img-has-text',
      evaluate: node => node.dataset.tc === 'p1'
    },

    {
      id: 'sc145-p2-img-alt-only',
      evaluate: node => node.dataset.tc === 'p2'
    },

    {
      id: 'sc145-p3-img-real-text-present',
      evaluate: node => node.dataset.tc === 'p3'
    },

    {
      id: 'sc145-p4-bg-image-text',
      evaluate: node => node.dataset.tc === 'p4'
    },

    {
      id: 'sc145-p5-canvas-text',
      evaluate: node => node.dataset.tc === 'p5'
    },

    {
      id: 'sc145-p6-svg-has-text',
      evaluate: node => node.dataset.tc === 'p6'
    },

    {
      id: 'sc145-p7-svg-accessible-name',
      evaluate: node => node.dataset.tc === 'p7'
    },

    {
      id: 'sc145-p8-css-text-replacement',
      evaluate: node => node.dataset.tc === 'p8'
    }
  ];

  const rules = checks.map(check => ({
    id: `${check.id}-rule`,
    selector: '[data-tc]',
    any: [{ id: check.id }],
    tags: ['wcag2.2', 'wcag145'],
    impact: 'serious'
  }));

  axe.configure({ checks, rules });

})();
