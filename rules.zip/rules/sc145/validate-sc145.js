const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

/**
 * Expected mapping:
 * parameter -> ruleId
 */
const expectedFailures = {
  p1: 'sc145-p1-img-has-text-rule',
  p2: 'sc145-p2-img-alt-only-rule',
  p3: 'sc145-p3-img-real-text-present-rule',
  p4: 'sc145-p4-bg-image-text-rule',
  p5: 'sc145-p5-canvas-text-rule',
  p6: 'sc145-p6-svg-has-text-rule',
  p7: 'sc145-p7-svg-accessible-name-rule',
  p8: 'sc145-p8-css-text-replacement-rule'
};

(async () => {
  const browser = await puppeteer.launch({ headless: true });
  const page = await browser.newPage();

  /* -------------------------------------------------
     Load test page
  -------------------------------------------------- */
  await page.goto(
    'file://' + path.resolve(__dirname, 'sc145-test.html'),
    { waitUntil: 'load' }
  );

  /* -------------------------------------------------
     Inject axe-core
  -------------------------------------------------- */
  await page.addScriptTag({
    path: require.resolve('axe-core/axe.min.js')
  });

  /* -------------------------------------------------
     Inject custom SC 1.4.5 rules
  -------------------------------------------------- */
  const customJs = fs.readFileSync(
    path.resolve(__dirname, 'custom-sc145-configure.js'),
    'utf8'
  );

  await page.evaluate(js => {
    eval(js); // must call axe.configure()
  }, customJs);

  console.log('✔ axe.configure executed successfully');

  /* -------------------------------------------------
     Run axe (Node passes ruleIds explicitly)
  -------------------------------------------------- */
  const ruleIds = Object.values(expectedFailures);

  const results = await page.evaluate(ruleIds =>
    axe.run(document, {
      runOnly: {
        type: 'rule',
        values: ruleIds
      }
    }),
    ruleIds
  );

  /* -------------------------------------------------
     Build actual result map
  -------------------------------------------------- */
  const actualFailures = {};

  results.violations.forEach(v => {
    v.nodes.forEach(n => {
      const selector = n.target[0];
      const match = selector.match(/data-tc="(p\d)"/);
      if (match) {
        actualFailures[match[1]] = v.id;
      }
    });
  });

  /* -------------------------------------------------
     Validation (1:1 parameter check)
  -------------------------------------------------- */
  let failed = false;

  Object.entries(expectedFailures).forEach(([param, expectedRule]) => {
    const actualRule = actualFailures[param];

    if (actualRule !== expectedRule) {
      failed = true;
      console.error(`❌ FAILED: ${param}`);
      console.error(`   Expected rule: ${expectedRule}`);
      console.error(`   Actual rule:   ${actualRule || 'NONE'}\n`);
    }
  });

  if (!failed) {
    console.log(
      '\n✅ SUCCESS: All expected violations matched actual violations for SC 1.4.5\n'
    );
  } else {
    console.error('❌ VALIDATION FAILED — see details above\n');
  }

  await browser.close();
})();
