(function () {

  const checks = [
    {
      id: 'sc245-multiple-ways-check',
      evaluate: function () {

        const hasNav = document.querySelector('nav') !== null;

        const hasSearch =
          document.querySelector('input[type="search"]') !== null ||
          document.querySelector('[role="search"]') !== null;

        const hasBreadcrumb =
          document.querySelector('[aria-label*="breadcrumb" i]') !== null ||
          document.querySelector('.breadcrumb') !== null;

        const hasSitemap =
          Array.from(document.querySelectorAll('a')).some(a =>
            /sitemap/i.test(a.textContent)
          );

        const ways = [
          hasNav,
          hasSearch,
          hasBreadcrumb,
          hasSitemap
        ].filter(Boolean).length;

        // At least two independent ways required
        return ways >= 2;
      }
    }
  ];

  const rules = [
    {
      id: 'sc245-multiple-ways-rule',
      impact: 'moderate',
      selector: 'body',
      enabled: true,
      tags: ['wcag2.1', 'wcag245', 'navigation'],
      description:
        'Detects pages that provide only one way to locate content.',
      help:
        'Provide more than one way to locate pages, such as navigation, search, or breadcrumbs.',
      helpUrl:
        'https://www.w3.org/WAI/WCAG21/Understanding/multiple-ways.html',
      all: ['sc245-multiple-ways-check']
    }
  ];

  axe.configure({
    checks,
    rules
  });

})();
