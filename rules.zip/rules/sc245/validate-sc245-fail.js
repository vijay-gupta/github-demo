const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

(async () => {
  /* -------------------------------------------------
     1. Launch browser
  -------------------------------------------------- */
  const browser = await puppeteer.launch({
    headless: true,
    args: ['--disable-gpu']
  });

  const page = await browser.newPage();

  /* -------------------------------------------------
     2. Load SC 2.4.5 FAIL test page
     (This page intentionally provides ONLY ONE WAY)
  -------------------------------------------------- */
  const htmlPath = path.resolve(__dirname, 'sc245-fail.html');
  await page.goto('file://' + htmlPath, { waitUntil: 'load' });

  /* -------------------------------------------------
     3. Inject axe-core
  -------------------------------------------------- */
  await page.addScriptTag({
    path: require.resolve('axe-core/axe.min.js')
  });

  /* -------------------------------------------------
     4. Inject custom SC 2.4.5 rule
  -------------------------------------------------- */
  const customRulePath = path.resolve(
    __dirname,
    'custom-sc245-configure.js'
  );
  const customRuleJs = fs.readFileSync(customRulePath, 'utf8');

  const configureResult = await page.evaluate(js => {
    try {
      eval(js); // must call axe.configure(...)
      return { ok: true };
    } catch (e) {
      return { ok: false, err: e.stack || String(e) };
    }
  }, customRuleJs);

  if (!configureResult.ok) {
    throw new Error(
      'axe.configure failed:\n' + configureResult.err
    );
  }

  console.log('✔ axe.configure executed successfully');

  /* -------------------------------------------------
     5. Verify rule registration
  -------------------------------------------------- */
  const registeredRules = await page.evaluate(() =>
    axe.getRules().map(r => r.ruleId)
  );

  if (!registeredRules.includes('sc245-multiple-ways-rule')) {
    throw new Error(
      'Custom rule sc245-multiple-ways-rule NOT registered.\n' +
      JSON.stringify(registeredRules, null, 2)
    );
  }

  console.log('✔ SC 2.4.5 rule registered');

  /* -------------------------------------------------
     6. Run axe (ONLY SC 2.4.5)
  -------------------------------------------------- */
  const results = await page.evaluate(() =>
    axe.run(document, {
      runOnly: {
        type: 'rule',
        values: ['sc245-multiple-ways-rule']
      }
    })
  );

  /* -------------------------------------------------
     7. VALIDATION (document-level rule)
  -------------------------------------------------- */
  const hasViolation = results.violations.some(
    v => v.id === 'sc245-multiple-ways-rule'
  );

  if (hasViolation) {
    console.log(
      '\nSUCCESS: All expected violations matched actual violations for SC 2.4.5 tests\n'
    );
  } else {
    console.error(
      '\nVALIDATION FAILED: Expected SC 2.4.5 violation not detected\n'
    );
  }

  /* -------------------------------------------------
     8. Optional debug output
  -------------------------------------------------- */
  /*
  console.log(
    JSON.stringify(results.violations, null, 2)
  );
  */

  await browser.close();
})();
