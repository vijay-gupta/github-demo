// validate-sc1412.js
const fs = require('fs');
const path = require('path');
const puppeteer = require('puppeteer');

const PAGE = 'file://' + path.join(__dirname, 'sc1412-test.html');
const CUSTOM = path.join(__dirname, 'custom-sc1412-configure.js');

const EXPECTED = {
  'sc1412-text-spacing-rule': ['#fail1', '#fail2']
};

function mapResults(violations) {
  const m = {};
  (violations || []).forEach(v => {
    m[v.id] = m[v.id] || new Set();
    (v.nodes || []).forEach(n => {
      var t = (n.target && n.target[0]) || n.html || '';
      m[v.id].add(t);
    });
  });
  return m;
}

(async () => {
  if (!fs.existsSync(CUSTOM)) {
    console.error('Missing custom rule file:', CUSTOM);
    process.exit(2);
  }

  const browser = await puppeteer.launch({ headless: true, args: ['--no-sandbox','--disable-setuid-sandbox'] });
  const page = await browser.newPage();
  await page.setViewport({ width: 360, height: 800 });
  await page.goto(PAGE, { waitUntil: 'load' });

  // inject axe-core
  const axePath = require.resolve('axe-core/axe.min.js');
  const axeSource = fs.readFileSync(axePath, 'utf8');
  await page.addScriptTag({ content: axeSource });

  // inject custom rules wrapped to capture exceptions
  const customSource = fs.readFileSync(CUSTOM, 'utf8');
  const wrapped = `(function(){ try { ${customSource} ; window.__SC1412_OK__ = true; } catch(e) { window.__SC1412_OK__ = false; window.__SC1412_ERR__ = (e && e.stack) ? e.stack.toString() : String(e); console.error('SC1412 config error', window.__SC1412_ERR__); } })();`;
  await page.addScriptTag({ content: wrapped });

  // small wait
  await new Promise(r => setTimeout(r, 120));

  // run full axe and filter for our rule
  const results = await page.evaluate(async () => {
    return await window.axe.run(document);
  });

  const allViolations = results.violations || [];
  const filtered = allViolations.filter(v => Object.keys(EXPECTED).indexOf(v.id) !== -1);

  await browser.close();

  const actualMap = mapResults(filtered);

  // Compare expected vs actual
  let ok = true;
  const diffs = [];
  for (const ruleId of Object.keys(EXPECTED)) {
    const expectedSet = new Set(EXPECTED[ruleId]);
    const actualSet = actualMap[ruleId] || new Set();
    expectedSet.forEach(sel => {
      if (!actualSet.has(sel)) {
        ok = false;
        diffs.push({ type: 'MISSING_EXPECTED', ruleId, selector: sel });
      }
    });
    actualSet.forEach(sel => {
      if (!expectedSet.has(sel)) {
        ok = false;
        diffs.push({ type: 'UNEXPECTED_VIOLATION', ruleId, selector: sel });
      }
    });
  }

  if (ok) {
    console.log('SUCCESS: SC 1.4.12 validation passed for configured test cases.');
    process.exit(0);
  } else {
    console.error('VALIDATION FAILED. Diffs:');
    console.error(JSON.stringify(diffs, null, 2));
    console.error('\nFull aggregated axe violations output:');
    console.error(JSON.stringify(filtered, null, 2));
    process.exit(1);
  }

})();
