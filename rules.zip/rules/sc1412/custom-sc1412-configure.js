// custom-sc1412-configure.js
// Axe.configure for WCAG 2.1/2.2 SC 1.4.12 Text Spacing
// Deterministic ownership: overflowing descendant -> nearest block ancestor is reported.

(function () {
  var TOL = 2;

  function isVisible(el) {
    if (!el) return false;
    var s = window.getComputedStyle(el);
    if (!s) return false;
    if (s.display === 'none' || s.visibility === 'hidden' || parseFloat(s.opacity || '1') === 0) return false;
    if (el.getAttribute && el.getAttribute('aria-hidden') === 'true') return false;
    return true;
  }

  function rectsIntersect(r1, r2) {
    if (!r1 || !r2) return false;
    return !(r2.left >= r1.right - TOL || r2.right <= r1.left + TOL || r2.top >= r1.bottom - TOL || r2.bottom <= r1.top + TOL);
  }

  function elementHasDirectTextNode(el) {
    if (!el) return false;
    for (var i = 0; i < el.childNodes.length; i++) {
      var n = el.childNodes[i];
      if (n.nodeType === Node.TEXT_NODE && n.nodeValue && n.nodeValue.trim().length > 0) return true;
    }
    return false;
  }

  function elementContainsTextNode(el) {
    if (!el) return false;
    var walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, null, false);
    while (walker.nextNode()) {
      if (walker.currentNode && walker.currentNode.nodeValue && walker.currentNode.nodeValue.trim().length > 0) return true;
    }
    return false;
  }

  function isInlineElement(el) {
    try {
      var s = window.getComputedStyle(el);
      if (!s) return false;
      var d = s.getPropertyValue('display') || '';
      // treat inline and inline-* as inline-ish
      return d.indexOf('inline') === 0;
    } catch (e) {
      return false;
    }
  }

  function isBlockLike(el) {
    try {
      var s = window.getComputedStyle(el);
      if (!s) return true;
      var d = s.getPropertyValue('display') || '';
      // consider these as block-like owners
      return (d.indexOf('block') === 0) || d === 'flex' || d === 'grid' || d === 'table' || d === 'flow-root';
    } catch (e) {
      return true;
    }
  }

  function hasBlockChild(el) {
    try {
      var ch = el.children || [];
      for (var i = 0; i < ch.length; i++) {
        if (isBlockLike(ch[i])) return true;
      }
    } catch (e) {}
    return false;
  }

  function nearestClippingAncestor(node) {
    var cur = node;
    while (cur && cur !== document.documentElement) {
      try {
        var s = window.getComputedStyle(cur);
        if (!s) { cur = cur.parentElement; continue; }
        var ov = (s.getPropertyValue('overflow') || '') + ' ' + (s.getPropertyValue('overflow-y') || '') + ' ' + (s.getPropertyValue('overflow-x') || '');
        var clientH = cur.clientHeight || 0;
        var scrollH = cur.scrollHeight || 0;
        if (ov.indexOf('hidden') !== -1 || ov.indexOf('clip') !== -1) return cur;
        if (clientH > 0 && scrollH > clientH + TOL) return cur;
      } catch (e) {}
      cur = cur.parentElement;
    }
    return null;
  }

  function collectTextClientRects(el, limit) {
    var rects = [];
    try {
      var walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, null, false);
      var count = 0;
      while (walker.nextNode() && count < (limit || 500)) {
        var tn = walker.currentNode;
        if (!tn || !tn.nodeValue || tn.nodeValue.trim().length === 0) continue;
        var range = document.createRange();
        range.selectNodeContents(tn);
        var crs = range.getClientRects();
        for (var i = 0; i < crs.length; i++) {
          var cr = crs[i];
          if (cr.width > 0 && cr.height > 0) rects.push(cr);
        }
        range.detach && range.detach();
        count++;
      }
    } catch (e) {}
    return rects;
  }

  // find the nearest block-like ancestor of an element up to the stopAt (exclusive). If none found, returns document.body
  function nearestBlockAncestorOf(el, stopAt) {
    var cur = el;
    while (cur && cur !== stopAt && cur !== document.documentElement) {
      if (isBlockLike(cur)) return cur;
      cur = cur.parentElement;
    }
    return document.body;
  }

  // detect overflowing descendant text nodes (heuristic): long unbroken text or explicit white-space:nowrap; returns array of offending descendants
  function findOverflowingDescendants(root) {
    var offenders = [];
    try {
      var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null, false);
      var count = 0;
      while (walker.nextNode() && count < 1000) {
        var tn = walker.currentNode;
        if (!tn || !tn.nodeValue) continue;
        var text = tn.nodeValue.trim();
        if (!text) continue;
        // heuristic: consider long unbroken words (no spaces longer than 20 chars) or few spaces with very long token
        var tokens = text.split(/\s+/);
        var longToken = tokens.some(t => t.length > 30);
        // find the element containing this text node
        var el = tn.parentElement;
        if (!el) continue;
        // if element or its computed style uses nowrap OR it has a long token, measure its scrollWidth vs clientWidth
        var cs = window.getComputedStyle(el);
        var isNowrap = false;
        try { if (cs && cs.getPropertyValue('white-space') && cs.getPropertyValue('white-space').indexOf('nowrap') !== -1) isNowrap = true; } catch (e) {}
        if (!isNowrap && !longToken) { count++; continue; }
        // if inline parent, measure the earliest block ancestor's responsibility later; but collect this el as candidate
        // measure scroll vs client
        try {
          var cW = el.clientWidth || 0;
          var sW = el.scrollWidth || 0;
          if (sW > cW + TOL) {
            offenders.push(el);
          } else {
            // also check bounding rect extends beyond viewport or parent
            var r = el.getBoundingClientRect();
            if (r && (r.right > (document.documentElement.clientWidth || window.innerWidth) + TOL)) {
              offenders.push(el);
            }
          }
        } catch (e) {}
        count++;
      }
    } catch (e) {}
    return offenders;
  }

  var check = {
    id: 'sc1412-text-spacing-check',
    evaluate: function (node, options) {
      try {
        if (!node || node.nodeType !== 1) return true;
        if (!isVisible(node)) return true;

        // only test nodes that contain text or interactive controls
        var mayMatter = elementContainsTextNode(node) || (node.querySelector && node.querySelector('button,input,select,textarea,a'));
        if (!mayMatter) return true;

        // insert simulated spacing style
        var styleId = '__sc1412_sim_style';
        var existing = document.getElementById(styleId);
        if (existing) existing.parentNode.removeChild(existing);
        var style = document.createElement('style');
        style.id = styleId;
        var css = [
          '* { line-height: 1.5 !important; letter-spacing: 0.12em !important; word-spacing: 0.16em !important; }',
          'p, li, dd, dt, blockquote, h1, h2, h3, h4, h5, h6 { margin-block-end: 2em !important; }'
        ].join('\n');
        style.appendChild(document.createTextNode(css));
        document.head.appendChild(style);
        void document.body.offsetHeight; // reflow

        // 1) node disappears -> flag node
        var stillVisible = isVisible(node) && (node.offsetWidth > 0 || node.offsetHeight > 0);
        if (!stillVisible) {
          style.parentNode && style.parentNode.removeChild(style);
          return false;
        }

        // 2) node itself clips -> node is responsible
        try {
          var nStyle = window.getComputedStyle(node);
          var nOv = (nStyle.getPropertyValue('overflow') || '') + ' ' + (nStyle.getPropertyValue('overflow-y') || '');
          if (nOv.indexOf('hidden') !== -1 || nOv.indexOf('clip') !== -1) {
            if (node.scrollHeight > node.clientHeight + TOL) {
              style.parentNode && style.parentNode.removeChild(style);
              return false;
            }
          }
        } catch (e) {}

        // 3) nearest clipping ancestor: if exists and is not this node, skip (ancestor will be flagged)
        var clipAnc = nearestClippingAncestor(node);
        if (clipAnc && clipAnc !== node) {
          style.parentNode && style.parentNode.removeChild(style);
          return true;
        }

        // 4) find overflowing descendants under this node
        var offenders = findOverflowingDescendants(node);
        if (offenders && offenders.length > 0) {
          // for each offender, compute its nearest block ancestor (up to this node)
          for (var i = 0; i < offenders.length; i++) {
            var off = offenders[i];
            var owner = nearestBlockAncestorOf(off, node.parentElement || document.body);
            // if the owner is exactly the current node, then current node owns the failure -> flag
            if (owner === node) {
              style.parentNode && style.parentNode.removeChild(style);
              return false;
            } else {
              // otherwise, skip flagging this node — the owner will be evaluated (or will be flagged when its evaluation runs)
              style.parentNode && style.parentNode.removeChild(style);
              return true;
            }
          }
        }

        // 5) Overlap detection — only for leaf nodes or nodes with direct text nodes AND not containing block children.
        var directText = elementHasDirectTextNode(node);
        var leaf = (node.children && node.children.length === 0);
        var blockChild = hasBlockChild(node);
        var doOverlapCheck = ( (leaf || directText) && !blockChild );

        // avoid overlap check for headings — we do not want to flag labels adjacent to failing boxes
        var isHeading = false;
        try { isHeading = !!node.matches && node.matches('h1,h2,h3,h4,h5,h6'); } catch (e) { isHeading = false; }
        if (isHeading) doOverlapCheck = false;

        if (doOverlapCheck) {
          try {
            var nodeRects = collectTextClientRects(node, 400);
            if (nodeRects.length > 0) {
              var outsideRects = [];
              var walker2 = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
              var ccount = 0;
              while (walker2.nextNode() && ccount < 400) {
                var tn2 = walker2.currentNode;
                if (!tn2 || !tn2.nodeValue || tn2.nodeValue.trim().length === 0) continue;
                if (node.contains(tn2)) continue;
                var r2 = document.createRange();
                r2.selectNodeContents(tn2);
                var crs2 = r2.getClientRects();
                for (var j = 0; j < crs2.length; j++) {
                  var crj = crs2[j];
                  if (crj.width > 0 && crj.height > 0) outsideRects.push(crj);
                }
                r2.detach && r2.detach();
                ccount++;
              }
              for (var a = 0; a < nodeRects.length; a++) {
                for (var b = 0; b < outsideRects.length; b++) {
                  if (rectsIntersect(nodeRects[a], outsideRects[b])) {
                    var overlapWidth = Math.min(nodeRects[a].right, outsideRects[b].right) - Math.max(nodeRects[a].left, outsideRects[b].left);
                    var overlapHeight = Math.min(nodeRects[a].bottom, outsideRects[b].bottom) - Math.max(nodeRects[a].top, outsideRects[b].top);
                    if (overlapWidth > 4 && overlapHeight > 2) {
                      style.parentNode && style.parentNode.removeChild(style);
                      return false;
                    }
                  }
                }
              }
            }
          } catch (e) {}
        }

        // 6) no problem found
        style.parentNode && style.parentNode.removeChild(style);
        return true;
      } catch (e) {
        try { var s2 = document.getElementById('__sc1412_sim_style'); if (s2) s2.parentNode.removeChild(s2); } catch (e2) {}
        return true;
      }
    },
    metadata: {
      impact: 'serious',
      messages: {
        pass: 'Text remains readable with required spacing.',
        fail: 'Text spacing change causes content to be clipped, overlap, or functionality loss.'
      }
    }
  };

  axe.configure({
    checks: [check],
    rules: [
      {
        id: 'sc1412-text-spacing-rule',
        selector: '*',
        enabled: true,
        tags: ['wcag2.1', 'wcag2.2', 'wcag1412', 'text-spacing'],
        any: ['sc1412-text-spacing-check'],
        checks: [{ id: 'sc1412-text-spacing-check', options: {} }],
        metadata: {
          description: 'Verify text remains readable and usable when users increase text spacing per SC 1.4.12.',
          help: 'Ensure no clipping, overlap, or loss of functionality when line-height/paragraph/word/letter spacing are increased.',
          helpUrl: 'https://www.w3.org/WAI/WCAG21/Understanding/text-spacing.html',
          messages: { pass: 'Text spacing OK', fail: 'Text spacing failure — content clipped/overlapped or functionality lost' }
        }
      }
    ]
  });

})();
