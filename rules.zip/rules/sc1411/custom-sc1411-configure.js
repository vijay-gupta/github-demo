// custom-sc1411-configure.js
// axe.configure for WCAG 2.1/2.2 SC 1.4.11 Non-text Contrast
// Heuristic checks for:
//  - interactive controls (buttons/links/inputs) with background-color or icon fills
//  - borders/outlines thicker than 1px that must meet contrast requirement
//  - SVG fills/strokes which carry meaning
//
// Notes: uses conservative heuristics; images/complex icons may need manual review.

(function () {

  // color utilities (WCAG luminance + contrast)
  function toRgb(str) {
    if (!str) return null;
    str = str.trim();
    // handle hex
    var m;
    if ((m = str.match(/^#([0-9a-fA-F]{3})$/))) {
      var s = m[1];
      return [
        parseInt(s[0] + s[0], 16),
        parseInt(s[1] + s[1], 16),
        parseInt(s[2] + s[2], 16)
      ];
    }
    if ((m = str.match(/^#([0-9a-fA-F]{6})$/))) {
      var s = m[1];
      return [
        parseInt(s.substr(0, 2), 16),
        parseInt(s.substr(2, 2), 16),
        parseInt(s.substr(4, 2), 16)
      ];
    }
    // rgb(a)
    if ((m = str.match(/^rgba?\(\s*([0-9]+)[, ]\s*([0-9]+)[, ]\s*([0-9]+)(?:[, ]\s*([\d.]+))?\s*\)$/i))) {
      return [parseInt(m[1], 10), parseInt(m[2], 10), parseInt(m[3], 10)];
    }
    // named colors / computed style fallback: let the browser compute later
    return null;
  }

  function srgbToLin(c) {
    c = c / 255;
    return (c <= 0.03928) ? (c / 12.92) : Math.pow((c + 0.055) / 1.055, 2.4);
  }

  function relativeLuminance(rgb) {
    if (!rgb) return null;
    return 0.2126 * srgbToLin(rgb[0]) + 0.7152 * srgbToLin(rgb[1]) + 0.0722 * srgbToLin(rgb[2]);
  }

  function contrastRatio(rgb1, rgb2) {
    if (!rgb1 || !rgb2) return null;
    var L1 = relativeLuminance(rgb1);
    var L2 = relativeLuminance(rgb2);
    if (L1 === null || L2 === null) return null;
    var lighter = Math.max(L1, L2);
    var darker = Math.min(L1, L2);
    return (lighter + 0.05) / (darker + 0.05);
  }

  function parseComputedColor(style, property) {
    var v = style.getPropertyValue(property);
    if (!v) return null;
    var rgb = toRgb(v);
    if (rgb) return rgb;
    // fallback: create temporary element to let browser compute named colors (rare)
    return null;
  }

  // Heuristics defaults
  var REQUIRED_RATIO = 3.0; // SC 1.4.11 threshold

  // Check 1: UI controls (buttons, inputs, anchors with role=button, clickable elements)
  var uiControlCheck = {
    id: 'sc1411-ui-control-contrast-check',
    evaluate: function (node, options) {
      try {
        if (!node || node.nodeType !== 1) return true;

        // skip hidden/decorative nodes
        var style = window.getComputedStyle(node);
        if (!style || style.visibility === 'hidden' || style.display === 'none' || parseFloat(style.opacity || '1') === 0) return true;

        // skip if aria-hidden true
        if (node.getAttribute && (node.getAttribute('aria-hidden') === 'true')) return true;

        // Identify interactive controls: button, input[type], select, textarea, a[href], role=button, role=link, [onclick]
        var nodeName = node.nodeName.toLowerCase();
        var isInteractive = false;
        if (nodeName === 'button' || nodeName === 'select' || nodeName === 'textarea') isInteractive = true;
        if (nodeName === 'input') {
          var t = (node.getAttribute('type') || '').toLowerCase();
          if (['button', 'submit', 'reset', 'checkbox', 'radio', 'image'].indexOf(t) !== -1) isInteractive = true;
        }
        if (nodeName === 'a' && node.getAttribute && node.getAttribute('href')) isInteractive = true;
        var role = (node.getAttribute && node.getAttribute('role')) || '';
        if (role && (role === 'button' || role === 'link' || role.indexOf('button') !== -1)) isInteractive = true;
        if (node.getAttribute && node.getAttribute('onclick')) isInteractive = true;

        if (!isInteractive) return true;

        // Now evaluate visible graphical elements of the control:
        // - If control has a background-color or background-image and a foreground icon or background fill, measure background vs page background
        // - If control has an icon (svg inside) with fill/stroke, that will be handled by svg-check
        // We take the element background color vs effective parent background color (approx).
        var bg = parseComputedColor(style, 'background-color');
        var borderColor = parseComputedColor(style, 'border-color');
        // compute element's background: if background-color is transparent, walk up to find nearest non-transparent bg
        function findEffectiveBackground(el) {
          var cur = el;
          while (cur && cur !== document.documentElement) {
            var s = window.getComputedStyle(cur);
            if (!s) { cur = cur.parentElement; continue; }
            var b = s.getPropertyValue('background-color');
            if (b && b !== 'transparent' && b !== 'rgba(0, 0, 0, 0)') {
              var rgb = toRgb(b);
              if (rgb) return rgb;
            }
            cur = cur.parentElement;
          }
          // fallback: white
          return [255, 255, 255];
        }

        var elementBg = bg || findEffectiveBackground(node);

        // If element has no visible fill and only thin border, border-check handles it. Here require significant fill or area.
        // If element has background-size or background-image but no bg color, treat as needing manual review (pass to avoid false positives)
        var bgImage = style.getPropertyValue('background-image');
        if (!bg && bgImage && bgImage !== 'none') {
          // avoid false positives for complex background images — do not fail automatically
          return true;
        }

        // compute contrast between element background and its parent's bg
        var parentBg = findEffectiveBackground(node.parentElement || document.documentElement);
        var bgContrast = contrastRatio(elementBg, parentBg);

        // If control has border that provides contrast, border-check will handle. For filled controls, require element-bg vs parent-bg >= REQUIRED_RATIO
        if (bgContrast !== null && bgContrast < REQUIRED_RATIO) {
          // If control contains an SVG/icon with its own fill/stroke that meets contrast, allow (svg check handles), here conservative: flag
          return false;
        }

        return true;
      } catch (e) {
        return true; // be permissive on errors
      }
    },
    metadata: {
      impact: 'serious',
      messages: {
        pass: 'UI control has sufficient non-text contrast.',
        fail: 'UI control lacks required non-text contrast (background vs parent background < 3:1).'
      }
    }
  };

  // Check 2: borders/outlines (borders thicker than 1px that convey information)
  var borderCheck = {
    id: 'sc1411-border-contrast-check',
    evaluate: function (node, options) {
      try {
        if (!node || node.nodeType !== 1) return true;
        var style = window.getComputedStyle(node);
        if (!style) return true;
        if (style.getPropertyValue('display') === 'none' || style.getPropertyValue('visibility') === 'hidden') return true;
        if (node.getAttribute && (node.getAttribute('aria-hidden') === 'true')) return true;

        // border width (use computed border-left-width as representative)
        var bw = parseFloat(style.getPropertyValue('border-left-width') || '0');
        // treat borders thicker than 1px (or 2px for high DPI) as potential non-text contrast requirement
        if (!bw || bw < 1.2) return true;

        // compute border color vs element background
        var bCol = parseComputedColor(style, 'border-left-color') || [0, 0, 0];
        // find element bg
        function findBg(el) {
          var cur = el;
          while (cur && cur !== document.documentElement) {
            var s = window.getComputedStyle(cur);
            if (!s) { cur = cur.parentElement; continue; }
            var b = s.getPropertyValue('background-color');
            if (b && b !== 'transparent' && b !== 'rgba(0, 0, 0, 0)') {
              var rgb = toRgb(b);
              if (rgb) return rgb;
            }
            cur = cur.parentElement;
          }
          return [255, 255, 255];
        }
        var elemBg = findBg(node);

        var c = contrastRatio(bCol, elemBg);
        if (c === null) return true;
        if (c < REQUIRED_RATIO) {
          return false;
        }
        return true;
      } catch (e) {
        return true;
      }
    },
    metadata: {
      impact: 'serious',
      messages: {
        pass: 'Border/outline meets non-text contrast requirements.',
        fail: 'Border/outline does not meet non-text contrast requirement (contrast < 3:1).'
      }
    }
  };

  // Check 3: SVG fills/strokes that convey information
  var svgCheck = {
    id: 'sc1411-svg-contrast-check',
    evaluate: function (node, options) {
      try {
        if (!node || node.nodeName.toLowerCase() !== 'svg') return true;
        // skip if aria-hidden
        if (node.getAttribute && node.getAttribute('aria-hidden') === 'true') return true;

        // find any <path>, <rect>, <circle>, <line>, <polyline>, <polygon> that has fill/stroke not 'none'
        var shapes = node.querySelectorAll('path, rect, circle, line, polyline, polygon');
        if (!shapes || shapes.length === 0) return true;

        // find effective background behind svg by searching parent chain
        function findEffectiveBg(el) {
          var cur = el.parentElement;
          while (cur && cur !== document.documentElement) {
            var s = window.getComputedStyle(cur);
            if (s) {
              var b = s.getPropertyValue('background-color');
              if (b && b !== 'transparent' && b !== 'rgba(0, 0, 0, 0)') {
                var rgb = toRgb(b);
                if (rgb) return rgb;
              }
            }
            cur = cur.parentElement;
          }
          return [255, 255, 255];
        }
        var bg = findEffectiveBg(node);

        for (var i = 0; i < shapes.length; i++) {
          var sh = shapes[i];
          var sstyle = window.getComputedStyle(sh);
          if (!sstyle) continue;
          var fill = sstyle.getPropertyValue('fill');
          var stroke = sstyle.getPropertyValue('stroke');

          // skip shapes that are clearly decorative (stroke:none && fill:none)
          if ((!fill || fill === 'none' || fill === 'transparent') && (!stroke || stroke === 'none' || stroke === 'transparent')) continue;

          // If fill is present and not 'currentColor', test contrast fill vs bg
          if (fill && fill !== 'none' && fill !== 'transparent') {
            var rgbf = toRgb(fill) || null;
            // if not parseable, skip (avoid false positives)
            if (rgbf) {
              var cr = contrastRatio(rgbf, bg);
              if (cr !== null && cr < REQUIRED_RATIO) return false;
            }
          }

          if (stroke && stroke !== 'none' && stroke !== 'transparent') {
            var rgbs = toRgb(stroke) || null;
            if (rgbs) {
              var cr2 = contrastRatio(rgbs, bg);
              if (cr2 !== null && cr2 < REQUIRED_RATIO) return false;
            }
          }
        }

        return true;
      } catch (e) {
        return true;
      }
    },
    metadata: {
      impact: 'serious',
      messages: {
        pass: 'SVG shapes have sufficient contrast vs background.',
        fail: 'SVG shapes (fill/stroke) do not meet non-text contrast requirement (contrast < 3:1).'
      }
    }
  };

  // Register checks and rules
  axe.configure({
    checks: [uiControlCheck, borderCheck, svgCheck],
    rules: [
      {
        id: 'sc1411-ui-control-rule',
        selector: 'button, input, select, textarea, a, [role="button"], [role="link"], [onclick]',
        enabled: true,
        tags: ['wcag2.1', 'wcag2.2', 'wcag1411', 'non-text-contrast'],
        all: ['sc1411-ui-control-contrast-check'],
        checks: [{ id: 'sc1411-ui-control-contrast-check', options: {} }],
        metadata: {
          description: 'UI controls must meet non-text contrast ratio (>= 3:1) between their graphical parts and adjacent background.',
          help: 'Ensure control fills/icons provide contrast of at least 3:1 against adjacent background or provide another mode for perception.',
          helpUrl: 'https://www.w3.org/WAI/WCAG22/Understanding/non-text-contrast.html',
          messages: { pass: 'UI control meets non-text contrast', fail: 'UI control fails non-text contrast (contrast < 3:1)' }
        }
      },
      {
        id: 'sc1411-border-rule',
        selector: '*',
        enabled: true,
        tags: ['wcag2.1', 'wcag2.2', 'wcag1411', 'non-text-contrast'],
        all: ['sc1411-border-contrast-check'],
        checks: [{ id: 'sc1411-border-contrast-check', options: {} }],
        metadata: {
          description: 'Borders or focus outlines that convey information must have contrast ratio >= 3:1.',
          help: 'Ensure thicker borders/outlines meet the contrast requirement.',
          helpUrl: 'https://www.w3.org/WAI/WCAG22/Understanding/non-text-contrast.html',
          messages: { pass: 'Border meets required contrast', fail: 'Border does not meet required contrast (contrast < 3:1)' }
        }
      },
      {
        id: 'sc1411-svg-rule',
        selector: 'svg',
        enabled: true,
        tags: ['wcag2.1', 'wcag2.2', 'wcag1411', 'non-text-contrast'],
        all: ['sc1411-svg-contrast-check'],
        checks: [{ id: 'sc1411-svg-contrast-check', options: {} }],
        metadata: {
          description: 'SVG graphical objects that convey information must have contrast ratio >= 3:1 vs background.',
          help: 'Ensure SVG fills/strokes have sufficient contrast against adjacent background.',
          helpUrl: 'https://www.w3.org/WAI/WCAG22/Understanding/non-text-contrast.html',
          messages: { pass: 'SVG meets non-text contrast', fail: 'SVG does not meet non-text contrast (contrast < 3:1)' }
        }
      }
    ]
  });

})();
