// custom-sc1413-configure.js
// axe.configure for WCAG 1.4.13 Content on Hover or Focus
// Heuristic + runtime checks are implemented by validator; this file registers checks
// that mark elements which appear on hover/focus and require runtime behavioural tests.

(function () {

  // Check: detect potential hover/focus triggered popups (heuristic)
  var appearCheck = {
    id: 'sc1413-appear-on-hover-focus-check',
    evaluate: function (node, options) {
      try {
        if (!node || node.nodeType !== 1) return true;
        // skip invisible / decorative
        var s = window.getComputedStyle(node);
        if (!s) return true;
        if (s.visibility === 'hidden' || s.display === 'none') return true;
        if (node.getAttribute && node.getAttribute('aria-hidden') === 'true') return true;

        // Heuristics for being a popup or appearing content:
        //  - has role tooltip/menu/listbox or aria-live region (may be dynamic) OR
        //  - is positioned absolute/fixed and initially hidden (visibility none / opacity 0) then later shown (we can't detect later here)
        //  - or has CSS classes commonly used: 'tooltip','popover','popup','menu','dropdown'
        var role = (node.getAttribute && node.getAttribute('role')) || '';
        if (role && (/tooltip|dialog|menu|listbox|menuitem/).test(role)) return false;

        var cls = node.className || '';
        if (typeof cls === 'string' && (/tooltip|popover|popup|menu|dropdown|flyout/).test(cls)) return false;

        // positioned element candidates (may be popup)
        var pos = s.getPropertyValue('position') || '';
        if (pos === 'absolute' || pos === 'fixed' || pos === 'sticky') {
          // element is positioned — potential popup; let validator runtime tests validate behaviour
          return false;
        }

        return true;
      } catch (e) {
        return true;
      }
    },
    metadata: {
      impact: 'serious',
      messages: {
        pass: 'Element does not look like dynamic hover/focus content.',
        fail: 'Element looks like content that appears on hover or focus and requires behaviour testing (dismissible, hoverable, persistent).'
      }
    }
  };

  axe.configure({
    checks: [ appearCheck ],
    rules: [
      {
        id: 'sc1413-appear-rule',
        selector: '*',
        enabled: true,
        tags: ['wcag2.1','wcag2.2','wcag1413','content-hover-focus'],
        any: ['sc1413-appear-on-hover-focus-check'],
        checks: [{ id: 'sc1413-appear-on-hover-focus-check', options: {} }],
        metadata: {
          description: 'Detect elements that appear on hover or focus (heuristic). Behavioural tests (validator) required to check dismissible/hoverable/persistent rules.',
          help: 'Content that appears on hover or focus must be dismissible, hoverable and persistent while focused.',
          helpUrl: 'https://www.w3.org/WAI/WCAG21/Understanding/content-on-hover-or-focus.html',
          messages: { pass: 'Element not identified as appearing content', fail: 'Element appears to be dynamic hover/focus content — requires runtime behaviour validation' }
        }
      }
    ]
  });

})();
