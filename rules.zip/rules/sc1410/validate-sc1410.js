// validate-sc1410.js (robust: run full axe, then filter custom-rule violations)
const fs = require('fs');
const path = require('path');
const puppeteer = require('puppeteer');

const PAGE = 'file://' + path.join(__dirname, 'sc1410-test.html');
const CUSTOM = path.join(__dirname, 'custom-sc1410-configure.js');

// Expected violations mapping for rule IDs -> selectors
const EXPECTED = {
  'sc1410-fixed-width-rule': ['#fixed-wide', '#nowrap', '#abs-out', '#bg-long'],
  'sc1410-overflow-rule': ['html', 'body'],
  'sc1410-abs-pos-rule': ['#abs-out']
};

function mapResults(violations) {
  const m = {};
  (violations || []).forEach(v => {
    m[v.id] = m[v.id] || new Set();
    (v.nodes || []).forEach(n => {
      const t = (n.target && n.target[0]) || n.html || '';
      m[v.id].add(t);
    });
  });
  return m;
}

(async () => {
  try {
    if (!fs.existsSync(CUSTOM)) {
      console.error('Missing custom rule file:', CUSTOM);
      process.exit(2);
    }

    const browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    const page = await browser.newPage();

    // viewports used to emulate narrow layout / zoom proxy
    const viewports = [
      { width: 320, height: 800 },
      { width: 256, height: 800 }
    ];

    let aggregatedViolations = [];

    for (const vp of viewports) {
      await page.setViewport(vp);
      await page.goto(PAGE, { waitUntil: 'load' });

      // short pause to allow fonts and layout to settle
      await new Promise(resolve => setTimeout(resolve, 150));

      // inject axe-core as a script tag
      const axePath = require.resolve('axe-core/axe.min.js');
      const axeSource = fs.readFileSync(axePath, 'utf8');
      await page.addScriptTag({ content: axeSource });

      // inject custom configure file
      const customSource = fs.readFileSync(CUSTOM, 'utf8');
      await page.addScriptTag({ content: customSource });

      // give the browser a beat to execute injected scripts
      await new Promise(resolve => setTimeout(resolve, 50));

      // run full axe (no runOnly) — then we'll filter results for our custom rule IDs
      const results = await page.evaluate(async () => {
        return await window.axe.run(document);
      });

      // filter results: keep only violations whose id is one of EXPECTED keys
      const expectedRuleIds = Object.keys(EXPECTED);
      const filtered = (results.violations || []).filter(v => expectedRuleIds.indexOf(v.id) !== -1);

      // merge filtered violations into aggregatedViolations
      for (const v of filtered) {
        const existing = aggregatedViolations.find(x => x.id === v.id);
        if (!existing) aggregatedViolations.push(v);
        else {
          const existingTargets = new Set(existing.nodes.map(n => (n.target && n.target[0]) || n.html));
          for (const node of v.nodes || []) {
            const target = (node.target && node.target[0]) || node.html;
            if (!existingTargets.has(target)) {
              existing.nodes.push(node);
              existingTargets.add(target);
            }
          }
        }
      }
    } // end viewports loop

    await browser.close();

    // Map aggregated violations to sets for comparison
    const actualMap = mapResults(aggregatedViolations);

    // Compare actual -> expected
    let ok = true;
    const diffs = [];

    for (const ruleId of Object.keys(EXPECTED)) {
      const expectedSet = new Set(EXPECTED[ruleId]);
      const actualSet = actualMap[ruleId] || new Set();

      expectedSet.forEach(sel => {
        if (!actualSet.has(sel)) {
          ok = false;
          diffs.push({ type: 'MISSING_EXPECTED', ruleId, selector: sel });
        }
      });

      actualSet.forEach(sel => {
        if (!expectedSet.has(sel)) {
          ok = false;
          diffs.push({ type: 'UNEXPECTED_VIOLATION', ruleId, selector: sel });
        }
      });
    }

    if (ok) {
      console.log('SUCCESS: SC 1.4.10 validation passed for configured test cases.');
      process.exit(0);
    } else {
      console.error('VALIDATION FAILED. Diffs:');
      console.error(JSON.stringify(diffs, null, 2));
      console.error('\nFull aggregated axe violations output:');
      console.error(JSON.stringify(aggregatedViolations, null, 2));
      process.exit(1);
    }

  } catch (err) {
    console.error('Validator threw an exception:', err && err.stack ? err.stack : err);
    process.exit(3);
  }
})();
