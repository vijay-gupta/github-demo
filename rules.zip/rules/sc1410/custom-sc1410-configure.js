// custom-sc1410-configure.js
// Axe.configure for WCAG 2.2 SC 1.4.10 (Reflow)
// Fix: detect overflowing descendants by comparing bounding rect positions (handles absolutely positioned children).

axe.configure({
  checks: [

    {
      id: 'sc1410-fixed-width-check',
      evaluate: function (node, options) {
        if (!node || node.nodeType !== 1) return true;
        if (node === document.documentElement || node === document.body) return true;

        var opts = Object.assign({
          maxRelativeWidth: 1.0,
          pxWidthThreshold: null,
          rightTolerancePx: 3,
          responsiveFillThreshold: 0.98
        }, options || {});

        try {
          var rect = node.getBoundingClientRect();
          if (!rect) return true;
          var computed = window.getComputedStyle(node);
          if (!computed) return true;
          var viewportWidth = document.documentElement.clientWidth || window.innerWidth || 0;
          if (!viewportWidth || viewportWidth <= 0) return true;

          // Helpers
          function isLeafElement(n) {
            var c = n.children || [];
            return c.length === 0;
          }

          // Determine if any descendant is the real cause: descendant's bounding rect extends
          // beyond parent bounding rect (left or right) by tolerance OR descendant overflows itself.
          function hasOverflowingDescendant(parent) {
            var tol = opts.rightTolerancePx;
            var pRect = parent.getBoundingClientRect();
            var descendants = parent.querySelectorAll('*');
            for (var i = 0; i < descendants.length; i++) {
              var d = descendants[i];
              if (d === parent) continue;
              try {
                var dRect = d.getBoundingClientRect && d.getBoundingClientRect();
                if (dRect) {
                  // descendant extends past parent's left/right edge -> descendant causes overflow
                  if (dRect.left < pRect.left - tol || dRect.right > pRect.right + tol) return true;
                }
                // descendant scroll overflow relative to its own client
                var dClient = d.clientWidth || 0;
                var dScroll = d.scrollWidth || 0;
                if (dScroll > dClient + tol && dScroll > pRect.width + tol) return true;
              } catch (e) {
                // ignore
              }
            }
            return false;
          }

          // 1) nowrap (element-level)
          var whiteSpace = computed.getPropertyValue('white-space');
          if (whiteSpace && whiteSpace.indexOf('nowrap') !== -1) {
            var txt = (node.textContent || '').trim();
            if (txt.length > 20) return false;
          }

          // 2) background-image without DOM text -> violation
          var bg = computed.getPropertyValue('background-image');
          if (bg && bg !== 'none') {
            var txtInside = (node.textContent || '').trim();
            if (!txtInside || txtInside.length === 0) return false;
          }

          // 3) explicit px width
          var widthCss = computed.getPropertyValue('width') || '';
          var declaredWidthPx = null;
          var m = widthCss.match(/^([0-9]+)px/);
          if (m) declaredWidthPx = parseInt(m[1], 10);
          if (declaredWidthPx !== null) {
            if (opts.pxWidthThreshold && declaredWidthPx >= opts.pxWidthThreshold) return false;
            if (declaredWidthPx > Math.floor(viewportWidth * opts.maxRelativeWidth) + opts.rightTolerancePx) {
              return false;
            }
          }

          // 4) element-level scroll overflow (candidate)
          var nodeClientW = node.clientWidth || 0;
          var nodeScrollW = node.scrollWidth || 0;
          if (nodeScrollW && nodeClientW) {
            var nodeOverflowsSelf = nodeScrollW > nodeClientW + opts.rightTolerancePx && nodeScrollW > viewportWidth + opts.rightTolerancePx;
            if (nodeOverflowsSelf) {
              if (!isLeafElement(node) && hasOverflowingDescendant(node)) {
                // descendant explains overflow — do not flag this container
              } else {
                return false; // node is the offender
              }
            }
          }

          // 5) bounding rect extends beyond viewport
          if (rect.right > viewportWidth + opts.rightTolerancePx || rect.left < -opts.rightTolerancePx) {
            // if node essentially fills viewport, treat as responsive
            if (rect.width >= Math.floor(viewportWidth * opts.responsiveFillThreshold)) {
              return true;
            }
            // if a descendant explains overflow by being positioned outside parent, skip this parent
            if (!isLeafElement(node) && hasOverflowingDescendant(node)) {
              return true;
            }
            // else, flag this node
            return false;
          }

          return true;
        } catch (e) {
          return true;
        }
      },
      metadata: {
        impact: 'serious',
        messages: {
          pass: 'Element allows reflow.',
          fail: 'Element likely prevents reflow (fixed width / nowrap / background-only or element-local overflow).'
        }
      }
    },

    {
      id: 'sc1410-overflow-scroll-check',
      evaluate: function (node, options) {
        if (!node) return true;
        try {
          var doc = document.documentElement || document.body;
          var scrollW = Math.max(doc.scrollWidth || 0, doc.offsetWidth || 0, doc.clientWidth || 0);
          var clientW = doc.clientWidth || window.innerWidth || 0;
          if (scrollW > clientW + 1) {
            if (node === document.documentElement || node === document.body) return false;
          }
          return true;
        } catch (e) {
          return true;
        }
      },
      metadata: {
        impact: 'serious',
        messages: {
          pass: 'No document-level horizontal scrolling detected.',
          fail: 'Document causes horizontal scroll at this viewport (reflow failure).'
        }
      }
    },

    {
      id: 'sc1410-abs-position-check',
      evaluate: function (node, options) {
        if (!node || node.nodeType !== 1) return true;
        try {
          var computed = window.getComputedStyle(node);
          if (!computed) return true;
          var pos = computed.getPropertyValue('position');
          if (pos !== 'absolute' && pos !== 'fixed') return true;
          var rect = node.getBoundingClientRect();
          var vw = document.documentElement.clientWidth || window.innerWidth || 0;
          var tol = 3;
          if (rect.left < -tol || rect.right > vw + tol) return false;
          return true;
        } catch (e) {
          return true;
        }
      },
      metadata: {
        impact: 'moderate',
        messages: {
          pass: 'Positioned element stays within viewport.',
          fail: 'Positioned element sticks outside viewport and may break reflow.'
        }
      }
    }

  ],

  rules: [

    {
      id: 'sc1410-fixed-width-rule',
      selector: '*',
      enabled: true,
      tags: ['wcag2.2', 'wcag1410', 'reflow'],
      any: ['sc1410-fixed-width-check'],
      checks: [
        {
          id: 'sc1410-fixed-width-check',
          options: {
            maxRelativeWidth: 1.0,
            pxWidthThreshold: null,
            rightTolerancePx: 3,
            responsiveFillThreshold: 0.98
          }
        }
      ],
      metadata: {
        description: 'Detect elements that use fixed widths, nowrap, background-only banners or element-local overflow that prevents reflow.',
        help: 'Use relative widths and real DOM text; avoid elements that overflow their container or exceed viewport width.',
        helpUrl: 'https://www.w3.org/WAI/WCAG22/Understanding/reflow.html',
        messages: { pass: 'Element allows reflow.', fail: 'Element may prevent reflow.' }
      }
    },

    {
      id: 'sc1410-overflow-rule',
      selector: 'html, body',
      enabled: true,
      tags: ['wcag2.2', 'wcag1410', 'reflow'],
      all: ['sc1410-overflow-scroll-check'],
      checks: [
        { id: 'sc1410-overflow-scroll-check', options: {} }
      ],
      metadata: { description: 'Detect document-level horizontal scrolling.', help: 'Avoid horizontal scrolling at narrow viewports.', helpUrl: 'https://www.w3.org/WAI/WCAG22/Understanding/reflow.html', messages: { pass: 'No horizontal scroll detected.', fail: 'Horizontal scrolling detected.' } }
    },

    {
      id: 'sc1410-abs-pos-rule',
      selector: '*',
      enabled: true,
      tags: ['wcag2.2', 'wcag1410', 'reflow'],
      any: ['sc1410-abs-position-check'],
      checks: [ { id: 'sc1410-abs-position-check', options: {} } ],
      metadata: { description: 'Detect absolutely/fixed positioned elements that overflow viewport.', helpUrl: 'https://www.w3.org/WAI/WCAG22/Understanding/reflow.html', messages: { pass: 'Positioned elements OK.', fail: 'Positioned element overflows viewport.' } }
    }

  ]

});
