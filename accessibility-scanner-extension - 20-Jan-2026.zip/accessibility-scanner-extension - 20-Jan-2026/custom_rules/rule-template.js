export default {
  id: '',
  description: '',
  help: '',
  metadata: {},
  evaluate: () => ({ result: 'inapplicable' })
};
