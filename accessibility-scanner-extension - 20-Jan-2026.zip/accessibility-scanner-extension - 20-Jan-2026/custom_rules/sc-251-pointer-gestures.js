/**
 * SC 2.5.1 Pointer Gestures
 * Automatable subset: Inline multi-pointer gesture handlers (gesture events
 * or touch handlers checking multiple touch points) without an inline
 * single-pointer alternative on the same element.
 * Limitations:
 * - Does not detect handlers added via addEventListener or external scripts.
 * - Cannot verify single-pointer alternatives provided on different elements.
 * - Does not detect path-based gestures without explicit multi-touch checks.
 * - Cannot determine whether a gesture is essential.
 * Version: 1.0
 * Author: Vijay Gupta  
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-251-pointer-gestures";
  const CHECK_ID = "sc-251-multipoint-gesture-has-alternative";

  const TOUCH_HANDLER_ATTRS = [
    "ontouchstart",
    "ontouchmove",
    "ontouchend",
    "ontouchcancel"
  ];
  const GESTURE_HANDLER_ATTRS = [
    "ongesturestart",
    "ongesturechange",
    "ongestureend"
  ];
  const INLINE_GESTURE_SELECTOR = [
    ...TOUCH_HANDLER_ATTRS.map((attr) => `[${attr}]`),
    ...GESTURE_HANDLER_ATTRS.map((attr) => `[${attr}]`)
  ].join(", ");

  const SINGLE_POINTER_ALT_ATTRS = [
    "onclick",
    "onmousedown",
    "onmouseup",
    "onpointerdown",
    "onpointerup"
  ];

  const KEY_HANDLER_ATTRS = ["onkeydown", "onkeyup", "onkeypress"];

  const MULTI_TOUCH_INDEX_REGEXES = [
    /\btouches\s*\[\s*1\s*\]/i,
    /\bchangedTouches\s*\[\s*1\s*\]/i
  ];

  const FOCUSABLE_SELECTOR = [
    "a[href]",
    "button",
    "input:not([type=\"hidden\"])",
    "select",
    "textarea",
    "summary",
    "[role=\"button\"]",
    "[role=\"link\"]",
    "[role=\"menuitem\"]",
    "[role=\"tab\"]",
    "[role=\"switch\"]",
    "[role=\"checkbox\"]",
    "[role=\"radio\"]",
    "[role=\"option\"]",
    "[role=\"textbox\"]",
    "[contenteditable=\"true\"]",
    "[tabindex]:not([tabindex=\"-1\"])"
  ].join(", ");

  function isVisible(node) {
    const style = window.getComputedStyle(node);
    if (!style) return false;
    if (style.display === "none") return false;
    if (style.visibility === "hidden") return false;
    if (parseFloat(style.opacity) === 0) return false;
    return true;
  }

  function getInlineHandler(node, attr) {
    const value = node.getAttribute(attr);
    return value ? value.trim() : "";
  }

  function getInlineHandlers(node, attrs) {
    return attrs.map((attr) => getInlineHandler(node, attr)).join(" ");
  }

  function hasMultiTouchLengthCheck(handler, propName) {
    const regex = new RegExp(
      `\\b${propName}\\s*\\.\\s*length\\s*(===|==|>=|>|!==|!=)\\s*(\\d+)`,
      "gi"
    );
    let match;
    while ((match = regex.exec(handler))) {
      const comparator = match[1];
      const value = parseInt(match[2], 10);
      if (Number.isNaN(value)) continue;

      if (comparator === ">" && value >= 1) return true;
      if (comparator === ">=" && value >= 2) return true;
      if ((comparator === "==" || comparator === "===") && value >= 2) {
        return true;
      }
    }
    return false;
  }

  function hasMultiPointerGesture(node) {
    const gestureHandlers = getInlineHandlers(node, GESTURE_HANDLER_ATTRS);
    if (gestureHandlers.trim().length > 0) return true;

    const touchHandlers = getInlineHandlers(node, TOUCH_HANDLER_ATTRS);
    if (!touchHandlers.trim().length) return false;
    if (hasMultiTouchLengthCheck(touchHandlers, "touches")) return true;
    if (hasMultiTouchLengthCheck(touchHandlers, "changedTouches")) return true;
    return MULTI_TOUCH_INDEX_REGEXES.some((regex) =>
      regex.test(touchHandlers)
    );
  }

  function hasInlineSinglePointerAlternative(node) {
    for (const attr of SINGLE_POINTER_ALT_ATTRS) {
      if (getInlineHandler(node, attr).length > 0) return true;
    }

    const hasKeyboardHandler = KEY_HANDLER_ATTRS.some(
      (attr) => getInlineHandler(node, attr).length > 0
    );
    if (!hasKeyboardHandler) return false;
    if (typeof node.matches !== "function") return false;
    return node.matches(FOCUSABLE_SELECTOR);
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector: INLINE_GESTURE_SELECTOR,
        impact: "serious",
        tags: ["wcag2aa", "wcag22aa", "wcag251", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Multi-pointer gesture handlers must provide a single-pointer alternative",
          help:
            "Ensure multi-pointer gestures can be completed with a single pointer on the same control",
          helpUrl: "https://www.w3.org/TR/WCAG22/#pointer-gestures",
          messages: {
            pass: "2.5.1 - Pointer Gestures - Pass",
            fail: "2.5.1 - Pointer Gestures - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          if (!node || typeof node.matches !== "function") return true;
          if (!node.matches(INLINE_GESTURE_SELECTOR)) return true;
          if (!isVisible(node)) return true;
          if (!hasMultiPointerGesture(node)) return true;

          return hasInlineSinglePointerAlternative(node);
        },
        metadata: {
          impact: "serious",
          messages: {
            pass:
              "2.5.1 - Pointer Gestures - multi-pointer gesture has single-pointer alternative - Pass",
            fail:
              "2.5.1 - Pointer Gestures - multi-pointer gesture lacks single-pointer alternative - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-251-pointer-gestures loaded");
})();
