/**
 * SC 2.4.11 Focus Not Obscured (Minimum)
 * Automatable subset: Focusable, visible elements in the viewport must not be
 * entirely obscured by author-created content (checked via elementFromPoint).
 * Limitations:
 * - Does not force focus/scroll into view.
 * - Cannot detect dynamic overlays that appear only on focus.
 * - Cannot distinguish author-created vs. UA chrome/assistive tech overlays.
 * Version: 1.0
 * Author: Vijay Gupta  
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-2411-focus-not-obscured-minimum";
  const CHECK_ID = "sc-2411-focus-not-obscured-minimum-visible";

  const FOCUSABLE_TAGS = new Set(["A", "BUTTON", "INPUT", "SELECT", "TEXTAREA"]);

  function isVisible(node) {
    const style = window.getComputedStyle(node);
    if (!style) return false;
    if (style.display === "none") return false;
    if (style.visibility === "hidden") return false;
    if (parseFloat(style.opacity || "1") === 0) return false;
    return true;
  }

  function isHiddenInput(node) {
    return node.tagName === "INPUT" && node.type === "hidden";
  }

  function isDisabled(node) {
    return "disabled" in node && node.disabled === true;
  }

  function isFocusable(node) {
    if (isHiddenInput(node)) return false;
    if (isDisabled(node)) return false;

    if (node.isContentEditable) return true;
    if (node.tabIndex >= 0) return true;

    if (FOCUSABLE_TAGS.has(node.tagName)) {
      if (node.tagName === "A") return node.hasAttribute("href");
      return true;
    }

    return false;
  }

  function rectInViewport(rect) {
    const vw = window.innerWidth || document.documentElement.clientWidth;
    const vh = window.innerHeight || document.documentElement.clientHeight;
    return rect.right > 0 && rect.bottom > 0 && rect.left < vw && rect.top < vh;
  }

  function pointInViewport(point) {
    const vw = window.innerWidth || document.documentElement.clientWidth;
    const vh = window.innerHeight || document.documentElement.clientHeight;
    return (
      point.x >= 0 &&
      point.y >= 0 &&
      point.x <= vw - 1 &&
      point.y <= vh - 1
    );
  }

  function getSamplePoints(rect) {
    const inset = 1;
    const points = [
      { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 },
      { x: rect.left + inset, y: rect.top + inset },
      { x: rect.right - inset, y: rect.top + inset },
      { x: rect.left + inset, y: rect.bottom - inset },
      { x: rect.right - inset, y: rect.bottom - inset }
    ];

    return points.filter(
      (p) =>
        p.x >= rect.left &&
        p.x <= rect.right &&
        p.y >= rect.top &&
        p.y <= rect.bottom
    );
  }

  function isVisibleAtPoint(node, point) {
    const topElement = document.elementFromPoint(point.x, point.y);
    if (!topElement) return false;
    return topElement === node || node.contains(topElement);
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector:
          'a[href], button, input, select, textarea, [tabindex], [contenteditable=""], [contenteditable="true"]',
        impact: "serious",
        tags: ["wcag2aa", "wcag22aa", "wcag2411", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Focusable elements should not be entirely obscured by other content",
          help:
            "Ensure focusable elements remain at least partially visible when in view",
          helpUrl:
            "https://www.w3.org/TR/WCAG22/#focus-not-obscured-minimum",
          messages: {
            pass: "2.4.11 - Focus Not Obscured (Minimum) - Pass",
            fail: "2.4.11 - Focus Not Obscured (Minimum) - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          if (!isFocusable(node)) return true;
          if (!isVisible(node)) return true;

          const rect = node.getBoundingClientRect();
          if (!rect || rect.width <= 0 || rect.height <= 0) return true;
          if (!rectInViewport(rect)) return true;

          const points = getSamplePoints(rect).filter(pointInViewport);
          if (!points.length) return true;

          for (const point of points) {
            if (isVisibleAtPoint(node, point)) return true;
          }

          return false;
        },
        metadata: {
          impact: "serious",
          messages: {
            pass:
              "2.4.11 - Focus Not Obscured (Minimum) - focusable element not fully covered - Pass",
            fail:
              "2.4.11 - Focus Not Obscured (Minimum) - focusable element fully covered - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-2411-focus-not-obscured-minimum loaded");
})();
