/**
 * SC 3.2.1 On Focus
 * Automatable subset: Focusable elements with inline onfocus handlers must not
 * trigger obvious context changes like navigation, new windows, or form submit.
 * Limitations:
 * - Cannot detect handlers added via addEventListener or external scripts.
 * - Cannot determine whether a context change is user-initiated or expected.
 * Version: 1.0
 * Author: Vijay Gupta  
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-321-on-focus";
  const CHECK_ID = "sc-321-inline-onfocus-context-change";

  const FOCUSABLE_SELECTOR = [
    "a[href]",
    "button",
    "input:not([type=\"hidden\"])",
    "select",
    "textarea",
    "summary",
    "[role=\"button\"]",
    "[role=\"link\"]",
    "[role=\"menuitem\"]",
    "[role=\"tab\"]",
    "[role=\"switch\"]",
    "[role=\"checkbox\"]",
    "[role=\"radio\"]",
    "[role=\"option\"]",
    "[role=\"textbox\"]",
    "[contenteditable=\"true\"]",
    "[tabindex]:not([tabindex=\"-1\"])"
  ].join(", ");

  const CONTEXT_CHANGE_PATTERNS = [
    { id: "location-assign", regex: /\blocation\.assign\s*\(/i },
    { id: "location-replace", regex: /\blocation\.replace\s*\(/i },
    { id: "location-href", regex: /\blocation\.href\s*=/i },
    { id: "window-location", regex: /\bwindow\.location\s*=/i },
    { id: "document-location", regex: /\bdocument\.location\s*=/i },
    { id: "location-equals", regex: /\blocation\s*=\s*/i },
    { id: "window-open", regex: /\bwindow\.open\s*\(/i },
    { id: "document-open", regex: /\bdocument\.open\s*\(/i },
    { id: "form-submit", regex: /\bsubmit\s*\(/i }
  ];

  function isDisabled(node) {
    return node.matches(
      "button[disabled], input[disabled], select[disabled], textarea[disabled]"
    );
  }

  function isFocusable(node) {
    if (!node || typeof node.matches !== "function") return false;
    if (!node.matches(FOCUSABLE_SELECTOR)) return false;
    if (isDisabled(node)) return false;
    return true;
  }

  function getInlineOnFocus(node) {
    return (node.getAttribute("onfocus") || "").trim();
  }

  function hasContextChange(handler) {
    if (!handler) return false;
    return CONTEXT_CHANGE_PATTERNS.some((pattern) => pattern.regex.test(handler));
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector: "[onfocus]",
        impact: "serious",
        tags: ["wcag2aa", "wcag22aa", "wcag321", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Focusable elements must not trigger a change of context on focus",
          help:
            "Ensure inline onfocus handlers do not navigate, open new windows, or submit forms",
          helpUrl: "https://www.w3.org/TR/WCAG22/#on-focus",
          messages: {
            pass: "3.2.1 - On Focus - Pass",
            fail: "3.2.1 - On Focus - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          if (!isFocusable(node)) return true;

          const handler = getInlineOnFocus(node);
          if (!handler) return true;

          return !hasContextChange(handler);
        },
        metadata: {
          impact: "serious",
          messages: {
            pass:
              "3.2.1 - On Focus - inline onfocus does not change context - Pass",
            fail:
              "3.2.1 - On Focus - inline onfocus changes context - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-321-on-focus loaded");
})();
