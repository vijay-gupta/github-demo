/**
 * Accessibility Scanner – Background Service Worker (MV3)
 */

// ---------------------------------------------------------
// In-memory aggregation for current scan session
// ---------------------------------------------------------
let manualScanInProgress = false;
let aggregatedResults = [];


let scanSession = {
  active: false,
  pages: []   // each entry = one page's axe results
};


function buildHtmlReport(payload) {
  const { url, results } = payload;

  function escapeHtml(str) {
    if (!str) return "";
    return str.replace(/[&<>"']/g, m => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      "\"": "&quot;",
      "'": "&#039;"
    }[m]));
  }

  function renderNodes(nodes) {
    if (!nodes || !nodes.length) return "—";

    return `
      <details>
        <summary>${nodes.length} element(s)</summary>
        <ul>
          ${nodes.map(n => `
            <li>
              <code>${escapeHtml(n.target.join(" "))}</code>
              ${n.failureSummary ? `<div class="failure">${escapeHtml(n.failureSummary)}</div>` : ""}
            </li>
          `).join("")}
        </ul>
      </details>
    `;
  }

  function renderTable(title, items) {
    if (!items || !items.length) {
      return `
        <h2>${title} (0)</h2>
        <p class="empty">No ${title.toLowerCase()} found.</p>
      `;
    }

    return `
      <h2>${title} (${items.length})</h2>
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>Rule ID</th>
            <th>Description</th>
            <th>Impact</th>
            <th>Tags</th>
            <th>Affected Elements</th>
            <th>Help</th>
          </tr>
        </thead>
        <tbody>
          ${items.map((item, index) => `
            <tr>
              <td>${index + 1}</td>
              <td>${escapeHtml(item.id)}</td>
              <td>${escapeHtml(item.description)}</td>
              <td class="impact ${item.impact || "none"}">
                ${item.impact || "—"}
              </td>
              <td>
                ${item.tags.map(t => `<span class="tag">${t}</span>`).join("")}
              </td>
              <td>${renderNodes(item.nodes)}</td>
              <td>
                <a href="${item.helpUrl}" target="_blank">Reference</a>
              </td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    `;
  }

  const manualReview = (results.incomplete || []).filter(
    item => item.tags && item.tags.includes("manual-review")
  );
  const incompleteNonManual = (results.incomplete || []).filter(
    item => !item.tags || !item.tags.includes("manual-review")
  );

  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Accessibility Report</title>

  <style>
    body {
      font-family: Arial, sans-serif;
      padding: 20px;
      background: #fafafa;
    }

    h1 {
      margin-bottom: 5px;
    }

    .meta {
      color: #555;
      margin-bottom: 30px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 40px;
      background: #fff;
    }

    th, td {
      border: 1px solid #ddd;
      padding: 8px;
      vertical-align: top;
      font-size: 14px;
    }

    th {
      background: #f0f0f0;
      text-align: left;
    }

    .impact.critical { color: #b00020; font-weight: bold; }
    .impact.serious  { color: #e65100; font-weight: bold; }
    .impact.moderate { color: #f9a825; font-weight: bold; }
    .impact.minor    { color: #2e7d32; font-weight: bold; }

    .tag {
      display: inline-block;
      background: #e0e0e0;
      padding: 2px 6px;
      margin: 2px;
      border-radius: 4px;
      font-size: 12px;
    }

    details summary {
      cursor: pointer;
      color: #1565c0;
    }

    .failure {
      margin-top: 4px;
      color: #c62828;
      font-size: 13px;
    }

    .empty {
      font-style: italic;
      color: #777;
      margin-bottom: 40px;
    }

    details {
      margin-bottom: 30px;
    }

    summary {
      background: #e3f2fd;
      padding: 10px;
      border-radius: 6px;
    }

    details[open] summary {
      margin-bottom: 15px;
    }

  </style>
</head>

<body>

  <h1>Accessibility Scan Report</h1>
  <div class="meta">
    <div><strong>URL:</strong> ${escapeHtml(url)}</div>
    <div><strong>Generated:</strong> ${new Date().toLocaleString()}</div>
  </div>

  ${renderTable("Violations", results.violations)}
  ${renderTable("Passes", results.passes)}
  ${renderTable("Manual Review", manualReview)}
  ${renderTable("Incomplete", incompleteNonManual)}
  ${renderTable("Inapplicable", results.inapplicable)}

</body>
</html>
`;
}


/**
 * Send START_SCAN to the currently active tab
 */
function triggerScanOnActiveTab() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs || !tabs.length) return;

    chrome.tabs.sendMessage(
      tabs[0].id,
      { type: "START_SCAN" },
      () => {
        if (chrome.runtime.lastError) {
          console.warn(
            "[BG] START_SCAN failed:",
            chrome.runtime.lastError.message
          );
        } else {
          console.log("[BG] START_SCAN sent to active tab");
        }
      }
    );
  });
}

function setScanState(active) {
  chrome.storage.local.set({ scanState: { active } });
}

function getScanState(callback) {
  chrome.storage.local.get("scanState", (data) => {
    callback(data.scanState?.active === true);
  });
}


chrome.runtime.onMessage.addListener((msg, sender) => {

  /**
   * ---------------------------------------------------------
   * Popup → Start scanning
   * ---------------------------------------------------------
   */
  if (msg.action === "START") {
    aggregatedResults = [];
    setScanState(true);
    console.log("[BG] Scanning session STARTED");
    triggerScanOnActiveTab();
  }

  /**
   * ---------------------------------------------------------
   * Popup → Stop scanning
   * ---------------------------------------------------------
   */
  if (msg.action === "STOP") {
    setScanState(false);
    console.log("[BG] Scanning session STOPPED");

    // ======================================================
    // [ADDED] Generate SUMMARY report on Stop Scanning
    // ======================================================
    if (!aggregatedResults.length) {
      console.warn("[BG] No pages scanned. Summary report not generated.");
      return;
    }

    const summaryHtml = buildSummaryHtmlReport(aggregatedResults);

    const dataUrl =
      "data:text/html;charset=utf-8," + encodeURIComponent(summaryHtml);

    chrome.downloads.download(
      {
        url: dataUrl,
        filename: `accessibility-summary-report-${Date.now()}.html`,
        saveAs: false
      },
      (downloadId) => {
        if (chrome.runtime.lastError) {
          console.error(
            "[BG] Summary Report download failed:",
            chrome.runtime.lastError.message
          );
        } else {
          console.log("[BG] Summary Report downloaded, ID:", downloadId);
        }
      }
    );

    // Optional reset for next session
    aggregatedResults = [];
  }


  function buildSummaryHtmlReport(pages) {

    function escapeHtml(str) {
      if (!str) return "";
      return str.replace(/[&<>"']/g, m => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        "\"": "&quot;",
        "'": "&#039;"
      }[m]));
    }

    function renderNodes(nodes) {
      if (!nodes || !nodes.length) return "—";

      return `
        <details>
          <summary>${nodes.length} element(s)</summary>
          <ul>
            ${nodes.map(n => `
              <li>
                <code>${escapeHtml(n.target.join(" "))}</code>
                ${n.failureSummary ? `<div class="failure">${escapeHtml(n.failureSummary)}</div>` : ""}
              </li>
            `).join("")}
          </ul>
        </details>
      `;
    }

    // ------------------------------------------------------
    // [ADDED] Flatten results across ALL pages
    // ------------------------------------------------------
    function flatten(type) {
      return pages.flatMap(p =>
        (p.results[type] || []).map(item => ({
          ...item,
          pageUrl: p.url
        }))
      );
    }

    function renderSummaryByPage(pages) {
      return `
        <h2>Summary by Page</h2>
        <table>
          <thead>
            <tr>
              <th>Page URL</th>
              <th>Violations</th>
              <th>Passes</th>
              <th>Incomplete</th>
              <th>Inapplicable</th>
            </tr>
          </thead>
          <tbody>
            ${pages.map(p => `
              <tr>
                <td class="url">${escapeHtml(p.url)}</td>
                <td>${p.results.violations?.length || 0}</td>
                <td>${p.results.passes?.length || 0}</td>
                <td>${p.results.incomplete?.length || 0}</td>
                <td>${p.results.inapplicable?.length || 0}</td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      `;
    }

    function aggregateByRule(pages) {
      const ruleMap = {};

      pages.forEach(page => {
        const url = page.url;

        ["violations", "passes", "incomplete", "inapplicable"].forEach(type => {
          (page.results[type] || []).forEach(rule => {
            if (!ruleMap[rule.id]) {
              ruleMap[rule.id] = {
                id: rule.id,
                description: rule.description,
                impact: rule.impact || "—",
                tags: rule.tags || [],
                occurrences: 0,
                pages: new Set()
              };
            }

            ruleMap[rule.id].occurrences += rule.nodes?.length || 1;
            ruleMap[rule.id].pages.add(url);
          });
        });
      });

      return Object.values(ruleMap).map(r => ({
        ...r,
        pageCount: r.pages.size
      }));
    }


    function renderSummaryByRule(rules) {

      if (!Array.isArray(rules)) {
        console.warn("[BG] Rule summary skipped – invalid data");
        return "";
      }


      if (!rules.length) {
        return `<h2>Summary by Rule</h2><p class="empty">No rules found.</p>`;
      }

      return `
        <h2>Summary by Rule</h2>
        <table>
          <thead>
            <tr>
              <th>Rule ID</th>
              <th>Description</th>
              <th>Impact</th>
              <th>Tags</th>
              <th>Occurrences</th>
              <th>Pages Affected</th>
            </tr>
          </thead>
          <tbody>
            ${rules.map(r => `
              <tr>
                <td>${escapeHtml(r.id)}</td>
                <td>${escapeHtml(r.description)}</td>
                <td class="impact ${r.impact}">${r.impact}</td>
                <td>
                  ${(r.tags || []).map(t => `<span class="tag">${t}</span>`).join("")}
                </td>
                <td>${r.occurrences}</td>
                <td>${r.pageCount || 0}</td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      `;
    }




    function renderTable(title, items) {
      if (!items.length) {
        return `
          <h2>${title} (0)</h2>
          <p class="empty">No ${title.toLowerCase()} found.</p>
        `;
      }

      return `
        <h2>${title} (${items.length})</h2>
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>Rule ID</th>
              <th>Description</th>
              <th>Impact</th>
              <th>Tags</th>
              <th>Page URL</th>
              <th>Affected Elements</th>
              <th>Help</th>
            </tr>
          </thead>
          <tbody>
            ${items.map((item, index) => `
              <tr>
                <td>${index + 1}</td>
                <td>${escapeHtml(item.id)}</td>
                <td>${escapeHtml(item.description)}</td>
                <td class="impact ${item.impact || "none"}">
                  ${item.impact || "—"}
                </td>
                <td>
                  ${item.tags.map(t => `<span class="tag">${t}</span>`).join("")}
                </td>
                <td class="url">${escapeHtml(item.pageUrl)}</td>
                <td>${renderNodes(item.nodes)}</td>
                <td>
                  <a href="${item.helpUrl}" target="_blank">Reference</a>
                </td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      `;
    }

    const violations = flatten("violations");
    const passes = flatten("passes");
    const incomplete = flatten("incomplete");
    const inapplicable = flatten("inapplicable");

    const rulesSummary = aggregateByRule(aggregatedResults);

    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>Accessibility Summary Report</title>

        <style>
          body { font-family: Arial, sans-serif; padding: 20px; background: #fafafa; }
          h1 { margin-bottom: 10px; }
          table { width: 100%; border-collapse: collapse; margin-bottom: 40px; background: #fff; }
          th, td { border: 1px solid #ddd; padding: 8px; font-size: 14px; vertical-align: top; }
          th { background: #f0f0f0; }
          .impact.critical { color: #b00020; font-weight: bold; }
          .impact.serious  { color: #e65100; font-weight: bold; }
          .impact.moderate { color: #f9a825; font-weight: bold; }
          .impact.minor    { color: #2e7d32; font-weight: bold; }
          .tag { background: #e0e0e0; padding: 2px 6px; margin: 2px; border-radius: 4px; font-size: 12px; display: inline-block; }
          .url { font-size: 12px; word-break: break-all; color: #1565c0; }
          .empty { font-style: italic; color: #777; }
          details summary { cursor: pointer; color: #1565c0; }
          .failure { margin-top: 4px; color: #c62828; }
        </style>
      </head>

      <body>

      <h1>Accessibility Summary Report</h1>
      <p><strong>Generated:</strong> ${new Date().toLocaleString()}</p>
      <p><strong>Total Pages Scanned:</strong> ${pages.length}</p>

      
       <!-- ✅ NEW SECTION -->

      <details>
        <summary style="font-size:18px;font-weight:bold;cursor:pointer;">
          Summary by Rule
        </summary>
        ${renderSummaryByRule(rulesSummary)}
      </details>

      <details>
        <summary style="font-size:18px;font-weight:bold;cursor:pointer;">
          Summary by Page
        </summary>
        ${renderSummaryByPage(aggregatedResults)}
      </details>

      ${renderTable("Violations", violations)}
      ${renderTable("Passes", passes)}
      ${renderTable("Incomplete", incomplete)}
      ${renderTable("Inapplicable", inapplicable)}

    </body>
    </html>
      `;
  }




  if (msg.action === "SCAN_CURRENT_PAGE") {
    console.log("[BG] Scan current page requested");
    manualScanInProgress = true;
    triggerScanOnActiveTab();
  }

  /**
   * ---------------------------------------------------------
   * Content script → Page ready
   * Auto-scan on navigation if session active
   * ---------------------------------------------------------
   */
  if (msg.type === "PAGE_READY") {
    console.log("[BG] PAGE_READY:", msg.url);

    //Skip auto-scan if manual scan is running
    if (manualScanInProgress) {
      console.log("[BG] Skipping auto-scan due to manual scan in progress");
      return;
    }

    getScanState((isActive) => {
      if (isActive && sender.tab?.id) {
        chrome.tabs.sendMessage(sender.tab.id, { type: "START_SCAN" });
        console.log("[BG] START_SCAN sent due to PAGE_READY");
      }
    });
  }


  /**
   * ---------------------------------------------------------
   * Content script → Axe results received
   * ---------------------------------------------------------
   */
  if (msg.type === "AXE_RESULTS") {
    console.log("[BG] AXE_RESULTS received for:", msg.url);

    getScanState((isActive) => {
      
      // ✅ Allow download for manual OR automated scan
      if (!isActive && !manualScanInProgress) {
        console.log("[BG] Ignoring AXE_RESULTS – no active scan");
        return;
      }

      // -----------------------------------------------------
      // 1. Aggregate results for summary
      // -----------------------------------------------------
      aggregatedResults.push({
        url: msg.url,
        results: msg.payload
      });

      console.log("[BG] Results aggregated for:", msg.url,
        "Total pages:", aggregatedResults.length
      );


      const html = buildHtmlReport({
        url: msg.url,
        results: msg.payload
      });

      const dataUrl =
        "data:text/html;charset=utf-8," + encodeURIComponent(html);

      chrome.downloads.download(
        {
          url: dataUrl,
          filename: `accessibility-report-${Date.now()}.html`,
          saveAs: false
        },
        (downloadId) => {
          if (chrome.runtime.lastError) {
            console.error(
              "[BG] Page Report download failed:",
              chrome.runtime.lastError.message
            );
          } else {
            console.log("[BG] Page Report downloaded, ID:", downloadId);
          }

          if (manualScanInProgress) {
            manualScanInProgress = false;
            console.log("[BG] Manual scan completed");
          }
        }
      );
});
    return true;
}
});
