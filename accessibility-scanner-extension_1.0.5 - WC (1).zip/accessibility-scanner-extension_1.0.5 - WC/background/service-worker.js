/**
 * Accessibility Scanner Background Service Worker (MV3)
 */

import { normalizeAxeResults } from "../normalization/axe-normalizer.js";

// ---------------------------------------------------------
// In-memory aggregation for current scan session
// ---------------------------------------------------------
let manualScanInProgress = false;
let manualScanId = null;
let startScanCompletionId = null;
let startScanTimeoutId = null;
let pendingPageReadyScan = null;
const extVersion = chrome.runtime.getManifest().version;
let aggregatedResults = [];

const reportDefaults = {
  showDebugDetails: true,
  showNormalizedOutput: true,
};

function getReportClientHelpers() {
  return `
      function escapeHtml(str) {
        if (!str) return "";
        return str.replace(/[&<>"']/g, function (m) {
          return {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
          }[m];
        });
      }

      function escapeAttr(str) {
        return escapeHtml(String(str || "")).replace(/\\n/g, "&#10;");
      }

      function parseColorToRgb(value) {
        if (!value) return null;
        var raw = String(value).trim().toLowerCase();
        if (!raw || raw === "transparent" || raw === "none") return null;
        var rgbMatch = raw.match(/^rgba?\\(([^)]+)\\)$/);
        if (rgbMatch) {
          var parts = rgbMatch[1].split(",").map(function (p) { return p.trim(); });
          if (parts.length < 3) return null;
          var r = parseFloat(parts[0]);
          var g = parseFloat(parts[1]);
          var b = parseFloat(parts[2]);
          if ([r, g, b].some(function (n) { return !Number.isFinite(n); })) return null;
          return { r: r, g: g, b: b };
        }
        var hexMatch = raw.match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i);
        if (hexMatch) {
          var hex = hexMatch[1];
          if (hex.length === 3) {
            hex = hex.split("").map(function (c) { return c + c; }).join("");
          }
          var intVal = parseInt(hex, 16);
          return {
            r: (intVal >> 16) & 255,
            g: (intVal >> 8) & 255,
            b: intVal & 255
          };
        }
        return null;
      }

      function relativeLuminance(rgb) {
        if (!rgb) return null;
        function toLin(c) {
          var cs = c / 255;
          return cs <= 0.03928 ? cs / 12.92 : Math.pow((cs + 0.055) / 1.055, 2.4);
        }
        var r = toLin(rgb.r);
        var g = toLin(rgb.g);
        var b = toLin(rgb.b);
        return 0.2126 * r + 0.7152 * g + 0.0722 * b;
      }

      function formatLuminance(value) {
        if (value === null || value === undefined) return "n/a";
        return Number(value).toFixed(3);
      }

      function formatRgb(rgb) {
        if (!rgb) return "n/a";
        return "rgb(" + rgb.r + ", " + rgb.g + ", " + rgb.b + ")";
      }

      function formatContrastFormula(l1, l2) {
        if (l1 === null || l2 === null || l1 === undefined || l2 === undefined) return "";
        var high = Math.max(l1, l2);
        var low = Math.min(l1, l2);
        return "(" + high.toFixed(3) + " + 0.05) / (" + low.toFixed(3) + " + 0.05)";
      }

      function colorNameFromRgb(rgb) {
        if (!rgb) return "unknown";
        var palette = [
          { name: "black", r: 0, g: 0, b: 0 },
          { name: "white", r: 255, g: 255, b: 255 },
          { name: "red", r: 255, g: 0, b: 0 },
          { name: "green", r: 0, g: 128, b: 0 },
          { name: "blue", r: 0, g: 0, b: 255 },
          { name: "yellow", r: 255, g: 255, b: 0 },
          { name: "cyan", r: 0, g: 255, b: 255 },
          { name: "magenta", r: 255, g: 0, b: 255 },
          { name: "gray", r: 128, g: 128, b: 128 },
          { name: "light gray", r: 211, g: 211, b: 211 },
          { name: "dark gray", r: 64, g: 64, b: 64 },
          { name: "orange", r: 255, g: 165, b: 0 },
          { name: "brown", r: 165, g: 42, b: 42 },
          { name: "purple", r: 128, g: 0, b: 128 }
        ];
        var best = palette[0];
        var bestDist = Infinity;
        for (var i = 0; i < palette.length; i += 1) {
          var entry = palette[i];
          var dr = rgb.r - entry.r;
          var dg = rgb.g - entry.g;
          var db = rgb.b - entry.b;
          var dist = dr * dr + dg * dg + db * db;
          if (dist < bestDist) {
            bestDist = dist;
            best = entry;
          }
        }
        return best && best.name ? best.name : "unknown";
      }

      function copyText(text) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          return navigator.clipboard.writeText(text);
        }
        return new Promise(function (resolve, reject) {
          try {
            var textarea = document.createElement("textarea");
            textarea.value = text;
            textarea.style.position = "fixed";
            textarea.style.opacity = "0";
            document.body.appendChild(textarea);
            textarea.focus();
            textarea.select();
            var ok = document.execCommand("copy");
            document.body.removeChild(textarea);
            if (ok) resolve();
            else reject(new Error("copy failed"));
          } catch (err) {
            reject(err);
          }
        });
      }
    `;
}

function escapeHtml(str) {
  if (!str) return "";
  return String(str).replace(
    /[&<>"']/g,
    (m) =>
      ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;",
      })[m]
  );
}

function escapeAttr(str) {
  return escapeHtml(String(str || "")).replace(/\n/g, "&#10;");
}

function parseColorToRgb(value) {
  if (!value) return null;
  const raw = String(value).trim().toLowerCase();
  if (!raw || raw === "transparent" || raw === "none") return null;
  const rgbMatch = raw.match(/^rgba?\(([^)]+)\)$/);
  if (rgbMatch) {
    const parts = rgbMatch[1].split(",").map((p) => p.trim());
    if (parts.length < 3) return null;
    const r = parseFloat(parts[0]);
    const g = parseFloat(parts[1]);
    const b = parseFloat(parts[2]);
    if ([r, g, b].some((n) => !Number.isFinite(n))) return null;
    return { r, g, b };
  }
  const hexMatch = raw.match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i);
  if (hexMatch) {
    let hex = hexMatch[1];
    if (hex.length === 3) {
      hex = hex
        .split("")
        .map((c) => c + c)
        .join("");
    }
    const intVal = parseInt(hex, 16);
    return {
      r: (intVal >> 16) & 255,
      g: (intVal >> 8) & 255,
      b: intVal & 255,
    };
  }
  return null;
}

function relativeLuminance(rgb) {
  if (!rgb) return null;
  const toLin = (c) => {
    const cs = c / 255;
    return cs <= 0.03928 ? cs / 12.92 : Math.pow((cs + 0.055) / 1.055, 2.4);
  };
  const r = toLin(rgb.r);
  const g = toLin(rgb.g);
  const b = toLin(rgb.b);
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

function formatLuminance(value) {
  if (value === null || value === undefined) return "n/a";
  return Number(value).toFixed(3);
}

function formatRgb(rgb) {
  if (!rgb) return "n/a";
  return `rgb(${rgb.r}, ${rgb.g}, ${rgb.b})`;
}

function formatContrastFormula(l1, l2) {
  if (l1 === null || l2 === null || l1 === undefined || l2 === undefined) return "";
  const high = Math.max(l1, l2);
  const low = Math.min(l1, l2);
  return `(${high.toFixed(3)} + 0.05) / (${low.toFixed(3)} + 0.05)`;
}

function colorNameFromRgb(rgb) {
  if (!rgb) return "unknown";
  const palette = [
    { name: "black", r: 0, g: 0, b: 0 },
    { name: "white", r: 255, g: 255, b: 255 },
    { name: "red", r: 255, g: 0, b: 0 },
    { name: "green", r: 0, g: 128, b: 0 },
    { name: "blue", r: 0, g: 0, b: 255 },
    { name: "yellow", r: 255, g: 255, b: 0 },
    { name: "cyan", r: 0, g: 255, b: 255 },
    { name: "magenta", r: 255, g: 0, b: 255 },
    { name: "gray", r: 128, g: 128, b: 128 },
    { name: "light gray", r: 211, g: 211, b: 211 },
    { name: "dark gray", r: 64, g: 64, b: 64 },
    { name: "orange", r: 255, g: 165, b: 0 },
    { name: "brown", r: 165, g: 42, b: 42 },
    { name: "purple", r: 128, g: 0, b: 128 },
  ];
  let best = palette[0];
  let bestDist = Number.POSITIVE_INFINITY;
  for (const entry of palette) {
    const dr = rgb.r - entry.r;
    const dg = rgb.g - entry.g;
    const db = rgb.b - entry.b;
    const dist = dr * dr + dg * dg + db * db;
    if (dist < bestDist) {
      bestDist = dist;
      best = entry;
    }
  }
  return best?.name || "unknown";
}

function createScanId() {
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function sanitizeFilenamePart(value) {
  if (!value) return "unknown";
  return (
    String(value)
      .toLowerCase()
      .replace(/[^a-z0-9.-]+/g, "_")
      .replace(/^_+|_+$/g, "") || "unknown"
  );
}

function formatTimestampSeconds(date) {
  const pad = (num) => String(num).padStart(2, "0");
  const yyyy = date.getFullYear();
  const mm = pad(date.getMonth() + 1);
  const dd = pad(date.getDate());
  const hh = pad(date.getHours());
  const min = pad(date.getMinutes());
  const ss = pad(date.getSeconds());
  return `${yyyy}${mm}${dd}_${hh}${min}${ss}`;
}

function buildPageReportFilename(url) {
  let host = "unknown";
  try {
    host = new URL(url).hostname || host;
  } catch (_) {
    // ignore invalid URL
  }
  const safeHost = sanitizeFilenamePart(host);
  const timestamp = formatTimestampSeconds(new Date());
  return `accessibility-report-${safeHost}-${timestamp}.html`;
}

function getReportSettings(callback) {
  chrome.storage.local.get("reportSettings", (data) => {
    const settings = Object.assign({}, reportDefaults, data.reportSettings || {});
    callback(settings);
  });
}

function buildHtmlReport(payload, options = {}) {
  const { url, results, suppressionMetadata, phase1Filtered } = payload;
  const showDebugDetails = options.showDebugDetails !== false;
  const isNormalized = options.showNormalizedOutput === true;
  const suppressionIndex = buildSuppressionIndex(suppressionMetadata);
  const filterIndex = buildFilterIndex(phase1Filtered);

  function targetKey(target) {
    if (Array.isArray(target)) return JSON.stringify(target);
    if (target === null || target === undefined) return "";
    return String(target);
  }

  function nodeTargetValue(node) {
    if (Array.isArray(node?.target) && node.target.length) return node.target;
    if (typeof node?.xpath === "string" && node.xpath) return [node.xpath];
    return [];
  }

  function buildFilterIndex(items) {
    const index = new Map();
    if (!Array.isArray(items)) return index;
    items.forEach((entry) => {
      if (!entry || !entry.ruleId) return;
      const key = targetKey(nodeTargetValue(entry.node || {}));
      if (!key) return;
      if (!index.has(entry.ruleId)) index.set(entry.ruleId, new Map());
      index.get(entry.ruleId).set(key, entry.reason || "FILTERED:CSS_HIDDEN");
    });
    return index;
  }

  function formatFilterReason(reason) {
    if (!reason) return "UNKNOWN";
    return String(reason).replace(/^FILTERED:/, "");
  }

  function buildSuppressionIndex(metadata) {
    const index = new Map();
    if (!Array.isArray(metadata)) return index;
    metadata.forEach((entry) => {
      if (!entry || !entry.ruleId) return;
      if (!index.has(entry.ruleId)) index.set(entry.ruleId, new Map());
      const ruleMap = index.get(entry.ruleId);
      const key = targetKey(entry.suppressedNodeTarget);
      if (!key) return;
      ruleMap.set(key, {
        reason: entry.reason || "ANCESTOR_SUPPRESSED",
        keptNodeXPath: entry.keptNodeXPath || "",
        keptNodeTarget: entry.keptNodeTarget || [],
      });
    });
    return index;
  }

  function getNodeStatus(ruleId, node) {
    if (!isNormalized) return null;
    const filterMap = filterIndex.get(ruleId);
    const filterKey = targetKey(nodeTargetValue(node));
    if (filterMap && filterMap.has(filterKey)) {
      return {
        status: "filtered",
        reason: filterMap.get(filterKey),
      };
    }
    const ruleMap = suppressionIndex.get(ruleId);
    const key = targetKey(nodeTargetValue(node));
    if (ruleMap && ruleMap.has(key)) {
      const detail = ruleMap.get(key);
      return {
        status: "removed",
        reason: detail.reason,
        keptNodeXPath: detail.keptNodeXPath,
        keptNodeTarget: detail.keptNodeTarget,
      };
    }
    return { status: "normalized" };
  }

  function formatTarget(target) {
    if (Array.isArray(target)) return target.join(", ");
    if (target === null || target === undefined) return "";
    return String(target);
  }

  function renderStatusBadge(ruleId, node) {
    const status = getNodeStatus(ruleId, node);
    if (!status) return "";
    if (status.status === "filtered") {
      return `<span class="badge filtered">filtering: ${escapeHtml(formatFilterReason(status.reason))}</span>`;
    }
    if (status.status === "removed") {
      const kept = status.keptNodeXPath || "";
      const keptTarget = formatTarget(status.keptNodeTarget);
      const keptLabel = kept
        ? escapeHtml(kept)
        : keptTarget
          ? escapeHtml(keptTarget)
          : "xpath unavailable";
      return `
        <span class="badge removed">removed: ${escapeHtml(status.reason)}</span>
        <div class="badge-sub">kept: ${keptLabel}</div>
      `;
    }
    return `<span class="badge normalized">normalized</span>`;
  }

  function renderNodes(nodes, ruleId, ruleImpact, sectionName) {
    if (!nodes || !nodes.length) return "";
    const isCustomRule = String(ruleId || "").startsWith("custom");
    const isViolation = sectionName === "Violations";
    const showDebugForSection = sectionName === "Violations" || sectionName === "Incomplete";
    const showBuiltInMinimal = isViolation && !isCustomRule;
    const showFixGuidance = isViolation && isCustomRule;
    const renderFixGuidanceSafe =
      typeof renderFixGuidance === "function" ? renderFixGuidance : null;

    function getFailureSummary(node) {
      if (!node) return "";
      const checks = [].concat(node.any || [], node.all || [], node.none || []);
      const checkWithMessage = checks.find((check) => check?.message);
      return checkWithMessage?.message || node?.failureSummary || "";
    }

    function findTextSpacingData(node) {
      if (!node) return null;
      const checks = [].concat(node.any || [], node.all || [], node.none || []);
      return checks.find((check) => check.id === "sc-1412-text-spacing-no-clipping" && check.data)
        ?.data;
    }

    function renderTextSpacingDebug(data) {
      if (!data) return "";
      const style = data.style || {};
      const metrics = data.metrics || {};
      const clipping = data.clipping || {};
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "Clipped after spacing")}</dd></div>
            <div><dt>ClipX</dt><dd>${clipping.clippedX}</dd></div>
            <div><dt>ClipY</dt><dd>${clipping.clippedY}</dd></div>
            ${data.baselineClipping ? `<div><dt>BaselineClipX</dt><dd>${escapeHtml(String(data.baselineClipping.clippedX))}</dd></div>` : ""}
            ${data.baselineClipping ? `<div><dt>BaselineClipY</dt><dd>${escapeHtml(String(data.baselineClipping.clippedY))}</dd></div>` : ""}
            <div><dt>OverflowX</dt><dd>${escapeHtml(style.overflowX || "")}</dd></div>
            <div><dt>OverflowY</dt><dd>${escapeHtml(style.overflowY || "")}</dd></div>
            <div><dt>Width</dt><dd>${escapeHtml(style.width || "")}</dd></div>
            <div><dt>MaxWidth</dt><dd>${escapeHtml(style.maxWidth || "")}</dd></div>
            <div><dt>Height</dt><dd>${escapeHtml(style.height || "")}</dd></div>
            <div><dt>MaxHeight</dt><dd>${escapeHtml(style.maxHeight || "")}</dd></div>
            <div><dt>ScrollH</dt><dd>${metrics.scrollHeight}</dd></div>
            <div><dt>ClientH</dt><dd>${metrics.clientHeight}</dd></div>
            <div><dt>ScrollW</dt><dd>${metrics.scrollWidth}</dd></div>
            <div><dt>ClientW</dt><dd>${metrics.clientWidth}</dd></div>
            ${data.baselineMetrics ? `<div><dt>Baseline Metrics</dt><dd>${escapeHtml(JSON.stringify(data.baselineMetrics))}</dd></div>` : ""}
          </dl>
        </div>
      `;
    }

    function renderOnFocusDebug(node) {
      const checks = [].concat(node.any || [], node.all || [], node.none || []);
      const data = checks.find(
        (check) => check.id === "sc-321-inline-onfocus-context-change" && check.data
      )?.data;
      if (!data) return "";
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "")}</dd></div>
            <div><dt>Matched Patterns</dt><dd>${escapeHtml((data.patterns || []).join(", "))}</dd></div>
          </dl>
          ${data.handler ? `<div><strong>Handler</strong></div><pre class="debug-code">${escapeHtml(data.handler)}</pre>` : ""}
        </div>
      `;
    }

    function renderOnInputDebug(node) {
      const checks = [].concat(node.any || [], node.all || [], node.none || []);
      const data = checks.find(
        (check) => check.id === "sc-322-inline-oninput-context-change" && check.data
      )?.data;
      if (!data) return "";
      const handlers = Array.isArray(data.handlers) ? data.handlers : [];
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "")}</dd></div>
            <div><dt>Matched Patterns</dt><dd>${escapeHtml((data.patterns || []).join(", "))}</dd></div>
          </dl>
          ${handlers.length ? `<div><strong>Handlers</strong></div><pre class="debug-code">${escapeHtml(handlers.join("\n"))}</pre>` : ""}
        </div>
      `;
    }

    function renderFocusNotObscuredDebug(node) {
      if (!node) return "";
      const checks = [].concat(node.any || [], node.all || [], node.none || []);
      const check = checks.find((item) => item.id === "sc-2411-focus-not-obscured-minimum-visible");
      const data = check?.data || null;
      const reason = data?.reason || check?.message || node?.failureSummary || "";
      if (!reason && !data) return "";
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(reason)}</dd></div>
            ${
              data?.boundingBox
                ? `
              <div><dt>Bounding Box</dt><dd>${escapeHtml(JSON.stringify(data.boundingBox))}</dd></div>
            `
                : ""
            }
            ${
              data?.viewport
                ? `
              <div><dt>Viewport</dt><dd>${escapeHtml(JSON.stringify(data.viewport))}</dd></div>
            `
                : ""
            }
            ${
              Array.isArray(data?.samplePoints)
                ? `
              <div><dt>Sample Points</dt><dd>
                <ul class="debug-list">
                  ${data.samplePoints
                    .map(
                      (p) =>
                        `<li>${escapeHtml(`${p.x},${p.y} -> ${p.visible ? "visible" : "covered"} (${p.topElement || "unknown"})`)}</li>`
                    )
                    .join("")}
                </ul>
              </dd></div>
            `
                : ""
            }
          </dl>
        </div>
      `;
    }

    function getConsistentIdentificationData(node) {
      const checks = [].concat(node.any || [], node.all || [], node.none || []);
      return checks.find((check) => check.id === "sc-324-consistent-identification" && check.data)
        ?.data;
    }

    function renderConsistentIdentificationDebug(node) {
      const data = getConsistentIdentificationData(node);
      if (!data) return "";
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            ${data.outcome ? `<div><dt>Outcome</dt><dd>${escapeHtml(data.outcome)}</dd></div>` : ""}
            ${data.visibilityState ? `<div><dt>Visibility</dt><dd>${escapeHtml(data.visibilityState)}</dd></div>` : ""}
            ${data.visibilityReason ? `<div><dt>Visibility Reason</dt><dd>${escapeHtml(data.visibilityReason)}</dd></div>` : ""}
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "")}</dd></div>
            <div><dt>Key</dt><dd>${escapeHtml(data.key || "")}</dd></div>
            <div><dt>Current Name</dt><dd>${escapeHtml(data.currentName || "")}</dd></div>
            <div><dt>Group Size</dt><dd>${escapeHtml(String(data.groupSize ?? ""))}</dd></div>
            <div><dt>Distinct Names</dt><dd>${escapeHtml((data.distinctNames || []).join(", "))}</dd></div>
          </dl>
        </div>
      `;
    }

    function renderConsistentIdentificationGroupDebug(data, groupSize) {
      if (!data) return "";
      const size = data.groupSize ?? groupSize ?? "";
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            ${data.outcome ? `<div><dt>Outcome</dt><dd>${escapeHtml(data.outcome)}</dd></div>` : ""}
            ${data.visibilityState ? `<div><dt>Visibility</dt><dd>${escapeHtml(data.visibilityState)}</dd></div>` : ""}
            ${data.visibilityReason ? `<div><dt>Visibility Reason</dt><dd>${escapeHtml(data.visibilityReason)}</dd></div>` : ""}
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "")}</dd></div>
            <div><dt>Key</dt><dd>${escapeHtml(data.key || "")}</dd></div>
            <div><dt>Group Size</dt><dd>${escapeHtml(String(size))}</dd></div>
            <div><dt>Distinct Names</dt><dd>${escapeHtml((data.distinctNames || []).join(", "))}</dd></div>
          </dl>
        </div>
      `;
    }

    function renderHoverFocusContentDebug(node) {
      const checks = [].concat(node.any || [], node.all || [], node.none || []);
      const data = checks.find(
        (check) => check.id === "sc-1413-title-tooltip-disallowed" && check.data
      )?.data;
      if (!data) return "";
      const matchedPatterns = Array.isArray(data.matchedPatterns) ? data.matchedPatterns : [];
      const matchedHandlers = Array.isArray(data.matchedHandlers) ? data.matchedHandlers : [];
      const dismissSignals = Array.isArray(data.dismissSignalsFound)
        ? data.dismissSignalsFound
        : [];
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "")}</dd></div>
            <div><dt>Outcome</dt><dd>${escapeHtml(data.outcome || "")}</dd></div>
            <div><dt>Trigger Type</dt><dd>${escapeHtml(data.triggerType || "")}</dd></div>
            <div><dt>Matched Patterns</dt><dd>${escapeHtml(matchedPatterns.join(", "))}</dd></div>
            <div><dt>Matched Handlers</dt><dd>${escapeHtml(matchedHandlers.join(", "))}</dd></div>
            <div><dt>Dismiss Signals</dt><dd>${escapeHtml(dismissSignals.join(", "))}</dd></div>
            <div><dt>Dismiss Scope</dt><dd>${escapeHtml(data.dismissScope || "")}</dd></div>
            <div><dt>Interactive</dt><dd>${escapeHtml(String(data.isInteractive ?? ""))}</dd></div>
            <div><dt>Hidden</dt><dd>${escapeHtml(String(data.isHidden ?? ""))}</dd></div>
          </dl>
        </div>
      `;
    }

    function renderHeadingsLabelsDebug(node) {
      if (!node) return "";
      const checks = [].concat(node.any || [], node.all || [], node.none || []);
      const data = checks.find(
        (check) => check.id === "sc-246-heading-label-has-text" && check.data
      )?.data;
      const fallbackReason =
        checks.find((check) => check?.message)?.message || node?.failureSummary || "";
      if (!data && !fallbackReason) return "";
      const labelled = data ? data.ariaLabelledby || {} : {};
      const labelledIds = Array.isArray(labelled.ids) ? labelled.ids.join(", ") : "";
      const labelledTexts = Array.isArray(labelled.texts) ? labelled.texts.join(", ") : "";
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data?.reason || fallbackReason || "")}</dd></div>
            ${
              data
                ? `
              <div><dt>Hidden</dt><dd>${escapeHtml(String(data.hidden ?? ""))}</dd></div>
              <div><dt>Source</dt><dd>${escapeHtml(data.source || "")}</dd></div>
              <div><dt>Text</dt><dd>${escapeHtml(data.textContent || "")}</dd></div>
              <div><dt>Aria Label</dt><dd>${escapeHtml(data.ariaLabel || "")}</dd></div>
              <div><dt>Aria Labelledby Ids</dt><dd>${escapeHtml(labelledIds)}</dd></div>
              <div><dt>Aria Labelledby Text</dt><dd>${escapeHtml(labelledTexts)}</dd></div>
            `
                : ""
            }
          </dl>
        </div>
      `;
    }

    function renderReflowDebug(node) {
      const checks = [].concat(node.any || [], node.all || [], node.none || []);
      const data = checks.find(
        (check) => check.id === "sc-1410-reflow-min-width-over-320" && check.data
      )?.data;
      if (!data) return "";
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "")}</dd></div>
            <div><dt>Outcome</dt><dd>${escapeHtml(data.outcome || "fail")}</dd></div>
            ${data.riskType ? `<div><dt>Risk Type</dt><dd>${escapeHtml(data.riskType)}</dd></div>` : ""}
            <div><dt>MinWidth</dt><dd>${escapeHtml(String(data.minWidth ?? ""))}</dd></div>
            <div><dt>InlineWidth</dt><dd>${escapeHtml(String(data.inlineWidth ?? ""))}</dd></div>
            <div><dt>Limit</dt><dd>${escapeHtml(String(data.limit ?? ""))}</dd></div>
            ${data.clipX !== undefined ? `<div><dt>ClipX</dt><dd>${escapeHtml(String(data.clipX))}</dd></div>` : ""}
            ${data.clipY !== undefined ? `<div><dt>ClipY</dt><dd>${escapeHtml(String(data.clipY))}</dd></div>` : ""}
            ${data.metrics ? `<div><dt>Metrics</dt><dd>${escapeHtml(JSON.stringify(data.metrics))}</dd></div>` : ""}
            ${data.boundingBox ? `<div><dt>Bounding Box</dt><dd>${escapeHtml(JSON.stringify(data.boundingBox))}</dd></div>` : ""}
            ${Array.isArray(data.samplePoints) ? `<div><dt>Sample Points</dt><dd>${escapeHtml(JSON.stringify(data.samplePoints))}</dd></div>` : ""}
            ${data.style ? `<div><dt>Style</dt><dd>${escapeHtml(JSON.stringify(data.style))}</dd></div>` : ""}
          </dl>
        </div>
      `;
    }

    function renderJsonBlock(label, payload) {
      if (!payload) return "";
      return `
        <div><strong>${escapeHtml(label)}</strong></div>
        <pre class="debug-code">${escapeHtml(JSON.stringify(payload, null, 2))}</pre>
      `;
    }

    function renderNonTextContrastDebug(node) {
      if (!node) return "";
      const checks = [].concat(node.any || [], node.all || [], node.none || []);
      const check = checks.find((item) => item.id === "sc-1411-non-text-contrast-min-3");
      const data = check?.data || node?.__nonTextContrastDebug;
      let fallbackReason = check?.message || node?.failureSummary || "";
      if (
        !data?.reason &&
        fallbackReason &&
        fallbackReason.toLowerCase().includes("fix any of the following")
      ) {
        fallbackReason =
          "Boundary not deterministically found for native form controls (e.g., input/select/textarea/button) (as it is browser/OS rendered); requires manual review.";
      }

      if (!data && !fallbackReason) return "";

      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data?.reason || fallbackReason || "")}</dd></div>
              ${
                data
                  ? `
                <div><dt>State</dt><dd>${escapeHtml(String(data.state || ""))}</dd></div>
                <div><dt>Boundary Type</dt><dd>${escapeHtml(String(data.boundaryType || ""))}</dd></div>
                ${data.boundarySource ? `<div><dt>Boundary Source</dt><dd>${escapeHtml(String(data.boundarySource || ""))}</dd></div>` : ""}
                ${data.boundaryColor ? `<div><dt>Boundary Color</dt><dd>${escapeHtml(String(data.boundaryColor))}</dd></div>` : ""}
                ${data.backgroundColor ? `<div><dt>Adjacent Background</dt><dd>${escapeHtml(String(data.backgroundColor))}</dd></div>` : ""}
                <div><dt>Ratio</dt><dd>${escapeHtml(String(data.ratio ?? ""))}</dd></div>
                <div><dt>Min Contrast</dt><dd>${escapeHtml(String(data.minContrast ?? ""))}</dd></div>
                ${data.note ? `<div><dt>Note</dt><dd>${escapeHtml(String(data.note))}</dd></div>` : ""}
                ${
                  data.determinism
                    ? `
                  <div><dt>Element Background Deterministic</dt><dd>${escapeHtml(String(data.determinism.deterministic))}</dd></div>
                  <div><dt>Background Opaque</dt><dd>${escapeHtml(String(data.determinism.backgroundOpaque))}</dd></div>
                  <div><dt>No Background Image</dt><dd>${escapeHtml(String(data.determinism.noBackgroundImage))}</dd></div>
                  <div><dt>No Visible Pseudo</dt><dd>${escapeHtml(String(data.determinism.noVisiblePseudo))}</dd></div>
                  <div><dt>No Non-text Descendants</dt><dd>${escapeHtml(String(data.determinism.noNonTextDescendants))}</dd></div>
                  <div><dt>No Boundary Children</dt><dd>${escapeHtml(String(data.determinism.noBoundaryChildren))}</dd></div>
                  <div><dt>Min Size OK</dt><dd>${escapeHtml(String(data.determinism.sizeOk))}</dd></div>
                `
                    : ""
                }
              `
                  : ""
              }
            </dl>
          ${data ? renderJsonBlock("Tester Debug", data.testerDebug) : ""}
          ${data ? renderJsonBlock("Engine Debug", data.engineDebug) : ""}
          ${data ? renderJsonBlock("State Results", data.stateResults) : ""}
        </div>
      `;
    }

    function getGenericDebugData(node) {
      if (!node) return { reason: "n/a", checkIds: [] };
      const checks = [].concat(node.any || [], node.all || [], node.none || []);
      const checkWithReason = checks.find((check) => check?.data?.reason);
      const checkWithMessage = checks.find((check) => check?.message);
      const reason =
        checkWithReason?.data?.reason || checkWithMessage?.message || node?.failureSummary || "";
      const checkIds = checks.map((check) => check.id).filter(Boolean);
      return {
        reason,
        checkIds,
      };
    }

    function renderGenericDebug(node, impact) {
      const data = getGenericDebugData(node);
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "n/a")}</dd></div>
            <div><dt>Check IDs</dt><dd>${escapeHtml(data.checkIds.length ? data.checkIds.join(", ") : "n/a")}</dd></div>
            <div><dt>Impact</dt><dd>${escapeHtml(impact || "n/a")}</dd></div>
          </dl>
        </div>
      `;
    }

    function renderRuleDebug(node, ruleId, impact) {
      if (ruleId === "custom-wcag22-sc-1412-text-spacing") {
        return renderTextSpacingDebug(findTextSpacingData(node));
      }
      if (ruleId === "custom-wcag22-sc-1410-reflow") {
        return renderReflowDebug(node);
      }
      if (ruleId === "custom-wcag22-sc-1413-hover-focus-content") {
        return renderHoverFocusContentDebug(node);
      }
      if (ruleId === "custom-wcag22-sc-246-headings-labels") {
        return renderHeadingsLabelsDebug(node);
      }
      if (ruleId === "custom-wcag22-sc-331-error-identification") {
        return renderGenericDebug(node, impact);
      }
      if (ruleId === "custom-wcag22-sc-321-on-focus") {
        return renderOnFocusDebug(node);
      }
      if (ruleId === "custom-wcag22-sc-322-on-input") {
        return renderOnInputDebug(node);
      }
      if (ruleId === "custom-wcag22-sc-2411-focus-not-obscured-minimum") {
        return renderFocusNotObscuredDebug(node);
      }
      if (ruleId === "custom-wcag22-sc-324-consistent-identification") {
        return renderConsistentIdentificationDebug(node);
      }
      if (ruleId === "custom-wcag22-sc-1411-non-text-contrast") {
        return renderNonTextContrastDebug(node);
      }
      return renderGenericDebug(node, impact);
    }

    function getCheckData(node, checkId) {
      const checks = [].concat(node.any || [], node.all || [], node.none || []);
      return checks.find((check) => check.id === checkId)?.data || null;
    }

    function renderFixGuidance(node, ruleId) {
      if (!showFixGuidance) return "";
      if (!node || !ruleId) return "";
      const diagnosis = [];
      const fixes = [];
      const component = [];
      const observed = [];
      const locator = node?.xpath ? `xpath: ${node.xpath}` : formatNodeTarget(node) || "";
      const locatorLine = locator ? `Element: ${locator}` : "";
      const rawHtml = (node?.html || "").toLowerCase();
      const targetHint = (Array.isArray(node?.target) ? node.target.join(" ") : "").toLowerCase();
      const componentHint = rawHtml || targetHint;
      const isHeading = /<h[1-6]\b/.test(componentHint) || /\bh[1-6]\b/.test(componentHint);
      const isParagraph = /<p\b/.test(componentHint) || /\bp\b/.test(componentHint);
      const isLink = /<a\b/.test(componentHint) || /\ba\b/.test(componentHint);
      const isButton = /<button\b/.test(componentHint) || /\bbutton\b/.test(componentHint);
      const isInput = /<input\b/.test(componentHint) || /\binput\b/.test(componentHint);

      if (ruleId === "custom-wcag22-sc-1411-non-text-contrast") {
        const data =
          getCheckData(node, "sc-1411-non-text-contrast-min-3") ||
          node?.__nonTextContrastDebug ||
          null;
        if (!data) return "";
        diagnosis.push("Non-text UI component or focus indicator is below 3:1 contrast.");
        fixes.push(
          "Ensure non-text UI components and focus indicators have at least 3:1 contrast against adjacent colors."
        );
        if (data.ratio !== null && data.ratio !== undefined) {
          observed.push(`Contrast ratio: ${data.ratio} (minimum ${data.minContrast || 3}).`);
        }
        const colors = data.colors || {};
        const boundaryColor = data.boundaryColor || colors.borderColor || colors.outlineColor || "";
        const backgroundColor = data.backgroundColor || colors.backgroundColor || "";
        const boundaryRgb = parseColorToRgb(boundaryColor);
        const backgroundRgb = parseColorToRgb(backgroundColor);
        const boundaryLum = relativeLuminance(boundaryRgb);
        const backgroundLum = relativeLuminance(backgroundRgb);
        const boundaryName = colorNameFromRgb(boundaryRgb);
        const backgroundName = colorNameFromRgb(backgroundRgb);
        const contrastFormula = formatContrastFormula(boundaryLum, backgroundLum);
        const outlineWidth = (colors.outlineWidth || "").trim();
        const borderWidth = (colors.borderWidth || "").trim();
        if (outlineWidth && outlineWidth !== "0px") {
          fixes.push(
            "This looks like an outline/focus indicator. Increase outline color contrast or thickness."
          );
          if (colors.outlineColor) {
            observed.push(
              `Outline color: ${colorNameFromRgb(parseColorToRgb(colors.outlineColor))}, width: ${outlineWidth || "n/a"}.`
            );
          }
        } else if (borderWidth && borderWidth !== "0px") {
          fixes.push(
            "This looks like a border. Increase border color contrast against the background."
          );
          if (colors.borderColor) {
            observed.push(
              `Border color: ${colorNameFromRgb(parseColorToRgb(colors.borderColor))}, width: ${borderWidth || "n/a"}.`
            );
          }
        } else {
          fixes.push(
            "Increase contrast for the component fill/background against adjacent colors."
          );
          if (colors.backgroundColor) {
            observed.push(
              `Background color: ${colorNameFromRgb(parseColorToRgb(colors.backgroundColor))}.`
            );
          }
        }
        if (boundaryColor) {
          observed.push(
            `Boundary color: ${boundaryName} (${formatRgb(boundaryRgb)}), luminance ${formatLuminance(boundaryLum)}.`
          );
        }
        if (backgroundColor) {
          observed.push(
            `Adjacent background: ${backgroundName} (${formatRgb(backgroundRgb)}), luminance ${formatLuminance(backgroundLum)}.`
          );
        }
        if (contrastFormula) {
          observed.push(`Contrast formula: ${contrastFormula}.`);
        }
        if (isButton || isLink || isInput) {
          component.push(
            "For interactive controls, ensure the control boundary or focus ring meets 3:1 against the adjacent color."
          );
        }
      }

      if (ruleId === "custom-wcag22-sc-1412-text-spacing") {
        const data = findTextSpacingData(node);
        if (!data) return "";
        diagnosis.push(
          "Text is clipped after applying WCAG text spacing (line-height 1.5, letter-spacing 0.12em, word-spacing 0.16em)."
        );
        fixes.push("Allow increased text spacing without clipping.");
        const clipX = data.clipping?.clippedX;
        const clipY = data.clipping?.clippedY;
        if (clipX || clipY) {
          const axis =
            clipX && clipY ? "horizontal and vertical" : clipX ? "horizontal" : "vertical";
          diagnosis.push(`Text is clipped on the ${axis} axis after spacing changes.`);
        }
        if (
          data.style?.overflowX === "hidden" ||
          data.style?.overflowY === "hidden" ||
          data.style?.overflowX === "clip" ||
          data.style?.overflowY === "clip"
        ) {
          fixes.push(
            "Avoid overflow: hidden/clip when fixed dimensions are used. Prefer min-height/auto height or allow overflow."
          );
          observed.push(
            `OverflowX: ${data.style?.overflowX || "n/a"}, OverflowY: ${data.style?.overflowY || "n/a"}.`
          );
        }
        if (data.baselineClipping?.clippedX || data.baselineClipping?.clippedY) {
          diagnosis.push(
            "The text was already clipped before spacing changes. Fix base layout or sizing first."
          );
        }
        if (data.style) {
          observed.push(
            `Size: width ${data.style.width || "n/a"}, height ${data.style.height || "n/a"}, max-width ${data.style.maxWidth || "n/a"}, max-height ${data.style.maxHeight || "n/a"}.`
          );
        }
        if (data.textStyle) {
          observed.push(
            `Text style: font-size ${data.textStyle.fontSize || "n/a"}, line-height ${data.textStyle.lineHeight || "n/a"}, letter-spacing ${data.textStyle.letterSpacing || "n/a"}, word-spacing ${data.textStyle.wordSpacing || "n/a"}.`
          );
        }
        if (data.spacingApplied) {
          observed.push(
            `Applied spacing: line-height ${data.spacingApplied.lineHeight || "n/a"}, letter-spacing ${data.spacingApplied.letterSpacing || "n/a"}, word-spacing ${data.spacingApplied.wordSpacing || "n/a"}.`
          );
        } else {
          observed.push(
            "Applied spacing: line-height 1.5, letter-spacing 0.12em, word-spacing 0.16em."
          );
        }
        if (data.metrics) {
          observed.push(
            `After spacing: scrollH ${data.metrics.scrollHeight}, clientH ${data.metrics.clientHeight}, scrollW ${data.metrics.scrollWidth}, clientW ${data.metrics.clientWidth}.`
          );
        }
        if (data.baselineMetrics) {
          observed.push(
            `Before spacing: scrollH ${data.baselineMetrics.scrollHeight}, clientH ${data.baselineMetrics.clientHeight}, scrollW ${data.baselineMetrics.scrollWidth}, clientW ${data.baselineMetrics.clientWidth}.`
          );
        }
        if (isHeading) {
          component.push(
            "For headings, allow wrapping and remove fixed heights so larger line-height can expand."
          );
        } else if (isParagraph) {
          component.push(
            "For paragraphs, avoid fixed height and allow line wrapping to prevent clipping."
          );
        } else if (isLink || isButton) {
          component.push(
            "For interactive labels, avoid truncation on the label itself; let the container grow."
          );
        }
      }

      if (ruleId === "custom-wcag22-sc-2411-focus-not-obscured-minimum") {
        const data = getCheckData(node, "sc-2411-focus-not-obscured-minimum-visible");
        if (!data) return "";
        diagnosis.push(
          "Focusable element is covered by another element at one or more sampled points."
        );
        fixes.push("Ensure the focused element is not covered by other content.");
        if (Array.isArray(data.obscuredBy) && data.obscuredBy.length) {
          observed.push(`Covered by: ${data.obscuredBy.join(", ")}.`);
        }
        if (data.targetStyle) {
          observed.push(
            `Target style: position ${data.targetStyle.position || "n/a"}, z-index ${data.targetStyle.zIndex || "n/a"}, overflow ${data.targetStyle.overflow || "n/a"}.`
          );
        }
        if (data.obscuredPointCount !== undefined) {
          observed.push(`Obscured points: ${data.obscuredPointCount}.`);
        }
        if (data.boundingBox) {
          observed.push(`Bounding box: ${JSON.stringify(data.boundingBox)}.`);
        }
        if (data.viewport) {
          observed.push(`Viewport: ${JSON.stringify(data.viewport)}.`);
        }
        fixes.push(
          "Adjust z-index or layout of overlays/sticky headers, or add scroll padding so focus is visible."
        );
        if (isLink || isButton || isInput) {
          component.push(
            "Ensure sticky headers/footers don’t overlap focusable controls in the viewport."
          );
        }
      }

      if (ruleId === "custom-wcag22-sc-324-consistent-identification") {
        const data = getCheckData(node, "sc-324-consistent-identification");
        if (!data) return "";
        diagnosis.push("Elements with the same destination/id have inconsistent accessible names.");
        fixes.push(
          "Use the same accessible name for controls that share the same destination or consistent ID."
        );
        if (Array.isArray(data.distinctNames) && data.distinctNames.length) {
          observed.push(`Current names differ: ${data.distinctNames.join(", ")}.`);
        }
        if (data.keyType) {
          observed.push(
            `Consistency key: ${data.keyType} ${data.href || data.dataConsistentId || ""}`.trim() +
              "."
          );
        }
        if (data.groupSize !== undefined) {
          observed.push(`Group size: ${data.groupSize}.`);
        }
        if (data.currentName) {
          observed.push(`Current name: ${data.currentName}.`);
        }
        if (isLink || isButton) {
          component.push(
            "For repeated links/buttons, keep the visible label and accessible name consistent."
          );
        }
      }

      if (ruleId === "custom-wcag22-sc-1413-hover-focus-content") {
        const data = getCheckData(node, "sc-1413-title-tooltip-disallowed");
        if (!data) return "";
        diagnosis.push("Hover/focus content is not dismissible, or relies on the title attribute.");
        if (data.reason === "TITLE_TOOLTIP") {
          fixes.push("Avoid using the title attribute as hover/focus content.");
          fixes.push(
            "Provide a persistent tooltip/popover that remains on hover/focus and can be dismissed."
          );
          if (data.title) observed.push(`Title attribute: ${data.title}.`);
        } else {
          fixes.push(
            "Ensure hover/focus-triggered content is dismissible and remains visible while the pointer or focus is on it."
          );
          if (!data.hasEscapeHandler) {
            fixes.push("Add a clear dismiss mechanism, such as Escape or a close button.");
          }
          if (Array.isArray(data.matchedHandlers) && data.matchedHandlers.length) {
            observed.push(`Inline handlers: ${data.matchedHandlers.join(", ")}.`);
          }
        }
        if (data.dismissSignalsFound && data.dismissSignalsFound.length) {
          observed.push(`Dismiss signals: ${data.dismissSignalsFound.join(", ")}.`);
        }
        if (isLink || isButton) {
          component.push(
            "For interactive triggers, ensure hover/focus content can be dismissed without moving the pointer or focus."
          );
        }
      }

      if (ruleId === "custom-wcag22-sc-246-headings-labels") {
        const data = getCheckData(node, "sc-246-heading-label-has-text");
        if (!data) return "";
        diagnosis.push("Heading/label is missing accessible text.");
        if (!data.accessibleName) {
          fixes.push(
            "Add descriptive text or an accessible name using aria-label or aria-labelledby."
          );
        } else {
          fixes.push(
            "Ensure headings and labels remain descriptive and consistent with the visible text."
          );
        }
        if (data.hidden) {
          fixes.push("Make sure the heading/label is not hidden from assistive technology.");
        }
        if (data.tagName) {
          observed.push(
            `Element: <${data.tagName}> role=${data.role || "n/a"} id=${data.id || "n/a"}.`
          );
        }
        if (isHeading) {
          component.push(
            "Headings should describe the section purpose and be visible to assistive tech."
          );
        } else if (isInput || isButton) {
          component.push(
            "Form controls should have a visible label tied via <label> or aria-labelledby."
          );
        }
      }

      if (ruleId === "custom-wcag22-sc-331-error-identification") {
        const data = getCheckData(node, "sc-331-error-message-present");
        if (!data) return "";

        const elementTypeEi = /\bselect\b/.test(componentHint)
          ? "select"
          : /\btextarea\b/.test(componentHint)
            ? "textarea"
            : (() => {
                const m = componentHint.match(/type="([^"]+)"/);
                return m ? `input[type="${m[1]}"]` : "form control";
              })();

        diagnosis.push(
          `This ${elementTypeEi} does not reference any error message container via ` +
            `aria-describedby or aria-errormessage. When this field has a validation ` +
            `error, users relying on assistive technology will not be informed of the error.`
        );

        fixes.push(
          "Add an aria-describedby or aria-errormessage attribute to this form control " +
            "pointing to an element that contains the error message."
        );
        fixes.push(
          "Ensure the referenced error message element is present in the DOM and " +
            "contains descriptive error text when the field fails validation."
        );
        fixes.push(
          "Link error messages to the form control so assistive technology can announce " +
            "validation failures when the user moves focus to the field."
        );

        const describedByValEi =
          Array.isArray(data.ariaDescribedByIds) && data.ariaDescribedByIds.length
            ? data.ariaDescribedByIds.join(", ")
            : "not set";
        const errorMsgValEi =
          Array.isArray(data.ariaErrorMessageIds) && data.ariaErrorMessageIds.length
            ? data.ariaErrorMessageIds.join(", ")
            : "not set";

        observed.push(`Form element: ${elementTypeEi}.`);
        observed.push(`aria-describedby: ${describedByValEi}.`);
        observed.push(`aria-errormessage: ${errorMsgValEi}.`);

        if (isInput) {
          component.push(
            "Form controls must programmatically associate error messages so that " +
              "screen readers can announce validation failures when the user moves " +
              "focus to the field."
          );
        }
      }

      if (!diagnosis.length && !fixes.length && !component.length && !observed.length) return "";
      const suggestedFixText = fixes.join("\n");
      return `
        <div class="fix-guidance">
          <div class="fix-title">Fix Guidance</div>
          ${locatorLine ? `<div class="fix-meta">${escapeHtml(locatorLine)}</div>` : ""}
          <div class="fix-actions">
            ${locatorLine ? `<button class="copy-btn" data-copy="${escapeAttr(locatorLine)}">Copy locator</button>` : ""}
            ${fixes.length ? `<button class="copy-btn" data-copy="${escapeAttr(suggestedFixText)}">Copy suggested fix</button>` : ""}
          </div>
          ${
            diagnosis.length
              ? `
            <div class="fix-subtitle">Diagnosis</div>
            <ul class="fix-list">
              ${diagnosis.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}
            </ul>
          `
              : ""
          }
          ${diagnosis.length && fixes.length ? `<div class="fix-divider"></div>` : ""}
          ${
            fixes.length
              ? `
            <div class="fix-subtitle">Actionable Fixes</div>
            <ul class="fix-list">
              ${fixes.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}
            </ul>
          `
              : ""
          }
          ${(diagnosis.length || fixes.length) && observed.length ? `<div class="fix-divider"></div>` : ""}
          ${
            observed.length
              ? `
            <div class="fix-subtitle">Observed Values</div>
            <ul class="fix-list">
              ${observed.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}
            </ul>
          `
              : ""
          }
          ${(diagnosis.length || fixes.length || observed.length) && component.length ? `<div class="fix-divider"></div>` : ""}
          ${
            component.length
              ? `
            <div class="fix-subtitle">Component-Aware Suggestions</div>
            <ul class="fix-list">
              ${component.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}
            </ul>
          `
              : ""
          }
        </div>
      `;
    }

    function formatNodeTarget(node) {
      if (node?.__uniqueTarget) return node.__uniqueTarget;
      if (Array.isArray(node?.target) && node.target.length) {
        return node.target.join(", ");
      }
      return "";
    }

    function renderNodeDetails(node, alwaysShow) {
      const targetLabel = formatNodeTarget(node);
      if (!alwaysShow && !node?.xpath && !targetLabel && !node?.html) return "";
      const xpathLabel = node?.xpath ? node.xpath : "n/a";
      const targetOutput = !node?.xpath ? targetLabel || "n/a" : targetLabel;
      const hasCopyableTarget = !node?.xpath && targetOutput && targetOutput !== "n/a";
      return `
    <div class="debug-block">
      <div class="debug-title" style="display:flex;align-items:center;gap:12px;">Node Details${hasCopyableTarget ? ` <button class="copy-target-btn" data-copy="${escapeAttr(targetOutput)}">Copy target</button>` : ""}</div>
      <div><strong>XPath:</strong> ${escapeHtml(xpathLabel)}</div>
      ${!node?.xpath ? `<div><strong>Target:</strong> ${escapeHtml(targetOutput)}</div>` : ""}
      ${node.html ? `<div><strong>HTML:</strong></div><pre class="debug-code">${escapeHtml(node.html)}</pre>` : ""}
    </div>
  `;
    }

    function renderBuiltInMinimal(node) {
      const targetLabel = formatNodeTarget(node) || "n/a";
      const failureSummary = getFailureSummary(node) || "n/a";
      const hasCopyableTarget = targetLabel && targetLabel !== "n/a";
      return `
        <div class="debug-block">
          <div style="display:flex;align-items:center;gap:12px;margin-bottom:4px;"><strong>Details</strong>${hasCopyableTarget ? ` <button class="copy-target-btn" data-copy="${escapeAttr(targetLabel)}">Copy target</button>` : ""}</div>
          <div><strong>Target:</strong> ${escapeHtml(targetLabel)}</div>
          <div><strong>Summary:</strong> ${escapeHtml(failureSummary)}</div>
        </div>
      `;
    }

    function renderConsistentIdentificationGroups(nodes) {
      const groups = [];
      const indexByKey = new Map();

      nodes.forEach((node, index) => {
        const data = getConsistentIdentificationData(node);
        const key = data?.key || `__unknown_${index}`;
        let groupIndex = indexByKey.get(key);
        if (groupIndex === undefined) {
          groupIndex = groups.length;
          indexByKey.set(key, groupIndex);
          groups.push({ key, data: data || null, nodes: [] });
        }
        const group = groups[groupIndex];
        if (!group.data && data) group.data = data;
        group.nodes.push(node);
      });

      return `
          <details>
            <summary>Consistent Identification Groups (${groups.length})</summary>
            <div class="group-list">
              ${groups
                .map(
                  (group, idx) => `
                <details>
                  <summary>Group ${idx + 1}: ${group.nodes.length} element(s)</summary>
                  ${showDebugDetails ? renderConsistentIdentificationGroupDebug(group.data, group.nodes.length) : ""}
                  <ul>
                    ${group.nodes
                      .map(
                        (node) => `
                      <li>
                        ${renderStatusBadge(ruleId, node)}
                        ${renderNodeDetails(node, true)}
                        ${renderFixGuidanceSafe ? renderFixGuidanceSafe(node, ruleId, sectionName) : ""}
                      </li>
                    `
                      )
                      .join("")}
                  </ul>
                </details>
              `
                )
                .join("")}
            </div>
          </details>
        `;
    }

    if (
      isViolation &&
      isCustomRule &&
      ruleId === "custom-wcag22-sc-324-consistent-identification"
    ) {
      return renderConsistentIdentificationGroups(nodes);
    }

    const filteredCount = isNormalized
      ? nodes.filter((node) => {
          const ruleMap = filterIndex.get(ruleId);
          if (!ruleMap) return false;
          return ruleMap.has(targetKey(nodeTargetValue(node)));
        }).length
      : 0;
    const removedCount = isNormalized
      ? nodes.filter((node) => {
          const ruleMap = suppressionIndex.get(ruleId);
          if (!ruleMap) return false;
          return ruleMap.has(targetKey(nodeTargetValue(node)));
        }).length
      : 0;
    const visibleCount = nodes.length - filteredCount - removedCount;
    const countLabel =
      isNormalized && (filteredCount > 0 || removedCount > 0)
        ? `${visibleCount} of ${nodes.length} element(s)`
        : `${nodes.length} element(s)`;

    return `
      <details>
        <summary>${countLabel}</summary>
        <ul>
          ${nodes
            .map(
              (n, idx) => `
            <li>
              <span class="element-counter">Element ${idx + 1}</span>
              ${renderStatusBadge(ruleId, n)}
              ${isViolation ? renderNodeDetails(n, true) : ""}
              ${showFixGuidance && renderFixGuidanceSafe ? renderFixGuidanceSafe(n, ruleId, sectionName) : ""}
              ${showDebugForSection && showDebugDetails ? renderRuleDebug(n, ruleId, ruleImpact) : ""}
            </li>
          `
            )
            .join("")}
        </ul>
      </details>
    `;
  }

  function renderNodesLazyPlaceholder(nodes, ruleId, ruleImpact, sectionName) {
    if (!nodes || !nodes.length) return "";
    const payload = {
      ruleId,
      ruleImpact,
      sectionName,
      nodes,
    };
    const json = JSON.stringify(payload).replace(/</g, "\\u003c");
    const countLabel = `${nodes.length} element(s)`;
    return `
      <div class="lazy-count">${countLabel}</div>
      <div class="lazy-nodes" data-section="${escapeHtml(sectionName)}" data-rule-id="${escapeHtml(ruleId)}"></div>
      <script type="application/json" class="nodes-data" data-section="${escapeHtml(sectionName)}" data-rule-id="${escapeHtml(ruleId)}">${json}</script>
    `;
  }

  function formatDate(date) {
    const months = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ];
    const day = date.getDate();
    const month = months[date.getMonth()];
    const year = date.getFullYear();
    const ordinal =
      day === 1 || day === 21 || day === 31
        ? "st"
        : day === 2 || day === 22
          ? "nd"
          : day === 3 || day === 23
            ? "rd"
            : "th";
    const pad = (n) => String(n).padStart(2, "0");
    const time = `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
    return `${day}${ordinal} ${month}, ${year}, ${time}`;
  }

  function renderTable(title, items) {
    if (!items || !items.length) {
      return `
        <h2>${title} (0)</h2>
        <p class="empty">No ${title.toLowerCase()} found.</p>
      `;
    }
    const showLazyToggle = title === "Passes" || title === "Incomplete";
    const sectionKey = String(title || "")
      .toLowerCase()
      .replace(/\s+/g, "-");

    return `
      <div class="section" id="section-${escapeHtml(sectionKey)}" data-section="${escapeHtml(sectionKey)}" data-page-size="5">
        <div class="section-header">
          <h2>${title} (${items.length})</h2>
          <div class="section-controls">
            ${
              showLazyToggle
                ? `
              <label class="section-toggle">
                <input type="checkbox" class="toggle-details" data-section="${escapeHtml(title)}">
                Show node/debug details
              </label>
            `
                : ""
            }
          </div>
        </div>
        <table data-section="${escapeHtml(sectionKey)}">
          <thead>
            <tr>
              <th>#</th>
              <th>Rule ID</th>
              <th>Description</th>
              <th>Impact</th>
              <th>Tags</th>
              <th>Affected Elements</th>
              <th>Help</th>
            </tr>
          </thead>
          <tbody>
            ${items
              .map(
                (item, index) => `
              <tr data-row-index="${index}">
                <td>${index + 1}</td>
                <td>${escapeHtml(item.id)}</td>
                <td>${escapeHtml(item.description)}</td>
                <td>
                  <span class="impact ${item.impact || "none"}">
                    ${item.impact || ""}
                  </span>
                </td>
                <td>
                  ${item.tags.map((t) => `<span class="tag">${t}</span>`).join("")}
                </td>
                <td>${
                  title === "Violations"
                    ? renderNodes(item.nodes, item.id, item.impact, title)
                    : showLazyToggle
                      ? renderNodesLazyPlaceholder(item.nodes, item.id, item.impact, title)
                      : ""
                }</td>
                <td>
                  <a href="${item.helpUrl}" target="_blank">Reference</a>
                </td>
              </tr>
            `
              )
              .join("")}
          </tbody>
        </table>
        <div class="pagination-footer" data-section="${escapeHtml(sectionKey)}">
          <div class="page-status">Showing 0-0 of 0 entries</div>
          <div class="pagination" data-section="${escapeHtml(sectionKey)}">
            <button class="page-prev" type="button" disabled>Previous</button>
            <div class="page-links"></div>
            <button class="page-next" type="button" disabled>Next</button>
          </div>
        </div>
      </div>
    `;
  }

  const manualReview = (results.incomplete || []).filter(
    (item) => item.tags && item.tags.includes("manual-review")
  );
  const incompleteNonManual = (results.incomplete || []).filter(
    (item) => !item.tags || !item.tags.includes("manual-review")
  );

  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Accessibility Report</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

:root {
  --brand: #2563eb;
  --bg: #f0f2f5;
  --surface: #ffffff;
  --surface-alt: #f8fafc;
  --border: #e2e8f0;
  --text: #0f172a;
  --muted: #64748b;
  --critical: #dc2626; --critical-bg: #fef2f2; --critical-bd: #fca5a5;
  --serious:  #ea580c; --serious-bg:  #fff7ed; --serious-bd:  #fdba74;
  --moderate: #d97706; --moderate-bg: #fffbeb; --moderate-bd: #fcd34d;
  --minor:    #16a34a; --minor-bg:    #f0fdf4; --minor-bd:    #86efac;
  --radius: 8px;
  --shadow: 0 1px 3px rgba(0,0,0,.08), 0 1px 2px rgba(0,0,0,.04);
}
* { box-sizing: border-box; }
body { font-family: 'Inter', Arial, sans-serif; background: var(--bg); color: var(--text); margin: 0; padding: 0; font-size: 14px; line-height: 1.6; }

.report-header { background: #1e293b; color: #fff; padding: 20px 32px; display: flex; align-items: flex-start; justify-content: space-between; gap: 16px; flex-wrap: wrap; }
.report-header h1 { margin: 0 0 6px; font-size: 26px; font-weight: 700; letter-spacing: -.3px; }
.meta-row { display: flex; flex-wrap: wrap; gap: 16px; font-size: 14px; color: #94a3b8; }
.meta-row strong { color: #cbd5e1; margin-right: 4px; }
.meta-row a { color: #60a5fa; text-decoration: none; word-break: break-all; }
.meta-row a:hover { text-decoration: underline; }
.report-badge { background: var(--brand); color: #fff; padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .5px; align-self: flex-start; white-space: nowrap; }

.stats-bar { display: flex; border-bottom: 1px solid var(--border); background: var(--surface); }
.stat-cell { flex: 1; padding: 14px 24px; border-right: 1px solid var(--border); }
.stat-cell:last-child { border-right: none; }
.stat-num { display: block; font-size: 26px; font-weight: 700; line-height: 1; letter-spacing: -1px; margin-bottom: 2px; }
.stat-label { font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: .5px; color: #475569; }
.stat-cell.violations .stat-num { color: var(--critical); }
.stat-cell.incomplete  .stat-num { color: var(--moderate); }
.stat-cell.passes      .stat-num { color: var(--minor); }
a.stat-cell { display: block; text-decoration: none; color: inherit; cursor: pointer; transition: background .15s; }
a.stat-cell:hover { background: #eff6ff; }
html { scroll-behavior: smooth; }

.report-body { padding: 28px 32px; max-width: 1400px; margin: 0 auto; }

.section { margin-bottom: 28px; }
.section-header { display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; margin-bottom: 10px; }
.section-header h2 { margin: 0; font-size: 17px; font-weight: 700; display: flex; align-items: center; gap: 8px; }
.section-header h2::before { content: ''; display: inline-block; width: 4px; height: 16px; border-radius: 2px; background: var(--brand); flex-shrink: 0; }
.section[data-section="violations"]                     .section-header h2::before { background: var(--critical); }
.section[data-section="incomplete"]                     .section-header h2::before { background: var(--moderate); }
.section[data-section="incomplete-needs-manual-review"] .section-header h2::before { background: var(--moderate); }
.section[data-section="passes"]                         .section-header h2::before { background: var(--minor); }
.section-controls { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }
.section-toggle { display: flex; align-items: center; gap: 6px; font-size: 12px; color: var(--muted); cursor: pointer; user-select: none; }

table { width: 100%; border-collapse: separate; border-spacing: 0; background: var(--surface); border-radius: var(--radius); box-shadow: var(--shadow); overflow: hidden; margin-bottom: 8px; }
th { background: #f1f5f9; color: var(--muted); font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .5px; padding: 10px 12px; text-align: left; border-bottom: 1px solid var(--border); }
td { padding: 11px 12px; border-bottom: 1px solid var(--border); vertical-align: top; font-size: 13px; }
tr:last-child td { border-bottom: none; }
tbody tr:nth-child(even) td { background: var(--surface-alt); }
tbody tr:hover td { background: #eff6ff; }

.impact { font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .4px; white-space: nowrap; padding: 3px 9px; border-radius: 20px; display: inline-block; }
.impact.critical { background: var(--critical-bg); color: var(--critical); border: 1px solid var(--critical-bd); }
.impact.serious  { background: var(--serious-bg);  color: var(--serious);  border: 1px solid var(--serious-bd);  }
.impact.moderate { background: var(--moderate-bg); color: var(--moderate); border: 1px solid var(--moderate-bd); }
.impact.minor    { background: var(--minor-bg);    color: var(--minor);    border: 1px solid var(--minor-bd);    }

.tag { display: inline-block; background: #eff6ff; color: #2563eb; border: 1px solid #bfdbfe; padding: 2px 7px; margin: 2px; border-radius: 20px; font-size: 11px; font-weight: 500; }

.badge { display: inline-block; margin-bottom: 6px; padding: 2px 8px; border-radius: 20px; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: .3px; }
.badge-sub { font-size: 11px; color: var(--muted); margin: 0 0 6px 2px; word-break: break-word; }
.badge.removed    { background: #fef2f2; color: #991b1b; border: 1px solid #fca5a5; }
.badge.normalized { background: #f0fdf4; color: #166534; border: 1px solid #86efac; }
.badge.filtered   { background: #fff7ed; color: #9a3412; border: 1px solid #fdba74; }

details { margin-bottom: 6px; }
details summary { cursor: pointer; background: #f1f5f9; border: 1px solid var(--border); border-radius: 6px; padding: 7px 12px; font-size: 12px; font-weight: 600; color: var(--brand); list-style: none; display: flex; align-items: center; gap: 6px; user-select: none; transition: background .15s; }
details summary::-webkit-details-marker { display: none; }
details summary::before { content: '›'; font-size: 16px; font-weight: 700; color: var(--brand); transition: transform .2s; display: inline-block; line-height: 1; }
details[open] summary::before { transform: rotate(90deg); }
details[open] summary { background: #dbeafe; border-color: #bfdbfe; border-radius: 6px 6px 0 0; }
details[open] > ul, details[open] > div.group-list { border: 1px solid var(--border); border-top: none; border-radius: 0 0 6px 6px; padding: 8px; background: var(--surface); }
details ul { margin: 0; padding: 0; list-style: none; }
details li { padding: 8px 0; border-bottom: 1px solid var(--border); }
details li:last-child { border-bottom: none; padding-bottom: 0; }

.debug-block { margin-top: 8px; background: #f8fafc; border: 1px solid var(--border); border-left: 3px solid #94a3b8; border-radius: 0 6px 6px 0; padding: 10px 12px; font-size: 12px; }
.debug-title { font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: .5px; color: var(--muted); margin-bottom: 8px; }
.debug-grid { display: grid; grid-template-columns: 160px 1fr; gap: 4px 12px; margin: 0; }
.debug-grid div { display: contents; }
.debug-grid dt { font-weight: 600; color: #475569; }
.debug-grid dd { margin: 0; word-break: break-word; }
.debug-code { margin: 6px 0 0; padding: 8px; background: #0f172a; color: #e2e8f0; border-radius: 4px; font-size: 11px; font-family: 'Courier New', Courier, monospace; white-space: pre-wrap; word-break: break-word; }
.debug-list { margin: 6px 0 0 16px; padding: 0; }
.debug-list li { margin: 2px 0; border-bottom: none; padding: 0; }

.fix-guidance { margin-top: 8px; background: var(--surface); border: 1px solid #fcd34d; border-left: 4px solid #f59e0b; border-radius: 0 6px 6px 0; padding: 12px 14px; font-size: 12px; }
.fix-title { font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: .6px; color: #92400e; margin-bottom: 10px; }
.fix-meta { font-size: 11px; color: var(--muted); margin-bottom: 8px; word-break: break-word; font-family: 'Courier New', Courier, monospace; }
.fix-subtitle { font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: .6px; color: #78350f; margin: 10px 0 4px; }
.fix-divider { height: 1px; background: #fde68a; margin: 8px 0; }
.fix-actions { display: flex; gap: 8px; flex-wrap: wrap; margin: 4px 0 10px; }
.copy-btn { border: 1px solid #d97706; background: transparent; color: #92400e; padding: 4px 10px; font-size: 11px; font-weight: 600; border-radius: 4px; cursor: pointer; transition: background .15s; }
.copy-btn:hover { background: #fef3c7; }
.fix-list { margin: 0; padding: 0; list-style: none; }
.fix-list li { padding: 3px 0 3px 12px; position: relative; border-bottom: none; color: var(--text); }
.fix-list li::before { content: '›'; position: absolute; left: 0; color: #f59e0b; font-weight: 700; }

.builtin-minimal { padding: 6px 0; font-size: 12px; color: var(--muted); }

.element-counter { display: inline-block; background: var(--brand); color: #fff; padding: 2px 7px; border-radius: 12px; font-size: 10px; font-weight: 700; margin-right: 8px; text-transform: uppercase; letter-spacing: 0.3px; }

.target-row { display: flex; align-items: flex-start; gap: 24px; flex-wrap: wrap; }

.copy-target-btn { border: 1px solid #3b82f6; background: transparent; color: #1e40af; padding: 3px 8px; font-size: 11px; font-weight: 600; border-radius: 3px; cursor: pointer; transition: background .15s; white-space: nowrap; }

.copy-target-btn:hover { background: #dbeafe; }

.pagination-footer { display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; margin-top: 8px; padding: 8px 12px; background: var(--surface); border-radius: var(--radius); border: 1px solid var(--border); }
.page-status { font-size: 12px; color: #475569; font-weight: 500; }
.pagination { display: inline-flex; align-items: center; gap: 4px; font-size: 12px; }
.pagination button, .page-link { border: 1px solid var(--border); background: var(--surface); color: var(--text); padding: 4px 10px; border-radius: 4px; cursor: pointer; font-size: 12px; font-weight: 500; transition: background .15s, border-color .15s; }
.pagination button:hover, .page-link:hover { background: #2563eb; border-color: #2563eb; color: #fff; }
.pagination button[disabled] { opacity: .4; cursor: default; }
.pagination button[disabled]:hover { background: var(--surface); border-color: var(--border); color: var(--text); }
.page-link.active { background: var(--brand); border-color: var(--brand); color: #fff; cursor: default; }
.page-links { display: inline-flex; gap: 4px; flex-wrap: wrap; }
.page-ellipsis { padding: 0 4px; color: var(--muted); }

.empty { font-style: italic; color: var(--muted); padding: 24px; text-align: center; background: var(--surface); border-radius: var(--radius); border: 1px dashed var(--border); margin-bottom: 28px; }
a { color: var(--brand); text-decoration: none; font-weight: 500; }
a:hover { text-decoration: underline; }
.url { font-size: 12px; word-break: break-all; color: var(--brand); min-width: 240px; }
  </style>
</head>

  <body>
  <div class="report-header">
    <div>
      <h1>Accessibility Scan Report</h1>
      <div class="meta-row">
        <span><strong>URL:</strong> <a href="${url}" target="_blank">${escapeHtml(url)}</a></span>
        <span><strong>Generated:</strong> ${formatDate(new Date())}</span>
        <span><strong>Version:</strong> ${extVersion}</span>
      </div>
    </div>
    <span class="report-badge">${isNormalized ? "Normalized" : "Raw"}</span>
  </div>
  <div class="stats-bar">
    <a class="stat-cell violations" href="#section-violations">
      <span class="stat-num">${(results.violations || []).length}</span>
      <span class="stat-label">Violations</span>
    </a>
    <a class="stat-cell incomplete" href="#section-incomplete">
      <span class="stat-num">${(incompleteNonManual || []).length}</span>
      <span class="stat-label">Incomplete</span>
    </a>
    <a class="stat-cell passes" href="#section-passes">
      <span class="stat-num">${(results.passes || []).length}</span>
      <span class="stat-label">Passes</span>
    </a>
  </div>
  <div class="report-body">
  

  ${renderTable("Violations", results.violations)}
  ${renderTable("Incomplete", incompleteNonManual)}
  ${renderTable("Passes", results.passes)}
  <!-- ${renderTable("Inapplicable", results.inapplicable)} -->

  </div>
</body>
</html>

  <script>
    (function () {
      ${getReportClientHelpers()}

      function renderNodeDetails(node) {
        var targetLabel = Array.isArray(node && node.target) && node.target.length
          ? node.target.join(", ")
          : "";
        var xpathLabel = node && node.xpath ? node.xpath : "n/a";
        var targetOutput = !node || !node.xpath ? (targetLabel || "n/a") : targetLabel;
        var hasCopyableTarget = (!node || !node.xpath) && targetOutput && targetOutput !== "n/a";
        var html = "";
        html += '<div class="debug-block">';
        html += '<div class="debug-title" style="display:flex;align-items:center;gap:12px;">Node Details' +
          (hasCopyableTarget ? ' <button class="copy-target-btn" data-copy="' + escapeAttr(targetOutput) + '">Copy target</button>' : '') + '</div>';
        html += '<div><strong>XPath:</strong> ' + escapeHtml(xpathLabel) + "</div>";
        if (!node || !node.xpath) {
          html += '<div><strong>Target:</strong> ' + escapeHtml(targetOutput) + "</div>";
        }
        if (node && node.html) {
          html += '<div><strong>HTML:</strong></div>';
          html += '<pre class="debug-code">' + escapeHtml(node.html) + "</pre>";
        }
        html += "</div>";
        return html;
      }

    function renderGenericDebug(node, impact) {
      var checks = []
        .concat((node && node.any) || [], (node && node.all) || [], (node && node.none) || []);
      var reason = "";
        for (var i = 0; i < checks.length; i += 1) {
          if (checks[i] && checks[i].data && checks[i].data.reason) {
            reason = checks[i].data.reason;
            break;
          }
        }
        if (!reason) {
          for (var j = 0; j < checks.length; j += 1) {
            var msg = checks[j] && checks[j].message ? checks[j].message.trim() : "";
            if (msg && !/^fix (any|all) of the following:?$/i.test(msg)) {
              reason = msg;
              break;
            }
          }
        }
        if (!reason && node && node.failureSummary) {
          reason = node.failureSummary
            .replace(/^fix any of the following:\s*/i, "")
            .replace(/^fix all of the following:\s*/i, "")
            .trim();
        }
        if (!reason) return "";

        var checkIds = [];
        for (var k = 0; k < checks.length; k += 1) {
          if (checks[k] && checks[k].id) checkIds.push(checks[k].id);
        }

        var html = "";
        html += '<div class="debug-block">';
        html += '<div class="debug-title">Debug Details</div>';
        html += '<dl class="debug-grid">';
        html += '<div><dt>Reason</dt><dd>' + escapeHtml(reason) + "</dd></div>";
        if (checkIds.length) {
          html += '<div><dt>Check IDs</dt><dd>' + escapeHtml(checkIds.join(", ")) + "</dd></div>";
        }
        if (impact) {
          html += '<div><dt>Impact</dt><dd>' + escapeHtml(impact) + "</dd></div>";
        }
        html += "</dl>";
      html += "</div>";
      return html;
    }

      function renderReflowDebug(node) {
        var checks = []
          .concat((node && node.any) || [], (node && node.all) || [], (node && node.none) || []);
        var data = null;
        for (var i = 0; i < checks.length; i += 1) {
          if (checks[i] && checks[i].id === "sc-1410-reflow-min-width-over-320" && checks[i].data) {
            data = checks[i].data;
            break;
          }
        }
        if (!data) return "";
        var html = "";
        html += '<div class="debug-block">';
        html += '<div class="debug-title">Debug Details</div>';
        html += '<dl class="debug-grid">';
        html += '<div><dt>Reason</dt><dd>' + escapeHtml(data.reason || "") + "</dd></div>";
        html += '<div><dt>Outcome</dt><dd>' + escapeHtml(data.outcome || "fail") + "</dd></div>";
        if (data.riskType) {
          html += '<div><dt>Risk Type</dt><dd>' + escapeHtml(data.riskType) + "</dd></div>";
        }
        html += '<div><dt>MinWidth</dt><dd>' + escapeHtml(String(data.minWidth || "")) + "</dd></div>";
        html += '<div><dt>InlineWidth</dt><dd>' + escapeHtml(String(data.inlineWidth || "")) + "</dd></div>";
        html += '<div><dt>Limit</dt><dd>' + escapeHtml(String(data.limit || "")) + "</dd></div>";
        if (data.clipX !== undefined) {
          html += '<div><dt>ClipX</dt><dd>' + escapeHtml(String(data.clipX)) + "</dd></div>";
        }
        if (data.clipY !== undefined) {
          html += '<div><dt>ClipY</dt><dd>' + escapeHtml(String(data.clipY)) + "</dd></div>";
        }
        if (data.metrics) {
          html += '<div><dt>Metrics</dt><dd>' + escapeHtml(JSON.stringify(data.metrics)) + "</dd></div>";
        }
        if (data.boundingBox) {
          html += '<div><dt>Bounding Box</dt><dd>' + escapeHtml(JSON.stringify(data.boundingBox)) + "</dd></div>";
        }
        if (Array.isArray(data.samplePoints)) {
          html += '<div><dt>Sample Points</dt><dd>' + escapeHtml(JSON.stringify(data.samplePoints)) + "</dd></div>";
        }
        if (data.style) {
          html += '<div><dt>Style</dt><dd>' + escapeHtml(JSON.stringify(data.style)) + "</dd></div>";
        }
        html += "</dl>";
        html += "</div>";
        return html;
      }

      function renderHoverFocusContentDebug(node) {
        var checks = []
          .concat((node && node.any) || [], (node && node.all) || [], (node && node.none) || []);
        var data = null;
        for (var i = 0; i < checks.length; i += 1) {
          if (checks[i] && checks[i].id === "sc-1413-title-tooltip-disallowed" && checks[i].data) {
            data = checks[i].data;
            break;
          }
        }
        if (!data) return "";
        var matchedPatterns = Array.isArray(data.matchedPatterns) ? data.matchedPatterns : [];
        var matchedHandlers = Array.isArray(data.matchedHandlers) ? data.matchedHandlers : [];
        var dismissSignals = Array.isArray(data.dismissSignalsFound) ? data.dismissSignalsFound : [];
        var html = "";
        html += '<div class="debug-block">';
        html += '<div class="debug-title">Debug Details</div>';
        html += '<dl class="debug-grid">';
        html += '<div><dt>Reason</dt><dd>' + escapeHtml(data.reason || "") + "</dd></div>";
        html += '<div><dt>Outcome</dt><dd>' + escapeHtml(data.outcome || "") + "</dd></div>";
        html += '<div><dt>Trigger Type</dt><dd>' + escapeHtml(data.triggerType || "") + "</dd></div>";
        html += '<div><dt>Matched Patterns</dt><dd>' + escapeHtml(matchedPatterns.join(", ")) + "</dd></div>";
        html += '<div><dt>Matched Handlers</dt><dd>' + escapeHtml(matchedHandlers.join(", ")) + "</dd></div>";
        html += '<div><dt>Dismiss Signals</dt><dd>' + escapeHtml(dismissSignals.join(", ")) + "</dd></div>";
        html += '<div><dt>Dismiss Scope</dt><dd>' + escapeHtml(data.dismissScope || "") + "</dd></div>";
        html += '<div><dt>Interactive</dt><dd>' + escapeHtml(String(data.isInteractive !== undefined ? data.isInteractive : "")) + "</dd></div>";
        html += '<div><dt>Hidden</dt><dd>' + escapeHtml(String(data.isHidden !== undefined ? data.isHidden : "")) + "</dd></div>";
        html += "</dl>";
        html += "</div>";
        return html;
      }

      function renderRuleDebug(node, ruleId, impact) {
        if (ruleId === "custom-wcag22-sc-1410-reflow") {
          return renderReflowDebug(node);
        }
        if (ruleId === "custom-wcag22-sc-1413-hover-focus-content") {
          return renderHoverFocusContentDebug(node);
        }
        return renderGenericDebug(node, impact);
      }

      function getCheckData(node, checkId) {
        var checks = []
          .concat((node && node.any) || [], (node && node.all) || [], (node && node.none) || []);
        for (var i = 0; i < checks.length; i += 1) {
          if (checks[i] && checks[i].id === checkId) return checks[i].data || null;
        }
        return null;
      }

      function renderFixGuidance(node, ruleId, sectionName) {
        if (sectionName !== "Violations") return "";
        if (!ruleId || ruleId.indexOf("custom") !== 0) return "";
        var diagnosis = [];
        var fixes = [];
        var component = [];
        var observed = [];
        var locator = node && node.xpath
          ? "xpath: " + node.xpath
          : (Array.isArray(node && node.target) && node.target.length ? node.target.join(", ") : "");
        var locatorLine = locator ? "Element: " + locator : "";
        var rawHtml = (node && node.html ? node.html : "").toLowerCase();
        var targetHint = (Array.isArray(node && node.target) ? node.target.join(" ") : "").toLowerCase();
        var componentHint = rawHtml || targetHint;
        var isHeading = /<h[1-6]\b/.test(componentHint) || /\bh[1-6]\b/.test(componentHint);
        var isParagraph = /<p\b/.test(componentHint) || /\bp\b/.test(componentHint);
        var isLink = /<a\b/.test(componentHint) || /\ba\b/.test(componentHint);
        var isButton = /<button\b/.test(componentHint) || /\bbutton\b/.test(componentHint);
        var isInput = /<input\b/.test(componentHint) || /\binput\b/.test(componentHint);

        if (ruleId === "custom-wcag22-sc-1411-non-text-contrast") {
          var data =
            getCheckData(node, "sc-1411-non-text-contrast-min-3") ||
            (node && node.__nonTextContrastDebug) ||
            null;
          if (!data) return "";
          diagnosis.push("Non-text UI component or focus indicator is below 3:1 contrast.");
          fixes.push("Ensure non-text UI components and focus indicators have at least 3:1 contrast against adjacent colors.");
          if (data.ratio !== null && data.ratio !== undefined) {
            observed.push("Contrast ratio: " + data.ratio + " (minimum " + (data.minContrast || 3) + ").");
          }
          var colors = data.colors || {};
          var boundaryColor = data.boundaryColor || colors.borderColor || colors.outlineColor || "";
          var backgroundColor = data.backgroundColor || colors.backgroundColor || "";
          var boundaryRgb = parseColorToRgb(boundaryColor);
          var backgroundRgb = parseColorToRgb(backgroundColor);
          var boundaryLum = relativeLuminance(boundaryRgb);
          var backgroundLum = relativeLuminance(backgroundRgb);
          var boundaryName = colorNameFromRgb(boundaryRgb);
          var backgroundName = colorNameFromRgb(backgroundRgb);
          var contrastFormula = formatContrastFormula(boundaryLum, backgroundLum);
          var outlineWidth = (colors.outlineWidth || "").trim();
          var borderWidth = (colors.borderWidth || "").trim();
          if (outlineWidth && outlineWidth !== "0px") {
            fixes.push("This looks like an outline/focus indicator. Increase outline color contrast or thickness.");
            if (colors.outlineColor) {
              observed.push("Outline color: " + colorNameFromRgb(parseColorToRgb(colors.outlineColor)) + ", width: " + (outlineWidth || "n/a") + ".");
            }
          } else if (borderWidth && borderWidth !== "0px") {
            fixes.push("This looks like a border. Increase border color contrast against the background.");
            if (colors.borderColor) {
              observed.push("Border color: " + colorNameFromRgb(parseColorToRgb(colors.borderColor)) + ", width: " + (borderWidth || "n/a") + ".");
            }
          } else {
            fixes.push("Increase contrast for the component fill/background against adjacent colors.");
            if (colors.backgroundColor) {
              observed.push("Background color: " + colorNameFromRgb(parseColorToRgb(colors.backgroundColor)) + ".");
            }
          }
          if (boundaryColor) {
            observed.push("Boundary color: " + boundaryName + " (" + formatRgb(boundaryRgb) + "), luminance " + formatLuminance(boundaryLum) + ".");
          }
          if (backgroundColor) {
            observed.push("Adjacent background: " + backgroundName + " (" + formatRgb(backgroundRgb) + "), luminance " + formatLuminance(backgroundLum) + ".");
          }
          if (contrastFormula) {
            observed.push("Contrast formula: " + contrastFormula + ".");
          }
          if (isButton || isLink || isInput) {
            component.push("For interactive controls, ensure the control boundary or focus ring meets 3:1 against the adjacent color.");
          }
        }

        if (ruleId === "custom-wcag22-sc-1412-text-spacing") {
          var dataTs = getCheckData(node, "sc-1412-text-spacing-no-clipping");
          if (!dataTs) return "";
          diagnosis.push("Text is clipped after applying WCAG text spacing (line-height 1.5, letter-spacing 0.12em, word-spacing 0.16em).");
          fixes.push("Allow increased text spacing without clipping.");
          var clipX = dataTs.clipping && dataTs.clipping.clippedX;
          var clipY = dataTs.clipping && dataTs.clipping.clippedY;
          if (clipX || clipY) {
            var axis = clipX && clipY ? "horizontal and vertical" : clipX ? "horizontal" : "vertical";
            diagnosis.push("Text is clipped on the " + axis + " axis after spacing changes.");
          }
          if (dataTs.style && (dataTs.style.overflowX === "hidden" || dataTs.style.overflowY === "hidden" || dataTs.style.overflowX === "clip" || dataTs.style.overflowY === "clip")) {
            fixes.push("Avoid overflow: hidden/clip when fixed dimensions are used. Prefer min-height/auto height or allow overflow.");
            observed.push("OverflowX: " + (dataTs.style.overflowX || "n/a") + ", OverflowY: " + (dataTs.style.overflowY || "n/a") + ".");
          }
          if (dataTs.baselineClipping && (dataTs.baselineClipping.clippedX || dataTs.baselineClipping.clippedY)) {
            diagnosis.push("The text was already clipped before spacing changes. Fix base layout or sizing first.");
          }
          if (dataTs.style) {
            observed.push("Size: width " + (dataTs.style.width || "n/a") + ", height " + (dataTs.style.height || "n/a") + ", max-width " + (dataTs.style.maxWidth || "n/a") + ", max-height " + (dataTs.style.maxHeight || "n/a") + ".");
          }
          if (dataTs.textStyle) {
            observed.push("Text style: font-size " + (dataTs.textStyle.fontSize || "n/a") + ", line-height " + (dataTs.textStyle.lineHeight || "n/a") + ", letter-spacing " + (dataTs.textStyle.letterSpacing || "n/a") + ", word-spacing " + (dataTs.textStyle.wordSpacing || "n/a") + ".");
          }
          if (dataTs.spacingApplied) {
            observed.push("Applied spacing: line-height " + (dataTs.spacingApplied.lineHeight || "n/a") + ", letter-spacing " + (dataTs.spacingApplied.letterSpacing || "n/a") + ", word-spacing " + (dataTs.spacingApplied.wordSpacing || "n/a") + ".");
          } else {
            observed.push("Applied spacing: line-height 1.5, letter-spacing 0.12em, word-spacing 0.16em.");
          }
          if (dataTs.metrics) {
            observed.push("After spacing: scrollH " + dataTs.metrics.scrollHeight + ", clientH " + dataTs.metrics.clientHeight + ", scrollW " + dataTs.metrics.scrollWidth + ", clientW " + dataTs.metrics.clientWidth + ".");
          }
          if (dataTs.baselineMetrics) {
            observed.push("Before spacing: scrollH " + dataTs.baselineMetrics.scrollHeight + ", clientH " + dataTs.baselineMetrics.clientHeight + ", scrollW " + dataTs.baselineMetrics.scrollWidth + ", clientW " + dataTs.baselineMetrics.clientWidth + ".");
          }
          if (isHeading) {
            component.push("For headings, allow wrapping and remove fixed heights so larger line-height can expand.");
          } else if (isParagraph) {
            component.push("For paragraphs, avoid fixed height and allow line wrapping to prevent clipping.");
          } else if (isLink || isButton) {
            component.push("For interactive labels, avoid truncation on the label itself; let the container grow.");
          }
        }

        if (ruleId === "custom-wcag22-sc-2411-focus-not-obscured-minimum") {
          var dataFn = getCheckData(node, "sc-2411-focus-not-obscured-minimum-visible");
          if (!dataFn) return "";
          diagnosis.push("Focusable element is covered by another element at one or more sampled points.");
          fixes.push("Ensure the focused element is not covered by other content.");
          if (dataFn.obscuredBy && dataFn.obscuredBy.length) {
            observed.push("Covered by: " + dataFn.obscuredBy.join(", ") + ".");
          }
          if (dataFn.targetStyle) {
            observed.push("Target style: position " + (dataFn.targetStyle.position || "n/a") + ", z-index " + (dataFn.targetStyle.zIndex || "n/a") + ", overflow " + (dataFn.targetStyle.overflow || "n/a") + ".");
          }
          if (dataFn.obscuredPointCount !== undefined) {
            observed.push("Obscured points: " + dataFn.obscuredPointCount + ".");
          }
          if (dataFn.boundingBox) {
            observed.push("Bounding box: " + JSON.stringify(dataFn.boundingBox) + ".");
          }
          if (dataFn.viewport) {
            observed.push("Viewport: " + JSON.stringify(dataFn.viewport) + ".");
          }
          fixes.push("Adjust z-index or layout of overlays/sticky headers, or add scroll padding so focus is visible.");
          if (isLink || isButton || isInput) {
            component.push("Ensure sticky headers/footers don’t overlap focusable controls in the viewport.");
          }
        }

        if (ruleId === "custom-wcag22-sc-324-consistent-identification") {
          var dataCi = getCheckData(node, "sc-324-consistent-identification");
          if (!dataCi) return "";
          diagnosis.push("Elements with the same destination/id have inconsistent accessible names.");
          fixes.push("Use the same accessible name for controls that share the same destination or consistent ID.");
          if (dataCi.distinctNames && dataCi.distinctNames.length) {
            observed.push("Current names differ: " + dataCi.distinctNames.join(", ") + ".");
          }
          if (dataCi.keyType) {
            observed.push(("Consistency key: " + dataCi.keyType + " " + (dataCi.href || dataCi.dataConsistentId || "")).trim() + ".");
          }
          if (dataCi.groupSize !== undefined) {
            observed.push("Group size: " + dataCi.groupSize + ".");
          }
          if (dataCi.currentName) {
            observed.push("Current name: " + dataCi.currentName + ".");
          }
          if (isLink || isButton) {
            component.push("For repeated links/buttons, keep the visible label and accessible name consistent.");
          }
        }

        if (ruleId === "custom-wcag22-sc-1413-hover-focus-content") {
          var dataHf = getCheckData(node, "sc-1413-title-tooltip-disallowed");
          if (!dataHf) return "";
          diagnosis.push("Hover/focus content is not dismissible, or relies on the title attribute.");
          if (dataHf.reason === "TITLE_TOOLTIP") {
            fixes.push("Avoid using the title attribute as hover/focus content.");
            fixes.push("Provide a persistent tooltip/popover that remains on hover/focus and can be dismissed.");
            if (dataHf.title) observed.push("Title attribute: " + dataHf.title + ".");
          } else {
            fixes.push("Ensure hover/focus-triggered content is dismissible and remains visible while the pointer or focus is on it.");
            if (!dataHf.hasEscapeHandler) {
              fixes.push("Add a clear dismiss mechanism, such as Escape or a close button.");
            }
            if (dataHf.matchedHandlers && dataHf.matchedHandlers.length) {
              observed.push("Inline handlers: " + dataHf.matchedHandlers.join(", ") + ".");
            }
          }
          if (dataHf.dismissSignalsFound && dataHf.dismissSignalsFound.length) {
            observed.push("Dismiss signals: " + dataHf.dismissSignalsFound.join(", ") + ".");
          }
          if (isLink || isButton) {
            component.push("For interactive triggers, ensure hover/focus content can be dismissed without moving the pointer or focus.");
          }
        }

        if (ruleId === "custom-wcag22-sc-246-headings-labels") {
          var dataHl = getCheckData(node, "sc-246-heading-label-has-text");
          if (!dataHl) return "";
          diagnosis.push("Heading/label is missing accessible text.");
          if (!dataHl.accessibleName) {
            fixes.push("Add descriptive text or an accessible name using aria-label or aria-labelledby.");
          } else {
            fixes.push("Ensure headings and labels remain descriptive and consistent with the visible text.");
          }
          if (dataHl.hidden) {
            fixes.push("Make sure the heading/label is not hidden from assistive technology.");
          }
          if (dataHl.tagName) {
            observed.push("Element: <" + dataHl.tagName + "> role=" + (dataHl.role || "n/a") + " id=" + (dataHl.id || "n/a") + ".");
          }
          if (isHeading) {
            component.push("Headings should describe the section purpose and be visible to assistive tech.");
          } else if (isInput || isButton) {
            component.push("Form controls should have a visible label tied via <label> or aria-labelledby.");
          }
        }


        if (!diagnosis.length && !fixes.length && !component.length && !observed.length) return "";
        var suggestedFixText = fixes.join("\\n");
        var html = "";
        html += '<div class="fix-guidance">';
        html += '<div class="fix-title">Fix Guidance</div>';
        if (locatorLine) {
          html += '<div class="fix-meta">' + escapeHtml(locatorLine) + "</div>";
        }
        html += '<div class="fix-actions">';
        if (locatorLine) {
          html += '<button class="copy-btn" data-copy="' + escapeAttr(locatorLine) + '">Copy locator</button>';
        }
        if (fixes.length) {
          html += '<button class="copy-btn" data-copy="' + escapeAttr(suggestedFixText) + '">Copy suggested fix</button>';
        }
        html += "</div>";
        if (diagnosis.length) {
          html += '<div class="fix-subtitle">Diagnosis</div>';
          html += '<ul class="fix-list">';
          for (var i = 0; i < diagnosis.length; i += 1) {
            html += "<li>" + escapeHtml(diagnosis[i]) + "</li>";
          }
          html += "</ul>";
        }
        if (diagnosis.length && fixes.length) {
          html += '<div class="fix-divider"></div>';
        }
        if (fixes.length) {
          html += '<div class="fix-subtitle">Actionable Fixes</div>';
          html += '<ul class="fix-list">';
          for (var j = 0; j < fixes.length; j += 1) {
            html += "<li>" + escapeHtml(fixes[j]) + "</li>";
          }
          html += "</ul>";
        }
        if ((diagnosis.length || fixes.length) && observed.length) {
          html += '<div class="fix-divider"></div>';
        }
        if (observed.length) {
          html += '<div class="fix-subtitle">Observed Values</div>';
          html += '<ul class="fix-list">';
          for (var k = 0; k < observed.length; k += 1) {
            html += "<li>" + escapeHtml(observed[k]) + "</li>";
          }
          html += "</ul>";
        }
        if ((diagnosis.length || fixes.length || observed.length) && component.length) {
          html += '<div class="fix-divider"></div>';
        }
        if (component.length) {
          html += '<div class="fix-subtitle">Component-Aware Suggestions</div>';
          html += '<ul class="fix-list">';
          for (var m = 0; m < component.length; m += 1) {
            html += "<li>" + escapeHtml(component[m]) + "</li>";
          }
          html += "</ul>";
        }
        html += "</div>";
        return html;
      }

    function renderBuiltInMinimal(node) {
      var targetLabel = (node && node.__uniqueTarget) || "";
      if (!targetLabel && Array.isArray(node && node.target) && node.target.length) {
        targetLabel = node.target.join(", ");
      }
      targetLabel = targetLabel || "n/a";
      var failureSummary = (node && node.failureSummary) || "n/a";
      var hasCopyableTarget = targetLabel !== "n/a";
      var html = '<div class="debug-block">';
      html += '<div style="display:flex;align-items:center;gap:12px;margin-bottom:4px;"><strong>Details</strong>';
      if (hasCopyableTarget) {
        html += ' <button class="copy-target-btn" data-copy="' + escapeAttr(targetLabel) + '">Copy target</button>';
      }
      html += '</div>';
      html += '<div><strong>Target:</strong> ' + escapeHtml(targetLabel) + '</div>';
      html += '<div><strong>Summary:</strong> ' + escapeHtml(failureSummary) + '</div>';
      html += '</div>';
      return html;
    }

    function renderNodesFromPayload(payload) {
      if (!payload || !Array.isArray(payload.nodes)) return "";
      var isCustomRule = String(payload.ruleId || "").indexOf("custom") === 0;
      var items = "";
      for (var i = 0; i < payload.nodes.length; i += 1) {
        var node = payload.nodes[i];
        items += "<li>";
        items += '<span class="element-counter">Element ' + (i + 1) + '</span>';
        items += renderNodeDetails(node);
        items += renderFixGuidance(node, payload.ruleId || "", payload.sectionName || "");
        items += renderRuleDebug(node, payload.ruleId || "", payload.ruleImpact || "");
        items += "</li>";
      }
        var html = "";
        html += "<details>";
        html += "<summary>" + payload.nodes.length + " element(s)</summary>";
        html += "<ul>" + items + "</ul>";
        html += "</details>";
        return html;
      }

      function loadSection(sectionName) {
        var placeholders = document.querySelectorAll(
          '.lazy-nodes[data-section="' + sectionName + '"]'
        );
        placeholders.forEach(function (placeholder) {
          if (placeholder.dataset.loaded === "true") return;
          var ruleId = placeholder.getAttribute("data-rule-id");
          var script = document.querySelector(
            '.nodes-data[data-section="' + sectionName + '"][data-rule-id="' + ruleId + '"]'
          );
          if (!script) return;
          try {
            var payload = JSON.parse(script.textContent || "{}");
            placeholder.innerHTML = renderNodesFromPayload(payload);
            var countEl = placeholder.previousElementSibling;
            if (countEl && countEl.classList && countEl.classList.contains("lazy-count")) {
              countEl.style.display = "none";
            }
            placeholder.dataset.loaded = "true";
          } catch (e) {
            placeholder.innerHTML = "<em>Failed to load details</em>";
          }
        });
      }

      document.querySelectorAll(".toggle-details").forEach(function (toggle) {
        toggle.addEventListener("change", function () {
          var section = this.getAttribute("data-section");
          if (this.checked) {
            loadSection(section);
          } else {
          document.querySelectorAll('.lazy-nodes[data-section="' + section + '"]').forEach(function (el) {
            el.innerHTML = "";
            el.dataset.loaded = "false";
            var countEl = el.previousElementSibling;
            if (countEl && countEl.classList && countEl.classList.contains("lazy-count")) {
              countEl.style.display = "";
            }
          });
          }
        });
      });

      document.addEventListener("click", function (event) {
        var target = event.target;
        if (!target || !target.closest) return;
        var btn = target.closest(".copy-btn");
        if (!btn) return;
        var text = btn.getAttribute("data-copy") || "";
        var original = btn.textContent;
        copyText(text).then(function () {
          btn.textContent = "Copied";
          setTimeout(function () {
            btn.textContent = original;
          }, 1200);
        }).catch(function () {
          btn.textContent = "Copy failed";
          setTimeout(function () {
            btn.textContent = original;
          }, 1200);
        });
      });

      document.addEventListener("click", function (event) {
        var target = event.target;
        if (!target || !target.closest) return;
        var btn = target.closest(".copy-target-btn");
        if (!btn) return;
        var text = btn.getAttribute("data-copy") || "";
        var original = btn.textContent;
        copyText(text).then(function () {
          btn.textContent = "Copied";
          setTimeout(function () {
            btn.textContent = original;
          }, 2000);
        }).catch(function () {
          btn.textContent = "Copy failed";
          setTimeout(function () {
            btn.textContent = original;
          }, 2000);
        });
      });

      function initPagination() {
        document.querySelectorAll(".section[data-page-size]").forEach(function (section) {
          var pageSize = parseInt(section.getAttribute("data-page-size"), 10) || 5;
          var rows = Array.prototype.slice.call(section.querySelectorAll("tbody > tr"));
          if (!rows.length) return;
          var currentPage = 1;
          var totalPages = Math.max(1, Math.ceil(rows.length / pageSize));
          var prev = section.querySelector(".page-prev");
          var next = section.querySelector(".page-next");
          var links = section.querySelector(".page-links");
          var status = section.querySelector(".page-status");

          function addEllipsis() {
            if (!links) return;
            var ellipsis = document.createElement("span");
            ellipsis.className = "page-ellipsis";
            ellipsis.textContent = "...";
            links.appendChild(ellipsis);
          }

          function addPageLink(pageNum) {
            if (!links) return;
            var btn = document.createElement("button");
            btn.type = "button";
            btn.className = "page-link" + (pageNum === currentPage ? " active" : "");
            btn.textContent = String(pageNum);
            if (pageNum !== currentPage) {
              btn.addEventListener("click", function () {
                currentPage = pageNum;
                renderPage();
              });
            }
            links.appendChild(btn);
          }

          function renderLinks() {
            if (!links) return;
            links.innerHTML = "";
            if (totalPages <= 3) {
              for (var i = 1; i <= totalPages; i += 1) {
                addPageLink(i);
              }
              return;
            }

            addPageLink(1);

            var start = Math.max(2, currentPage - 1);
            var end = Math.min(totalPages - 1, currentPage + 1);

            if (start > 2) addEllipsis();

            for (var p = start; p <= end; p += 1) {
              addPageLink(p);
            }

            if (end < totalPages - 1) addEllipsis();

            addPageLink(totalPages);
          }

          function renderStatus() {
            if (!status) return;
            var startIndex = (currentPage - 1) * pageSize + 1;
            var endIndex = Math.min(currentPage * pageSize, rows.length);
            status.textContent = "Showing " + startIndex + "-" + endIndex + " of " + rows.length + " entries";
          }

          function renderPage() {
            var start = (currentPage - 1) * pageSize;
            var end = start + pageSize;
            rows.forEach(function (row, idx) {
              row.style.display = idx >= start && idx < end ? "" : "none";
            });
            if (prev) prev.disabled = currentPage <= 1;
            if (next) next.disabled = currentPage >= totalPages;
            renderLinks();
            renderStatus();
          }

          if (prev) {
            prev.addEventListener("click", function () {
              if (currentPage > 1) {
                currentPage -= 1;
                renderPage();
              }
            });
          }

          if (next) {
            next.addEventListener("click", function () {
              if (currentPage < totalPages) {
                currentPage += 1;
                renderPage();
              }
            });
          }


          renderPage();
        });
      }

        initPagination();

      })();
  </script>

</body>
</html>
`;
}

/**
 * Send START_SCAN to the currently active tab
 */
function triggerScanOnActiveTab(scanContext) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs || !tabs.length) return;
    const tab = tabs[0];
    const context = Object.assign({}, scanContext, { url: tab.url });
    sendStartScan(tab.id, context);
  });
}

function sendStartScan(tabId, scanContext) {
  console.log("[BG][TIMING] START_SCAN sendMessage", tabId, scanContext?.scanId, Date.now());
  chrome.tabs.sendMessage(
    tabId,
    {
      type: "START_SCAN",
      scanId: scanContext.scanId,
      scanContext,
      manual: scanContext.manual === true,
    },
    () => {
      if (chrome.runtime.lastError) {
        console.warn("[BG] START_SCAN failed:", chrome.runtime.lastError.message);
      } else {
        console.log("[BG] START_SCAN sent to tab", tabId);
      }
    }
  );
}

function sendStartScanForPageReady(pending) {
  if (!pending || !pending.tabId || !pending.url) return;
  sendStartScan(pending.tabId, {
    scanId: createScanId(),
    manual: false,
    url: pending.url,
  });
  console.log("[BG] START_SCAN sent for pending PAGE_READY", pending.url);
}

function setScanState(active, extra = {}) {
  chrome.storage.local.get("scanState", (data) => {
    const prev = data.scanState || {};
    chrome.storage.local.set({ scanState: { ...prev, active, ...extra } });
  });
}

function clearStartScanTimeout() {
  if (startScanTimeoutId) {
    clearTimeout(startScanTimeoutId);
    startScanTimeoutId = null;
  }
}

function getScanState(callback) {
  chrome.storage.local.get("scanState", (data) => {
    callback(data.scanState?.active === true);
  });
}

function buildSummaryHtmlReport(pages, options = {}) {
  const showDebugDetails = options.showDebugDetails !== false;
  const isNormalized = options.showNormalizedOutput === true;

  function targetKey(target) {
    if (Array.isArray(target)) return JSON.stringify(target);
    if (target === null || target === undefined) return "";
    return String(target);
  }

  function nodeTargetValue(node) {
    if (Array.isArray(node?.target) && node.target.length) return node.target;
    if (typeof node?.xpath === "string" && node.xpath) return [node.xpath];
    return [];
  }

  function buildFilterIndex(items) {
    const index = new Map();
    if (!Array.isArray(items)) return index;
    items.forEach((entry) => {
      if (!entry || !entry.ruleId) return;
      const key = targetKey(nodeTargetValue(entry.node || {}));
      if (!key) return;
      if (!index.has(entry.ruleId)) index.set(entry.ruleId, new Map());
      index.get(entry.ruleId).set(key, entry.reason || "FILTERED:CSS_HIDDEN");
    });
    return index;
  }

  function formatFilterReason(reason) {
    if (!reason) return "UNKNOWN";
    return String(reason).replace(/^FILTERED:/, "");
  }

  function buildSuppressionIndex(metadata) {
    const index = new Map();
    if (!Array.isArray(metadata)) return index;
    metadata.forEach((entry) => {
      if (!entry || !entry.ruleId) return;
      if (!index.has(entry.ruleId)) index.set(entry.ruleId, new Map());
      const ruleMap = index.get(entry.ruleId);
      const key = targetKey(entry.suppressedNodeTarget);
      if (!key) return;
      ruleMap.set(key, {
        reason: entry.reason || "ANCESTOR_SUPPRESSED",
        keptNodeXPath: entry.keptNodeXPath || "",
        keptNodeTarget: entry.keptNodeTarget || [],
      });
    });
    return index;
  }

  function getNodeStatus(ruleId, node, suppressionIndex, filterIndex) {
    if (!isNormalized) return null;
    const filterMap = filterIndex.get(ruleId);
    const filterKey = targetKey(nodeTargetValue(node));
    if (filterMap && filterMap.has(filterKey)) {
      return {
        status: "filtered",
        reason: filterMap.get(filterKey),
      };
    }
    const ruleMap = suppressionIndex.get(ruleId);
    const key = targetKey(nodeTargetValue(node));
    if (ruleMap && ruleMap.has(key)) {
      const detail = ruleMap.get(key);
      return {
        status: "removed",
        reason: detail.reason,
        keptNodeXPath: detail.keptNodeXPath,
        keptNodeTarget: detail.keptNodeTarget,
      };
    }
    return { status: "normalized" };
  }

  function formatTarget(target) {
    if (Array.isArray(target)) return target.join(", ");
    if (target === null || target === undefined) return "";
    return String(target);
  }

  function renderStatusBadge(ruleId, node, suppressionIndex, filterIndex) {
    const status = getNodeStatus(ruleId, node, suppressionIndex, filterIndex);
    if (!status) return "";
    if (status.status === "filtered") {
      return `<span class="badge filtered">filtering: ${escapeHtml(formatFilterReason(status.reason))}</span>`;
    }
    if (status.status === "removed") {
      const kept = status.keptNodeXPath || "";
      const keptTarget = formatTarget(status.keptNodeTarget);
      const keptLabel = kept
        ? escapeHtml(kept)
        : keptTarget
          ? escapeHtml(keptTarget)
          : "xpath unavailable";
      return `
        <span class="badge removed">removed: ${escapeHtml(status.reason)}</span>
        <div class="badge-sub">kept: ${keptLabel}</div>
      `;
    }
    return `<span class="badge normalized">normalized</span>`;
  }

  function renderNodes(
    nodes,
    ruleId,
    ruleImpact,
    suppressionMetadata,
    phase1Filtered,
    sectionName
  ) {
    if (!nodes || !nodes.length) return "";
    const suppressionIndex = buildSuppressionIndex(suppressionMetadata);
    const filterIndex = buildFilterIndex(phase1Filtered);
    const isCustomRule = String(ruleId || "").startsWith("custom");
    const isViolation = sectionName === "Violations";
    const showDebugForSection = sectionName === "Violations" || sectionName === "Incomplete";
    const showBuiltInMinimal = isViolation && !isCustomRule;
    const showFixGuidance = isViolation && isCustomRule;
    const renderFixGuidanceSafe =
      typeof renderFixGuidance === "function" ? renderFixGuidance : null;

    function getFailureSummary(node) {
      if (!node) return "";
      const checks = [].concat(node.any || [], node.all || [], node.none || []);
      const checkWithMessage = checks.find((check) => check?.message);
      return checkWithMessage?.message || node?.failureSummary || "";
    }

    function findTextSpacingData(node) {
      const checks = [].concat(node.any || [], node.all || [], node.none || []);
      return checks.find((check) => check.id === "sc-1412-text-spacing-no-clipping" && check.data)
        ?.data;
    }

    function renderTextSpacingDebug(data) {
      if (!data) return "";
      const style = data.style || {};
      const metrics = data.metrics || {};
      const clipping = data.clipping || {};
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "Clipped after spacing")}</dd></div>
            <div><dt>ClipX</dt><dd>${clipping.clippedX}</dd></div>
            <div><dt>ClipY</dt><dd>${clipping.clippedY}</dd></div>
            ${data.baselineClipping ? `<div><dt>BaselineClipX</dt><dd>${escapeHtml(String(data.baselineClipping.clippedX))}</dd></div>` : ""}
            ${data.baselineClipping ? `<div><dt>BaselineClipY</dt><dd>${escapeHtml(String(data.baselineClipping.clippedY))}</dd></div>` : ""}
            <div><dt>OverflowX</dt><dd>${escapeHtml(style.overflowX || "")}</dd></div>
            <div><dt>OverflowY</dt><dd>${escapeHtml(style.overflowY || "")}</dd></div>
            <div><dt>Width</dt><dd>${escapeHtml(style.width || "")}</dd></div>
            <div><dt>MaxWidth</dt><dd>${escapeHtml(style.maxWidth || "")}</dd></div>
            <div><dt>Height</dt><dd>${escapeHtml(style.height || "")}</dd></div>
            <div><dt>MaxHeight</dt><dd>${escapeHtml(style.maxHeight || "")}</dd></div>
            <div><dt>ScrollH</dt><dd>${metrics.scrollHeight}</dd></div>
            <div><dt>ClientH</dt><dd>${metrics.clientHeight}</dd></div>
            <div><dt>ScrollW</dt><dd>${metrics.scrollWidth}</dd></div>
            <div><dt>ClientW</dt><dd>${metrics.clientWidth}</dd></div>
            ${data.baselineMetrics ? `<div><dt>Baseline Metrics</dt><dd>${escapeHtml(JSON.stringify(data.baselineMetrics))}</dd></div>` : ""}
          </dl>
        </div>
      `;
    }

    function renderOnFocusDebug(node) {
      const checks = [].concat(node.any || [], node.all || [], node.none || []);
      const data = checks.find(
        (check) => check.id === "sc-321-inline-onfocus-context-change" && check.data
      )?.data;
      if (!data) return "";
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "")}</dd></div>
            <div><dt>Matched Patterns</dt><dd>${escapeHtml((data.patterns || []).join(", "))}</dd></div>
          </dl>
          ${data.handler ? `<div><strong>Handler</strong></div><pre class="debug-code">${escapeHtml(data.handler)}</pre>` : ""}
        </div>
      `;
    }

    function renderOnInputDebug(node) {
      const checks = [].concat(node.any || [], node.all || [], node.none || []);
      const data = checks.find(
        (check) => check.id === "sc-322-inline-oninput-context-change" && check.data
      )?.data;
      if (!data) return "";
      const handlers = Array.isArray(data.handlers) ? data.handlers : [];
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "")}</dd></div>
            <div><dt>Matched Patterns</dt><dd>${escapeHtml((data.patterns || []).join(", "))}</dd></div>
          </dl>
          ${handlers.length ? `<div><strong>Handlers</strong></div><pre class="debug-code">${escapeHtml(handlers.join("\n"))}</pre>` : ""}
        </div>
      `;
    }

    function renderFocusNotObscuredDebug(node) {
      if (!node) return "";
      const checks = [].concat(node.any || [], node.all || [], node.none || []);
      const check = checks.find((item) => item.id === "sc-2411-focus-not-obscured-minimum-visible");
      const data = check?.data || null;
      const reason = data?.reason || check?.message || node?.failureSummary || "";
      if (!reason && !data) return "";
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(reason)}</dd></div>
            ${
              data?.boundingBox
                ? `
              <div><dt>Bounding Box</dt><dd>${escapeHtml(JSON.stringify(data.boundingBox))}</dd></div>
            `
                : ""
            }
            ${
              data?.viewport
                ? `
              <div><dt>Viewport</dt><dd>${escapeHtml(JSON.stringify(data.viewport))}</dd></div>
            `
                : ""
            }
            ${
              Array.isArray(data?.samplePoints)
                ? `
              <div><dt>Sample Points</dt><dd>
                <ul class="debug-list">
                  ${data.samplePoints
                    .map(
                      (p) =>
                        `<li>${escapeHtml(`${p.x},${p.y} -> ${p.visible ? "visible" : "covered"} (${p.topElement || "unknown"})`)}</li>`
                    )
                    .join("")}
                </ul>
              </dd></div>
            `
                : ""
            }
          </dl>
        </div>
      `;
    }

    function renderHoverFocusContentDebug(node) {
      if (!node) return "";
      const checks = [].concat(node.any || [], node.all || [], node.none || []);
      const data = checks.find(
        (check) => check.id === "sc-1413-title-tooltip-disallowed" && check.data
      )?.data;
      if (!data) return "";
      const matchedPatterns = Array.isArray(data.matchedPatterns) ? data.matchedPatterns : [];
      const matchedHandlers = Array.isArray(data.matchedHandlers) ? data.matchedHandlers : [];
      const dismissSignals = Array.isArray(data.dismissSignalsFound)
        ? data.dismissSignalsFound
        : [];
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "")}</dd></div>
            <div><dt>Outcome</dt><dd>${escapeHtml(data.outcome || "")}</dd></div>
            <div><dt>Trigger Type</dt><dd>${escapeHtml(data.triggerType || "")}</dd></div>
            <div><dt>Matched Patterns</dt><dd>${escapeHtml(matchedPatterns.join(", "))}</dd></div>
            <div><dt>Matched Handlers</dt><dd>${escapeHtml(matchedHandlers.join(", "))}</dd></div>
            <div><dt>Dismiss Signals</dt><dd>${escapeHtml(dismissSignals.join(", "))}</dd></div>
            <div><dt>Dismiss Scope</dt><dd>${escapeHtml(data.dismissScope || "")}</dd></div>
            <div><dt>Interactive</dt><dd>${escapeHtml(String(data.isInteractive ?? ""))}</dd></div>
            <div><dt>Hidden</dt><dd>${escapeHtml(String(data.isHidden ?? ""))}</dd></div>
          </dl>
        </div>
      `;
    }

    function getConsistentIdentificationData(node) {
      const checks = [].concat(node.any || [], node.all || [], node.none || []);
      return checks.find((check) => check.id === "sc-324-consistent-identification" && check.data)
        ?.data;
    }

    function renderConsistentIdentificationDebug(node) {
      const data = getConsistentIdentificationData(node);
      if (!data) return "";
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            ${data.outcome ? `<div><dt>Outcome</dt><dd>${escapeHtml(data.outcome)}</dd></div>` : ""}
            ${data.visibilityState ? `<div><dt>Visibility</dt><dd>${escapeHtml(data.visibilityState)}</dd></div>` : ""}
            ${data.visibilityReason ? `<div><dt>Visibility Reason</dt><dd>${escapeHtml(data.visibilityReason)}</dd></div>` : ""}
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "")}</dd></div>
            <div><dt>Key</dt><dd>${escapeHtml(data.key || "")}</dd></div>
            <div><dt>Current Name</dt><dd>${escapeHtml(data.currentName || "")}</dd></div>
            <div><dt>Group Size</dt><dd>${escapeHtml(String(data.groupSize ?? ""))}</dd></div>
            <div><dt>Distinct Names</dt><dd>${escapeHtml((data.distinctNames || []).join(", "))}</dd></div>
          </dl>
        </div>
      `;
    }

    function renderConsistentIdentificationGroupDebug(data, groupSize) {
      if (!data) return "";
      const size = data.groupSize ?? groupSize ?? "";
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            ${data.outcome ? `<div><dt>Outcome</dt><dd>${escapeHtml(data.outcome)}</dd></div>` : ""}
            ${data.visibilityState ? `<div><dt>Visibility</dt><dd>${escapeHtml(data.visibilityState)}</dd></div>` : ""}
            ${data.visibilityReason ? `<div><dt>Visibility Reason</dt><dd>${escapeHtml(data.visibilityReason)}</dd></div>` : ""}
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "")}</dd></div>
            <div><dt>Key</dt><dd>${escapeHtml(data.key || "")}</dd></div>
            <div><dt>Group Size</dt><dd>${escapeHtml(String(size))}</dd></div>
            <div><dt>Distinct Names</dt><dd>${escapeHtml((data.distinctNames || []).join(", "))}</dd></div>
          </dl>
        </div>
      `;
    }

    function renderHeadingsLabelsDebug(node) {
      if (!node) return "";
      const checks = [].concat(node.any || [], node.all || [], node.none || []);
      const data = checks.find(
        (check) => check.id === "sc-246-heading-label-has-text" && check.data
      )?.data;
      const fallbackReason =
        checks.find((check) => check?.message)?.message || node?.failureSummary || "";
      if (!data && !fallbackReason) return "";
      const labelled = data ? data.ariaLabelledby || {} : {};
      const labelledIds = Array.isArray(labelled.ids) ? labelled.ids.join(", ") : "";
      const labelledTexts = Array.isArray(labelled.texts) ? labelled.texts.join(", ") : "";
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data?.reason || fallbackReason || "")}</dd></div>
            ${
              data
                ? `
              <div><dt>Hidden</dt><dd>${escapeHtml(String(data.hidden ?? ""))}</dd></div>
              <div><dt>Source</dt><dd>${escapeHtml(data.source || "")}</dd></div>
              <div><dt>Text</dt><dd>${escapeHtml(data.textContent || "")}</dd></div>
              <div><dt>Aria Label</dt><dd>${escapeHtml(data.ariaLabel || "")}</dd></div>
              <div><dt>Aria Labelledby Ids</dt><dd>${escapeHtml(labelledIds)}</dd></div>
              <div><dt>Aria Labelledby Text</dt><dd>${escapeHtml(labelledTexts)}</dd></div>
            `
                : ""
            }
          </dl>
        </div>
      `;
    }

    function renderJsonBlock(label, payload) {
      if (!payload) return "";
      return `
        <div><strong>${escapeHtml(label)}</strong></div>
        <pre class="debug-code">${escapeHtml(JSON.stringify(payload, null, 2))}</pre>
      `;
    }

    function renderNonTextContrastDebug(node) {
      if (!node) return "";
      const checks = [].concat(node.any || [], node.all || [], node.none || []);
      const check = checks.find((item) => item.id === "sc-1411-non-text-contrast-min-3");
      const data = check?.data || node?.__nonTextContrastDebug;
      const formatNamedColorValue = (value) => {
        if (!value) return "";
        var rgb = parseColorToRgb(value);
        if (!rgb) return String(value);
        return colorNameFromRgb(rgb) + " (" + formatRgb(rgb) + ")";
      };
      let fallbackReason = check?.message || node?.failureSummary || "";
      if (
        !data?.reason &&
        fallbackReason &&
        fallbackReason.toLowerCase().includes("fix any of the following")
      ) {
        fallbackReason =
          "Boundary not deterministically found for native form controls (e.g., input/select/textarea/button) (as it is browser/OS rendered); requires manual review.";
      }

      if (!data && !fallbackReason) return "";

      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data?.reason || fallbackReason || "")}</dd></div>
            ${
              data
                ? `
                <div><dt>State</dt><dd>${escapeHtml(String(data.state || ""))}</dd></div>
                <div><dt>Boundary Type</dt><dd>${escapeHtml(String(data.boundaryType || ""))}</dd></div>
                ${data.boundarySource ? `<div><dt>Boundary Source</dt><dd>${escapeHtml(String(data.boundarySource || ""))}</dd></div>` : ""}
                ${data.boundaryColor ? `<div><dt>Boundary Color</dt><dd>${escapeHtml(formatNamedColorValue(data.boundaryColor))}</dd></div>` : ""}
                ${data.backgroundColor ? `<div><dt>Adjacent Background</dt><dd>${escapeHtml(formatNamedColorValue(data.backgroundColor))}</dd></div>` : ""}
                <div><dt>Ratio</dt><dd>${escapeHtml(String(data.ratio ?? ""))}</dd></div>
                <div><dt>Min Contrast</dt><dd>${escapeHtml(String(data.minContrast ?? ""))}</dd></div>
                ${data.note ? `<div><dt>Note</dt><dd>${escapeHtml(String(data.note))}</dd></div>` : ""}
                ${
                  data.determinism
                    ? `
                  <div><dt>Element Background Deterministic</dt><dd>${escapeHtml(String(data.determinism.deterministic))}</dd></div>
                  <div><dt>Background Opaque</dt><dd>${escapeHtml(String(data.determinism.backgroundOpaque))}</dd></div>
                  <div><dt>No Background Image</dt><dd>${escapeHtml(String(data.determinism.noBackgroundImage))}</dd></div>
                  <div><dt>No Visible Pseudo</dt><dd>${escapeHtml(String(data.determinism.noVisiblePseudo))}</dd></div>
                  <div><dt>No Non-text Descendants</dt><dd>${escapeHtml(String(data.determinism.noNonTextDescendants))}</dd></div>
                  <div><dt>No Boundary Children</dt><dd>${escapeHtml(String(data.determinism.noBoundaryChildren))}</dd></div>
                  <div><dt>Min Size OK</dt><dd>${escapeHtml(String(data.determinism.sizeOk))}</dd></div>
                `
                    : ""
                }
              `
                : ""
            }
            </dl>
          ${data ? renderJsonBlock("Tester Debug", data.testerDebug) : ""}
          ${data ? renderJsonBlock("Engine Debug", data.engineDebug) : ""}
          ${data ? renderJsonBlock("State Results", data.stateResults) : ""}
        </div>
      `;
    }

    function getGenericDebugData(node) {
      if (!node) return { reason: "n/a", checkIds: [] };
      const checks = [].concat(node.any || [], node.all || [], node.none || []);
      const checkWithReason = checks.find((check) => check?.data?.reason);
      const checkWithMessage = checks.find((check) => check?.message);
      const reason =
        checkWithReason?.data?.reason || checkWithMessage?.message || node?.failureSummary || "";
      const checkIds = checks.map((check) => check.id).filter(Boolean);
      return {
        reason,
        checkIds,
      };
    }

    function renderGenericDebug(node, impact) {
      const data = getGenericDebugData(node);
      return `
        <div class="debug-block">
          <div class="debug-title">Debug Details</div>
          <dl class="debug-grid">
            <div><dt>Reason</dt><dd>${escapeHtml(data.reason || "n/a")}</dd></div>
            <div><dt>Check IDs</dt><dd>${escapeHtml(data.checkIds.length ? data.checkIds.join(", ") : "n/a")}</dd></div>
            <div><dt>Impact</dt><dd>${escapeHtml(impact || "n/a")}</dd></div>
          </dl>
        </div>
      `;
    }

    function renderRuleDebug(node, ruleId, impact) {
      if (ruleId === "custom-wcag22-sc-1412-text-spacing") {
        return renderTextSpacingDebug(findTextSpacingData(node));
      }
      if (ruleId === "custom-wcag22-sc-1410-reflow") {
        return renderReflowDebug(node);
      }
      if (ruleId === "custom-wcag22-sc-1413-hover-focus-content") {
        return renderHoverFocusContentDebug(node);
      }
      if (ruleId === "custom-wcag22-sc-246-headings-labels") {
        return renderHeadingsLabelsDebug(node);
      }
      if (ruleId === "custom-wcag22-sc-331-error-identification") {
        return renderGenericDebug(node, impact);
      }
      if (ruleId === "custom-wcag22-sc-321-on-focus") {
        return renderOnFocusDebug(node);
      }
      if (ruleId === "custom-wcag22-sc-322-on-input") {
        return renderOnInputDebug(node);
      }
      if (ruleId === "custom-wcag22-sc-2411-focus-not-obscured-minimum") {
        return renderFocusNotObscuredDebug(node);
      }
      if (ruleId === "custom-wcag22-sc-324-consistent-identification") {
        return renderConsistentIdentificationDebug(node);
      }
      if (ruleId === "custom-wcag22-sc-1411-non-text-contrast") {
        return renderNonTextContrastDebug(node);
      }
      return renderGenericDebug(node, impact);
    }

    function formatNodeTarget(node) {
      if (!node) return "";
      if (node?.__uniqueTarget) return node.__uniqueTarget;
      if (Array.isArray(node?.target) && node.target.length) {
        return node.target.join(", ");
      }
      return "";
    }

    function renderBuiltInMinimal(node) {
      const targetLabel = formatNodeTarget(node) || "n/a";
      const failureSummary = getFailureSummary(node) || "n/a";
      const hasCopyableTarget = targetLabel && targetLabel !== "n/a";
      return `
        <div class="debug-block">
          <div style="display:flex;align-items:center;gap:12px;margin-bottom:4px;"><strong>Details</strong>${hasCopyableTarget ? ` <button class="copy-target-btn" data-copy="${escapeAttr(targetLabel)}">Copy target</button>` : ""}</div>
          <div><strong>Target:</strong> ${escapeHtml(targetLabel)}</div>
          <div><strong>Summary:</strong> ${escapeHtml(failureSummary)}</div>
        </div>
      `;
    }

    function renderNodeDetails(node, alwaysShow) {
      const targetLabel = formatNodeTarget(node);
      if (!alwaysShow && !node?.xpath && !targetLabel && !node?.html) return "";
      const xpathLabel = node?.xpath ? node.xpath : "n/a";
      const targetOutput = !node?.xpath ? targetLabel || "n/a" : targetLabel;
      const hasCopyableTarget = !node?.xpath && targetOutput && targetOutput !== "n/a";
      return `
    <div class="debug-block">
      <div class="debug-title" style="display:flex;align-items:center;gap:12px;">Node Details${hasCopyableTarget ? ` <button class="copy-target-btn" data-copy="${escapeAttr(targetOutput)}">Copy target</button>` : ""}</div>
      <div><strong>XPath:</strong> ${escapeHtml(xpathLabel)}</div>
      ${!node?.xpath ? `<div><strong>Target:</strong> ${escapeHtml(targetOutput)}</div>` : ""}
      ${node.html ? `<div><strong>HTML:</strong></div><pre class="debug-code">${escapeHtml(node.html)}</pre>` : ""}
    </div>
  `;
    }

    function renderConsistentIdentificationGroups(nodes, suppressionIndex, filterIndex) {
      const groups = [];
      const indexByKey = new Map();

      nodes.forEach((node, index) => {
        const data = getConsistentIdentificationData(node);
        const key = data?.key || `__unknown_${index}`;
        let groupIndex = indexByKey.get(key);
        if (groupIndex === undefined) {
          groupIndex = groups.length;
          indexByKey.set(key, groupIndex);
          groups.push({ key, data: data || null, nodes: [] });
        }
        const group = groups[groupIndex];
        if (!group.data && data) group.data = data;
        group.nodes.push(node);
      });

      return `
          <details>
            <summary>Consistent Identification Groups (${groups.length})</summary>
            <div class="group-list">
              ${groups
                .map(
                  (group, idx) => `
                <details>
                  <summary>Group ${idx + 1}: ${group.nodes.length} element(s)</summary>
                  ${showDebugDetails ? renderConsistentIdentificationGroupDebug(group.data, group.nodes.length) : ""}
                  <ul>
                    ${group.nodes
                      .map(
                        (node) => `
                      <li>
                        ${renderStatusBadge(ruleId, node, suppressionIndex, filterIndex)}
                        ${renderNodeDetails(node, true)}
                        ${renderFixGuidanceSafe ? renderFixGuidanceSafe(node, ruleId, sectionName) : ""}
                      </li>
                    `
                      )
                      .join("")}
                  </ul>
                </details>
              `
                )
                .join("")}
            </div>
          </details>
        `;
    }

    if (
      isViolation &&
      isCustomRule &&
      ruleId === "custom-wcag22-sc-324-consistent-identification"
    ) {
      return renderConsistentIdentificationGroups(nodes, suppressionIndex, filterIndex);
    }

    const filteredCount = isNormalized
      ? nodes.filter((node) => {
          const ruleMap = filterIndex.get(ruleId);
          if (!ruleMap) return false;
          return ruleMap.has(targetKey(nodeTargetValue(node)));
        }).length
      : 0;
    const removedCount = isNormalized
      ? nodes.filter((node) => {
          const ruleMap = suppressionIndex.get(ruleId);
          if (!ruleMap) return false;
          return ruleMap.has(targetKey(nodeTargetValue(node)));
        }).length
      : 0;
    const visibleCount = nodes.length - filteredCount - removedCount;
    const countLabel =
      isNormalized && (filteredCount > 0 || removedCount > 0)
        ? `${visibleCount} of ${nodes.length} element(s)`
        : `${nodes.length} element(s)`;

    return `
      <details>
        <summary>${countLabel}</summary>
        <ul>
          ${nodes
            .map(
              (n, idx) => `
            <li>
              <span class="element-counter">Element ${idx + 1}</span>
              ${renderStatusBadge(ruleId, n, suppressionIndex, filterIndex)}
              ${isViolation ? renderNodeDetails(n, true) : ""}
              ${showFixGuidance && renderFixGuidanceSafe ? renderFixGuidanceSafe(n, ruleId, sectionName) : ""}
              ${showDebugForSection && showDebugDetails ? renderRuleDebug(n, ruleId, ruleImpact) : ""}
            </li>
          `
            )
            .join("")}
        </ul>
      </details>
    `;
  }

  function renderNodesLazyPlaceholder(nodes, ruleId, ruleImpact, sectionName) {
    if (!nodes || !nodes.length) return "";
    const payload = {
      ruleId,
      ruleImpact,
      sectionName,
      nodes,
    };
    const json = JSON.stringify(payload).replace(/</g, "\\u003c");
    const countLabel = `${nodes.length} element(s)`;
    return `
      <div class="lazy-count">${countLabel}</div>
      <div class="lazy-nodes" data-section="${escapeHtml(sectionName)}" data-rule-id="${escapeHtml(ruleId)}"></div>
      <script type="application/json" class="nodes-data" data-section="${escapeHtml(sectionName)}" data-rule-id="${escapeHtml(ruleId)}">${json}</script>
    `;
  }

  // ------------------------------------------------------
  // [ADDED] Flatten results across ALL pages
  // ------------------------------------------------------
  function flatten(type) {
    return pages.flatMap((p) =>
      (p.results[type] || []).map((item) => ({
        ...item,
        pageUrl: p.url,
        suppressionMetadata: p.suppressionMetadata || [],
        phase1Filtered: p.phase1Filtered || [],
      }))
    );
  }

  function renderSummaryByPage(pages) {
    return `
      <table>
        <thead>
          <tr>
            <th>Page URL</th>
            <th>Violations</th>
            <th>Incomplete</th>
            <th>Passes</th>
            <!-- <th>Inapplicable</th> -->
          </tr>
        </thead>
        <tbody>
          ${pages
            .map(
              (p) => `
            <tr>
              <td class="url">${escapeHtml(p.url)}</td>
              <td>${p.results.violations?.length || 0}</td>
              <td>${p.results.incomplete?.length || 0}</td>
              <td>${p.results.passes?.length || 0}</td>
              <!-- <td>${p.results.inapplicable?.length || 0}</td> -->
            </tr>
          `
            )
            .join("")}
        </tbody>
      </table>
    `;
  }

  function aggregateByRule(pages) {
    const ruleMap = {};

    pages.forEach((page) => {
      const url = page.url;

      ["violations", "passes", "incomplete", "inapplicable"].forEach((type) => {
        (page.results[type] || []).forEach((rule) => {
          if (!ruleMap[rule.id]) {
            ruleMap[rule.id] = {
              id: rule.id,
              description: rule.description,
              impact: rule.impact || "",
              tags: rule.tags || [],
              occurrences: 0,
              pages: new Set(),
            };
          }

          ruleMap[rule.id].occurrences += rule.nodes?.length || 1;
          ruleMap[rule.id].pages.add(url);
        });
      });
    });

    return Object.values(ruleMap).map((r) => ({
      ...r,
      pageCount: r.pages.size,
    }));
  }

  function renderSummaryByRule(rules) {
    if (!Array.isArray(rules)) {
      console.warn("[BG] Rule summary skipped - invalid data");
      return "";
    }

    if (!rules.length) {
      return `<h2>Summary by Rule</h2><p class="empty">No rules found.</p>`;
    }

    const sectionKey = "summary-by-rule";
    return `
      <div class="section" data-section="${sectionKey}" data-page-size="10">
        <div class="section-header">
          <h2>Summary by Rule (${rules.length})</h2>
        </div>
        <table data-section="${sectionKey}">
          <thead>
            <tr>
              <th>#</th>
              <th>Rule ID</th>
              <th>Description</th>
              <th>Impact</th>
              <th>Tags</th>
              <th>Occurrences</th>
              <th>Pages Affected</th>
            </tr>
          </thead>
          <tbody>
            ${rules
              .map(
                (r, idx) => `
              <tr>
                <td>${idx + 1}</td>
                <td>${escapeHtml(r.id)}</td>
                <td>${escapeHtml(r.description)}</td>
                <td>
                  <span class="impact ${r.impact}">${r.impact}</span>
                </td>
                <td>
                  ${(r.tags || []).map((t) => `<span class="tag">${t}</span>`).join("")}
                </td>
                <td>${r.occurrences}</td>
                <td>${r.pageCount || 0}</td>
              </tr>
            `
              )
              .join("")}
          </tbody>
        </table>
        <div class="pagination-footer" data-section="${sectionKey}">
          <div class="page-status">Showing 0-0 of 0 entries</div>
          <div class="pagination" data-section="${sectionKey}">
            <button class="page-prev" type="button" disabled>Previous</button>
            <div class="page-links"></div>
            <button class="page-next" type="button" disabled>Next</button>
          </div>
        </div>
      </div>
    `;
  }

  function formatDate(date) {
    const months = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ];
    const day = date.getDate();
    const month = months[date.getMonth()];
    const year = date.getFullYear();
    const ordinal =
      day === 1 || day === 21 || day === 31
        ? "st"
        : day === 2 || day === 22
          ? "nd"
          : day === 3 || day === 23
            ? "rd"
            : "th";
    const pad = (n) => String(n).padStart(2, "0");
    const time = `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
    return `${day}${ordinal} ${month}, ${year}, ${time}`;
  }

  function renderTable(title, items) {
    if (!items.length) {
      return `
        <h2>${title} (0)</h2>
        <p class="empty">No ${title.toLowerCase()} found.</p>
      `;
    }

    const showLazyToggle = title === "Passes" || title === "Incomplete";
    const sectionKey = String(title || "")
      .toLowerCase()
      .replace(/\s+/g, "-");
    return `
      <div class="section" id="section-${escapeHtml(sectionKey)}" data-section="${escapeHtml(sectionKey)}" data-page-size="5">
        <div class="section-header">
          <h2>${title} (${items.length})</h2>
          <div class="section-controls">
            ${
              showLazyToggle
                ? `
              <label class="section-toggle">
                <input type="checkbox" class="toggle-details" data-section="${escapeHtml(title)}">
                Show node/debug details
              </label>
            `
                : ""
            }
          </div>
        </div>
        <table data-section="${escapeHtml(sectionKey)}">
          <thead>
            <tr>
              <th>#</th>
              <th>Rule ID</th>
              <th>Description</th>
              <th>Impact</th>
              <th>Tags</th>
              <th>Page URL</th>
              <th>Affected Elements</th>
              <th>Help</th>
            </tr>
          </thead>
          <tbody>
            ${items
              .map(
                (item, index) => `
              <tr data-row-index="${index}">
                <td>${index + 1}</td>
                <td>${escapeHtml(item.id)}</td>
                <td>${escapeHtml(item.description)}</td>
                <td>
                  <span class="impact ${item.impact || "none"}">
                    ${item.impact || ""}
                  </span>
                </td>
                <td>
                  ${item.tags.map((t) => `<span class="tag">${t}</span>`).join("")}
                </td>
                <td class="url">${escapeHtml(item.pageUrl)}</td>
                  <td>${
                    title === "Violations"
                      ? renderNodes(
                          item.nodes,
                          item.id,
                          item.impact,
                          item.suppressionMetadata,
                          item.phase1Filtered,
                          title
                        )
                      : showLazyToggle
                        ? renderNodesLazyPlaceholder(item.nodes, item.id, item.impact, title)
                        : ""
                  }</td>
                <td>
                  <a href="${item.helpUrl}" target="_blank">Reference</a>
                </td>
              </tr>
          `
              )
              .join("")}
        </tbody>
      </table>
        <div class="pagination-footer" data-section="${escapeHtml(sectionKey)}">
          <div class="page-status">Showing 0-0 of 0 entries</div>
          <div class="pagination" data-section="${escapeHtml(sectionKey)}">
            <button class="page-prev" type="button" disabled>Previous</button>
            <div class="page-links"></div>
            <button class="page-next" type="button" disabled>Next</button>
          </div>
        </div>
      </div>
    `;
  }

  const violations = flatten("violations");
  const passes = flatten("passes");
  const incomplete = flatten("incomplete");
  const inapplicable = flatten("inapplicable");

  const rulesSummary = aggregateByRule(pages);

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>Accessibility Summary Report</title>
      <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

:root {
  --brand: #2563eb;
  --bg: #f0f2f5;
  --surface: #ffffff;
  --surface-alt: #f8fafc;
  --border: #e2e8f0;
  --text: #0f172a;
  --muted: #64748b;
  --critical: #dc2626; --critical-bg: #fef2f2; --critical-bd: #fca5a5;
  --serious:  #ea580c; --serious-bg:  #fff7ed; --serious-bd:  #fdba74;
  --moderate: #d97706; --moderate-bg: #fffbeb; --moderate-bd: #fcd34d;
  --minor:    #16a34a; --minor-bg:    #f0fdf4; --minor-bd:    #86efac;
  --radius: 8px;
  --shadow: 0 1px 3px rgba(0,0,0,.08), 0 1px 2px rgba(0,0,0,.04);
}
* { box-sizing: border-box; }
body { font-family: 'Inter', Arial, sans-serif; background: var(--bg); color: var(--text); margin: 0; padding: 0; font-size: 14px; line-height: 1.6; }

.report-header { background: #1e293b; color: #fff; padding: 20px 32px; display: flex; align-items: flex-start; justify-content: space-between; gap: 16px; flex-wrap: wrap; }
.report-header h1 { margin: 0 0 6px; font-size: 26px; font-weight: 700; letter-spacing: -.3px; }
.meta-row { display: flex; flex-wrap: wrap; gap: 16px; font-size: 14px; color: #94a3b8; }
.meta-row strong { color: #cbd5e1; margin-right: 4px; }
.meta-row a { color: #60a5fa; text-decoration: none; word-break: break-all; }
.meta-row a:hover { text-decoration: underline; }
.report-badge { background: var(--brand); color: #fff; padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .5px; align-self: flex-start; white-space: nowrap; }

.stats-bar { display: flex; border-bottom: 1px solid var(--border); background: var(--surface); }
.stat-cell { flex: 1; padding: 14px 24px; border-right: 1px solid var(--border); }
.stat-cell:last-child { border-right: none; }
.stat-num { display: block; font-size: 26px; font-weight: 700; line-height: 1; letter-spacing: -1px; margin-bottom: 2px; }
.stat-label { font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: .5px; color: #475569; }
.stat-cell.violations .stat-num { color: var(--critical); }
.stat-cell.incomplete  .stat-num { color: var(--moderate); }
.stat-cell.passes      .stat-num { color: var(--minor); }
a.stat-cell { display: block; text-decoration: none; color: inherit; cursor: pointer; transition: background .15s; }
a.stat-cell:hover { background: #eff6ff; }
html { scroll-behavior: smooth; }

.report-body { padding: 28px 32px; max-width: 1400px; margin: 0 auto; }

.section { margin-bottom: 28px; margin-top: 14px; }
.section-header { display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; margin-bottom: 10px; }
.section-header h2 { margin: 0; font-size: 17px; font-weight: 700; display: flex; align-items: center; gap: 8px; }
.section-header h2::before { content: ''; display: inline-block; width: 4px; height: 16px; border-radius: 2px; background: var(--brand); flex-shrink: 0; }
.section[data-section="violations"]                     .section-header h2::before { background: var(--critical); }
.section[data-section="incomplete"]                     .section-header h2::before { background: var(--moderate); }
.section[data-section="incomplete-needs-manual-review"] .section-header h2::before { background: var(--moderate); }
.section[data-section="passes"]                         .section-header h2::before { background: var(--minor); }
.section-controls { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }
.section-toggle { display: flex; align-items: center; gap: 6px; font-size: 12px; color: var(--muted); cursor: pointer; user-select: none; }

table { width: 100%; border-collapse: separate; border-spacing: 0; background: var(--surface); border-radius: var(--radius); box-shadow: var(--shadow); overflow: hidden; margin-bottom: 8px; }
th { background: #f1f5f9; color: var(--muted); font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .5px; padding: 10px 12px; text-align: left; border-bottom: 1px solid var(--border); }
td { padding: 11px 12px; border-bottom: 1px solid var(--border); vertical-align: top; font-size: 13px; }
tr:last-child td { border-bottom: none; }
tbody tr:nth-child(even) td { background: var(--surface-alt); }
tbody tr:hover td { background: #eff6ff; }

.impact { font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .4px; white-space: nowrap; padding: 3px 9px; border-radius: 20px; display: inline-block; }
.impact.critical { background: var(--critical-bg); color: var(--critical); border: 1px solid var(--critical-bd); }
.impact.serious  { background: var(--serious-bg);  color: var(--serious);  border: 1px solid var(--serious-bd);  }
.impact.moderate { background: var(--moderate-bg); color: var(--moderate); border: 1px solid var(--moderate-bd); }
.impact.minor    { background: var(--minor-bg);    color: var(--minor);    border: 1px solid var(--minor-bd);    }

.tag { display: inline-block; background: #eff6ff; color: #2563eb; border: 1px solid #bfdbfe; padding: 2px 7px; margin: 2px; border-radius: 20px; font-size: 11px; font-weight: 500; }

.badge { display: inline-block; margin-bottom: 6px; padding: 2px 8px; border-radius: 20px; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: .3px; }
.badge-sub { font-size: 11px; color: var(--muted); margin: 0 0 6px 2px; word-break: break-word; }
.badge.removed    { background: #fef2f2; color: #991b1b; border: 1px solid #fca5a5; }
.badge.normalized { background: #f0fdf4; color: #166534; border: 1px solid #86efac; }
.badge.filtered   { background: #fff7ed; color: #9a3412; border: 1px solid #fdba74; }

.element-counter { display: inline-block; background: var(--brand); color: #fff; padding: 2px 7px; border-radius: 12px; font-size: 10px; font-weight: 700; margin-right: 8px; text-transform: uppercase; letter-spacing: 0.3px; }

details { margin-bottom: 6px; }
details summary { cursor: pointer; background: #f1f5f9; border: 1px solid var(--border); border-radius: 6px; padding: 7px 12px; font-size: 12px; font-weight: 600; color: var(--brand); list-style: none; display: flex; align-items: center; gap: 6px; user-select: none; transition: background .15s; }
details summary::-webkit-details-marker { display: none; }
details summary::before { content: '›'; font-size: 16px; font-weight: 700; color: var(--brand); transition: transform .2s; display: inline-block; line-height: 1; }
details[open] summary::before { transform: rotate(90deg); }
details[open] summary { background: #dbeafe; border-color: #bfdbfe; border-radius: 6px 6px 0 0; }
details[open] > ul, details[open] > div.group-list { border: 1px solid var(--border); border-top: none; border-radius: 0 0 6px 6px; padding: 8px; background: var(--surface); }
details ul { margin: 0; padding: 0; list-style: none; }
details li { padding: 8px 0; border-bottom: 1px solid var(--border); }
details li:last-child { border-bottom: none; padding-bottom: 0; }

.debug-block { margin-top: 8px; background: #f8fafc; border: 1px solid var(--border); border-left: 3px solid #94a3b8; border-radius: 0 6px 6px 0; padding: 10px 12px; font-size: 12px; }
.debug-title { font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: .5px; color: var(--muted); margin-bottom: 8px; }
.debug-grid { display: grid; grid-template-columns: 160px 1fr; gap: 4px 12px; margin: 0; }
.debug-grid div { display: contents; }
.debug-grid dt { font-weight: 600; color: #475569; }
.debug-grid dd { margin: 0; word-break: break-word; }
.debug-code { margin: 6px 0 0; padding: 8px; background: #0f172a; color: #e2e8f0; border-radius: 4px; font-size: 11px; font-family: 'Courier New', Courier, monospace; white-space: pre-wrap; word-break: break-word; }
.debug-list { margin: 6px 0 0 16px; padding: 0; }
.debug-list li { margin: 2px 0; border-bottom: none; padding: 0; }

.fix-guidance { margin-top: 8px; background: var(--surface); border: 1px solid #fcd34d; border-left: 4px solid #f59e0b; border-radius: 0 6px 6px 0; padding: 12px 14px; font-size: 12px; }
.fix-title { font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: .6px; color: #92400e; margin-bottom: 10px; }
.fix-meta { font-size: 11px; color: var(--muted); margin-bottom: 8px; word-break: break-word; font-family: 'Courier New', Courier, monospace; }
.fix-subtitle { font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: .6px; color: #78350f; margin: 10px 0 4px; }
.fix-divider { height: 1px; background: #fde68a; margin: 8px 0; }
.fix-actions { display: flex; gap: 8px; flex-wrap: wrap; margin: 4px 0 10px; }
.copy-btn { border: 1px solid #d97706; background: transparent; color: #92400e; padding: 4px 10px; font-size: 11px; font-weight: 600; border-radius: 4px; cursor: pointer; transition: background .15s; }
.copy-btn:hover { background: #fef3c7; }
.fix-list { margin: 0; padding: 0; list-style: none; }
.fix-list li { padding: 3px 0 3px 12px; position: relative; border-bottom: none; color: var(--text); }
.fix-list li::before { content: '›'; position: absolute; left: 0; color: #f59e0b; font-weight: 700; }

.builtin-minimal { padding: 6px 0; font-size: 12px; color: var(--muted); }

.pagination-footer { display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; margin-top: 8px; padding: 8px 12px; background: var(--surface); border-radius: var(--radius); border: 1px solid var(--border); }
.page-status { font-size: 12px; color: var(--muted); }
.pagination { display: inline-flex; align-items: center; gap: 4px; font-size: 12px; }
.pagination button, .page-link { border: 1px solid var(--border); background: var(--surface); color: var(--text); padding: 4px 10px; border-radius: 4px; cursor: pointer; font-size: 12px; font-weight: 500; transition: background .15s, border-color .15s; }
.pagination button:hover, .page-link:hover { background: #2563eb; border-color: #2563eb; color: #fff; }
.pagination button[disabled] { opacity: .4; cursor: default; }
.pagination button[disabled]:hover { background: var(--surface); border-color: var(--border); color: var(--text); }
.page-link.active { background: var(--brand); border-color: var(--brand); color: #fff; cursor: default; }
.page-links { display: inline-flex; gap: 4px; flex-wrap: wrap; }
.page-ellipsis { padding: 0 4px; color: var(--muted); }

.empty { font-style: italic; color: var(--muted); padding: 24px; text-align: center; background: var(--surface); border-radius: var(--radius); border: 1px dashed var(--border); margin-bottom: 28px; }
a { color: var(--brand); text-decoration: none; font-weight: 500; }
a:hover { text-decoration: underline; }
.url { font-size: 12px; word-break: break-all; color: var(--brand); min-width: 240px; }

.copy-target-btn { border: 1px solid #3b82f6; background: transparent; color: #1e40af; padding: 3px 8px; font-size: 11px; font-weight: 600; border-radius: 3px; cursor: pointer; transition: background .15s; white-space: nowrap; }
.copy-target-btn:hover { background: #dbeafe; }

.copy-btn { border: 1px solid #d97706; background: transparent; color: #92400e; padding: 4px 10px; font-size: 11px; font-weight: 600; border-radius: 4px; cursor: pointer; transition: background .15s; }
.copy-btn:hover { background: #fef3c7; }
      </style>
    </head>

    <body>

    <div class="report-header">
    <div>
      <h1>Accessibility Summary Report</h1>
      <div class="meta-row">
        <span><strong>Pages Scanned:</strong> ${pages.length}</span>
        <span><strong>Generated:</strong> ${formatDate(new Date())}</span>
        <span><strong>Version:</strong> ${extVersion}</span>
      </div>
    </div>
    <span class="report-badge">${isNormalized ? "Normalized" : "Raw"}</span>
  </div>
  <div class="stats-bar">
    <a class="stat-cell violations" href="#section-violations">
      <span class="stat-num">${violations.length}</span>
      <span class="stat-label">Violations</span>
    </a>
    <a class="stat-cell incomplete" href="#section-incomplete">
      <span class="stat-num">${incomplete.length}</span>
      <span class="stat-label">Incomplete</span>
    </a>
    <a class="stat-cell passes" href="#section-passes">
      <span class="stat-num">${passes.length}</span>
      <span class="stat-label">Passes</span>
    </a>
  </div>
  <div class="report-body">
    <details>
      <summary style="font-size:18px;font-weight:bold;cursor:pointer;">
        Summary by Rule
      </summary>
      ${renderSummaryByRule(rulesSummary)}
    </details>

    <details>
      <summary style="font-size:18px;font-weight:bold;cursor:pointer;">
        Summary by Page
      </summary>
      ${renderSummaryByPage(pages)}
    </details>

    ${renderTable("Violations", violations)}
    ${renderTable("Incomplete", incomplete)}
    ${renderTable("Passes", passes)}
    <!-- ${renderTable("Inapplicable", inapplicable)} -->
  </div>
  </body>
  </html>

    <script>
      (function () {
        ${getReportClientHelpers()}

        function renderNodeDetails(node) {
          var targetLabel = Array.isArray(node && node.target) && node.target.length
            ? node.target.join(", ")
            : "";
          var xpathLabel = node && node.xpath ? node.xpath : "n/a";
          var targetOutput = !node || !node.xpath ? (targetLabel || "n/a") : targetLabel;
          var hasCopyableTarget = (!node || !node.xpath) && targetOutput && targetOutput !== "n/a";
          var html = "";
          html += '<div class="debug-block">';
          html += '<div class="debug-title" style="display:flex;align-items:center;gap:12px;">Node Details' +
            (hasCopyableTarget ? ' <button class="copy-target-btn" data-copy="' + escapeAttr(targetOutput) + '">Copy target</button>' : '') + '</div>';
          html += '<div><strong>XPath:</strong> ' + escapeHtml(xpathLabel) + "</div>";
          if (!node || !node.xpath) {
            html += '<div><strong>Target:</strong> ' + escapeHtml(targetOutput) + "</div>";
          }
          if (node && node.html) {
            html += '<div><strong>HTML:</strong></div>';
            html += '<pre class="debug-code">' + escapeHtml(node.html) + "</pre>";
          }
          html += "</div>";
          return html;
        }

        function renderGenericDebug(node, impact) {
          var checks = []
            .concat((node && node.any) || [], (node && node.all) || [], (node && node.none) || []);
          var reason = "";
          for (var i = 0; i < checks.length; i += 1) {
            if (checks[i] && checks[i].data && checks[i].data.reason) {
              reason = checks[i].data.reason;
              break;
            }
          }
          if (!reason) {
            for (var j = 0; j < checks.length; j += 1) {
              var msg = checks[j] && checks[j].message ? checks[j].message.trim() : "";
              if (msg && !/^fix (any|all) of the following:?$/i.test(msg)) {
                reason = msg;
                break;
              }
            }
          }
          if (!reason && node && node.failureSummary) {
            reason = node.failureSummary
              .replace(/^fix any of the following:\s*/i, "")
              .replace(/^fix all of the following:\s*/i, "")
              .trim();
          }
          if (!reason) return "";

          var checkIds = [];
          for (var k = 0; k < checks.length; k += 1) {
            if (checks[k] && checks[k].id) checkIds.push(checks[k].id);
          }

          var html = "";
          html += '<div class="debug-block">';
          html += '<div class="debug-title">Debug Details</div>';
          html += '<dl class="debug-grid">';
          html += '<div><dt>Reason</dt><dd>' + escapeHtml(reason) + "</dd></div>";
          if (checkIds.length) {
            html += '<div><dt>Check IDs</dt><dd>' + escapeHtml(checkIds.join(", ")) + "</dd></div>";
          }
          if (impact) {
            html += '<div><dt>Impact</dt><dd>' + escapeHtml(impact) + "</dd></div>";
          }
          html += "</dl>";
          html += "</div>";
          return html;
        }

        function renderReflowDebug(node) {
          var checks = []
            .concat((node && node.any) || [], (node && node.all) || [], (node && node.none) || []);
          var data = null;
          for (var i = 0; i < checks.length; i += 1) {
            if (checks[i] && checks[i].id === "sc-1410-reflow-min-width-over-320" && checks[i].data) {
              data = checks[i].data;
              break;
            }
          }
          if (!data) return "";
          var html = "";
          html += '<div class="debug-block">';
          html += '<div class="debug-title">Debug Details</div>';
          html += '<dl class="debug-grid">';
          html += '<div><dt>Reason</dt><dd>' + escapeHtml(data.reason || "") + "</dd></div>";
          html += '<div><dt>Outcome</dt><dd>' + escapeHtml(data.outcome || "fail") + "</dd></div>";
          if (data.riskType) {
            html += '<div><dt>Risk Type</dt><dd>' + escapeHtml(data.riskType) + "</dd></div>";
          }
          html += '<div><dt>MinWidth</dt><dd>' + escapeHtml(String(data.minWidth || "")) + "</dd></div>";
          html += '<div><dt>InlineWidth</dt><dd>' + escapeHtml(String(data.inlineWidth || "")) + "</dd></div>";
          html += '<div><dt>Limit</dt><dd>' + escapeHtml(String(data.limit || "")) + "</dd></div>";
          if (data.clipX !== undefined) {
            html += '<div><dt>ClipX</dt><dd>' + escapeHtml(String(data.clipX)) + "</dd></div>";
          }
          if (data.clipY !== undefined) {
            html += '<div><dt>ClipY</dt><dd>' + escapeHtml(String(data.clipY)) + "</dd></div>";
          }
          if (data.metrics) {
            html += '<div><dt>Metrics</dt><dd>' + escapeHtml(JSON.stringify(data.metrics)) + "</dd></div>";
          }
          if (data.boundingBox) {
            html += '<div><dt>Bounding Box</dt><dd>' + escapeHtml(JSON.stringify(data.boundingBox)) + "</dd></div>";
          }
          if (Array.isArray(data.samplePoints)) {
            html += '<div><dt>Sample Points</dt><dd>' + escapeHtml(JSON.stringify(data.samplePoints)) + "</dd></div>";
          }
          if (data.style) {
            html += '<div><dt>Style</dt><dd>' + escapeHtml(JSON.stringify(data.style)) + "</dd></div>";
          }
          html += "</dl>";
          html += "</div>";
          return html;
        }

        function renderHoverFocusContentDebug(node) {
          var checks = []
            .concat((node && node.any) || [], (node && node.all) || [], (node && node.none) || []);
          var data = null;
          for (var i = 0; i < checks.length; i += 1) {
            if (checks[i] && checks[i].id === "sc-1413-title-tooltip-disallowed" && checks[i].data) {
              data = checks[i].data;
              break;
            }
          }
          if (!data) return "";
          var matchedPatterns = Array.isArray(data.matchedPatterns) ? data.matchedPatterns : [];
          var matchedHandlers = Array.isArray(data.matchedHandlers) ? data.matchedHandlers : [];
          var dismissSignals = Array.isArray(data.dismissSignalsFound) ? data.dismissSignalsFound : [];
          var html = "";
          html += '<div class="debug-block">';
          html += '<div class="debug-title">Debug Details</div>';
          html += '<dl class="debug-grid">';
          html += '<div><dt>Reason</dt><dd>' + escapeHtml(data.reason || "") + "</dd></div>";
          html += '<div><dt>Outcome</dt><dd>' + escapeHtml(data.outcome || "") + "</dd></div>";
          html += '<div><dt>Trigger Type</dt><dd>' + escapeHtml(data.triggerType || "") + "</dd></div>";
          html += '<div><dt>Matched Patterns</dt><dd>' + escapeHtml(matchedPatterns.join(", ")) + "</dd></div>";
          html += '<div><dt>Matched Handlers</dt><dd>' + escapeHtml(matchedHandlers.join(", ")) + "</dd></div>";
          html += '<div><dt>Dismiss Signals</dt><dd>' + escapeHtml(dismissSignals.join(", ")) + "</dd></div>";
          html += '<div><dt>Dismiss Scope</dt><dd>' + escapeHtml(data.dismissScope || "") + "</dd></div>";
          html += '<div><dt>Interactive</dt><dd>' + escapeHtml(String(data.isInteractive !== undefined ? data.isInteractive : "")) + "</dd></div>";
          html += '<div><dt>Hidden</dt><dd>' + escapeHtml(String(data.isHidden !== undefined ? data.isHidden : "")) + "</dd></div>";
          html += "</dl>";
          html += "</div>";
          return html;
        }

        function renderRuleDebug(node, ruleId, impact) {
          if (ruleId === "custom-wcag22-sc-1410-reflow") {
            return renderReflowDebug(node);
          }
          if (ruleId === "custom-wcag22-sc-1413-hover-focus-content") {
            return renderHoverFocusContentDebug(node);
          }
          return renderGenericDebug(node, impact);
        }

        function getCheckData(node, checkId) {
          var checks = []
            .concat((node && node.any) || [], (node && node.all) || [], (node && node.none) || []);
          for (var i = 0; i < checks.length; i += 1) {
            if (checks[i] && checks[i].id === checkId) return checks[i].data || null;
          }
          return null;
        }

        function renderFixGuidance(node, ruleId, sectionName) {
          if (sectionName !== "Violations") return "";
          if (!ruleId || ruleId.indexOf("custom") !== 0) return "";
          var items = [];

          if (ruleId === "custom-wcag22-sc-1411-non-text-contrast") {
            var data =
              getCheckData(node, "sc-1411-non-text-contrast-min-3") ||
              (node && node.__nonTextContrastDebug) ||
              null;
            if (!data) return "";
            items.push("Ensure non-text UI components and focus indicators have at least 3:1 contrast against adjacent colors.");
            if (data.ratio !== null && data.ratio !== undefined) {
              items.push("Current contrast ratio: " + data.ratio + " (minimum " + (data.minContrast || 3) + ").");
            }
            var colors = data.colors || {};
            var outlineWidth = (colors.outlineWidth || "").trim();
            var borderWidth = (colors.borderWidth || "").trim();
            if (outlineWidth && outlineWidth !== "0px") {
              items.push("This looks like an outline/focus indicator. Increase outline color contrast or thickness.");
            } else if (borderWidth && borderWidth !== "0px") {
              items.push("This looks like a border. Increase border color contrast against the background.");
            } else {
              items.push("Increase contrast for the component fill/background against adjacent colors.");
            }
          }

          if (ruleId === "custom-wcag22-sc-1412-text-spacing") {
            var dataTs = getCheckData(node, "sc-1412-text-spacing-no-clipping");
            if (!dataTs) return "";
            items.push("Allow increased text spacing without clipping.");
            var clipX = dataTs.clipping && dataTs.clipping.clippedX;
            var clipY = dataTs.clipping && dataTs.clipping.clippedY;
            if (clipX || clipY) {
              var axis = clipX && clipY ? "horizontal and vertical" : clipX ? "horizontal" : "vertical";
              items.push("Text is clipped on the " + axis + " axis after spacing changes.");
            }
            if (dataTs.style && (dataTs.style.overflowX === "hidden" || dataTs.style.overflowY === "hidden" || dataTs.style.overflowX === "clip" || dataTs.style.overflowY === "clip")) {
              items.push("Avoid overflow: hidden/clip when fixed dimensions are used. Prefer min-height/auto height or allow overflow.");
            }
            if (dataTs.baselineClipping && (dataTs.baselineClipping.clippedX || dataTs.baselineClipping.clippedY)) {
              items.push("The text was already clipped before spacing changes. Fix base layout or sizing first.");
            }
          }

          if (ruleId === "custom-wcag22-sc-2411-focus-not-obscured-minimum") {
            var dataFn = getCheckData(node, "sc-2411-focus-not-obscured-minimum-visible");
            if (!dataFn) return "";
            items.push("Ensure the focused element is not covered by other content.");
            if (dataFn.obscuredBy && dataFn.obscuredBy.length) {
              items.push("Covered by: " + dataFn.obscuredBy.join(", ") + ".");
            }
            items.push("Adjust z-index or layout of overlays/sticky headers, or add scroll padding so focus is visible.");
          }

          if (ruleId === "custom-wcag22-sc-324-consistent-identification") {
            var dataCi = getCheckData(node, "sc-324-consistent-identification");
            if (!dataCi) return "";
            items.push("Use the same accessible name for controls that share the same destination or consistent ID.");
            if (dataCi.distinctNames && dataCi.distinctNames.length) {
              items.push("Current names differ: " + dataCi.distinctNames.join(", ") + ".");
            }
          }

          if (ruleId === "custom-wcag22-sc-1413-hover-focus-content") {
            var dataHf = getCheckData(node, "sc-1413-title-tooltip-disallowed");
            if (!dataHf) return "";
            if (dataHf.reason === "TITLE_TOOLTIP") {
              items.push("Avoid using the title attribute as hover/focus content.");
              items.push("Provide a persistent tooltip/popover that remains on hover/focus and can be dismissed.");
            } else {
              items.push("Ensure hover/focus-triggered content is dismissible and remains visible while the pointer or focus is on it.");
              if (!dataHf.hasEscapeHandler) {
                items.push("Add a clear dismiss mechanism, such as Escape or a close button.");
              }
            }
          }

          if (ruleId === "custom-wcag22-sc-246-headings-labels") {
            var dataHl = getCheckData(node, "sc-246-heading-label-has-text");
            if (!dataHl) return "";
            if (!dataHl.accessibleName) {
              items.push("Add descriptive text or an accessible name using aria-label or aria-labelledby.");
            } else {
              items.push("Ensure headings and labels remain descriptive and consistent with the visible text.");
            }
            if (dataHl.hidden) {
              items.push("Make sure the heading/label is not hidden from assistive technology.");
            }
          }


          if (!items.length) return "";
          var html = "";
          html += '<div class="fix-guidance">';
          html += '<div class="fix-title">Fix Guidance</div>';
          html += '<ul class="fix-list">';
          for (var i = 0; i < items.length; i += 1) {
            html += "<li>" + escapeHtml(items[i]) + "</li>";
          }
          html += "</ul>";
          html += "</div>";
          return html;
        }

        function renderBuiltInMinimal(node) {
          var targetLabel = (node && node.__uniqueTarget) || "";
          if (!targetLabel && Array.isArray(node && node.target) && node.target.length) {
            targetLabel = node.target.join(", ");
          }
          targetLabel = targetLabel || "n/a";
          var failureSummary = (node && node.failureSummary) || "n/a";
          var hasCopyableTarget = targetLabel !== "n/a";
          var html = '<div class="debug-block">';
          html += '<div style="display:flex;align-items:center;gap:12px;margin-bottom:4px;"><strong>Details</strong>';
          if (hasCopyableTarget) {
            html += ' <button class="copy-target-btn" data-copy="' + escapeAttr(targetLabel) + '">Copy target</button>';
          }
          html += '</div>';
          html += '<div><strong>Target:</strong> ' + escapeHtml(targetLabel) + '</div>';
          html += '<div><strong>Summary:</strong> ' + escapeHtml(failureSummary) + '</div>';
          html += '</div>';
          return html;
        }

        function renderNodesFromPayload(payload) {
          if (!payload || !Array.isArray(payload.nodes)) return "";
          var isCustomRule = String(payload.ruleId || "").indexOf("custom") === 0;
          var items = "";
          for (var i = 0; i < payload.nodes.length; i += 1) {
            var node = payload.nodes[i];
            items += "<li>";
            items += '<span class="element-counter">Element ' + (i + 1) + '</span>';
            items += renderNodeDetails(node);
            items += renderFixGuidance(node, payload.ruleId || "", payload.sectionName || "");
            items += renderRuleDebug(node, payload.ruleId || "", payload.ruleImpact || "");
            items += "</li>";
          }
          var html = "";
          html += "<details>";
          html += "<summary>" + payload.nodes.length + " element(s)</summary>";
          html += "<ul>" + items + "</ul>";
          html += "</details>";
          return html;
        }

        function loadSection(sectionName) {
          var placeholders = document.querySelectorAll(
            '.lazy-nodes[data-section="' + sectionName + '"]'
          );
          placeholders.forEach(function (placeholder) {
            if (placeholder.dataset.loaded === "true") return;
            var ruleId = placeholder.getAttribute("data-rule-id");
            var script = document.querySelector(
              '.nodes-data[data-section="' + sectionName + '"][data-rule-id="' + ruleId + '"]'
            );
            if (!script) return;
            try {
              var payload = JSON.parse(script.textContent || "{}");
              placeholder.innerHTML = renderNodesFromPayload(payload);
              var countEl = placeholder.previousElementSibling;
              if (countEl && countEl.classList && countEl.classList.contains("lazy-count")) {
                countEl.style.display = "none";
              }
              placeholder.dataset.loaded = "true";
            } catch (e) {
              placeholder.innerHTML = "<em>Failed to load details</em>";
            }
          });
        }

        document.querySelectorAll(".toggle-details").forEach(function (toggle) {
          toggle.addEventListener("change", function () {
            var section = this.getAttribute("data-section");
            if (this.checked) {
              loadSection(section);
            } else {
            document.querySelectorAll('.lazy-nodes[data-section="' + section + '"]').forEach(function (el) {
              el.innerHTML = "";
              el.dataset.loaded = "false";
              var countEl = el.previousElementSibling;
              if (countEl && countEl.classList && countEl.classList.contains("lazy-count")) {
                countEl.style.display = "";
              }
            });
            }
          });
        });

        document.addEventListener("click", function (event) {
          var target = event.target;
          if (!target || !target.closest) return;
          var btn = target.closest(".copy-btn");
          if (!btn) return;
          var text = btn.getAttribute("data-copy") || "";
          var original = btn.textContent;
          copyText(text).then(function () {
            btn.textContent = "Copied";
            setTimeout(function () {
              btn.textContent = original;
            }, 1200);
          }).catch(function () {
            btn.textContent = "Copy failed";
            setTimeout(function () {
              btn.textContent = original;
            }, 1200);
          });
        });

        document.addEventListener("click", function (event) {
          var target = event.target;
          if (!target || !target.closest) return;
          var btn = target.closest(".copy-target-btn");
          if (!btn) return;
          var text = btn.getAttribute("data-copy") || "";
          var original = btn.textContent;
          copyText(text).then(function () {
            btn.textContent = "Copied";
            setTimeout(function () {
              btn.textContent = original;
            }, 2000);
          }).catch(function () {
            btn.textContent = "Copy failed";
            setTimeout(function () {
              btn.textContent = original;
            }, 2000);
          });
        });

        function initPagination() {
          document.querySelectorAll(".section[data-page-size]").forEach(function (section) {
            var pageSize = parseInt(section.getAttribute("data-page-size"), 10) || 5;
            var rows = Array.prototype.slice.call(section.querySelectorAll("tbody > tr"));
            if (!rows.length) return;
            var currentPage = 1;
            var totalPages = Math.max(1, Math.ceil(rows.length / pageSize));
            var prev = section.querySelector(".page-prev");
            var next = section.querySelector(".page-next");
            var links = section.querySelector(".page-links");
            var status = section.querySelector(".page-status");

            function addEllipsis() {
              if (!links) return;
              var ellipsis = document.createElement("span");
              ellipsis.className = "page-ellipsis";
              ellipsis.textContent = "...";
              links.appendChild(ellipsis);
            }

            function addPageLink(pageNum) {
              if (!links) return;
              var btn = document.createElement("button");
              btn.type = "button";
              btn.className = "page-link" + (pageNum === currentPage ? " active" : "");
              btn.textContent = String(pageNum);
              if (pageNum !== currentPage) {
                btn.addEventListener("click", function () {
                  currentPage = pageNum;
                  renderPage();
                });
              }
              links.appendChild(btn);
            }

            function renderLinks() {
              if (!links) return;
              links.innerHTML = "";
              if (totalPages <= 3) {
                for (var i = 1; i <= totalPages; i += 1) {
                  addPageLink(i);
                }
                return;
              }

              addPageLink(1);

              var start = Math.max(2, currentPage - 1);
              var end = Math.min(totalPages - 1, currentPage + 1);

              if (start > 2) addEllipsis();

              for (var p = start; p <= end; p += 1) {
                addPageLink(p);
              }

              if (end < totalPages - 1) addEllipsis();

              addPageLink(totalPages);
            }

            function renderStatus() {
              if (!status) return;
              var startIndex = (currentPage - 1) * pageSize + 1;
              var endIndex = Math.min(currentPage * pageSize, rows.length);
              status.textContent = "Showing " + startIndex + "-" + endIndex + " of " + rows.length + " entries";
            }

            function renderPage() {
              var start = (currentPage - 1) * pageSize;
              var end = start + pageSize;
              rows.forEach(function (row, idx) {
                row.style.display = idx >= start && idx < end ? "" : "none";
              });
              if (prev) prev.disabled = currentPage <= 1;
              if (next) next.disabled = currentPage >= totalPages;
              renderLinks();
              renderStatus();
            }

            if (prev) {
              prev.addEventListener("click", function () {
                if (currentPage > 1) {
                  currentPage -= 1;
                  renderPage();
                }
              });
            }

            if (next) {
              next.addEventListener("click", function () {
                if (currentPage < totalPages) {
                  currentPage += 1;
                  renderPage();
                }
              });
            }

            renderPage();
          });
        }

        initPagination();

      })();
    </script>

  </body>
  </html>
    `;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  /**
   * ---------------------------------------------------------
   * Popup -> Start scanning
   * ---------------------------------------------------------
   */
  if (msg.action === "START") {
    aggregatedResults = [];
    const scanId = createScanId();
    startScanCompletionId = scanId;
    pendingPageReadyScan = null;
    setScanState(true, { startScanInProgress: true });
    console.log("[BG] Scanning session STARTED");

    clearStartScanTimeout();
    startScanTimeoutId = setTimeout(() => {
      if (startScanCompletionId === scanId) {
        startScanCompletionId = null;
        setScanState(true, { startScanInProgress: false });
        chrome.runtime.sendMessage({ type: "START_SCAN_TIMEOUT" });
        console.warn("[BG] Start scan timeout - re-enabling Stop button");
      }
      startScanTimeoutId = null;
    }, 30000);

    triggerScanOnActiveTab({
      scanId,
      manual: false,
    });
  }

  /**
   * ---------------------------------------------------------
   * Popup -> Stop scanning
   * ---------------------------------------------------------
   */
  if (msg.action === "STOP") {
    startScanCompletionId = null;
    clearStartScanTimeout();
    setScanState(false, { startScanInProgress: false });
    console.log("[BG] Scanning session STOPPED");

    if (!aggregatedResults.length) {
      console.warn("[BG] No pages scanned. Summary report not generated.");
      return;
    }

    getReportSettings((reportSettings) => {
      const pagesSnapshot = aggregatedResults.map((page) => ({
        url: page.url,
        results: page.rawResults,
        suppressionMetadata: page.suppressionMetadata,
        phase1Filtered: page.phase1Filtered,
      }));
      const summaryHtml = buildSummaryHtmlReport(pagesSnapshot, reportSettings);

      const dataUrl = "data:text/html;charset=utf-8," + encodeURIComponent(summaryHtml);

      chrome.downloads.download(
        {
          url: dataUrl,
          filename: `accessibility-summary-report-${Date.now()}.html`,
          saveAs: false,
        },
        (downloadId) => {
          if (chrome.runtime.lastError) {
            console.error("[BG] Summary Report download failed:", chrome.runtime.lastError.message);
          } else {
            console.log("[BG] Summary Report downloaded, ID:", downloadId);
          }
        }
      );
      aggregatedResults = [];
    });
  }

  if (msg.action === "SCAN_CURRENT_PAGE") {
    console.log("[BG] Scan current page requested");
    console.log("[BG][TIMING] SCAN_CURRENT_PAGE received", Date.now());
    manualScanInProgress = true;

    manualScanId = createScanId();
    console.log("[BG][TIMING] Manual scanId created", manualScanId, Date.now());
    triggerScanOnActiveTab({
      scanId: manualScanId,
      manual: true,
    });
  }

  /**
   * ---------------------------------------------------------
   * Content script -> Page ready
   * Auto-scan on navigation if session active
   * ---------------------------------------------------------
   */
  if (msg.type === "PAGE_READY") {
    console.log("[BG] PAGE_READY:", msg.url);

    // Skip auto-scan if manual scan is running
    if (manualScanInProgress) {
      console.log("[BG] Skipping auto-scan due to manual scan in progress");
      return;
    }

    getScanState((isActive) => {
      if (isActive && sender.tab?.id) {
        if (startScanCompletionId) {
          pendingPageReadyScan = {
            tabId: sender.tab.id,
            url: msg.url,
          };
          console.log("[BG] PAGE_READY queued until start scan completes");
          return;
        }
        sendStartScan(sender.tab.id, {
          scanId: createScanId(),
          manual: false,
          url: msg.url,
        });
        console.log("[BG] START_SCAN sent due to PAGE_READY");
      }
    });
  }

  /**
   * ---------------------------------------------------------
   * Content script -> Axe results received
   * ---------------------------------------------------------
   */
  if (msg.type === "AXE_RESULTS") {
    console.log("[BG] AXE_RESULTS received for:", msg.url);

    const scanId = msg.scanId || msg.payload?.__debug?.scanId || manualScanId;

    getScanState((isActive) => {
      // Allow download for manual OR automated scan
      if (!isActive && !manualScanInProgress) {
        console.log("[BG] Ignoring AXE_RESULTS - no active scan");
        return;
      }

      // -----------------------------------------------------
      // 1. Aggregate results for summary
      // -----------------------------------------------------
      const rawResults = msg.payload?.rawResults || msg.payload;
      const phase2InputResults = msg.payload?.phase2InputResults || rawResults;
      const phase1Filtered = msg.payload?.phase1Filtered || msg.payload?.phase1?.filtered || [];
      const providedSuppression = msg.payload?.phase2SuppressionMetadata;

      let suppressionMetadata = [];
      let phase2DedupedResults = phase2InputResults;

      if (Array.isArray(providedSuppression) && providedSuppression.length) {
        suppressionMetadata = providedSuppression;
      } else {
        const phase2Output = normalizeAxeResults(phase2InputResults);
        phase2DedupedResults = phase2Output.normalizedResults;
        suppressionMetadata = phase2Output.suppressionMetadata;
      }

      aggregatedResults.push({
        url: msg.url,
        rawResults,
        phase1Filtered,
        phase2DedupedResults,
        normalizedResults: phase2DedupedResults,
        suppressionMetadata,
      });

      console.log(
        "[BG] Results aggregated for:",
        msg.url,
        "Total pages:",
        aggregatedResults.length
      );

      getReportSettings((reportSettings) => {
        const html = buildHtmlReport(
          {
            url: msg.url,
            results: rawResults,
            suppressionMetadata,
            phase1Filtered,
          },
          reportSettings
        );

        const dataUrl = "data:text/html;charset=utf-8," + encodeURIComponent(html);

        chrome.downloads.download(
          {
            url: dataUrl,
            filename: buildPageReportFilename(msg.url),
            saveAs: false,
          },
          (downloadId) => {
            if (chrome.runtime.lastError) {
              console.error("[BG] Page Report download failed:", chrome.runtime.lastError.message);
            } else {
              console.log("[BG] Page Report downloaded, ID:", downloadId);
            }

            if (manualScanInProgress) {
              manualScanInProgress = false;
              console.log("[BG] Manual scan completed");
            }

            if (startScanCompletionId && scanId === startScanCompletionId) {
              startScanCompletionId = null;
              clearStartScanTimeout();
              setScanState(true, { startScanInProgress: false });
              chrome.runtime.sendMessage({ type: "START_SCAN_COMPLETED" });
              if (
                pendingPageReadyScan &&
                pendingPageReadyScan.tabId === sender.tab?.id &&
                pendingPageReadyScan.url === msg.url
              ) {
                pendingPageReadyScan = null;
              } else if (pendingPageReadyScan) {
                sendStartScanForPageReady(pendingPageReadyScan);
                pendingPageReadyScan = null;
              }
            }
          }
        );
      });
    });
    return true;
  }
});
