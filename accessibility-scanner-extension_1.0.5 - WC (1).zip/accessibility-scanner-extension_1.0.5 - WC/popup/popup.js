const status = document.getElementById('status');
let startScanInProgress = false;

document.getElementById('startBtn').onclick = () => {
  chrome.runtime.sendMessage({ action: 'START' });
  startScanInProgress = true;
  updateUI(true, startScanInProgress);
};

document.getElementById('stopBtn').onclick = () => {
  chrome.runtime.sendMessage({ action: 'STOP' });
  startScanInProgress = false;
  updateUI(false, startScanInProgress);
};

document.getElementById("scanBtn").addEventListener("click", () => {
  console.log("[POPUP][TIMING] Scan Current Page clicked", Date.now());
  chrome.runtime.sendMessage({ action: "SCAN_CURRENT_PAGE" });
});

function loadReportSettings() {
  chrome.storage.local.get("reportSettings", (data) => {
    const settings = Object.assign(
      { showDebugDetails: true, showNormalizedOutput: true },
      data.reportSettings || {}
    );
    document.getElementById("showDebugDetails").checked =
      settings.showDebugDetails !== false;
    document.getElementById("showNormalizedOutput").checked =
      settings.showNormalizedOutput !== false;
  });
}

function saveReportSettings() {
  const settings = {
    showDebugDetails: document.getElementById("showDebugDetails").checked,
    showNormalizedOutput: document.getElementById("showNormalizedOutput").checked
  };
  chrome.storage.local.set({ reportSettings: settings });
}

document
  .getElementById("showDebugDetails")
  .addEventListener("change", saveReportSettings);
document
  .getElementById("showNormalizedOutput")
  .addEventListener("change", saveReportSettings);

document.addEventListener("DOMContentLoaded", () => {
  const version = chrome.runtime.getManifest().version;
  document.getElementById("extVersion").textContent = version;
  chrome.storage.local.get("scanState", (data) => {
    const isActive = data.scanState?.active === true;
    startScanInProgress = data.scanState?.startScanInProgress === true;
    updateUI(isActive, startScanInProgress);
  });
  loadReportSettings();

  // Accordion toggle functionality
  const settingsToggle = document.getElementById("settingsToggle");
  const settingsContent = document.getElementById("settingsContent");
  const accordionText = document.getElementById("accordionText");

  settingsToggle.addEventListener("click", () => {
    const isExpanded = settingsToggle.classList.contains("expanded");
    
    if (isExpanded) {
      settingsToggle.classList.remove("expanded");
      settingsContent.classList.remove("expanded");
      accordionText.textContent = "Show more";
    } else {
      settingsToggle.classList.add("expanded");
      settingsContent.classList.add("expanded");
      accordionText.textContent = "Show less";
    }
  });
});

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "START_SCAN_COMPLETED" || message?.type === "START_SCAN_TIMEOUT") {
    startScanInProgress = false;
    chrome.storage.local.get("scanState", (data) => {
      const isActive = data.scanState?.active === true;
      updateUI(isActive, startScanInProgress);
    });
  }
});

function updateUI(isActive, scanInProgress = false) {
  const statusText = document.getElementById("statusText");
  const statusDot  = document.getElementById("statusDot");
  const startBtn   = document.getElementById("startBtn");
  const stopBtn    = document.getElementById("stopBtn");
  const scanBtn    = document.getElementById("scanBtn");

  if (isActive) {
    statusText.textContent = "Scanning…";
    statusDot.classList.add("is-scanning");
    startBtn.disabled = true;
    stopBtn.disabled = scanInProgress;
    scanBtn.disabled = true;
  } else {
    statusText.textContent = "Ready";
    statusDot.classList.remove("is-scanning");
    startBtn.disabled = false;
    stopBtn.disabled = true;
    scanBtn.disabled = false;
  }
}