/**
 * Custom axe-core Rule — WCAG 2.2 SC 3.3.1 Error Identification
 * Rule ID  : custom-wcag22-sc-331-error-identification
 * Check ID : sc-331-error-message-present
 * Version  : 2.0
 *
 * PASS  → The form control references a recognised error-message container
 *          via aria-describedby or aria-errormessage.
 * FAIL  → No such association exists.
 */

(() => {
  "use strict";

  /* ─────────────────────────────────────────────────────────────────────────
   * 1. CONSTANTS
   * ───────────────────────────────────────────────────────────────────────── */

  const RULE_ID  = "custom-wcag22-sc-331-error-identification";
  const CHECK_ID = "sc-331-error-message-present";
  const VERSION  = "2.0";

  /** Keywords that identify an error-message container (class, id, or role). */
  const ERROR_CONTAINER_KEYWORDS = [
    "error",
    "invalid",
    "field-error",
    "form-error",
    "input-error",
    "error-message",
    "error-msg",
    "error-text",
    "alert-danger",
    "alert-error",
  ];

  /**
   * CSS selector that captures every relevant form control.
   * Scoped input types + required select/textarea (required ensures they
   * participate in constraint validation and can have validation errors).
   */
  const FORM_CONTROL_SELECTOR = [
    'input[type="text"]',
    'input[type="email"]',
    'input[type="password"]',
    'input[type="tel"]',
    'input[type="url"]',
    'input[type="number"]',
    'input[type="date"]',
    'input[type="datetime-local"]',
    'input[type="time"]',
    'input[type="month"]',
    'input[type="week"]',
    'input[type="search"]',
    'input[type="file"]',
    "select[required]",
    "textarea[required]",
  ].join(", ");

  /* ─────────────────────────────────────────────────────────────────────────
   * 2. HELPER — buildErrorBucket
   *
   * Collects every element in the document that looks like an error-message
   * container.  An element qualifies if ANY of the following is true:
   *
   *   a) Its `id` attribute contains at least one ERROR_CONTAINER_KEYWORD.
   *   b) At least one of its CSS classes contains a keyword.
   *   c) Its `role` attribute equals one of the ERROR_ARIA_ROLES.
   *
   * Returns a Set of matching HTMLElements.
   * ───────────────────────────────────────────────────────────────────────── */

  /**
   * @returns {Set<HTMLElement>}
   */
  function buildErrorBucket() {
    const bucket = new Set();

    // (a & b) Match by class / ID keywords — one querySelectorAll per keyword
    //         using the CSS *= (substring) attribute selector so the browser
    //         does the filtering natively.
    ERROR_CONTAINER_KEYWORDS.forEach((keyword) => {
      const byClassOrId = document.querySelectorAll(
        `[class*="${keyword}"], [id*="${keyword}"]`
      );
      byClassOrId.forEach((el) => bucket.add(el));
    });

    // (c) Match by ARIA role
    const byRole = document.querySelectorAll('[role="alert"], [role="status"]');
    byRole.forEach((el) => bucket.add(el));

    return bucket;
  }

  /* ─────────────────────────────────────────────────────────────────────────
   * 3. HELPER — getReferencedIds
   *
   * Parses a whitespace-separated ID list from an ARIA attribute value and
   * returns an array of non-empty string tokens.
   * ───────────────────────────────────────────────────────────────────────── */

  /**
   * Get referenced IDs from an attribute
   * @param {HTMLElement} node
   * @param {string}      attr
   * @returns {string[]}
   */
  function getReferencedIds(node, attr) {
    const raw = node.getAttribute(attr) || "";
    return raw.trim().split(/\s+/).filter(Boolean);
  }

  /* ─────────────────────────────────────────────────────────────────────────
   * 4. HELPER — hasErrorAssociation
   *
   * Returns true when the form control has at least one ID in either
   * aria-describedby or aria-errormessage that resolves to an element
   * present in the errorBucket.
   * ───────────────────────────────────────────────────────────────────────── */

  /**
   * Check association between control and error bucket.
   * Returns true if association found, false otherwise.
   * @param {HTMLElement}     node
   * @param {Set<HTMLElement>} errorBucket
   * @returns {boolean}
   */
  function hasErrorAssociation(node, errorBucket) {
    const describedByIds  = getReferencedIds(node, "aria-describedby");
    const errorMessageIds = getReferencedIds(node, "aria-errormessage");

    const allIds = [...describedByIds, ...errorMessageIds];
    return allIds.some((id) => {
      const el = document.getElementById(id);
      return el && errorBucket.has(el);
    });
  }

  /* ─────────────────────────────────────────────────────────────────────────
   * 5. AXE CHECK DEFINITION
   * ───────────────────────────────────────────────────────────────────────── */

  const sc331Check = {
    id: CHECK_ID,

    /**
     * evaluate() runs once per node that the rule's selector matches.
     * Must return true (PASS) or false (FAIL).
     */
    /**
     * evaluate() runs once per node that the rule's selector matches.
     * Must return true (PASS) or false (FAIL).
     *
     * IMPORTANT: this.data() is the axe-core method that stores data on the
     * check result object. It must be called as a function — NOT assigned as
     * a property (this.data = {}) — otherwise check.data stays undefined in
     * the axe results and the report's getCheckData() returns null, causing
     * fix guidance to bail out with an empty return.
     */
    evaluate: function (node) {
      const errorBucket = buildErrorBucket();
      const passed      = hasErrorAssociation(node, errorBucket);

      const describedByIds  = getReferencedIds(node, "aria-describedby");
      const errorMessageIds = getReferencedIds(node, "aria-errormessage");

      this.data({
        reason: passed
          ? "Form control has error message association."
          : "Form control lacks error message association.",
        hasAriaDescribedBy:  describedByIds.length > 0,
        hasAriaErrorMessage: errorMessageIds.length > 0,
        ariaDescribedByIds:  describedByIds,
        ariaErrorMessageIds: errorMessageIds
      });

      // PASS if association found, FAIL otherwise
      return passed;
    },

    metadata: {
      impact: "serious",
      messages: {
        pass: "3.3.1 - Error Identification - control has error association - Pass",
        fail: "3.3.1 - Error Identification - control lacks error association - Fail",
      },
    },
  };

  /* ─────────────────────────────────────────────────────────────────────────
   * 6. AXE RULE DEFINITION
   * ───────────────────────────────────────────────────────────────────────── */

  const sc331Rule = {
    id: RULE_ID,

    /** CSS selector — axe will run the check only on matching nodes. */
    selector: FORM_CONTROL_SELECTOR,

    any: [CHECK_ID],
    enabled: true,

    /** Rule metadata */
    impact: "serious",
    tags: ["wcag2aa", "wcag22aa", "wcag331", "custom"],

    metadata: {
      description:
        "Form controls must be linked to an error message element using " +
        "aria-describedby or aria-errormessage.",

      help:
        "Ensure form controls reference an error message via " +
        "aria-describedby or aria-errormessage.",

      helpUrl:
        "https://www.w3.org/WAI/WCAG22/Understanding/error-identification.html",

      messages: {
        pass: "3.3.1 - Error Identification - Pass",
        fail: "3.3.1 - Error Identification - Fail",
      },
    },
  };

  /* ─────────────────────────────────────────────────────────────────────────
   * 7. REGISTER WITH AXE-CORE
   * ───────────────────────────────────────────────────────────────────────── */

  if (typeof axe === "undefined") {
    throw new ReferenceError(
      "[AXE_CUSTOM_RULE] axe-core is not loaded. " +
        "Please include axe-core before this script."
    );
  }

  axe.configure({
    checks: [sc331Check],
    rules:  [sc331Rule],
  });

  /* ─────────────────────────────────────────────────────────────────────────
   * 8. LOAD CONFIRMATION
   * ───────────────────────────────────────────────────────────────────────── */

  console.log(
    `[AXE_CUSTOM_RULE] sc-331-error-identification v${VERSION} loaded`
  );
})();