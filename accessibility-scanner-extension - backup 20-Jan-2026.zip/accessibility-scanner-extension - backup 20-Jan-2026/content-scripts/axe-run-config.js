// PAGE CONTEXT (CSP-safe)
window.__AXE_RUN_CONFIG__ = {
  customOnly: false // 🔁 toggle this
};

console.log(
  "[AXE_RUN_CONFIG] customOnly =",
  window.__AXE_RUN_CONFIG__.customOnly
);
