/**
 * SC 2.1.4 Character Key Shortcuts
 * Automatable subset: Inline key handlers on non-focusable elements that react
 * to single-character keys without modifier keys.
 * Limitations:
 * - Does not detect handlers added via addEventListener or external scripts.
 * - Cannot confirm user ability to disable/remap shortcuts.
 * - Cannot verify shortcuts are only active when a component has focus.
 * Version: 1.0
 * Author: Vijay Gupta  
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-214-character-key-shortcuts";
  const CHECK_ID = "sc-214-inline-character-shortcut";

  const INLINE_HANDLER_SELECTOR = "[onkeydown],[onkeypress],[onkeyup]";

  const FOCUSABLE_SELECTOR = [
    "a[href]",
    "button",
    "input:not([type=\"hidden\"])",
    "select",
    "textarea",
    "summary",
    "[role=\"button\"]",
    "[role=\"link\"]",
    "[role=\"menuitem\"]",
    "[role=\"tab\"]",
    "[role=\"switch\"]",
    "[role=\"checkbox\"]",
    "[role=\"radio\"]",
    "[role=\"option\"]",
    "[role=\"textbox\"]",
    "[contenteditable=\"true\"]",
    "[tabindex]:not([tabindex=\"-1\"])"
  ].join(", ");

  const MODIFIER_REGEX = /\b(ctrlKey|altKey|metaKey|shiftKey)\b/i;
  const KEY_LITERAL_REGEX = /\bkey\s*={1,3}\s*['"][^'"]{1}['"]/i;
  const KEYCODE_REGEX = /\b(keyCode|which)\s*={1,3}\s*(\d{2,3})/gi;

  function isVisible(node) {
    const style = window.getComputedStyle(node);
    if (!style) return false;
    if (style.display === "none") return false;
    if (style.visibility === "hidden") return false;
    if (parseFloat(style.opacity) === 0) return false;
    return true;
  }

  function getInlineHandler(node) {
    const onkeydown = node.getAttribute("onkeydown") || "";
    const onkeypress = node.getAttribute("onkeypress") || "";
    const onkeyup = node.getAttribute("onkeyup") || "";
    return `${onkeydown} ${onkeypress} ${onkeyup}`.trim();
  }

  function hasCharacterKeyCode(handler) {
    let match;
    while ((match = KEYCODE_REGEX.exec(handler))) {
      const code = parseInt(match[2], 10);
      if ((code >= 48 && code <= 57) || (code >= 65 && code <= 90)) {
        return true;
      }
    }
    return false;
  }

  function hasCharacterKeyShortcut(handler) {
    if (!handler) return false;
    if (MODIFIER_REGEX.test(handler)) return false;
    if (KEY_LITERAL_REGEX.test(handler)) return true;
    return hasCharacterKeyCode(handler);
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector: INLINE_HANDLER_SELECTOR,
        impact: "serious",
        tags: ["wcag2aa", "wcag22aa", "wcag214", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Character key shortcuts should not be bound to non-focusable elements",
          help:
            "Ensure single-character shortcuts are disabled, remappable, or only active on focused components",
          helpUrl: "https://www.w3.org/TR/WCAG22/#character-key-shortcuts",
          messages: {
            pass: "2.1.4 - Character Key Shortcuts - Pass",
            fail: "2.1.4 - Character Key Shortcuts - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          if (!node || typeof node.matches !== "function") return true;
          if (!node.matches(INLINE_HANDLER_SELECTOR)) return true;
          if (!isVisible(node)) return true;
          if (node.matches(FOCUSABLE_SELECTOR)) return true;

          const handler = getInlineHandler(node);
          if (!handler) return true;

          return !hasCharacterKeyShortcut(handler);
        },
        metadata: {
          impact: "serious",
          messages: {
            pass:
              "2.1.4 - Character Key Shortcuts - inline handler not a character key shortcut - Pass",
            fail:
              "2.1.4 - Character Key Shortcuts - inline handler uses character key shortcut on non-focusable element - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-214-character-key-shortcuts loaded");
})();
