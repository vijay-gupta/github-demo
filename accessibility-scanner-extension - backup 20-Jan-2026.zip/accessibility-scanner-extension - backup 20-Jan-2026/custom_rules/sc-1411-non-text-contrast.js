/**
 * SC 1.4.11 Non-text Contrast
 * Automatable subset: Visible UI components (native form controls + common ARIA roles)
 * with a discernible solid border or solid background must have >= 3:1 contrast
 * against the computed parent background.
 * Limitations:
 * - Does not evaluate complex graphics, icons, or background images.
 * - Does not detect contrast between component states (hover/active/focus).
 * - Uses computed styles only and cannot infer adjacent colors in complex layouts.
 * Version: 1.0
 * Author: Vijay Gupta  
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-1411-non-text-contrast";
  const CHECK_ID = "sc-1411-non-text-contrast-min-3";
  const MIN_CONTRAST = 3;

  const CONTROL_SELECTOR = [
    "button",
    "input",
    "select",
    "textarea",
    "[role=\"button\"]",
    "[role=\"checkbox\"]",
    "[role=\"radio\"]",
    "[role=\"switch\"]",
    "[role=\"combobox\"]",
    "[role=\"listbox\"]",
    "[role=\"slider\"]",
    "[role=\"spinbutton\"]",
    "[role=\"textbox\"]"
  ].join(", ");

  function parseColor(value) {
    if (!value) return null;
    if (value === "transparent") {
      return { r: 0, g: 0, b: 0, a: 0 };
    }

    const match = value.match(/rgba?\(([^)]+)\)/);
    if (!match) return null;

    const parts = match[1].split(",").map((part) => part.trim());
    if (parts.length < 3) return null;

    const r = parseFloat(parts[0]);
    const g = parseFloat(parts[1]);
    const b = parseFloat(parts[2]);
    const a = parts.length >= 4 ? parseFloat(parts[3]) : 1;

    if (![r, g, b, a].every((n) => Number.isFinite(n))) return null;

    return { r, g, b, a };
  }

  function blendColors(foreground, background) {
    const alpha = foreground.a;
    return {
      r: foreground.r * alpha + background.r * (1 - alpha),
      g: foreground.g * alpha + background.g * (1 - alpha),
      b: foreground.b * alpha + background.b * (1 - alpha),
      a: 1
    };
  }

  function srgbToLinear(channel) {
    const value = channel / 255;
    return value <= 0.03928
      ? value / 12.92
      : Math.pow((value + 0.055) / 1.055, 2.4);
  }

  function relativeLuminance(color) {
    return (
      0.2126 * srgbToLinear(color.r) +
      0.7152 * srgbToLinear(color.g) +
      0.0722 * srgbToLinear(color.b)
    );
  }

  function contrastRatio(colorA, colorB) {
    if (!colorA || !colorB) return null;
    const lumA = relativeLuminance(colorA);
    const lumB = relativeLuminance(colorB);
    const light = Math.max(lumA, lumB);
    const dark = Math.min(lumA, lumB);
    return (light + 0.05) / (dark + 0.05);
  }

  function isVisible(style) {
    if (!style) return false;
    if (style.display === "none") return false;
    if (style.visibility === "hidden") return false;
    if (parseFloat(style.opacity) === 0) return false;
    return true;
  }

  function getEffectiveBackground(element) {
    const layers = [];
    let current = element;

    while (current && current.nodeType === 1) {
      const style = window.getComputedStyle(current);
      const color = parseColor(style.backgroundColor);
      if (color && color.a > 0) {
        layers.push(color);
      }
      current = current.parentElement;
    }

    layers.reverse();

    let result = { r: 255, g: 255, b: 255, a: 1 };
    for (const layer of layers) {
      result = blendColors(layer, result);
    }

    return result;
  }

  function hasBorder(style) {
    const widths = [
      style.borderTopWidth,
      style.borderRightWidth,
      style.borderBottomWidth,
      style.borderLeftWidth
    ];

    return widths.some((value) => parseFloat(value) > 0);
  }

  function getBorderColor(style) {
    if (!hasBorder(style)) return null;
    const color = parseColor(style.borderTopColor);
    if (!color || color.a === 0) return null;
    return color;
  }

  function getBackgroundColor(style) {
    const color = parseColor(style.backgroundColor);
    if (!color || color.a === 0) return null;
    return color;
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector: CONTROL_SELECTOR,
        impact: "serious",
        tags: ["wcag2aa", "wcag22aa", "wcag1411", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "UI components must have at least 3:1 contrast against adjacent colors",
          help:
            "Ensure form controls and common ARIA widgets have 3:1 contrast for their boundary or fill",
          helpUrl: "https://www.w3.org/TR/WCAG22/#non-text-contrast",
          messages: {
            pass: "1.4.11 - Non-text Contrast - Pass",
            fail: "1.4.11 - Non-text Contrast - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          const style = window.getComputedStyle(node);

          if (!isVisible(style)) return true;
          if (node.tagName === "INPUT" && node.type === "hidden") return true;

          const parentBackground = getEffectiveBackground(node.parentElement);

          const borderColor = getBorderColor(style);
          let componentColor = null;

          if (borderColor) {
            componentColor = blendColors(borderColor, parentBackground);
          } else {
            if (style.backgroundImage && style.backgroundImage !== "none") {
              return true;
            }

            const backgroundColor = getBackgroundColor(style);
            if (!backgroundColor) return true;

            componentColor = blendColors(backgroundColor, parentBackground);
          }

          const ratio = contrastRatio(componentColor, parentBackground);
          if (ratio === null) return true;

          return ratio >= MIN_CONTRAST;
        },
        metadata: {
          impact: "serious",
          messages: {
            pass:
              "1.4.11 - Non-text Contrast - component boundary contrast >= 3:1 - Pass",
            fail:
              "1.4.11 - Non-text Contrast - component boundary contrast < 3:1 - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-1411-non-text-contrast loaded");
})();
