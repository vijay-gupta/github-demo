(function () {
  if (window.__AXE_CUSTOM_RULES_REGISTRY__) return;
  window.__AXE_CUSTOM_RULES_REGISTRY__ = true;

  console.log("[AXE_CUSTOM_RULES] registry loaded");

  const ruleFiles = [
    "custom_rules/sc-246-headings-labels.js",
    "custom_rules/sc-321-on-focus.js",
    "custom_rules/sc-322-on-input.js",
    "custom_rules/sc-324-consistent-identification.js",
    "custom_rules/sc-331-error-identification.js",
    "custom_rules/sc-337-redundant-entry.js",
    "custom_rules/sc-338-accessible-authentication-minimum.js",
    "custom_rules/sc-413-status-messages.js",
    "custom_rules/sc-1412-text-spacing.js",
    "custom_rules/sc-1410-reflow.js",
    "custom_rules/sc-1411-non-text-contrast.js",
    "custom_rules/sc-1413-hover-focus-content.js",
    "custom_rules/sc-212-no-keyboard-trap.js",
    "custom_rules/sc-214-character-key-shortcuts.js",
    "custom_rules/sc-2411-focus-not-obscured-minimum.js",
    "custom_rules/sc-251-pointer-gestures.js",
    "custom_rules/sc-252-pointer-cancellation.js",
    "custom_rules/sc-254-motion-actuation.js",
    "custom_rules/sc-257-dragging-movements.js"
  ];

  window.dispatchEvent(
    new CustomEvent("AXE_CUSTOM_RULES_REGISTRY_READY", {
      detail: ruleFiles
    })
  );
})();
